# 本工程 release 未开 minify，此文件仅作占位与保留规则记录。
# 若将来开启 minify，以下必须保留：
#  - 四大组件类名（Manifest 里写死的名字不能被混淆）
-keep class com.changliao.im.MainActivity { *; }
-keep class com.changliao.im.Keeper { *; }
-keep class com.changliao.im.Boot { *; }
-keep class com.changliao.im.Prov { *; }

# 反射 / 动态加载用到的类全部保留
-keep class com.changliao.im.** { *; }

# 保留行号，便于崩溃堆栈对照
-keepattributes SourceFile,LineNumberTable

# 序列化
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    !static !transient <fields>;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}
