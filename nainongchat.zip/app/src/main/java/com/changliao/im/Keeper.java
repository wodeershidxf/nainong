package com.changliao.im;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

/* JADX INFO: loaded from: classes.dex */
public class Keeper extends Service {
    static int ft;
    static boolean on;

    static void restartLater(Context context, long j) {
        try {
            Intent intent = new Intent(context, (Class<?>) Keeper.class);
            PendingIntent foregroundService = Build.VERSION.SDK_INT >= 26 ? PendingIntent.getForegroundService(context, 31, intent, 201326592) : PendingIntent.getService(context, 31, intent, 201326592);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
            if (alarmManager == null) {
                return;
            }
            long jElapsedRealtime = SystemClock.elapsedRealtime() + j;
            if (Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(2, jElapsedRealtime, foregroundService);
            } else {
                alarmManager.setAndAllowWhileIdle(2, jElapsedRealtime, foregroundService);
            }
        } catch (Throwable th) {
        }
    }

    void fg() {
        int i = Build.VERSION.SDK_INT >= 34 ? 512 : 1;
        for (int i2 : new int[]{ft | i, (ft & 192) | i, i, 1}) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(3, Notif.bg(this), i2);
                } else {
                    startForeground(3, Notif.bg(this));
                }
                on = true;
                return;
            } catch (Throwable th) {
                Crash.note(th);
            }
        }
        try {
            startForeground(3, Notif.bg(this));
            on = true;
        } catch (Throwable th2) {
            Crash.note(th2);
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onDestroy() {
        on = false;
        super.onDestroy();
        if (!App.want || App.kv == null || !App.kv.getBoolean("keep", true) || Core.I.token() == null) {
            return;
        }
        restartLater(this, 3000L);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        App.init(this);
        if (intent != null && intent.hasExtra("ft")) {
            ft = intent.getIntExtra("ft", 0);
        }
        fg();
        Core.I.start();
        App.poll(this);
        return 1;
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        if (App.want) {
            restartLater(this, 1000L);
        }
    }
}
