package com.changliao.im;

import android.graphics.Typeface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;

/* JADX INFO: loaded from: classes.dex */
public class TxtScr extends Scr {
    final File f;

    public TxtScr(File file) {
        this.f = file;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        String str;
        LinearLayout linearLayoutPage = page(this.f.getName(), true);
        this.right.addView(Ui.chip(this.a, "用其他应用打开", false, new View.OnClickListener() { // from class: com.changliao.im.TxtScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Upd.open(TxtScr.this.a, TxtScr.this.f, "text/plain");
            }
        }));
        ScrollView scrollView = new ScrollView(this.a);
        TextView textViewText = Ui.text(this.a, "", 14.0f, Ui.TEXT);
        textViewText.setTypeface(Typeface.MONOSPACE);
        textViewText.setTextIsSelectable(true);
        textViewText.setPadding(Ui.dp(14.0f), Ui.dp(12.0f), Ui.dp(14.0f), Ui.dp(30.0f));
        textViewText.setBackgroundColor(-1);
        try {
            byte[] bArr = Img.read(new FileInputStream(this.f));
            String str2 = new String(bArr, "UTF-8");
            if (str2.indexOf(65533) >= 0) {
                try {
                    str = new String(bArr, "GBK");
                } catch (Exception e) {
                    str = str2;
                }
            } else {
                str = str2;
            }
            textViewText.setText(str);
        } catch (Exception e2) {
            textViewText.setText("打不开这个文件：" + e2.getMessage());
        }
        scrollView.addView(textViewText);
        linearLayoutPage.addView(scrollView, Ui.lp(-1, 0, 1.0f));
        return linearLayoutPage;
    }
}
