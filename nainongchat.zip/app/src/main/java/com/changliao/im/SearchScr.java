package com.changliao.im;

import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class SearchScr extends Scr {
    J found;
    J gfound;
    final boolean newFriends;
    EditText q;
    LinearLayout res;

    public SearchScr(boolean z) {
        this.newFriends = z;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page(this.newFriends ? "新朋友" : "加好友/群", true);
        if (!this.newFriends) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
            this.q = Ui.input(this.a, "输入 NK号、昵称或群号", false);
            this.q.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(14.0f), Ui.dp(9.0f));
            this.q.setImeOptions(3);
            this.q.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.changliao.im.SearchScr.1
                @Override // android.widget.TextView.OnEditorActionListener
                public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                    SearchScr.this.go();
                    return true;
                }
            });
            linearLayoutRow.addView(this.q, Ui.lp(0, -2, 1.0f));
            linearLayoutRow.addView(sm("搜索", 1, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SearchScr.this.go();
                }
            }), Ui.lpm(-2, -2, 8, 0, 0, 0));
            linearLayoutPage.addView(linearLayoutRow);
            this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.SearchScr.3
                @Override // java.lang.Runnable
                public void run() {
                    if (SearchScr.this.alive) {
                        SearchScr.this.a.showKb(SearchScr.this.q);
                    }
                }
            }, 350L);
        }
        this.res = scrollPage(linearLayoutPage);
        render();
        return linearLayoutPage;
    }

    void go() {
        String strTrim = this.q.getText().toString().trim();
        if (strTrim.length() == 0) {
            return;
        }
        this.a.hideKb();
        this.C.send(J.of("t", "fr_search", "q", strTrim));
        this.C.send(J.of("t", "c_gsearch", "q", strTrim));
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("fr_found")) {
            this.found = j;
            render();
        } else if (str.equals("c_gfound")) {
            this.gfound = j;
            render();
        } else if (str.equals("friends") && this.newFriends) {
            render();
        }
    }

    void render() {
        TextView textViewSm;
        this.res.removeAllViews();
        if (this.newFriends) {
            renderNew();
            return;
        }
        boolean z = false;
        if (this.found != null && this.found.a("l").size() > 0) {
            sec(this.res, "用户");
            LinearLayout linearLayoutListW = listW(this.res);
            for (final J j : this.found.objs("l")) {
                String strS = j.s("state");
                row(linearLayoutListW, av(j.s("nick"), j.sn("av"), j.b("online")), 50, j.s("nick"), "NK " + j.s("nk") + (j.s("bio").length() > 0 ? " · " + j.s("bio") : ""), (strS.equals("friend") || strS.equals("sent")) ? Ui.text(this.a, strS.equals("friend") ? "已是好友" : "已申请", 14.0f, Ui.SUB) : sm(strS.equals("incoming") ? "同意" : "加好友", 1, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.C.send(J.of("t", "fr_add", "nick", j.s("nk")));
                        j.put("state", "sent");
                        SearchScr.this.render();
                    }
                }), new View.OnClickListener() { // from class: com.changliao.im.SearchScr.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.a.push(new ProfileScr(j.s("nk"), null));
                    }
                });
            }
            z = true;
        }
        if (this.gfound != null && this.gfound.a("l").size() > 0) {
            sec(this.res, "群聊");
            LinearLayout linearLayoutListW2 = listW(this.res);
            for (final J j2 : this.gfound.objs("l")) {
                if (j2.b("in")) {
                    textViewSm = sm("进入", 0, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.6
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SearchScr.this.a.openChat("g:" + j2.s("gid"));
                        }
                    });
                } else if (j2.b("req")) {
                    textViewSm = Ui.text(this.a, "已申请", 14.0f, Ui.SUB);
                } else if (j2.s("join").equals("free") || j2.s("join").equals("approve")) {
                    textViewSm = sm(j2.s("join").equals("free") ? "加入" : "申请", 1, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.7
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            if (j2.s("join").equals("approve")) {
                                SearchScr.this.a.ask("申请加入「" + j2.s("name") + "」", "验证信息（可不填）", "", false, 60, new MainActivity.Str() { // from class: com.changliao.im.SearchScr.7.1
                                    @Override // com.changliao.im.MainActivity.Str
                                    public void ok(String str) {
                                        SearchScr.this.C.send(J.of("t", "c_gjoin", "gid", j2.s("gid"), "text", str));
                                        j2.put("req", true);
                                        SearchScr.this.render();
                                    }
                                });
                                return;
                            }
                            SearchScr.this.C.send(J.of("t", "c_gjoin", "gid", j2.s("gid"), "text", ""));
                            j2.put("req", true);
                            SearchScr.this.render();
                        }
                    });
                } else {
                    textViewSm = Ui.text(this.a, "仅限邀请", 14.0f, Ui.SUB);
                }
                Img.Av av = new Img.Av(this.a);
                av.set(j2.s("name"), j2.sn("av"), true, "g:" + j2.s("gid"));
                row(linearLayoutListW2, av, 50, j2.s("name"), "群号 " + j2.s("gid") + " · " + j2.l("n") + " 人" + (j2.s("intro").length() > 0 ? " · " + j2.s("intro") : ""), textViewSm, null);
            }
            z = true;
        }
        if (z) {
            return;
        }
        this.res.addView(empty((this.found == null && this.gfound == null) ? "输入对方的 NK号 或昵称，或者群号" : "没有找到相关的用户或群"));
    }

    void renderNew() {
        LinearLayout linearLayoutListW = listW(this.res);
        boolean z = false;
        if (this.C.fr.a("incoming").size() > 0) {
            sec(linearLayoutListW, "好友申请");
            for (final J j : this.C.fr.objs("incoming")) {
                LinearLayout linearLayoutRow = Ui.row(this.a);
                linearLayoutRow.addView(sm("同意", 1, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.8
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.C.send(J.of("t", "fr_accept", "nick", j.s("nk")));
                    }
                }));
                linearLayoutRow.addView(sm("拒绝", 0, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.9
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.C.send(J.of("t", "fr_decline", "nick", j.s("nk")));
                    }
                }), Ui.lpm(-2, -2, 6, 0, 0, 0));
                row(linearLayoutListW, av(j.s("nick"), j.sn("av"), j.b("online")), 50, j.s("nick"), "请求加你为好友 · NK " + j.s("nk"), linearLayoutRow, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.10
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.a.push(new ProfileScr(j.s("nk"), null));
                    }
                });
            }
            z = true;
        }
        if (this.C.fr.a("outgoing").size() > 0) {
            sec(linearLayoutListW, "等待对方同意");
            for (final J j2 : this.C.fr.objs("outgoing")) {
                row(linearLayoutListW, av(j2.s("nick"), j2.sn("av"), false), 50, j2.s("nick"), "已发送申请", sm("撤回", 0, new View.OnClickListener() { // from class: com.changliao.im.SearchScr.12
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.withdraw(j2);
                    }
                }), new View.OnClickListener() { // from class: com.changliao.im.SearchScr.11
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SearchScr.this.a.push(new ProfileScr(j2.s("nk"), null));
                    }
                });
            }
            z = true;
        }
        if (z) {
            return;
        }
        linearLayoutListW.addView(empty("没有新的好友申请"));
    }

    void withdraw(final J j) {
        this.a.confirm("撤回好友申请", "撤回后对方就看不到你的申请了", "撤回", false, new Runnable() { // from class: com.changliao.im.SearchScr.13
            @Override // java.lang.Runnable
            public void run() {
                Core core = SearchScr.this.C;
                Object[] objArr = new Object[4];
                objArr[0] = "t";
                objArr[1] = "fr_remove";
                objArr[2] = "nick";
                objArr[3] = j.s("nk").length() > 0 ? j.s("nk") : j.s("nick");
                core.send(J.of(objArr));
                List<Object> listA = SearchScr.this.C.fr.a("outgoing");
                for (int size = listA.size() - 1; size >= 0; size--) {
                    Object obj = listA.get(size);
                    if ((obj instanceof J) && ((J) obj).s("nk").equals(j.s("nk")) && ((J) obj).s("nick").equals(j.s("nick"))) {
                        listA.remove(size);
                    }
                }
                SearchScr.this.a.toast("已撤回好友申请", false);
                SearchScr.this.render();
            }
        });
    }
}
