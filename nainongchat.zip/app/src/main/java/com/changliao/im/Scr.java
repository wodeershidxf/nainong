package com.changliao.im;

import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class Scr implements Core.L {
    public final Core C = Core.I;
    public MainActivity a;
    public boolean alive;
    public LinearLayout right;
    public View root;
    public TextView sub;
    public TextView title;
    public LinearLayout top;
    static Typeface bold = Typeface.DEFAULT_BOLD;
    static final Object OPT = new Object();

    public static class Chk extends View {
        boolean on;
        final Paint p;

        Chk(Context context) {
            super(context);
            this.p = new Paint(1);
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float width = getWidth();
            float fDp = (width / 2.0f) - Ui.dp(1.0f);
            if (!this.on) {
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(Ui.dp(1.5f));
                this.p.setColor(-1718181969);
                canvas.drawCircle(width / 2.0f, width / 2.0f, fDp, this.p);
                return;
            }
            this.p.setStyle(Paint.Style.FILL);
            this.p.setColor(-13793547);
            canvas.drawCircle(width / 2.0f, width / 2.0f, fDp, this.p);
            this.p.setColor(-1);
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(Ui.dp(2.0f));
            this.p.setStrokeCap(Paint.Cap.ROUND);
            Path path = new Path();
            path.moveTo(0.28f * width, 0.52f * width);
            path.lineTo(0.44f * width, 0.67f * width);
            path.lineTo(0.72f * width, width * 0.36f);
            canvas.drawPath(path, this.p);
        }

        void set(boolean z) {
            this.on = z;
            invalidate();
            if (!z) {
                setScaleX(1.0f);
                setScaleY(1.0f);
            } else {
                setScaleX(0.7f);
                setScaleY(0.7f);
                animate().scaleX(1.08f).scaleY(1.08f).setDuration(380L).setInterpolator(new OvershootInterpolator(3.0f)).start();
            }
        }
    }

    public static class Sw extends View {
        float k;
        boolean on;
        final Paint p;

        public interface L {
            void on(boolean z);
        }

        Sw(Context context, boolean z) {
            super(context);
            this.p = new Paint(1);
            this.on = z;
            this.k = z ? 1.0f : 0.0f;
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float width = getWidth();
            float height = getHeight();
            float f = height / 2.0f;
            this.p.setColor(G.mix(-13793547, Math.max(0.0f, Math.min(1.0f, this.k)), -2630686));
            canvas.drawRoundRect(0.0f, 0.0f, width, height, f, f, this.p);
            float fDp = height - Ui.dp(4.0f);
            float fDp2 = Ui.dp(2.0f) + (((width - fDp) - Ui.dp(4.0f)) * this.k);
            this.p.setColor(855638016);
            canvas.drawCircle((fDp / 2.0f) + fDp2, Ui.dp(2.0f) + (fDp / 2.0f) + Ui.dp(1.0f), fDp / 2.0f, this.p);
            this.p.setColor(-1);
            canvas.drawCircle(fDp2 + (fDp / 2.0f), Ui.dp(2.0f) + (fDp / 2.0f), fDp / 2.0f, this.p);
        }

        public void set(boolean z) {
            this.on = z;
            float[] fArr = new float[2];
            fArr[0] = this.k;
            fArr[1] = z ? 1.0f : 0.0f;
            ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
            valueAnimatorOfFloat.setDuration(420L);
            valueAnimatorOfFloat.setInterpolator(new OvershootInterpolator(1.6f));
            valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.changliao.im.Scr.Sw.1
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    Sw.this.k = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    Sw.this.invalidate();
                }
            });
            valueAnimatorOfFloat.start();
        }
    }

    public static void updBan(View view) {
        if (view == null || !(view.getTag() instanceof Runnable)) {
            return;
        }
        ((Runnable) view.getTag()).run();
    }

    void appeal() {
        J j = this.C.ban;
        if (j == null || !j.b("appealed")) {
            this.a.ask("封号申诉", "说明情况，系统会尽快处理", "", true, 500, new MainActivity.Str() { // from class: com.changliao.im.Scr.5
                @Override // com.changliao.im.MainActivity.Str
                public void ok(String str) {
                    if (str.length() < 2) {
                        Scr.this.toast("请写几句说明");
                    } else {
                        Scr.this.C.send(J.of("t", "c_appeal", "text", str));
                    }
                }
            });
        } else {
            toast("已经申诉过了，请等待系统处理");
        }
    }

    public Img.Av av(String str, String str2, boolean z) {
        Img.Av av = new Img.Av(this.a);
        av.set(str, str2, false);
        av.setOnline(z);
        return av;
    }

    public View banBar() {
        final LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(10.0f), Ui.dp(9.0f));
        linearLayoutRow.setBackground(Ui.round(-4884, 12.0f));
        final TextView textViewText = Ui.text(this.a, "", 13.0f, -2544339);
        textViewText.setLineSpacing(0.0f, 1.25f);
        linearLayoutRow.addView(textViewText, Ui.lp(0, -2, 1.0f));
        final TextView textViewSm = sm("申诉", 4, new View.OnClickListener() { // from class: com.changliao.im.Scr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Scr.this.appeal();
            }
        });
        linearLayoutRow.addView(textViewSm, Ui.lpm(-2, -2, 8, 0, 0, 0));
        linearLayoutRow.setTag(new Runnable() { // from class: com.changliao.im.Scr.4
            @Override // java.lang.Runnable
            public void run() {
                J j = Scr.this.C.ban;
                if (!Scr.this.C.banned()) {
                    linearLayoutRow.setVisibility(8);
                    return;
                }
                linearLayoutRow.setVisibility(0);
                textViewText.setText("账号封禁中（" + (j.s("reason").length() > 0 ? j.s("reason") : "违反用户协议") + "）\n" + MiscScr.ReportsScr.left(j.l("until")) + "，期间只能查看消息");
                textViewSm.setText(j.b("appealed") ? "已申诉" : "申诉");
            }
        });
        ((Runnable) linearLayoutRow.getTag()).run();
        return linearLayoutRow;
    }

    public LinearLayout bar(String str, boolean z) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setMinimumHeight(Ui.dp(56.0f));
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(8.0f), Ui.dp(6.0f));
        linearLayoutRow.setBackgroundColor(Ui.BG);
        if (z) {
            LinearLayout linearLayoutRow2 = Ui.row(this.a);
            linearLayoutRow2.setGravity(17);
            G.on(linearLayoutRow2, 0, 15.0f, 2.0f);
            ImageView imageView = new ImageView(this.a);
            imageView.setImageDrawable(new Ico("back", Ui.TEXT));
            linearLayoutRow2.addView(imageView, Ui.lp(Ui.dp(28.0f), Ui.dp(28.0f)));
            linearLayoutRow2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.Scr.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    Scr.this.a.back();
                }
            });
            Ui.bounce(linearLayoutRow2);
            linearLayoutRow.addView(linearLayoutRow2, Ui.lpm(Ui.dp(42.0f), Ui.dp(42.0f), 0, 0, 8, 0));
        }
        LinearLayout linearLayoutCol = Ui.col(this.a);
        this.title = Ui.one(Ui.bold(Ui.text(this.a, str, 18.0f, Ui.TEXT)));
        this.sub = Ui.one(Ui.text(this.a, "", 12.0f, Ui.SUB));
        this.sub.setVisibility(8);
        linearLayoutCol.addView(this.title);
        linearLayoutCol.addView(this.sub);
        linearLayoutRow.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
        this.right = Ui.row(this.a);
        linearLayoutRow.addView(this.right);
        this.top = linearLayoutRow;
        return linearLayoutRow;
    }

    public TextView bigBtn(LinearLayout linearLayout, String str, int i, View.OnClickListener onClickListener) {
        TextView textViewBtn = i == 1 ? Ui.btn(this.a, str, onClickListener) : Ui.btnGray(this.a, str, onClickListener);
        if (i == 4) {
            textViewBtn.setTextColor(Ui.RED);
        }
        linearLayout.addView(textViewBtn, Ui.lpm(-1, -2, 16, 12, 16, 0));
        return textViewBtn;
    }

    public abstract View build();

    public void copy(String str) {
        ((ClipboardManager) this.a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("t", str));
        toast("已复制");
    }

    public LinearLayout csec(LinearLayout linearLayout) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        G g = new G(0, 20.0f);
        g.bg = -197122;
        linearLayoutCol.setBackground(g);
        linearLayoutCol.setElevation(Ui.dp(1.5f));
        ChatScr.clip(linearLayoutCol, 20.0f);
        linearLayout.addView(linearLayoutCol, Ui.lpm(-1, -2, 12, 10, 12, 0));
        return linearLayoutCol;
    }

    public boolean dark() {
        return false;
    }

    View divider() {
        View view = new View(this.a);
        view.setBackgroundColor(-986637);
        LinearLayout.LayoutParams layoutParamsLp = Ui.lp(-1, Math.max(1, Ui.dp(0.7f)));
        layoutParamsLp.leftMargin = Ui.dp(16.0f);
        view.setLayoutParams(layoutParamsLp);
        return view;
    }

    public TextView empty(String str) {
        TextView textViewText = Ui.text(this.a, str, 14.0f, Ui.SUB);
        textViewText.setGravity(17);
        textViewText.setLineSpacing(0.0f, 1.3f);
        textViewText.setPadding(Ui.dp(20.0f), Ui.dp(40.0f), Ui.dp(20.0f), Ui.dp(40.0f));
        return textViewText;
    }

    public void err(String str) {
        this.a.toast(str, true);
    }

    public FrameLayout.LayoutParams fill() {
        return new FrameLayout.LayoutParams(-1, -1);
    }

    public boolean full() {
        return false;
    }

    public ImageView ib(String str, View.OnClickListener onClickListener) {
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, Ui.TEXT));
        int iDp = Ui.dp(8.0f);
        imageView.setPadding(iDp, iDp, iDp, iDp);
        G.on(imageView, 0, 15.0f, 2.0f);
        imageView.setOnClickListener(onClickListener);
        Ui.bounce(imageView);
        this.right.addView(imageView, Ui.lpm(Ui.dp(42.0f), Ui.dp(42.0f), 6, 0, 0, 0));
        return imageView;
    }

    public LinearLayout item(View view, String str, String str2, View.OnClickListener onClickListener) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(16.0f), Ui.dp(13.0f), Ui.dp(14.0f), Ui.dp(13.0f));
        linearLayoutRow.setBackground(Ui.press(-1, 0.0f));
        if (view != null) {
            LinearLayout.LayoutParams layoutParamsLp = Ui.lp(Ui.dp(26.0f), Ui.dp(26.0f));
            layoutParamsLp.rightMargin = Ui.dp(14.0f);
            linearLayoutRow.addView(view, layoutParamsLp);
        }
        linearLayoutRow.addView(Ui.one(Ui.text(this.a, str, 16.0f, Ui.TEXT)), Ui.lp(0, -2, 1.0f));
        if (str2 != null) {
            linearLayoutRow.addView(Ui.text(this.a, str2, 14.0f, Ui.SUB));
        }
        TextView textViewText = Ui.text(this.a, "›", 22.0f, -4143924);
        textViewText.setPadding(Ui.dp(8.0f), 0, 0, Ui.dp(2.0f));
        linearLayoutRow.addView(textViewText);
        linearLayoutRow.setOnClickListener(onClickListener);
        return linearLayoutRow;
    }

    public LinearLayout listW(LinearLayout linearLayout) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayout.addView(linearLayoutCol);
        return linearLayoutCol;
    }

    @Override // com.changliao.im.Core.L
    public void on(String str, J j) {
    }

    public boolean onBack() {
        return false;
    }

    public void onClose() {
    }

    public void onHide() {
    }

    public void onShow() {
    }

    public LinearLayout opt(LinearLayout linearLayout, String str, CharSequence charSequence, boolean z, View.OnClickListener onClickListener) {
        if (linearLayout.getChildCount() > 0 && linearLayout.getChildAt(linearLayout.getChildCount() - 1).getTag() == OPT) {
            linearLayout.addView(divider());
        }
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setTag(OPT);
        linearLayoutRow.setMinimumHeight(Ui.dp(52.0f));
        linearLayoutRow.setPadding(Ui.dp(16.0f), Ui.dp(13.0f), Ui.dp(16.0f), Ui.dp(13.0f));
        linearLayoutRow.setBackground(Ui.ripple(new ColorDrawable(0), 0.0f));
        linearLayoutRow.addView(Ui.text(this.a, str, 16.0f, Ui.TEXT));
        TextView textViewOne = Ui.one(Ui.text(this.a, charSequence == null ? "" : "", 14.0f, Ui.SUB));
        if (charSequence != null) {
            textViewOne.setText(charSequence);
        }
        textViewOne.setGravity(8388613);
        linearLayoutRow.addView(textViewOne, Ui.lpm(0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) textViewOne.getLayoutParams()).weight = 1.0f;
        if (z) {
            linearLayoutRow.addView(Ui.text(this.a, "›", 20.0f, -4143924), Ui.lpm(-2, -2, 8, 0, 0, 0));
        }
        if (onClickListener != null) {
            linearLayoutRow.setOnClickListener(onClickListener);
        }
        linearLayout.addView(linearLayoutRow);
        return linearLayoutRow;
    }

    public Sw optSw(LinearLayout linearLayout, String str, String str2, boolean z, final Sw.L l) {
        LinearLayout linearLayoutOpt = opt(linearLayout, str, str2, false, null);
        final Sw sw = new Sw(this.a, z);
        linearLayoutOpt.addView(sw, Ui.lpm(Ui.dp(46.0f), Ui.dp(28.0f), 10, 0, 0, 0));
        linearLayoutOpt.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.Scr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                sw.set(!sw.on);
                l.on(sw.on);
            }
        });
        return sw;
    }

    public LinearLayout page(String str, boolean z) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setBackgroundColor(Ui.BG);
        linearLayoutCol.addView(bar(str, z));
        G.keepClip(linearLayoutCol);
        return linearLayoutCol;
    }

    public LinearLayout row(LinearLayout linearLayout, View view, int i, CharSequence charSequence, CharSequence charSequence2, View view2, View.OnClickListener onClickListener) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setMinimumHeight(Ui.dp(i >= 50 ? 72.0f : 60.0f));
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
        linearLayoutRow.setBackground(new RippleDrawable(ColorStateList.valueOf(303462384), new HomeScr.Row(-1), null));
        if (view != null) {
            linearLayoutRow.addView(view, Ui.lpm(Ui.dp(i), Ui.dp(i), 0, 0, 12, 0));
        }
        LinearLayout linearLayoutCol = Ui.col(this.a);
        TextView textViewOne = Ui.one(Ui.text(this.a, "", 16.0f, Ui.TEXT));
        textViewOne.setText(charSequence);
        linearLayoutCol.addView(textViewOne);
        if (charSequence2 != null && charSequence2.length() > 0) {
            TextView textViewOne2 = Ui.one(Ui.text(this.a, "", 14.0f, Ui.SUB));
            textViewOne2.setText(charSequence2);
            linearLayoutCol.addView(textViewOne2, Ui.lpm(-1, -2, 0, 2, 0, 0));
        }
        linearLayoutRow.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
        if (view2 != null) {
            linearLayoutRow.addView(view2, Ui.lpm(-2, -2, 8, 0, 0, 0));
        }
        if (onClickListener != null) {
            linearLayoutRow.setOnClickListener(onClickListener);
        }
        linearLayout.addView(linearLayoutRow);
        return linearLayoutRow;
    }

    public LinearLayout scrollPage(LinearLayout linearLayout) {
        ScrollView scrollView = new ScrollView(this.a);
        scrollView.setFillViewport(true);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setPadding(0, 0, 0, Ui.dp(24.0f));
        scrollView.addView(linearLayoutCol);
        linearLayout.addView(scrollView, Ui.lp(-1, 0, 1.0f));
        G.keepClip(scrollView);
        G.keepClip(linearLayoutCol);
        return linearLayoutCol;
    }

    public EditText searchBox(LinearLayout linearLayout, String str) {
        EditText editTextInput = Ui.input(this.a, str, false);
        editTextInput.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(14.0f), Ui.dp(9.0f));
        linearLayout.addView(editTextInput, Ui.lpm(-1, -2, 14, 10, 14, 10));
        return editTextInput;
    }

    public TextView sec(LinearLayout linearLayout, String str) {
        TextView textViewText = Ui.text(this.a, str, 13.0f, Ui.SUB);
        textViewText.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(6.0f));
        linearLayout.addView(textViewText);
        return textViewText;
    }

    public void sec2(LinearLayout linearLayout, String str) {
        TextView textViewText = Ui.text(this.a, str, 13.0f, Ui.SUB);
        textViewText.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(16.0f), Ui.dp(2.0f));
        linearLayout.addView(textViewText);
    }

    public TextView sm(String str, int i, View.OnClickListener onClickListener) {
        TextView textViewText = Ui.text(this.a, str, 14.0f, i == 0 ? Ui.TEXT : -1);
        if (i != 0) {
            textViewText.setTypeface(bold);
        }
        textViewText.setGravity(17);
        textViewText.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(14.0f), Ui.dp(6.0f));
        G.on(textViewText, i, 16.0f, i == 0 ? 1.5f : 3.0f);
        textViewText.setOnClickListener(onClickListener);
        Ui.bounce(textViewText);
        return textViewText;
    }

    public TextView tb(String str, View.OnClickListener onClickListener) {
        TextView textViewBold = Ui.bold(Ui.text(this.a, str, 15.0f, Ui.BLUE));
        textViewBold.setGravity(17);
        textViewBold.setPadding(Ui.dp(14.0f), 0, Ui.dp(14.0f), 0);
        G.on(textViewBold, 0, 18.0f, 2.0f);
        textViewBold.setOnClickListener(onClickListener);
        Ui.bounce(textViewBold);
        this.right.addView(textViewBold, Ui.lpm(-2, Ui.dp(36.0f), 0, 0, 6, 0));
        return textViewBold;
    }

    public void toast(String str) {
        this.a.toast(str, false);
    }
}
