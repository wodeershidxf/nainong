package com.changliao.im;

import android.view.View;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class Ann {
    static final Set<String> seen = new HashSet();
    static View showing;

    public static void check(MainActivity mainActivity) {
        try {
            check0(mainActivity);
        } catch (Throwable th) {
            Crash.note(th);
            showing = null;
        }
    }

    static void check0(final MainActivity mainActivity) {
        J j;
        if (mainActivity == null || mainActivity.isFinishing() || mainActivity.overlay == null || live(showing, mainActivity) || live(Upd.shown, mainActivity)) {
            return;
        }
        showing = null;
        Iterator<J> it = Core.I.anns.iterator();
        while (true) {
            if (!it.hasNext()) {
                j = null;
                break;
            }
            J next = it.next();
            if (!done(next)) {
                j = next;
                break;
            }
        }
        if (j != null) {
            final String strKey = key(j);
            Runnable runnable = new Runnable() { // from class: com.changliao.im.Ann.2
                @Override // java.lang.Runnable
                public void run() {
                    Ann.seen.add(strKey);
                    Ann.showing = null;
                    Ann.check(mainActivity);
                }
            };
            showing = mainActivity.confirm("📢 " + (j.s("title").length() > 0 ? j.s("title") : "系统公告"), j.s("text"), "确认", "不再提示", false, runnable, new Runnable() { // from class: com.changliao.im.Ann.3
                @Override // java.lang.Runnable
                public void run() {
                    Ann.seen.add(strKey);
                    String string = App.kv.getString("annNo", "");
                    if (string.length() > 6000) {
                        string = string.substring(string.length() - 6000);
                    }
                    App.kv.edit().putString("annNo", string + strKey + "\n").apply();
                    Ann.showing = null;
                    Ann.check(mainActivity);
                }
            }, runnable);
        }
    }

    public static boolean done(J j) {
        String strKey = key(j);
        return seen.contains(strKey) || never(strKey);
    }

    public static void fetch(final MainActivity mainActivity) {
        new Thread(new Runnable() { // from class: com.changliao.im.Ann.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.http() + "/app/anns.json?t=" + System.currentTimeMillis()).openConnection();
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(10000);
                    final J jObj = J.obj(new String(Img.read(httpURLConnection.getInputStream()), "UTF-8"));
                    httpURLConnection.disconnect();
                    if (jObj == null) {
                        return;
                    }
                    mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Ann.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (!Core.I.authed || Core.I.anns.isEmpty()) {
                                Core.I.anns = jObj.objs("l");
                            }
                            Ann.check(mainActivity);
                        }
                    });
                } catch (Throwable th) {
                }
            }
        }).start();
    }

    static String key(J j) {
        return j.l("id") + ":" + j.l("v");
    }

    static boolean live(View view, MainActivity mainActivity) {
        return (view == null || view.getParent() == null || view.getContext() != mainActivity) ? false : true;
    }

    static boolean never(String str) {
        for (String str2 : App.kv.getString("annNo", "").split("\n")) {
            if (str2.equals(str)) {
                return true;
            }
        }
        return false;
    }
}
