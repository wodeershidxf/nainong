package com.changliao.im;

/* JADX INFO: loaded from: classes.dex */
final class BuildInfo {
    static final int CODE = 56;
    static final String NAME = "4.6";

    BuildInfo() {
    }
}
