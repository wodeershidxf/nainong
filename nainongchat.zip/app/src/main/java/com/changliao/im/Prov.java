package com.changliao.im;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URLConnection;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Prov extends ContentProvider {
    static String mime(String str) {
        String lowerCase = str == null ? "" : str.toLowerCase();
        int iLastIndexOf = lowerCase.lastIndexOf(46);
        String strSubstring = iLastIndexOf >= 0 ? lowerCase.substring(iLastIndexOf + 1) : "";
        String mimeTypeFromExtension = strSubstring.length() > 0 ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(strSubstring) : null;
        String strGuessContentTypeFromName = mimeTypeFromExtension == null ? URLConnection.guessContentTypeFromName(lowerCase) : mimeTypeFromExtension;
        if (strGuessContentTypeFromName != null) {
            return strGuessContentTypeFromName;
        }
        if (strSubstring.equals("apk")) {
            return "application/vnd.android.package-archive";
        }
        if (strSubstring.matches("docx?")) {
            return "application/msword";
        }
        if (strSubstring.matches("xlsx?")) {
            return "application/vnd.ms-excel";
        }
        if (strSubstring.matches("pptx?")) {
            return "application/vnd.ms-powerpoint";
        }
        if (strSubstring.equals("7z")) {
            return "application/x-7z-compressed";
        }
        return strSubstring.equals("rar") ? "application/vnd.rar" : strGuessContentTypeFromName;
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        return 0;
    }

    File fileOf(Uri uri) {
        List<String> pathSegments = uri.getPathSegments();
        File externalFilesDir = getContext().getExternalFilesDir(pathSegments.size() >= 2 && pathSegments.get(0).equals("dl") ? "Download" : "Camera");
        if (externalFilesDir != null) {
            externalFilesDir.mkdirs();
        }
        return new File(externalFilesDir, new File(uri.getLastPathSegment()).getName());
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        return mime(uri.getLastPathSegment());
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    @Override // android.content.ContentProvider
    public ParcelFileDescriptor openFile(Uri uri, String str) throws FileNotFoundException {
        File fileFileOf = fileOf(uri);
        if (str == null) {
            str = "r";
        }
        return ParcelFileDescriptor.open(fileFileOf, ParcelFileDescriptor.parseMode(str));
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        File fileFileOf = fileOf(uri);
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{"_display_name", "_size"});
        matrixCursor.addRow(new Object[]{fileFileOf.getName(), Long.valueOf(fileFileOf.length())});
        return matrixCursor;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        return 0;
    }
}
