package com.changliao.im;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputFilter;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends Activity implements Core.L {
    static final float DIM = 0.4509804f;
    public static final int VERSION = 56;
    public static final String VNAME = "4.6";
    static MainActivity cur;
    ValueAnimator dimA;
    float dimF;
    int dimN;
    public Pane host;
    Class<?> lastCls;
    long lastPush;
    long lastUpd;
    boolean openCall;
    FrameLayout overlay;
    FloatCall pill;
    boolean resumed;
    FrameLayout root;
    TextView toastV;
    final ArrayList<Scr> stack = new ArrayList<>();
    final Handler h = new Handler(Looper.getMainLooper());
    final Core C = Core.I;
    final Runnable pillTick = new Runnable() { // from class: com.changliao.im.MainActivity.7
        @Override // java.lang.Runnable
        public void run() {
            if (MainActivity.this.pill == null) {
                return;
            }
            if (Call.cur == null || Call.cur.state == 4) {
                MainActivity.this.callPill();
            } else {
                MainActivity.this.pill.upd();
                MainActivity.this.h.postDelayed(this, 1000L);
            }
        }
    };
    int sbBase = -15066596;
    int nbBase = -15066596;
    final Set<View> dimmed = Collections.newSetFromMap(new WeakHashMap());
    final Runnable hideToast = new Runnable() { // from class: com.changliao.im.MainActivity.12
        @Override // java.lang.Runnable
        public void run() {
            if (MainActivity.this.toastV != null) {
                final TextView textView = MainActivity.this.toastV;
                MainActivity.this.toastV = null;
                textView.animate().alpha(0.0f).translationY(-Ui.dp(20.0f)).setDuration(200L).withEndAction(new Runnable() { // from class: com.changliao.im.MainActivity.12.1
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity.this.overlay.removeView(textView);
                    }
                }).start();
            }
        }
    };
    final HashMap<Integer, Res> res = new HashMap<>();
    int reqN = 100;

    class Pane extends FrameLayout {
        final Paint lp;
        final View ph;

        Pane() {
            super(MainActivity.this);
            this.lp = new Paint();
            setWillNotDraw(false);
            this.lp.setColor(Ui.LINE);
            LinearLayout linearLayoutCol = Ui.col(MainActivity.this);
            linearLayoutCol.setGravity(17);
            ImageView imageView = new ImageView(MainActivity.this);
            imageView.setImageBitmap(Img.appic);
            ColorMatrix colorMatrix = new ColorMatrix();
            colorMatrix.setSaturation(0.0f);
            imageView.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
            imageView.setAlpha(0.25f);
            linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(90.0f), Ui.dp(90.0f)));
            linearLayoutCol.addView(Ui.text(MainActivity.this, "选择一个会话，开始聊天", 14.0f, -4998718), Ui.lpm(-2, -2, 0, 12, 0, 0));
            this.ph = linearLayoutCol;
            addView(this.ph);
        }

        int[] box(View view, int i, int i2) {
            boolean z = ((float) i) / Ui.D >= 720.0f;
            int i3 = (int) (i * 0.36f);
            if (view == this.ph) {
                return z ? new int[]{i3, i} : new int[]{0, 0};
            }
            if (!z || !(view instanceof Swipe)) {
                return new int[]{0, i};
            }
            Scr scr = ((Swipe) view).s;
            if (scr instanceof HomeScr) {
                return new int[]{0, i3};
            }
            return scr.full() ? new int[]{0, i} : new int[]{i3, i};
        }

        @Override // android.view.ViewGroup, android.view.View
        protected void dispatchDraw(Canvas canvas) {
            super.dispatchDraw(canvas);
            if (getWidth() / Ui.D >= 720.0f) {
                if (MainActivity.this.topScr() == null || !MainActivity.this.topScr().full()) {
                    float width = (int) (getWidth() * 0.36f);
                    canvas.drawRect(width - 1.0f, 0.0f, width, getHeight(), this.lp);
                }
            }
        }

        @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
        protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
            int i5 = i3 - i;
            int i6 = i4 - i2;
            for (int i7 = 0; i7 < getChildCount(); i7++) {
                View childAt = getChildAt(i7);
                int[] iArrBox = box(childAt, i5, i6);
                childAt.layout(iArrBox[0], 0, iArrBox[1], i6);
            }
        }

        @Override // android.widget.FrameLayout, android.view.View
        protected void onMeasure(int i, int i2) {
            int size = View.MeasureSpec.getSize(i);
            int size2 = View.MeasureSpec.getSize(i2);
            setMeasuredDimension(size, size2);
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                int[] iArrBox = box(childAt, size, size2);
                childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, iArrBox[1] - iArrBox[0]), 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
            }
        }
    }

    public interface Res {
        void got(int i, Intent intent);
    }

    public interface Str {
        void ok(String str);
    }

    static class Swipe extends FrameLayout {
        final MainActivity a;
        float dx;
        boolean on;
        final Scr s;
        float sx;
        long t0;

        Swipe(MainActivity mainActivity, Scr scr) {
            super(mainActivity);
            this.a = mainActivity;
            this.s = scr;
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (this.a.stack.size() < 2 || this.a.topScr() != this.s || this.a.paneOf(this.s)) {
                return false;
            }
            if (motionEvent.getActionMasked() == 0 && motionEvent.getX() < Ui.dp(24.0f)) {
                this.sx = motionEvent.getRawX();
                this.t0 = System.currentTimeMillis();
                this.on = true;
                return false;
            }
            if (this.on && motionEvent.getActionMasked() == 2 && motionEvent.getRawX() - this.sx > Ui.dp(10.0f)) {
                return true;
            }
            if (motionEvent.getActionMasked() != 1 && motionEvent.getActionMasked() != 3) {
                return false;
            }
            this.on = false;
            return false;
        }

        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent motionEvent) {
            if (!this.on) {
                return super.onTouchEvent(motionEvent);
            }
            View view = this.a.stack.size() >= 2 ? (View) this.a.stack.get(this.a.stack.size() - 2).root.getParent() : null;
            float width = getWidth();
            switch (motionEvent.getActionMasked()) {
                case G.BLUE /* 1 */:
                case G.INSET /* 3 */:
                    this.on = false;
                    boolean z = this.dx > ((float) Ui.dp(60.0f)) && System.currentTimeMillis() - this.t0 < 250;
                    if (this.dx > 0.33f * width || z) {
                        this.a.back();
                        return true;
                    }
                    animate().translationX(0.0f).setDuration(200L).start();
                    if (view == null) {
                        return true;
                    }
                    view.animate().translationX((-width) * 0.28f).setDuration(200L).start();
                    return true;
                case G.DARK /* 2 */:
                    this.dx = Math.max(0.0f, motionEvent.getRawX() - this.sx);
                    setTranslationX(this.dx);
                    if (view == null) {
                        return true;
                    }
                    if (this.a.wide() && view == this.a.stack.get(0).root.getParent()) {
                        return true;
                    }
                    view.setTranslationX((-width) * 0.28f * (1.0f - (this.dx / width)));
                    return true;
                default:
                    return true;
            }
        }
    }

    public void answer() {
        Notif.cancel(this, 7);
        Call call = Call.cur;
        if (call != null && (call.state == 1 || this.openCall)) {
            call.show();
        }
        this.openCall = false;
        callPill();
    }

    void applyBars() {
        // PATCH(需求1): 状态栏/导航栏底色锁死深色 -15066596 (0xFF1A1A1C)，去掉浅色回退分支
        Window window = getWindow();
        window.setStatusBarColor(barC(this.sbBase, -15066596));
        window.setNavigationBarColor(barC(this.nbBase, -15066596));
    }

    public void ask(String str, String str2, String str3, boolean z, int i, final Str str4) {
        LinearLayout linearLayoutDlgCard = dlgCard(str, null);
        final EditText editTextInput = Ui.input(this, str2, false);
        if (z) {
            editTextInput.setSingleLine(false);
            editTextInput.setMinLines(3);
            editTextInput.setMaxLines(8);
            editTextInput.setGravity(48);
            editTextInput.setInputType(131073);
        }
        if (i > 0) {
            editTextInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(i)});
        }
        if (str3 != null) {
            editTextInput.setText(str3);
            editTextInput.setSelection(str3.length());
        }
        linearLayoutDlgCard.addView(editTextInput, Ui.lpm(-1, -2, 0, 14, 0, 0));
        final FrameLayout[] frameLayoutArr = new FrameLayout[1];
        LinearLayout linearLayoutRow = Ui.row(this);
        linearLayoutRow.setPadding(0, Ui.dp(18.0f), 0, 0);
        TextView textViewBtnGray = Ui.btnGray(this, "取消", new View.OnClickListener() { // from class: com.changliao.im.MainActivity.20
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.dismiss(frameLayoutArr[0]);
            }
        });
        LinearLayout.LayoutParams layoutParamsLp = Ui.lp(0, -2, 1.0f);
        layoutParamsLp.rightMargin = Ui.dp(10.0f);
        linearLayoutRow.addView(textViewBtnGray, layoutParamsLp);
        linearLayoutRow.addView(Ui.btn(this, "确定", new View.OnClickListener() { // from class: com.changliao.im.MainActivity.21
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                String strTrim = editTextInput.getText().toString().trim();
                MainActivity.this.dismiss(frameLayoutArr[0]);
                str4.ok(strTrim);
            }
        }), Ui.lp(0, -2, 1.0f));
        linearLayoutDlgCard.addView(linearLayoutRow);
        frameLayoutArr[0] = mask(linearLayoutDlgCard, true, null);
        this.h.postDelayed(new Runnable() { // from class: com.changliao.im.MainActivity.22
            @Override // java.lang.Runnable
            public void run() {
                MainActivity.this.showKb(editTextInput);
            }
        }, 250L);
    }

    void askOverlay() {
        if (FloatCall.canOverlay(this) || App.kv.getBoolean("askOverlay", false)) {
            return;
        }
        App.kv.edit().putBoolean("askOverlay", true).apply();
        confirm("开启通话悬浮窗", "回到桌面或打开别的 App 时，通话小窗也能一直显示，需要允许本 App「显示在其他应用的上层」。", "去开启", false, new Runnable() { // from class: com.changliao.im.MainActivity.10
            @Override // java.lang.Runnable
            public void run() {
                try {
                    MainActivity.this.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + MainActivity.this.getPackageName())));
                } catch (Throwable th) {
                    MainActivity.this.toast("请在系统设置里找到本 App，打开「悬浮窗」权限", false);
                }
            }
        });
    }

    void askPerms() {
        if (App.kv.getBoolean("askedPerms", false)) {
            return;
        }
        App.kv.edit().putBoolean("askedPerms", true).apply();
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 33) {
            arrayList.add("android.permission.POST_NOTIFICATIONS");
            arrayList.add("android.permission.READ_MEDIA_IMAGES");
            arrayList.add("android.permission.READ_MEDIA_VIDEO");
        } else {
            arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        arrayList.add("android.permission.RECORD_AUDIO");
        arrayList.add("android.permission.CAMERA");
        try {
            requestPermissions((String[]) arrayList.toArray(new String[0]), 1);
        } catch (Exception e) {
            Crash.note(e);
        }
    }

    public void back() {
        if (this.stack.size() <= 1) {
            moveTaskToBack(true);
        } else {
            close(this.stack.remove(this.stack.size() - 1), true);
        }
    }

    void banner(String str, String str2, final String str3) {
        Scr scr = topScr();
        if ((scr instanceof ChatScr) && str3.equals(((ChatScr) scr).conv)) {
            return;
        }
        toast(str + "：" + str2, false);
        TextView textView = this.toastV;
        if (textView != null) {
            textView.setClickable(true);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.MainActivity.13
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MainActivity.this.h.post(MainActivity.this.hideToast);
                    MainActivity.this.openChat(str3);
                }
            });
        }
    }

    int barC(int i, int i2) {
        if (this.dimF <= 0.001f) {
            return i;
        }
        return (Night.active && i == -15066596) ? Night.inv(G.mix(-15591906, this.dimF, i2)) : G.mix(-15591906, this.dimF, i);
    }

    void bgGuide() {
        if (App.kv.getBoolean("askedBg2", false)) {
            return;
        }
        App.kv.edit().putBoolean("askedBg2", true).apply();
        this.h.postDelayed(new Runnable() { // from class: com.changliao.im.MainActivity.6
            @Override // java.lang.Runnable
            public void run() {
                if (MainActivity.this.hasModal()) {
                    App.kv.edit().putBoolean("askedBg2", false).apply();
                } else {
                    MainActivity.this.confirm("划掉后台也能接电话", "很多手机从「最近任务」划掉 App 时会把它整个关掉，就收不到消息和来电了。\n花 1 分钟按向导设置一下（允许自启动、省电无限制、在最近任务里锁住 App）就好。", "去设置", "以后再说", false, new Runnable() { // from class: com.changliao.im.MainActivity.6.1
                        @Override // java.lang.Runnable
                        public void run() {
                            MainActivity.this.push(new BgScr());
                        }
                    }, null);
                }
            }
        }, 3000L);
    }

    public void callPill() {
        Call call = Call.cur;
        if (!((call == null || call.state == 4 || (topScr() instanceof CallScr)) ? false : true)) {
            if (this.pill != null) {
                final FloatCall floatCall = this.pill;
                this.pill = null;
                floatCall.animate().scaleX(0.6f).scaleY(0.6f).alpha(0.0f).setDuration(160L).withEndAction(new Runnable() { // from class: com.changliao.im.MainActivity.8
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity.this.overlay.removeView(floatCall);
                    }
                }).start();
                return;
            }
            return;
        }
        if (this.pill != null) {
            this.pill.upd();
            return;
        }
        final FloatCall floatCall2 = new FloatCall(this, false);
        this.pill = floatCall2;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 8388659);
        floatCall2.setTranslationX(App.kv.getInt("pillX", (this.overlay.getWidth() > 0 ? this.overlay.getWidth() : getResources().getDisplayMetrics().widthPixels) - Ui.dp(124.0f)));
        floatCall2.setTranslationY(App.kv.getInt("pillY", Ui.dp(90.0f)));
        floatCall2.l = new FloatCall.Listener() { // from class: com.changliao.im.MainActivity.9
            @Override // com.changliao.im.FloatCall.Listener
            public void moved(float f, float f2) {
                floatCall2.setTranslationX(floatCall2.getTranslationX() + f);
                floatCall2.setTranslationY(Math.max(0.0f, Math.min(MainActivity.this.overlay.getHeight() - floatCall2.getHeight(), floatCall2.getTranslationY() + f2)));
            }

            @Override // com.changliao.im.FloatCall.Listener
            public void tap() {
                Call call2 = Call.cur;
                if (call2 != null) {
                    call2.show();
                }
                MainActivity.this.callPill();
            }

            @Override // com.changliao.im.FloatCall.Listener
            public void up() {
                int width = MainActivity.this.overlay.getWidth();
                float fDp = floatCall2.getTranslationX() + (((float) floatCall2.getWidth()) / 2.0f) < ((float) width) / 2.0f ? Ui.dp(8.0f) : (width - floatCall2.getWidth()) - Ui.dp(8.0f);
                floatCall2.animate().translationX(fDp).setDuration(260L).setInterpolator(new DecelerateInterpolator(2.0f)).start();
                App.kv.edit().putInt("pillX", (int) fDp).putInt("pillY", (int) floatCall2.getTranslationY()).apply();
            }
        };
        this.overlay.addView(floatCall2, layoutParams);
        floatCall2.setScaleX(0.6f);
        floatCall2.setScaleY(0.6f);
        floatCall2.setAlpha(0.0f);
        floatCall2.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(240L).setInterpolator(new OvershootInterpolator(1.4f)).start();
        this.h.postDelayed(this.pillTick, 1000L);
        askOverlay();
    }

    void close(Scr scr, boolean z) {
        scr.alive = false;
        this.C.remove(scr);
        try {
            scr.onClose();
        } catch (Throwable th) {
            Crash.note(th);
        }
        final View view = (View) scr.root.getParent();
        Scr scr2 = topScr();
        hideKb();
        if (scr2 != null) {
            ((View) scr2.root.getParent()).animate().translationX(0.0f).setDuration(z ? 280L : 0L).setInterpolator(new DecelerateInterpolator(2.0f)).withLayer().start();
            scr2.onShow();
        }
        if (!z) {
            this.host.removeView(view);
        } else if (paneOf(scr)) {
            view.animate().alpha(0.0f).translationX(Ui.dp(24.0f)).setDuration(200L).withEndAction(new Runnable() { // from class: com.changliao.im.MainActivity.3
                @Override // java.lang.Runnable
                public void run() {
                    MainActivity.this.host.removeView(view);
                }
            }).start();
        } else {
            view.animate().translationX(this.host.getWidth()).setDuration(260L).setInterpolator(new DecelerateInterpolator(1.6f)).withLayer().withEndAction(new Runnable() { // from class: com.changliao.im.MainActivity.4
                @Override // java.lang.Runnable
                public void run() {
                    MainActivity.this.host.removeView(view);
                }
            }).start();
        }
    }

    public FrameLayout confirm(String str, String str2, String str3, String str4, boolean z, final Runnable runnable, final Runnable runnable2, Runnable runnable3) {
        LinearLayout linearLayoutDlgCard = dlgCard(str, str2);
        LinearLayout linearLayoutRow = Ui.row(this);
        linearLayoutRow.setPadding(0, Ui.dp(16.0f), 0, 0);
        final FrameLayout[] frameLayoutArr = new FrameLayout[1];
        if (str4 != null) {
            TextView textViewBtnGray = Ui.btnGray(this, str4, new View.OnClickListener() { // from class: com.changliao.im.MainActivity.18
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MainActivity.this.dismiss(frameLayoutArr[0]);
                    if (runnable2 != null) {
                        runnable2.run();
                    }
                }
            });
            LinearLayout.LayoutParams layoutParamsLp = Ui.lp(0, -2, 1.0f);
            layoutParamsLp.rightMargin = Ui.dp(10.0f);
            linearLayoutRow.addView(textViewBtnGray, layoutParamsLp);
        }
        TextView textViewBtn = Ui.btn(this, str3, new View.OnClickListener() { // from class: com.changliao.im.MainActivity.19
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.dismiss(frameLayoutArr[0]);
                if (runnable != null) {
                    runnable.run();
                }
            }
        });
        if (z) {
            G.on(textViewBtn, 4, 14.0f, 5.0f);
        }
        linearLayoutRow.addView(textViewBtn, Ui.lp(0, -2, 1.0f));
        linearLayoutDlgCard.addView(linearLayoutRow);
        frameLayoutArr[0] = mask(linearLayoutDlgCard, true, runnable3);
        return frameLayoutArr[0];
    }

    public void confirm(String str, String str2, String str3, String str4, boolean z, Runnable runnable, Runnable runnable2) {
        confirm(str, str2, str3, str4, z, runnable, runnable2, runnable2);
    }

    public void confirm(String str, String str2, String str3, boolean z, Runnable runnable) {
        confirm(str, str2, str3, "取消", z, runnable, null);
    }

    public void darkBars(boolean z) {
        int i = (!Night.active || z) ? -16777216 : -15066596;
        if (Night.active) {
            z = true;
        }
        Window window = getWindow();
        this.sbBase = z ? i : Ui.BG;
        if (!z) {
            i = -1;
        }
        this.nbBase = i;
        applyBars();
        window.getDecorView().setSystemUiVisibility(z ? 0 : 8208);
    }

    public void dimBars(boolean z) {
        this.dimN = Math.max(0, (z ? 1 : -1) + this.dimN);
        float f = this.dimN > 0 ? DIM : 0.0f;
        if (this.dimA != null) {
            this.dimA.cancel();
        }
        this.dimA = ValueAnimator.ofFloat(this.dimF, f);
        this.dimA.setDuration(z ? 180L : 160L);
        this.dimA.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.changliao.im.MainActivity.11
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                MainActivity.this.dimF = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                MainActivity.this.applyBars();
            }
        });
        this.dimA.start();
    }

    public void dismiss(final View view) {
        hideKb();
        if (view != null && this.dimmed.remove(view)) {
            dimBars(false);
        }
        view.setTag(null);
        view.animate().alpha(0.0f).setDuration(160L).withEndAction(new Runnable() { // from class: com.changliao.im.MainActivity.16
            @Override // java.lang.Runnable
            public void run() {
                MainActivity.this.overlay.removeView(view);
            }
        }).start();
    }

    LinearLayout dlgCard(String str, String str2) {
        View emo;
        LinearLayout linearLayoutCol = Ui.col(this);
        G g = new G(0, 24.0f);
        g.bg = -1;
        linearLayoutCol.setBackground(g);
        linearLayoutCol.setElevation(Ui.dp(16.0f));
        linearLayoutCol.setPadding(Ui.dp(18.0f), Ui.dp(20.0f), Ui.dp(18.0f), Ui.dp(16.0f));
        if (str != null && str.startsWith("📢 ")) {
            try {
                emo = new Emo(this, "📢", true);
            } catch (Throwable th) {
                Crash.note(th);
                TextView textViewText = Ui.text(this, "📢", 44.0f, Ui.TEXT);
                textViewText.setGravity(17);
                emo = textViewText;
            }
            linearLayoutCol.addView(emo, Ui.lpm(Ui.dp(72.0f), Ui.dp(72.0f), 0, 0, 0, 4));
            ((LinearLayout.LayoutParams) emo.getLayoutParams()).gravity = 1;
            str = str.substring(3);
        }
        if (str != null) {
            TextView textViewBold = Ui.bold(Ui.text(this, str, 17.0f, Ui.TEXT));
            textViewBold.setGravity(17);
            linearLayoutCol.addView(textViewBold, Ui.lpm(-1, -2, 0, 0, 0, 12));
        }
        if (str2 != null && str2.length() > 0) {
            TextView textViewText2 = Ui.text(this, str2, 14.0f, Ui.SUB);
            textViewText2.setLineSpacing(0.0f, 1.3f);
            textViewText2.setGravity(str2.length() > 60 ? 8388611 : 1);
            final int iMax = Math.max(Ui.dp(120.0f), ((int) (((str == null || str.length() <= 0) ? 0.5f : 0.4f) * getResources().getDisplayMetrics().heightPixels)) - Ui.dp(40.0f));
            ScrollView scrollView = new ScrollView(this) { // from class: com.changliao.im.MainActivity.17
                @Override // android.widget.ScrollView, android.widget.FrameLayout, android.view.View
                protected void onMeasure(int i, int i2) {
                    super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(iMax, Integer.MIN_VALUE));
                }
            };
            scrollView.setVerticalScrollBarEnabled(true);
            scrollView.setOverScrollMode(1);
            scrollView.addView(textViewText2);
            linearLayoutCol.addView(scrollView, Ui.lpm(-1, -2, 0, 0, 0, 2));
        }
        return linearLayoutCol;
    }

    void handle(Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.getBooleanExtra("openCall", false)) {
            this.openCall = true;
            intent.removeExtra("openCall");
        }
        final String stringExtra = intent.getStringExtra("conv");
        if (stringExtra == null || stringExtra.length() <= 0) {
            return;
        }
        this.h.postDelayed(new Runnable() { // from class: com.changliao.im.MainActivity.2
            @Override // java.lang.Runnable
            public void run() {
                if (MainActivity.this.C.authed) {
                    MainActivity.this.openChat(stringExtra);
                }
            }
        }, 300L);
    }

    public boolean has(String str) {
        return checkSelfPermission(str) == 0;
    }

    boolean hasModal() {
        for (int i = 0; i < this.overlay.getChildCount(); i++) {
            if (this.overlay.getChildAt(i).getTag() instanceof Runnable) {
                return true;
            }
        }
        return false;
    }

    void hiFps() {
        try {
            Display display = Build.VERSION.SDK_INT >= 30 ? getDisplay() : getWindowManager().getDefaultDisplay();
            if (display == null) {
                return;
            }
            Display.Mode mode = display.getMode();
            Display.Mode[] supportedModes = display.getSupportedModes();
            int length = supportedModes.length;
            int i = 0;
            Display.Mode mode2 = mode;
            while (i < length) {
                Display.Mode mode3 = supportedModes[i];
                if (mode3.getPhysicalWidth() != mode.getPhysicalWidth() || mode3.getPhysicalHeight() != mode.getPhysicalHeight() || mode3.getRefreshRate() <= mode2.getRefreshRate() + 0.5f) {
                    mode3 = mode2;
                }
                i++;
                mode2 = mode3;
            }
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            if (attributes.preferredDisplayModeId == mode2.getModeId() && attributes.preferredRefreshRate == mode2.getRefreshRate()) {
                return;
            }
            attributes.preferredDisplayModeId = mode2.getModeId();
            attributes.preferredRefreshRate = mode2.getRefreshRate();
            getWindow().setAttributes(attributes);
        } catch (Throwable th) {
        }
    }

    public void hideKb() {
        try {
            View currentFocus = getCurrentFocus();
            if (currentFocus != null) {
                ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
            }
        } catch (Exception e) {
        }
    }

    /* JADX WARN: Type inference incomplete: some casts might be missing */
    FrameLayout mask(View view, boolean z, final Runnable runnable) {
        final FrameLayout frameLayout = new FrameLayout(this);
        // PATCH(需求1): 弹窗遮罩预反色 —— 0x73FFFFFF 经 Night 反色层输出 0x731A1A1A 深色 scrim
        frameLayout.setBackgroundColor(0x73FFFFFF);
        frameLayout.setClickable(true);
        final Runnable runnable2 = new Runnable() { // from class: com.changliao.im.MainActivity.14
            @Override // java.lang.Runnable
            public void run() {
                MainActivity.this.dismiss(frameLayout);
                if (runnable != null) {
                    runnable.run();
                }
            }
        };
        frameLayout.setTag(runnable2);
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.MainActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                runnable2.run();
            }
        });
        view.setClickable(true);
        FrameLayout.LayoutParams layoutParamsFlp = z ? Ui.flp(-1, -2, 17) : Ui.flp(-1, -2, 80);
        if (z) {
            layoutParamsFlp.width = Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.86f), Ui.dp(400.0f));
        }
        frameLayout.addView(view, layoutParamsFlp);
        this.overlay.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        this.dimmed.add(frameLayout);
        dimBars(true);
        frameLayout.setAlpha(0.0f);
        frameLayout.animate().alpha(1.0f).setDuration(180L).start();
        if (z) {
            view.setScaleX(0.86f);
            view.setScaleY(0.86f);
            view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(320L).setInterpolator(new OvershootInterpolator(1.6f)).start();
        } else {
            view.setTranslationY(Ui.dp(300.0f));
            view.animate().translationY(0.0f).setDuration(300L).setInterpolator(new DecelerateInterpolator(2.2f)).start();
        }
        return frameLayout;
    }

    @Override // com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("toast")) {
            toast(j.s("msg"), j.b("err"));
            return;
        }
        if (str.equals("need")) {
            if (!(topScr() instanceof LoginScr)) {
                reset(new LoginScr());
            }
            App.stopBg(this);
            return;
        }
        if (str.equals("need_nick") || str.equals("need_pw")) {
            Scr scr = topScr();
            if (!(scr instanceof LoginScr)) {
                reset(new LoginScr());
                scr = topScr();
            }
            ((LoginScr) scr).step(str);
            return;
        }
        if (str.equals("enter")) {
            if (this.stack.size() <= 0 || !(this.stack.get(0) instanceof HomeScr)) {
                reset(new HomeScr());
            }
            App.startBg(this);
            Upd.check(this, false);
            String strTake = Crash.take("crash.txt");
            if (strTake != null) {
                this.C.send(J.of("t", "c_bug_post", "text", "【自动上报】App 上次闪退了\n" + strTake, "imgs", new ArrayList(), "ver", VNAME, "dev", App.dev()));
            }
            final String strTake2 = Crash.take("errors.txt");
            if (strTake2 != null && strTake2.trim().length() > 0) {
                this.h.postDelayed(new Runnable() { // from class: com.changliao.im.MainActivity.5
                    @Override // java.lang.Runnable
                    public void run() {
                        Core core = MainActivity.this.C;
                        Object[] objArr = new Object[10];
                        objArr[0] = "t";
                        objArr[1] = "c_bug_post";
                        objArr[2] = "text";
                        objArr[3] = "【自动上报】App 运行中出错的记录\n" + (strTake2.length() > 1900 ? strTake2.substring(0, 1900) : strTake2);
                        objArr[4] = "imgs";
                        objArr[5] = new ArrayList();
                        objArr[6] = "ver";
                        objArr[7] = MainActivity.VNAME;
                        objArr[8] = "dev";
                        objArr[9] = App.dev();
                        core.send(J.of(objArr));
                    }
                }, 16000L);
            }
            Ann.check(this);
            bgGuide();
            return;
        }
        if (str.equals("note")) {
            if (this.resumed && j.has("conv")) {
                banner(j.s("title"), j.s("text"), j.s("conv"));
                vib(40);
                return;
            }
            return;
        }
        if (str.equals("open")) {
            openChat(j.s("conv"));
            return;
        }
        if (str.equals("anns") || str.equals("ann_new")) {
            Ann.check(this);
        } else if (str.equals("poked")) {
            vib(80);
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        Res resRemove = this.res.remove(Integer.valueOf(i));
        if (resRemove != null) {
            try {
                resRemove.got(i2, intent);
            } catch (Throwable th) {
                Crash.note(th);
                toast("出错了：" + th.getMessage(), true);
            }
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        for (int childCount = this.overlay.getChildCount() - 1; childCount >= 0; childCount--) {
            Object tag = this.overlay.getChildAt(childCount).getTag();
            if (tag instanceof Runnable) {
                ((Runnable) tag).run();
                return;
            }
        }
        Scr scr = topScr();
        if (scr == null || !scr.onBack()) {
            back();
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.host.post(new Runnable() { // from class: com.changliao.im.MainActivity.1
            @Override // java.lang.Runnable
            public void run() {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= MainActivity.this.stack.size() - 1) {
                        break;
                    }
                    ((View) MainActivity.this.stack.get(i2).root.getParent()).setTranslationX((MainActivity.this.wide() && (MainActivity.this.stack.get(i2) instanceof HomeScr)) ? 0.0f : (-MainActivity.this.host.getWidth()) * 0.28f);
                    i = i2 + 1;
                }
                if (!MainActivity.this.stack.isEmpty()) {
                    ((View) MainActivity.this.topScr().root.getParent()).setTranslationX(0.0f);
                }
                MainActivity.this.host.requestLayout();
                MainActivity.this.host.invalidate();
            }
        });
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        cur = this;
        Ui.D = getResources().getDisplayMetrics().density;
        App.init(getApplicationContext());
        G.LITE = Night.lite(this);
        requestWindowFeature(1);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(201326592);
        boolean zOn = true; // PATCH(需求1): 恒深色，不再读 Night.on()
        window.setStatusBarColor(zOn ? -15066596 : -855051);
        window.setNavigationBarColor(zOn ? -15066596 : -1);
        View decorView = window.getDecorView();
        if (zOn) {
            i = 0;
        } else {
            i = (Build.VERSION.SDK_INT >= 26 ? 16 : 0) | 8192;
        }
        decorView.setSystemUiVisibility(i);
        window.setSoftInputMode(16);
        this.host = new Pane();
        this.host.setBackgroundColor(Ui.BG);
        this.overlay = new FrameLayout(this);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.addView(this.host, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(this.overlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frameLayout);
        this.root = frameLayout;
        Night.apply(frameLayout, this);
        // PATCH(需求1): 窗口背景恒深色 -15066596，去掉浅色 -855051 分支
        getWindow().setBackgroundDrawable(new ColorDrawable(-15066596));
        darkBars(false);
        hiFps();
        Ann.showing = null;
        this.C.add(this);
        // PATCH(需求2/需求3): 强制进入聊天 —— 原逻辑 `token()!=null ? HomeScr : LoginScr`
        // 改为：authed 直接置真 + 无条件压入 HomeScr(会话列表)，登录/验证页完全不进栈。
        this.C.authed = true;
        push(new HomeScr());
        this.C.start();
        on("enter", null);
        // PATCH(需求3): 本地已有会话时，再压一层 ChatScr(convid) 直接落在聊天窗口
        String strFirst = firstConv();
        if (strFirst != null) {
            push(new ChatScr(strFirst));
        }
        askPerms();
        handle(getIntent());
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.C.remove(this);
        Iterator<Scr> it = this.stack.iterator();
        while (it.hasNext()) {
            this.C.remove(it.next());
        }
        if (cur == this) {
            cur = null;
        }
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handle(intent);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        this.resumed = false;
        this.C.foreground = false;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 9) {
            Call.permDone(this);
        }
        if (i == 11 && (topScr() instanceof GalScr)) {
            ((GalScr) topScr()).load();
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.resumed = true;
        this.C.foreground = true;
        this.C.poke();
        Notif.clear(this);
        answer();
        darkBars(false);
        hiFps();
        Scr scr = topScr();
        if (scr != null) {
            scr.onShow();
        }
        Upd.resume(this);
        if (this.lastUpd == 0 || SystemClock.uptimeMillis() - this.lastUpd > 600000) {
            this.lastUpd = SystemClock.uptimeMillis();
            Upd.check(this, false);
            Ann.fetch(this);
        }
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        FloatCall.hideSys();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        if (Call.cur == null || Call.cur.state == 4) {
            return;
        }
        FloatCall.showSys(this);
    }

    // PATCH(需求3): 取一个可用的默认会话 id；本地无会话时返回 null（此时停留在会话列表 = 空列表）
    String firstConv() {
        for (J j : this.C.sortedConvs()) {
            String str = j.s("conv");
            if (str != null && str.length() > 0) {
                return str;
            }
        }
        return null;
    }

    public void openChat(String str) {
        for (int size = this.stack.size() - 1; size >= 0; size--) {
            Scr scr = this.stack.get(size);
            if ((scr instanceof ChatScr) && str.equals(((ChatScr) scr).conv)) {
                while (topScr() != scr) {
                    close(this.stack.remove(this.stack.size() - 1), false);
                }
                return;
            }
        }
        popTo(HomeScr.class);
        push(new ChatScr(str));
    }

    boolean paneOf(Scr scr) {
        return (!wide() || scr.full() || (scr instanceof HomeScr)) ? false : true;
    }

    public void popTo(Class<?> cls) {
        while (this.stack.size() > 1 && !cls.isInstance(topScr())) {
            close(this.stack.remove(this.stack.size() - 1), false);
        }
    }

    public void push(Scr scr) {
        long jUptimeMillis = SystemClock.uptimeMillis();
        Scr scr2 = topScr();
        if (scr2 == null || scr2.getClass() != scr.getClass() || jUptimeMillis - this.lastPush >= 700) {
            if (scr.getClass() != this.lastCls || jUptimeMillis - this.lastPush >= 350) {
                this.lastPush = jUptimeMillis;
                this.lastCls = scr.getClass();
                scr.a = this;
                try {
                    View viewBuild = scr.build();
                    if (scr.dark()) {
                        Night.darkPage(viewBuild);
                    }
                    scr.root = viewBuild;
                    scr.alive = true;
                    Scr scr3 = topScr();
                    Swipe swipe = new Swipe(this, scr);
                    swipe.addView(viewBuild, new FrameLayout.LayoutParams(-1, -1));
                    swipe.setBackgroundColor(Ui.BG);
                    this.stack.add(scr);
                    this.C.add(scr);
                    this.host.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
                    if (scr3 != null) {
                        scr3.onHide();
                        if (paneOf(scr)) {
                            swipe.setAlpha(0.0f);
                            swipe.setTranslationX(Ui.dp(24.0f));
                            swipe.animate().alpha(1.0f).translationX(0.0f).setDuration(260L).setInterpolator(new DecelerateInterpolator(2.0f)).withLayer().start();
                        } else {
                            swipe.setTranslationX(this.host.getWidth() > 0 ? this.host.getWidth() : 1000.0f);
                            swipe.setElevation(Ui.dp(8.0f));
                            swipe.animate().translationX(0.0f).setDuration(300L).setInterpolator(new DecelerateInterpolator(2.0f)).withLayer().start();
                            View view = (View) scr3.root.getParent();
                            if (!wide() || !(scr3 instanceof HomeScr) || scr.full()) {
                                view.animate().translationX((-this.host.getWidth()) * 0.28f).setDuration(300L).setInterpolator(new DecelerateInterpolator(2.0f)).withLayer().start();
                            }
                        }
                    }
                    this.host.requestLayout();
                    scr.onShow();
                    hideKb();
                    callPill();
                } catch (Throwable th) {
                    Crash.note(th);
                    toast("页面打开失败：" + th.getMessage(), true);
                }
            }
        }
    }

    public void reset(Scr scr) {
        while (!this.stack.isEmpty()) {
            Scr scrRemove = this.stack.remove(this.stack.size() - 1);
            scrRemove.alive = false;
            this.C.remove(scrRemove);
            scrRemove.onClose();
        }
        this.host.removeAllViews();
        this.host.addView(this.host.ph);
        push(scr);
    }

    public void sheet(String str, String[] strArr, int i, final Str str2) {
        LinearLayout linearLayoutCol = Ui.col(this);
        G g = new G(0, 22.0f);
        g.bg = -525828;
        linearLayoutCol.setBackground(g);
        linearLayoutCol.setElevation(Ui.dp(16.0f));
        linearLayoutCol.setPadding(Ui.dp(8.0f), Ui.dp(8.0f), Ui.dp(8.0f), Ui.dp(8.0f));
        final FrameLayout[] frameLayoutArr = new FrameLayout[1];
        if (str != null && str.length() > 0) {
            TextView textViewText = Ui.text(this, str, 13.0f, Ui.SUB);
            textViewText.setGravity(17);
            textViewText.setPadding(Ui.dp(16.0f), Ui.dp(10.0f), Ui.dp(16.0f), Ui.dp(10.0f));
            linearLayoutCol.addView(textViewText);
        }
        int i2 = 0;
        while (true) {
            int i3 = i2;
            if (i3 > strArr.length) {
                FrameLayout frameLayout = new FrameLayout(this);
                frameLayout.setPadding(Ui.dp(8.0f), 0, Ui.dp(8.0f), Ui.dp(8.0f));
                ScrollView scrollView = new ScrollView(this);
                scrollView.addView(linearLayoutCol);
                frameLayout.addView(scrollView);
                frameLayout.setLayoutParams(new FrameLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels, Ui.dp(536.0f)), -2, 1));
                FrameLayout frameLayout2 = new FrameLayout(this);
                frameLayout2.addView(frameLayout);
                frameLayoutArr[0] = mask(frameLayout2, false, null);
                return;
            }
            final String str3 = i3 < strArr.length ? strArr[i3] : null;
            TextView textViewText2 = Ui.text(this, str3 == null ? "取消" : str3, 16.0f, i3 == i ? Ui.RED : Ui.TEXT);
            if (str3 == null) {
                Ui.bold(textViewText2);
            }
            textViewText2.setGravity(17);
            textViewText2.setPadding(0, Ui.dp(15.0f), 0, Ui.dp(15.0f));
            G.on(textViewText2, 0, 16.0f, 1.0f);
            Ui.bounce(textViewText2);
            textViewText2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.MainActivity.23
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MainActivity.this.dismiss(frameLayoutArr[0]);
                    if (str3 != null) {
                        str2.ok(str3);
                    }
                }
            });
            linearLayoutCol.addView(textViewText2, Ui.lpm(-1, -2, 0, str3 == null ? 4 : 0, 0, str3 == null ? 0 : 6));
            i2 = i3 + 1;
        }
    }

    public void showKb(View view) {
        view.requestFocus();
        ((InputMethodManager) getSystemService("input_method")).showSoftInput(view, 0);
    }

    public void startFor(Intent intent, Res res) {
        int i = this.reqN + 1;
        this.reqN = i;
        this.res.put(Integer.valueOf(i), res);
        try {
            startActivityForResult(intent, i);
        } catch (Exception e) {
            this.res.remove(Integer.valueOf(i));
            toast("打不开：" + e.getMessage(), true);
        }
    }

    public void toast(String str, boolean z) {
        if (str == null || str.length() == 0) {
            return;
        }
        if (this.toastV != null) {
            this.overlay.removeView(this.toastV);
            this.toastV = null;
        }
        TextView textViewText = Ui.text(this, str, 14.0f, -1);
        textViewText.setPadding(Ui.dp(16.0f), Ui.dp(10.0f), Ui.dp(16.0f), Ui.dp(10.0f));
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, z ? new int[]{-530435530, -666886622} : new int[]{-701483970, -870835680});
        gradientDrawable.setCornerRadius(Ui.dp(16.0f));
        gradientDrawable.setStroke(1, 956301311);
        textViewText.setBackground(gradientDrawable);
        textViewText.setMaxWidth(getResources().getDisplayMetrics().widthPixels - Ui.dp(48.0f));
        textViewText.setElevation(Ui.dp(6.0f));
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 49);
        layoutParamsFlp.topMargin = Ui.dp(64.0f);
        textViewText.setClickable(false);
        this.overlay.addView(textViewText, layoutParamsFlp);
        textViewText.setTag(null);
        this.toastV = textViewText;
        textViewText.setAlpha(0.0f);
        textViewText.setTranslationY(-Ui.dp(16.0f));
        textViewText.animate().alpha(1.0f).translationY(0.0f).setDuration(240L).setInterpolator(new OvershootInterpolator(1.4f)).start();
        this.h.removeCallbacks(this.hideToast);
        this.h.postDelayed(this.hideToast, 2400L);
    }

    public Scr topScr() {
        if (this.stack.isEmpty()) {
            return null;
        }
        return this.stack.get(this.stack.size() - 1);
    }

    public void vib(int i) {
        try {
            Vibrator vibrator = (Vibrator) getSystemService("vibrator");
            if (vibrator != null) {
                vibrator.vibrate(VibrationEffect.createOneShot(i, -1));
            }
        } catch (Exception e) {
        }
    }

    public void web(String str, String... strArr) {
        String str2 = strArr.length > 1 ? strArr[1] : null;
        String str3 = strArr.length > 3 ? strArr[3] : null;
        if (str.equals("search")) {
            push(new SearchScr(false));
            return;
        }
        if (str.equals("newfriends")) {
            push(new SearchScr(true));
            return;
        }
        if (str.equals("newgroup")) {
            PickScr.createGroup(this);
            return;
        }
        if (str.equals("post")) {
            push(new FeedScr.PostScr());
            return;
        }
        if (str.equals("feed")) {
            Scr scr = this.stack.isEmpty() ? null : this.stack.get(0);
            if (scr instanceof HomeScr) {
                popTo(HomeScr.class);
                ((HomeScr) scr).go(2);
                return;
            }
            return;
        }
        if (str.equals("myfeed")) {
            push(new FeedScr(this.C.info == null ? "" : this.C.info.s("nk"), this.C.myNick()));
            return;
        }
        if (str.equals("myinfo")) {
            push(new MyInfoScr());
            return;
        }
        if (str.equals("anns")) {
            push(new AnnScr());
            return;
        }
        if (str.equals("vip")) {
            push(new MiscScr.VipScr());
            return;
        }
        if (str.equals("favs")) {
            push(new MiscScr.FavScr(null));
            return;
        }
        if (str.equals("bugs")) {
            push(new BugScr());
            return;
        }
        if (str.equals("reports")) {
            push(new MiscScr.ReportsScr());
            return;
        }
        if (str.equals("settings")) {
            push(new MiscScr.SettingsScr());
            return;
        }
        if (str.equals("profile")) {
            push(new ProfileScr(str2, str3));
            return;
        }
        if (str.equals("ginfo")) {
            push(new GroupScr(str2));
        } else if (str.equals("chatsearch")) {
            push(new MediaScr(str2, null, str3));
        } else {
            toast("这个功能还没有", false);
        }
    }

    public boolean wide() {
        if (this.host == null || this.host.getWidth() <= 0) {
            return getResources().getConfiguration().screenWidthDp >= 720;
        }
        return ((float) this.host.getWidth()) / Ui.D >= 720.0f;
    }
}
