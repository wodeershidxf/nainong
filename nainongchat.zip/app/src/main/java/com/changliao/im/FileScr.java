package com.changliao.im;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class FileScr extends Scr {
    static List<J> apps;
    LinearLayout body;
    final ChatScr chat;
    List<J> myfiles;
    TextView okB;
    LinearLayout tabs;
    String tab = "chat";
    final LinkedHashMap<String, J> sel = new LinkedHashMap<>();

    public FileScr(ChatScr chatScr) {
        this.chat = chatScr;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("选择文件", true);
        this.okB = tb("发送", new View.OnClickListener() { // from class: com.changliao.im.FileScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FileScr.this.send();
            }
        });
        HorizontalScrollView horizontalScrollView = new HorizontalScrollView(this.a);
        horizontalScrollView.setHorizontalScrollBarEnabled(false);
        this.tabs = Ui.row(this.a);
        this.tabs.setPadding(Ui.dp(12.0f), Ui.dp(10.0f), Ui.dp(12.0f), Ui.dp(10.0f));
        horizontalScrollView.addView(this.tabs);
        linearLayoutPage.addView(horizontalScrollView);
        this.body = scrollPage(linearLayoutPage);
        this.C.send(J.of("t", "c_myfiles"));
        render();
        return linearLayoutPage;
    }

    void fileRow(LinearLayout linearLayout, final J j, final String str, String str2) {
        View view;
        CharSequence charSequenceS;
        final String strS = j.s("id");
        final Scr.Chk chk = new Scr.Chk(this.a);
        chk.on = this.sel.containsKey(strS);
        if (str.equals("img")) {
            ImageView imageView = new ImageView(this.a);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setBackground(Ui.round(-1117965, 10.0f));
            ChatScr.clip(imageView, 10.0f);
            Img.into(imageView, Core.fileUrl(strS, j.s("name")), 200);
            view = imageView;
        } else {
            TextView textViewText = Ui.text(this.a, str.equals("video") ? "🎬" : Ui.fileIcon(j.s("name")), 24.0f, Ui.TEXT);
            textViewText.setGravity(17);
            textViewText.setBackground(Ui.round(-1117965, 10.0f));
            view = textViewText;
        }
        if (j.s("name").length() > 0) {
            charSequenceS = j.s("name");
        } else {
            charSequenceS = str.equals("img") ? "图片" : "文件";
        }
        LinearLayout linearLayoutRow = row(linearLayout, view, 44, charSequenceS, str2, null, null);
        linearLayoutRow.addView(chk, 0, Ui.lpm(Ui.dp(22.0f), Ui.dp(22.0f), 0, 0, 12, 0));
        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FileScr.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                if (FileScr.this.sel.containsKey(strS)) {
                    FileScr.this.sel.remove(strS);
                } else {
                    J j2 = new J();
                    j2.putAll(j);
                    j2.put("k", str);
                    FileScr.this.sel.put(strS, j2);
                }
                chk.set(FileScr.this.sel.containsKey(strS));
                FileScr.this.okB.setText("发送" + (FileScr.this.sel.isEmpty() ? "" : "(" + FileScr.this.sel.size() + ")"));
            }
        });
    }

    void go(String str) {
        if (str.equals("album")) {
            this.a.back();
            this.a.push(new GalScr(new GalScr.Got() { // from class: com.changliao.im.FileScr.3
                @Override // com.changliao.im.GalScr.Got
                public void got(List<Uri> list, boolean z) {
                    FileScr.this.chat.sendUris(list, false, false);
                }
            }).title("手机相册"));
        } else if (str.equals("phone")) {
            this.a.back();
            this.chat.pickFile();
        } else {
            this.tab = str;
            render();
        }
    }

    void loadApps() {
        apps = new ArrayList();
        try {
            PackageManager packageManager = this.a.getPackageManager();
            for (ApplicationInfo applicationInfo : packageManager.getInstalledApplications(0)) {
                if ((applicationInfo.flags & 1) == 0 || (applicationInfo.flags & 128) != 0) {
                    if (!applicationInfo.packageName.equals(this.a.getPackageName()) && applicationInfo.sourceDir != null) {
                        apps.add(J.of("pkg", applicationInfo.packageName, "name", String.valueOf(packageManager.getApplicationLabel(applicationInfo)), "path", applicationInfo.sourceDir, "size", Long.valueOf(new File(applicationInfo.sourceDir).length())));
                    }
                }
            }
            final Collator collator = Collator.getInstance(Locale.CHINA);
            Collections.sort(apps, new Comparator<J>() { // from class: com.changliao.im.FileScr.8
                @Override // java.util.Comparator
                public int compare(J j, J j2) {
                    return collator.compare(j.s("name"), j2.s("name"));
                }
            });
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("c_myfiles")) {
            this.myfiles = j.objs("l");
            if (this.tab.equals("chat")) {
                render();
            }
        }
    }

    void render() {
        tabsUi();
        this.okB.setText("发送" + (this.sel.isEmpty() ? "" : "(" + this.sel.size() + ")"));
        this.body.removeAllViews();
        if (this.tab.equals("chat")) {
            if (this.myfiles == null) {
                this.body.addView(empty("加载中…"));
                return;
            }
            if (this.myfiles.isEmpty()) {
                this.body.addView(empty("聊天里还没有收发过文件"));
                return;
            }
            LinearLayout linearLayoutListW = listW(this.body);
            for (J j : this.myfiles) {
                J jO = j.o("f");
                if (jO != null) {
                    fileRow(linearLayoutListW, jO, "file", Ui.size(jO.l("size")) + " · " + j.s("ct") + " · " + Ui.fullWhen(j.l("ts")));
                }
            }
            return;
        }
        if (this.tab.equals("fav")) {
            ArrayList<J> arrayList = new ArrayList();
            for (J j2 : MiscScr.favs()) {
                if (j2.o("f") != null && j2.o("f").s("id").length() > 0) {
                    arrayList.add(j2);
                }
            }
            if (arrayList.isEmpty()) {
                this.body.addView(empty("收藏里没有文件"));
                return;
            }
            LinearLayout linearLayoutListW2 = listW(this.body);
            for (J j3 : arrayList) {
                fileRow(linearLayoutListW2, j3.o("f"), j3.s("k"), Ui.size(j3.o("f").l("size")) + " · 收藏 · 来自 " + j3.s("from"));
            }
            return;
        }
        if (this.tab.equals("apps")) {
            if (apps == null) {
                loadApps();
            }
            if (apps.isEmpty()) {
                this.body.addView(empty("没有读取到本机应用"));
            } else {
                LinearLayout linearLayoutListW3 = listW(this.body);
                PackageManager packageManager = this.a.getPackageManager();
                for (final J j4 : apps) {
                    final String str = "app:" + j4.s("pkg");
                    final Scr.Chk chk = new Scr.Chk(this.a);
                    chk.on = this.sel.containsKey(str);
                    ImageView imageView = new ImageView(this.a);
                    try {
                        imageView.setImageDrawable(packageManager.getApplicationIcon(j4.s("pkg")));
                    } catch (Throwable th) {
                    }
                    LinearLayout linearLayoutRow = row(linearLayoutListW3, imageView, 44, j4.s("name"), Ui.size(j4.l("size")), null, null);
                    linearLayoutRow.addView(chk, 0, Ui.lpm(Ui.dp(22.0f), Ui.dp(22.0f), 0, 0, 12, 0));
                    linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FileScr.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            if (FileScr.this.sel.containsKey(str)) {
                                FileScr.this.sel.remove(str);
                            } else {
                                FileScr.this.sel.put(str, j4);
                            }
                            chk.set(FileScr.this.sel.containsKey(str));
                            FileScr.this.okB.setText("发送" + (FileScr.this.sel.isEmpty() ? "" : "(" + FileScr.this.sel.size() + ")"));
                        }
                    });
                }
            }
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.setGravity(1);
            linearLayoutCol.setPadding(0, Ui.dp(14.0f), 0, Ui.dp(10.0f));
            linearLayoutCol.addView(Ui.text(this.a, "看不到全部应用？", 13.0f, Ui.SUB));
            LinearLayout linearLayoutRow2 = Ui.row(this.a);
            linearLayoutRow2.addView(sm("去开启「读取应用列表」权限", 0, new View.OnClickListener() { // from class: com.changliao.im.FileScr.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    try {
                        FileScr.this.a.startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + FileScr.this.a.getPackageName())));
                    } catch (Throwable th2) {
                    }
                }
            }));
            linearLayoutRow2.addView(sm("刷新", 0, new View.OnClickListener() { // from class: com.changliao.im.FileScr.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FileScr.apps = null;
                    FileScr.this.render();
                }
            }), Ui.lpm(-2, -2, 8, 0, 0, 0));
            linearLayoutCol.addView(linearLayoutRow2, Ui.lpm(-2, -2, 0, 8, 0, 0));
            this.body.addView(linearLayoutCol);
        }
    }

    void send() {
        if (this.sel.isEmpty()) {
            toast("请先选择文件");
            return;
        }
        final ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (J j : this.sel.values()) {
            if (j.has("pkg")) {
                Uri uriFromFile = Uri.fromFile(new File(j.s("path")));
                Up.names.put(uriFromFile.toString(), j.s("name") + ".apk");
                arrayList.add(uriFromFile);
            } else {
                arrayList2.add(j);
            }
        }
        this.a.back();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= arrayList2.size()) {
                break;
            }
            final J j2 = (J) arrayList2.get(i2);
            this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.FileScr.9
                @Override // java.lang.Runnable
                public void run() {
                    J jOf = J.of("t", "c_send", "conv", FileScr.this.chat.conv, "k", j2.s("k").length() > 0 ? j2.s("k") : "file", "fid", j2.s("id"));
                    if (j2.has("w")) {
                        jOf.put("w", Long.valueOf(j2.l("w")));
                    }
                    if (j2.has("h")) {
                        jOf.put("h", Long.valueOf(j2.l("h")));
                    }
                    if (j2.has("dur")) {
                        jOf.put("dur", Long.valueOf(j2.l("dur")));
                    }
                    if (j2.has("poster")) {
                        jOf.put("poster", j2.s("poster"));
                    }
                    FileScr.this.C.send(jOf);
                }
            }, ((long) i2) * 550);
            i = i2 + 1;
        }
        if (arrayList.isEmpty()) {
            return;
        }
        this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.FileScr.10
            @Override // java.lang.Runnable
            public void run() {
                FileScr.this.chat.sendUris(arrayList, false, false);
            }
        }, ((long) arrayList2.size()) * 550);
    }

    void tabsUi() {
        this.tabs.removeAllViews();
        for (final String[] strArr : new String[][]{new String[]{"chat", "聊天"}, new String[]{"fav", "收藏"}, new String[]{"album", "手机相册"}, new String[]{"apps", "本机应用"}, new String[]{"phone", "手机文件"}}) {
            this.tabs.addView(Ui.chip(this.a, strArr[1], this.tab.equals(strArr[0]), new View.OnClickListener() { // from class: com.changliao.im.FileScr.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FileScr.this.go(strArr[0]);
                }
            }), Ui.lpm(-2, -2, 0, 0, 8, 0));
        }
    }
}
