package com.changliao.im;

import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class BugScr extends Scr {
    boolean all;
    LinearLayout body;
    List<J> bugs;
    boolean busy;
    String view = "new";
    String draft = "";
    final List<J> imgs = new ArrayList();

    /* JADX INFO: renamed from: com.changliao.im.BugScr$10, reason: invalid class name */
    class AnonymousClass10 implements GalScr.Got {
        AnonymousClass10() {
        }

        @Override // com.changliao.im.GalScr.Got
        public void got(List<Uri> list, boolean z) {
            for (final Uri uri : list) {
                if (BugScr.this.imgs.size() >= 6) {
                    return;
                }
                final J jOf = J.of("p", Double.valueOf(0.0d));
                BugScr.this.imgs.add(jOf);
                BugScr.this.render();
                new Thread(new Runnable() { // from class: com.changliao.im.BugScr.10.1
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Object[] objArrJpeg = Up.jpeg(BugScr.this.a, uri, false);
                            jOf.put("bmp", Img.decode((byte[]) objArrJpeg[0], 300));
                            BugScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.BugScr.10.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    BugScr.this.render();
                                }
                            });
                            jOf.put("fid", Up.upload((byte[]) objArrJpeg[0], "bug.jpg", (String) objArrJpeg[3], new Up.P() { // from class: com.changliao.im.BugScr.10.1.2
                                @Override // com.changliao.im.Up.P
                                public void p(float f) {
                                    jOf.put("p", Double.valueOf(f));
                                }
                            }));
                        } catch (Throwable th) {
                            jOf.put("err", 1);
                            BugScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.BugScr.10.1.3
                                @Override // java.lang.Runnable
                                public void run() {
                                    BugScr.this.err("截图上传失败");
                                }
                            });
                        }
                        BugScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.BugScr.10.1.4
                            @Override // java.lang.Runnable
                            public void run() {
                                BugScr.this.render();
                            }
                        });
                    }
                }).start();
            }
        }
    }

    static List<J> fids(J j) {
        ArrayList arrayList = new ArrayList();
        Iterator<Object> it = j.a("imgs").iterator();
        while (it.hasNext()) {
            arrayList.add(J.of("fid", String.valueOf(it.next())));
        }
        return arrayList;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page(this.C.isOwner ? "Bug反馈处理" : "Bug反馈", true);
        this.body = scrollPage(linearLayoutPage);
        this.C.send(J.of("t", "c_bugs"));
        render();
        return linearLayoutPage;
    }

    View imgGrid(List<J> list, boolean z) {
        int width;
        GridLayout gridLayout = new GridLayout(this.a);
        gridLayout.setColumnCount(4);
        if (this.a.host.getWidth() > 0) {
            width = this.a.wide() ? (int) (this.a.host.getWidth() * 0.64f) : this.a.host.getWidth();
        } else {
            width = this.a.getResources().getDisplayMetrics().widthPixels;
        }
        int iDp = (((width - Ui.dp(24.0f)) - Ui.dp(32.0f)) / 4) - Ui.dp(8.0f);
        int i = 0;
        while (true) {
            final int i2 = i;
            if (i2 >= list.size()) {
                break;
            }
            final J j = list.get(i2);
            FrameLayout frameLayout = new FrameLayout(this.a);
            frameLayout.setBackground(Ui.round(-1117965, 10.0f));
            ChatScr.clip(frameLayout, 10.0f);
            ImageView imageView = new ImageView(this.a);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (j.has("bmp")) {
                imageView.setImageBitmap((Bitmap) j.get("bmp"));
            } else {
                Img.into(imageView, Core.fileUrl(j.s("fid"), "bug.jpg"), 300);
            }
            frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
            if (z) {
                if (!j.has("fid") && !j.has("err")) {
                    TextView textViewText = Ui.text(this.a, Math.round(j.d("p") * 100.0d) + "%", 13.0f, -1);
                    textViewText.setGravity(17);
                    textViewText.setBackgroundColor(1711276032);
                    frameLayout.addView(textViewText, new FrameLayout.LayoutParams(-1, -1));
                }
                TextView textViewText2 = Ui.text(this.a, "×", 14.0f, -1);
                textViewText2.setGravity(17);
                textViewText2.setBackground(Ui.oval(-1946157056));
                textViewText2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.BugScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        BugScr.this.imgs.remove(i2);
                        BugScr.this.render();
                    }
                });
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(Ui.dp(22.0f), Ui.dp(22.0f), 8388661);
                layoutParams.setMargins(0, Ui.dp(3.0f), Ui.dp(3.0f), 0);
                frameLayout.addView(textViewText2, layoutParams);
            } else {
                frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.BugScr.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        BugScr.this.a.push(new ImgScr(J.of("id", j.s("fid"), "name", "Bug截图.jpg"), null, null));
                    }
                });
            }
            GridLayout.LayoutParams layoutParams2 = new GridLayout.LayoutParams();
            layoutParams2.width = iDp;
            layoutParams2.height = iDp;
            layoutParams2.setMargins(0, 0, Ui.dp(8.0f), Ui.dp(8.0f));
            gridLayout.addView(frameLayout, layoutParams2);
            i = i2 + 1;
        }
        if (z && list.size() < 6) {
            TextView textViewText3 = Ui.text(this.a, "+", 30.0f, Ui.SUB);
            textViewText3.setGravity(17);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setCornerRadius(Ui.dp(10.0f));
            gradientDrawable.setStroke(Ui.dp(1.5f), -3946288, Ui.dp(4.0f), Ui.dp(3.0f));
            textViewText3.setBackground(gradientDrawable);
            textViewText3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.BugScr.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    BugScr.this.pick();
                }
            });
            GridLayout.LayoutParams layoutParams3 = new GridLayout.LayoutParams();
            layoutParams3.width = iDp;
            layoutParams3.height = iDp;
            layoutParams3.setMargins(0, 0, Ui.dp(8.0f), Ui.dp(8.0f));
            gridLayout.addView(textViewText3, layoutParams3);
        }
        return gridLayout;
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("c_bugs")) {
            this.bugs = j.objs("l");
            this.all = j.b("all");
            if (this.all) {
                this.C.bugN = 0;
            }
            render();
            return;
        }
        if ((str.equals("note") || str.equals("me")) && this.alive) {
            this.C.sendQ(J.of("t", "c_bugs"));
        }
    }

    void pick() {
        if (this.imgs.size() >= 6) {
            err("最多 6 张截图");
        } else {
            this.a.push(new GalScr(new AnonymousClass10()).title("选择截图").max(6 - this.imgs.size()).onlyImg().noOrig().ok("确定"));
        }
    }

    void render() {
        int i;
        this.body.removeAllViews();
        ArrayList<J> arrayList = this.bugs == null ? new ArrayList() : new ArrayList(this.bugs);
        Collections.reverse(arrayList);
        if (!this.C.isOwner) {
            LinearLayout linearLayoutCsec = csec(this.body);
            linearLayoutCsec.setPadding(Ui.dp(14.0f), Ui.dp(14.0f), Ui.dp(14.0f), Ui.dp(14.0f));
            EditText editText = new EditText(this.a);
            editText.setHint("遇到了什么问题？在哪个页面、做了什么操作之后出现的？写得越清楚，修得越快～");
            editText.setHintTextColor(-6643285);
            editText.setTextSize(15.0f);
            editText.setTextColor(Ui.TEXT);
            editText.setMinLines(4);
            editText.setGravity(48);
            editText.setBackground(null);
            editText.setText(this.draft);
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
            editText.addTextChangedListener(new TextWatcher() { // from class: com.changliao.im.BugScr.8
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                    BugScr.this.draft = editable.toString();
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                }
            });
            linearLayoutCsec.addView(editText);
            linearLayoutCsec.addView(imgGrid(this.imgs, true), Ui.lpm(-1, -2, 0, 10, 0, 0));
            linearLayoutCsec.addView(Ui.text(this.a, "可以加最多 6 张截图。提交后会直接发给系统。", 12.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 4, 0, 10));
            linearLayoutCsec.addView(Ui.btn(this.a, this.busy ? "提交中…" : "提交", new View.OnClickListener() { // from class: com.changliao.im.BugScr.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    BugScr.this.submit();
                }
            }));
            sec(this.body, "我提交过的");
            if (this.bugs == null) {
                this.body.addView(empty("加载中…"));
                return;
            }
            if (arrayList.isEmpty()) {
                this.body.addView(empty("还没有提交过反馈"));
                return;
            }
            for (J j : arrayList) {
                LinearLayout linearLayoutCsec2 = csec(this.body);
                linearLayoutCsec2.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(16.0f), Ui.dp(14.0f));
                LinearLayout linearLayoutRow = Ui.row(this.a);
                linearLayoutRow.addView(Ui.text(this.a, Ui.fullWhen(j.l("ts")), 12.0f, Ui.SUB), Ui.lp(0, -2, 1.0f));
                linearLayoutRow.addView(stTag(j));
                linearLayoutCsec2.addView(linearLayoutRow);
                if (j.s("text").length() > 0) {
                    linearLayoutCsec2.addView(Ui.text(this.a, j.s("text"), 15.0f, Ui.TEXT), Ui.lpm(-1, -2, 0, 8, 0, 0));
                }
                if (j.a("imgs").size() > 0) {
                    linearLayoutCsec2.addView(imgGrid(fids(j), false), Ui.lpm(-1, -2, 0, 10, 0, 0));
                }
                if (j.s("reply").length() > 0) {
                    TextView textViewText = Ui.text(this.a, "系统回复：" + j.s("reply"), 14.0f, Ui.TEXT);
                    textViewText.setPadding(Ui.dp(12.0f), Ui.dp(9.0f), Ui.dp(12.0f), Ui.dp(9.0f));
                    textViewText.setBackground(Ui.round(440241151, 12.0f));
                    linearLayoutCsec2.addView(textViewText, Ui.lpm(-1, -2, 0, 10, 0, 0));
                }
            }
            return;
        }
        int i2 = 0;
        Iterator it = arrayList.iterator();
        while (true) {
            i = i2;
            if (!it.hasNext()) {
                break;
            } else {
                i2 = ((J) it.next()).s("st").equals("new") ? i + 1 : i;
            }
        }
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setPadding(Ui.dp(12.0f), Ui.dp(12.0f), Ui.dp(12.0f), 0);
        linearLayoutRow2.addView(segB("待处理 " + (i > 0 ? Integer.valueOf(i) : ""), this.view.equals("new"), "new"), Ui.lpm(0, -2, 0, 0, 8, 0));
        ((LinearLayout.LayoutParams) linearLayoutRow2.getChildAt(0).getLayoutParams()).weight = 1.0f;
        linearLayoutRow2.addView(segB("全部 " + (arrayList.size() > 0 ? Integer.valueOf(arrayList.size()) : ""), this.view.equals("all"), "all"), Ui.lp(0, -2, 1.0f));
        this.body.addView(linearLayoutRow2);
        if (this.bugs == null) {
            this.body.addView(empty("加载中…"));
            return;
        }
        int i3 = 0;
        for (final J j2 : arrayList) {
            if (!this.view.equals("new") || j2.s("st").equals("new")) {
                int i4 = i3 + 1;
                LinearLayout linearLayoutCsec3 = csec(this.body);
                linearLayoutCsec3.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f));
                LinearLayout linearLayoutRow3 = Ui.row(this.a);
                linearLayoutRow3.addView(av(j2.s("nick"), j2.sn("av"), false), Ui.lpm(Ui.dp(40.0f), Ui.dp(40.0f), 0, 0, 10, 0));
                LinearLayout linearLayoutCol = Ui.col(this.a);
                linearLayoutCol.addView(Ui.bold(Ui.text(this.a, j2.s("nick"), 15.0f, Ui.TEXT)));
                linearLayoutCol.addView(Ui.text(this.a, "NK号 " + j2.s("nk") + " · " + Ui.fullWhen(j2.l("ts")), 12.0f, Ui.SUB));
                linearLayoutRow3.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
                linearLayoutRow3.addView(stTag(j2));
                linearLayoutCsec3.addView(linearLayoutRow3);
                if (j2.s("text").length() > 0) {
                    TextView textViewText2 = Ui.text(this.a, j2.s("text"), 15.0f, Ui.TEXT);
                    textViewText2.setTextIsSelectable(true);
                    textViewText2.setLineSpacing(0.0f, 1.3f);
                    linearLayoutCsec3.addView(textViewText2, Ui.lpm(-1, -2, 0, 10, 0, 0));
                }
                if (j2.a("imgs").size() > 0) {
                    linearLayoutCsec3.addView(imgGrid(fids(j2), false), Ui.lpm(-1, -2, 0, 10, 0, 0));
                }
                linearLayoutCsec3.addView(Ui.text(this.a, (j2.s("ver").length() > 0 ? "App v" + j2.s("ver") : "网页版") + (j2.s("dev").length() > 0 ? " · " + j2.s("dev") : ""), 12.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 8, 0, 0));
                if (j2.s("reply").length() > 0) {
                    TextView textViewText3 = Ui.text(this.a, "我的回复：" + j2.s("reply"), 14.0f, Ui.TEXT);
                    textViewText3.setPadding(Ui.dp(12.0f), Ui.dp(9.0f), Ui.dp(12.0f), Ui.dp(9.0f));
                    textViewText3.setBackground(Ui.round(440241151, 12.0f));
                    linearLayoutCsec3.addView(textViewText3, Ui.lpm(-1, -2, 0, 10, 0, 0));
                }
                LinearLayout linearLayoutRow4 = Ui.row(this.a);
                linearLayoutRow4.setGravity(8388613);
                linearLayoutRow4.addView(sm("删除", 0, new View.OnClickListener() { // from class: com.changliao.im.BugScr.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        BugScr.this.a.confirm("删除这条反馈？", "删除后就找不回来了", "删除", true, new Runnable() { // from class: com.changliao.im.BugScr.5.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BugScr.this.C.send(J.of("t", "c_bug_del", "id", Long.valueOf(j2.l("id"))));
                            }
                        });
                    }
                }));
                if (j2.s("st").equals("new")) {
                    linearLayoutRow4.addView(sm("已读", 0, new View.OnClickListener() { // from class: com.changliao.im.BugScr.6
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            BugScr.this.C.send(J.of("t", "c_bug_read", "id", Long.valueOf(j2.l("id"))));
                        }
                    }), Ui.lpm(-2, -2, 8, 0, 0, 0));
                }
                linearLayoutRow4.addView(sm(j2.s("reply").length() > 0 ? "修改回复" : "回复", 1, new View.OnClickListener() { // from class: com.changliao.im.BugScr.7
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        BugScr.this.a.ask("回复TA（会同时标记为已读）", "例如：收到，下个版本修复～", j2.s("reply"), true, 500, new MainActivity.Str() { // from class: com.changliao.im.BugScr.7.1
                            @Override // com.changliao.im.MainActivity.Str
                            public void ok(String str) {
                                if (str.length() > 0) {
                                    BugScr.this.C.send(J.of("t", "c_bug_read", "id", Long.valueOf(j2.l("id")), "reply", str));
                                }
                            }
                        });
                    }
                }), Ui.lpm(-2, -2, 8, 0, 0, 0));
                linearLayoutCsec3.addView(linearLayoutRow4, Ui.lpm(-1, -2, 0, 12, 0, 0));
                i3 = i4;
            }
        }
        if (i3 == 0) {
            this.body.addView(empty(this.view.equals("new") ? "没有待处理的反馈 🎉" : "还没有人提交过Bug反馈"));
        }
    }

    TextView segB(String str, boolean z, final String str2) {
        TextView textViewBtn = z ? Ui.btn(this.a, str, null) : Ui.btnGray(this.a, str, null);
        textViewBtn.setTextSize(14.0f);
        textViewBtn.setPadding(Ui.dp(14.0f), Ui.dp(8.0f), Ui.dp(14.0f), Ui.dp(8.0f));
        textViewBtn.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.BugScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BugScr.this.view = str2;
                BugScr.this.render();
            }
        });
        return textViewBtn;
    }

    TextView stTag(J j) {
        String str;
        int i;
        String strS = j.s("st");
        if (strS.equals("new")) {
            str = "待处理";
        } else {
            str = (this.C.isOwner ? "" : "系统") + (strS.equals("read") ? "已读" : "已回复");
        }
        TextView textViewText = Ui.text(this.a, str, 12.0f, -1);
        textViewText.setPadding(Ui.dp(8.0f), Ui.dp(2.0f), Ui.dp(8.0f), Ui.dp(2.0f));
        if (strS.equals("new")) {
            i = -24804;
        } else {
            i = strS.equals("read") ? -13912461 : -12743681;
        }
        textViewText.setBackground(Ui.round(i, 10.0f));
        return textViewText;
    }

    void submit() {
        if (this.busy) {
            return;
        }
        String strTrim = this.draft.trim();
        ArrayList arrayList = new ArrayList();
        for (J j : this.imgs) {
            if (!j.has("fid") && !j.has("err")) {
                err("截图还在上传，稍等一下");
                return;
            } else if (j.has("fid")) {
                arrayList.add(j.s("fid"));
            }
        }
        if (strTrim.length() == 0 && arrayList.isEmpty()) {
            err("写点文字或者加张截图吧");
            return;
        }
        this.busy = true;
        this.C.send(J.of("t", "c_bug_post", "text", strTrim, "imgs", arrayList, "ver", MainActivity.VNAME, "dev", App.dev()));
        this.draft = "";
        this.imgs.clear();
        this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.BugScr.11
            @Override // java.lang.Runnable
            public void run() {
                BugScr.this.busy = false;
                if (BugScr.this.alive) {
                    BugScr.this.render();
                }
            }
        }, 600L);
        render();
    }
}
