package com.changliao.im;

import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class PickScr extends Scr {
    final boolean create;
    final Done done;
    final List<String> exclude;
    EditText name;
    TextView ok;
    final String okText;
    final List<String> sel = new ArrayList();
    final String ttl;

    public interface Done {
        void done(List<String> list, String str);
    }

    public PickScr(String str, List<String> list, String str2, boolean z, String str3, Done done) {
        this.ttl = str;
        this.exclude = list == null ? new ArrayList<>() : list;
        this.okText = str2;
        this.create = z;
        this.done = done;
    }

    public static void createGroup(MainActivity mainActivity) {
        mainActivity.push(new PickScr("创建群聊", null, "创建", true, null, new Done() { // from class: com.changliao.im.PickScr.3
            @Override // com.changliao.im.PickScr.Done
            public void done(List<String> list, String str) {
                if (str.length() <= 0) {
                    str = Core.I.myNick() + "的群聊";
                }
                Core.I.send(J.of("t", "c_gcreate", "name", str, "members", new ArrayList(list)));
            }
        }));
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page(this.ttl, true);
        this.ok = tb(this.okText, new View.OnClickListener() { // from class: com.changliao.im.PickScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (PickScr.this.sel.isEmpty() && !PickScr.this.create) {
                    PickScr.this.err("请至少选一个好友");
                    return;
                }
                PickScr.this.done.done(new ArrayList(PickScr.this.sel), PickScr.this.name == null ? "" : PickScr.this.name.getText().toString().trim());
                if (PickScr.this.create) {
                    return;
                }
                PickScr.this.a.back();
            }
        });
        LinearLayout linearLayoutScrollPage = scrollPage(linearLayoutPage);
        if (this.create) {
            TextView textViewText = Ui.text(this.a, "群名称", 13.0f, Ui.SUB);
            textViewText.setPadding(Ui.dp(18.0f), Ui.dp(14.0f), 0, Ui.dp(6.0f));
            linearLayoutScrollPage.addView(textViewText);
            this.name = Ui.input(this.a, "给群起个名字", false);
            this.name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
            linearLayoutScrollPage.addView(this.name, Ui.lpm(-1, -2, 16, 0, 16, 0));
        }
        ArrayList<J> arrayList = new ArrayList();
        for (J j : this.C.fr.objs("friends")) {
            if (!this.exclude.contains(j.s("nk"))) {
                arrayList.add(j);
            }
        }
        if (arrayList.isEmpty()) {
            linearLayoutScrollPage.addView(empty("没有可以选的好友"));
            return linearLayoutPage;
        }
        sec(linearLayoutScrollPage, "选择好友");
        for (final J j2 : arrayList) {
            final Scr.Chk chk = new Scr.Chk(this.a);
            LinearLayout linearLayoutRow = row(linearLayoutScrollPage, av(j2.s("nick"), j2.sn("av"), j2.b("online")), 40, j2.s("nick"), null, null, null);
            linearLayoutRow.addView(chk, 0, Ui.lpm(Ui.dp(22.0f), Ui.dp(22.0f), 0, 0, 12, 0));
            linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.PickScr.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String strS = j2.s("nk");
                    if (PickScr.this.sel.contains(strS)) {
                        PickScr.this.sel.remove(strS);
                    } else {
                        PickScr.this.sel.add(strS);
                    }
                    chk.set(PickScr.this.sel.contains(strS));
                    PickScr.this.ok.setText(PickScr.this.sel.isEmpty() ? PickScr.this.okText : PickScr.this.okText + "(" + PickScr.this.sel.size() + ")");
                }
            });
        }
        return linearLayoutPage;
    }
}
