package com.changliao.im;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public class BgScr extends Scr {
    LinearLayout body;

    void autostart() {
        if (comp("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") || comp("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity") || comp("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity") || comp("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity") || comp("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity") || comp("com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity") || comp("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity") || comp("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager") || comp("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity")) {
            return;
        }
        this.a.toast("请在「应用信息」里找到「自启动」并打开", false);
        details();
    }

    boolean battery() {
        try {
            return ((PowerManager) this.a.getSystemService("power")).isIgnoringBatteryOptimizations(this.a.getPackageName());
        } catch (Throwable th) {
            return false;
        }
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("后台来电设置", true);
        this.body = scrollPage(linearLayoutPage);
        render();
        return linearLayoutPage;
    }

    boolean comp(String str, String str2) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(str, str2));
        intent.putExtra("package_name", this.a.getPackageName());
        intent.putExtra("package_label", "NAINONG Chat");
        return go(intent);
    }

    void details() {
        go(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + this.a.getPackageName())));
    }

    boolean go(Intent intent) {
        try {
            intent.addFlags(268435456);
            if (this.a.getPackageManager().resolveActivity(intent, 0) == null) {
                return false;
            }
            this.a.startActivity(intent);
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    boolean notif() {
        try {
            return ((NotificationManager) this.a.getSystemService("notification")).areNotificationsEnabled();
        } catch (Throwable th) {
            return true;
        }
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        if (this.body != null) {
            render();
        }
    }

    boolean overlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this.a);
    }

    void power() {
        if (comp("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")) {
            return;
        }
        this.a.toast("请在「应用信息 → 耗电/电池」里选择「无限制」或「允许后台活动」", false);
        details();
    }

    void render() {
        this.body.removeAllViews();
        String lowerCase = (Build.MANUFACTURER + " " + Build.BRAND).toLowerCase();
        boolean z = lowerCase.contains("xiaomi") || lowerCase.contains("redmi") || lowerCase.contains("poco");
        TextView textViewText = Ui.text(this.a, "手机系统在你从「最近任务」里划掉 App 时，可能会把 App 整个关掉，这时就收不到消息和来电了。\n按下面几步设置好（每台手机设一次就行），划掉后台也能响铃、弹出接听界面。", 14.0f, -11642519);
        textViewText.setLineSpacing(0.0f, 1.35f);
        textViewText.setPadding(Ui.dp(18.0f), Ui.dp(14.0f), Ui.dp(18.0f), Ui.dp(4.0f));
        this.body.addView(textViewText);
        LinearLayout linearLayoutCsec = csec(this.body);
        step(linearLayoutCsec, "1. 允许后台运行（忽略电池优化）", battery(), new Runnable() { // from class: com.changliao.im.BgScr.1
            @Override // java.lang.Runnable
            public void run() {
                if (BgScr.this.go(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + BgScr.this.a.getPackageName())))) {
                    return;
                }
                BgScr.this.details();
            }
        });
        step(linearLayoutCsec, "2. 允许自启动", false, new Runnable() { // from class: com.changliao.im.BgScr.2
            @Override // java.lang.Runnable
            public void run() {
                BgScr.this.autostart();
            }
        });
        step(linearLayoutCsec, "3. 省电策略改成「无限制」", false, new Runnable() { // from class: com.changliao.im.BgScr.3
            @Override // java.lang.Runnable
            public void run() {
                BgScr.this.power();
            }
        });
        step(linearLayoutCsec, "4. 允许「显示在其他应用上层」（来电直接弹出接听界面）", overlay(), new Runnable() { // from class: com.changliao.im.BgScr.4
            @Override // java.lang.Runnable
            public void run() {
                if (BgScr.this.go(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + BgScr.this.a.getPackageName())))) {
                    return;
                }
                BgScr.this.details();
            }
        });
        step(linearLayoutCsec, "5. 打开通知，并允许「来电」通知悬浮、锁屏显示、响铃", notif(), new Runnable() { // from class: com.changliao.im.BgScr.5
            @Override // java.lang.Runnable
            public void run() {
                if (BgScr.this.go(new Intent("android.settings.CHANNEL_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", BgScr.this.a.getPackageName()).putExtra("android.provider.extra.CHANNEL_ID", "nk_call2")) || BgScr.this.go(new Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", BgScr.this.a.getPackageName()))) {
                    return;
                }
                BgScr.this.details();
            }
        });
        LinearLayout linearLayoutCsec2 = csec(this.body);
        TextView textViewText2 = Ui.text(this.a, "6. 在最近任务里把本 App 锁住（最重要）\n" + (z ? "打开最近任务 → 按住本 App 的卡片（或往下拉一下）→ 点「🔒 锁定」。锁住后点「全部清除」也不会关掉它。" : "打开最近任务 → 按住本 App 的卡片（或往下拉一下）→ 点「锁定」或小锁图标。"), 14.0f, Ui.TEXT);
        textViewText2.setLineSpacing(0.0f, 1.35f);
        textViewText2.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f));
        linearLayoutCsec2.addView(textViewText2);
        LinearLayout linearLayoutCsec3 = csec(this.body);
        TextView textViewText3 = Ui.text(this.a, "设置里的「后台保持在线」也要打开。都设好以后，可以让好友给你打个电话试一下。", 13.0f, Ui.SUB);
        textViewText3.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(16.0f), Ui.dp(12.0f));
        textViewText3.setLineSpacing(0.0f, 1.3f);
        linearLayoutCsec3.addView(textViewText3);
    }

    void step(LinearLayout linearLayout, String str, boolean z, final Runnable runnable) {
        opt(linearLayout, str, z ? "✓ 已开启" : "去设置", true, new View.OnClickListener() { // from class: com.changliao.im.BgScr.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                runnable.run();
            }
        });
    }
}
