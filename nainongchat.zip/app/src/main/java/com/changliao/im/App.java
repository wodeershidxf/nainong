package com.changliao.im;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public class App {
    static Context ctx;
    static boolean inited;
    public static SharedPreferences kv;
    static Thread pollT;
    static volatile String pollTok;
    static final Handler H = new Handler(Looper.getMainLooper());
    static volatile boolean want = true;

    public static String dev() {
        return "Android " + Build.VERSION.RELEASE + " · " + Build.MANUFACTURER + " " + Build.MODEL;
    }

    public static void init(Context context) {
        if (inited) {
            return;
        }
        inited = true;
        ctx = context.getApplicationContext();
        Crash.ver = MainActivity.VNAME;
        Crash.install(ctx.getFilesDir());
        kv = ctx.getSharedPreferences("nk", 0);
        Core.main = new Executor() { // from class: com.changliao.im.App.1
            @Override // java.util.concurrent.Executor
            public void execute(Runnable runnable) {
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    runnable.run();
                } else {
                    App.H.post(runnable);
                }
            }
        };
        Core.timer = new Core.Timer() { // from class: com.changliao.im.App.2
            @Override // com.changliao.im.Core.Timer
            public void later(Runnable runnable, long j) {
                App.H.postDelayed(runnable, j);
            }
        };
        Core.kv = new Core.Kv() { // from class: com.changliao.im.App.3
            @Override // com.changliao.im.Core.Kv
            public String get(String str) {
                return App.kv.getString(str, null);
            }

            @Override // com.changliao.im.Core.Kv
            public void put(String str, String str2) {
                if (str2 == null) {
                    App.kv.edit().remove(str).apply();
                } else {
                    App.kv.edit().putString(str, str2).apply();
                }
            }
        };
        Img.init(ctx);
        Notif.channels(ctx);
        Call.init(ctx);
        Core.I.add(new Core.L() { // from class: com.changliao.im.App.4
            @Override // com.changliao.im.Core.L
            public void on(String str, J j) {
                if (str.equals("note")) {
                    if (Core.I.foreground) {
                        return;
                    }
                    Notif.msg(App.ctx, j.s("title"), j.s("text"), j.sn("conv"));
                } else if (!str.equals("ann_new")) {
                    if (str.equals("poll")) {
                        App.poll(App.ctx);
                    }
                } else {
                    J jO = j.o("a");
                    if (jO == null || Core.I.foreground) {
                        return;
                    }
                    Notif.msg(App.ctx, "📢 " + (jO.s("title").length() > 0 ? jO.s("title") : "系统公告"), jO.s("text"), null);
                }
            }
        });
    }

    public static synchronized void poll(Context context) {
        pollTok = Core.I.token();
        if (pollT == null || !pollT.isAlive()) {
            final Context applicationContext = context.getApplicationContext();
            pollT = new Thread(new Runnable() { // from class: com.changliao.im.App.5
                @Override // java.lang.Runnable
                public void run() {
                    int i;
                    int i2 = 0;
                    while (true) {
                        String str = App.pollTok;
                        if (str == null) {
                            try {
                                Thread.sleep(5000L);
                            } catch (Exception e) {
                                return;
                            }
                        } else {
                            try {
                                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.http() + "/c_poll?tok=" + URLEncoder.encode(str, "UTF-8")).openConnection();
                                httpURLConnection.setConnectTimeout(10000);
                                httpURLConnection.setReadTimeout(40000);
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "UTF-8"));
                                while (true) {
                                    String line = bufferedReader.readLine();
                                    if (line == null) {
                                        break;
                                    }
                                    String[] strArrSplit = line.split("\t", 3);
                                    if (strArrSplit.length >= 3 && (!Core.I.foreground || !Core.I.connected)) {
                                        if (strArrSplit[0].equals("call")) {
                                            Notif.call(applicationContext, strArrSplit[1], strArrSplit[2].contains("视频"));
                                        } else {
                                            Notif.msg(applicationContext, strArrSplit[1], strArrSplit[2], null);
                                        }
                                    }
                                }
                                bufferedReader.close();
                                httpURLConnection.disconnect();
                                i = 0;
                            } catch (Throwable th) {
                                i = i2 + 1;
                                try {
                                    Thread.sleep(Math.min(30000L, 2000 * ((long) i)));
                                } catch (Exception e2) {
                                    return;
                                }
                            }
                            i2 = i;
                        }
                    }
                }
            }, "poll");
            pollT.setDaemon(true);
            pollT.start();
        }
    }

    public static void startBg(Context context) {
        startBg(context, -1);
    }

    public static void startBg(Context context, int i) {
        if (kv.getBoolean("keep", true) || i > 0) {
            want = true;
            try {
                Intent intent = new Intent(context, (Class<?>) Keeper.class);
                if (i >= 0) {
                    intent.putExtra("ft", i);
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(intent);
                } else {
                    context.startService(intent);
                }
            } catch (Throwable th) {
                Crash.note(th);
            }
        }
    }

    public static void stopBg(Context context) {
        want = false;
        try {
            context.stopService(new Intent(context, (Class<?>) Keeper.class));
        } catch (Throwable th) {
        }
        pollTok = null;
    }
}
