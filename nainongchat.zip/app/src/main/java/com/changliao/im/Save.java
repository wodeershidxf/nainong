package com.changliao.im;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;

/* JADX INFO: loaded from: classes.dex */
public class Save {
    static void copy(InputStream inputStream, OutputStream outputStream) throws Exception {
        byte[] bArr = new byte[65536];
        while (true) {
            int i = inputStream.read(bArr);
            if (i <= 0) {
                inputStream.close();
                outputStream.close();
                return;
            }
            outputStream.write(bArr, 0, i);
        }
    }

    public static void save(final MainActivity mainActivity, final J j, final String str) {
        if (j == null) {
            return;
        }
        mainActivity.toast("正在保存…", false);
        new Thread(new Runnable() { // from class: com.changliao.im.Save.1
            @Override // java.lang.Runnable
            public void run() {
                String str2;
                final String str3;
                Uri uri;
                boolean z = true;
                try {
                    File fileDownload = Up.download(mainActivity, j.s("id"), j.s("name"), null);
                    String strS = j.s("name").length() > 0 ? j.s("name") : "file";
                    String strGuessContentTypeFromName = URLConnection.guessContentTypeFromName(strS);
                    boolean z2 = str.equals("img") || (strGuessContentTypeFromName != null && strGuessContentTypeFromName.startsWith("image/"));
                    if (!str.equals("video") && (strGuessContentTypeFromName == null || !strGuessContentTypeFromName.startsWith("video/"))) {
                        z = false;
                    }
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_display_name", strS);
                        if (strGuessContentTypeFromName != null) {
                            contentValues.put("mime_type", strGuessContentTypeFromName);
                        }
                        if (z2) {
                            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                            contentValues.put("relative_path", Environment.DIRECTORY_PICTURES + "/NAINONG Chat");
                            str3 = "相册";
                        } else if (z) {
                            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                            contentValues.put("relative_path", Environment.DIRECTORY_MOVIES + "/NAINONG Chat");
                            str3 = "相册";
                        } else {
                            uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                            contentValues.put("relative_path", Environment.DIRECTORY_DOWNLOADS + "/NAINONG Chat");
                            str3 = "「下载/NAINONG Chat」文件夹";
                        }
                        ContentResolver contentResolver = mainActivity.getContentResolver();
                        Uri uriInsert = contentResolver.insert(uri, contentValues);
                        if (uriInsert == null) {
                            throw new Exception("系统不让保存");
                        }
                        Save.copy(new FileInputStream(fileDownload), contentResolver.openOutputStream(uriInsert));
                    } else {
                        if (z2) {
                            str2 = Environment.DIRECTORY_PICTURES;
                        } else {
                            str2 = z ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS;
                        }
                        File file = new File(Environment.getExternalStoragePublicDirectory(str2), "NAINONG Chat");
                        file.mkdirs();
                        File file2 = new File(file, strS);
                        Save.copy(new FileInputStream(fileDownload), new FileOutputStream(file2));
                        mainActivity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file2)));
                        str3 = (z2 || z) ? "相册" : "「下载/NAINONG Chat」文件夹";
                    }
                    mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Save.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            mainActivity.toast("已保存到" + str3, false);
                        }
                    });
                } catch (Throwable th) {
                    mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Save.1.2
                        @Override // java.lang.Runnable
                        public void run() {
                            mainActivity.toast("保存失败：" + th.getMessage(), true);
                        }
                    });
                }
            }
        }).start();
    }
}
