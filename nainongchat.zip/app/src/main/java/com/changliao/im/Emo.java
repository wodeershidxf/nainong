package com.changliao.im;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.os.SystemClock;
import android.text.TextPaint;
import android.view.View;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/* JADX INFO: loaded from: classes.dex */
public class Emo extends View {
    static final int ANGRY = 8;
    static final int BOUNCE = 0;
    static final int BROKEN = 14;
    static final int CLAP = 12;
    static final int[] CONF;
    static final int COOL = 4;
    static final int CRY = 7;
    static final int DRINK = 22;
    static final int FIRE = 15;
    static final int FLEX = 24;
    static final HashMap<String, Integer> KIND = new HashMap<>();
    static final int KISS = 3;
    static final int LAUGH = 1;
    static final int LOVE = 2;
    static final int MUSIC = 21;
    static final int NO = 17;
    static final int PARTY = 10;
    static final int PRAY = 25;
    static final int RAIN = 19;
    static final int ROLL = 26;
    static final int SHOCK = 9;
    static final int SHOUT = 23;
    static final int SLEEP = 6;
    static final int STAR = 16;
    static final int SUN = 18;
    static final int SWAY = 20;
    static final int THINK = 5;
    static final int THUMB = 11;
    static final int WAVE = 13;
    static final HashMap<String, Bitmap> cache;
    static final HashMap<String, Long> recent;
    Bitmap bmp;
    final Paint cp;
    final String e;
    String key;
    final int kind;
    long lastFrame;
    float lastSpawn;
    final boolean loop;
    final Paint p;
    final List<Bitmap> pb;
    final List<float[]> ps;
    final Random rnd;
    final Paint sh;
    long t0;
    final boolean vec;
    final Paint wp;

    static {
        k(1, "😀 😁 😂 🤣 😅 😆 😄 😃 😹");
        k(2, "😍 🥰 ❤️ ❤ 💕 💖 💗 💓 💞 🤩 😻");
        k(3, "😘 😚 😙 💋");
        k(4, "😎 😏 😇 😊 ☺️ 🙂 🤗");
        k(ROLL, "🙄 🤔 🧐 😐 😑");
        k(6, "😴 💤 🥱 😪");
        k(CRY, "😭 🥺 😢 😿 😞 😔");
        k(ANGRY, "😡 😤 😠 🤬 👿");
        k(SHOCK, "😱 😨 😰 🤯 😳 😲");
        k(PARTY, "🥳 🎉 🎊 🎁 🎂 🎈");
        k(THUMB, "👍 👎 👌 ✌️ ✌ 🤞 🤟 🤘 👊 ✊");
        k(CLAP, "👏 🙌");
        k(WAVE, "👋 🤚 ✋");
        k(FLEX, "💪");
        k(PRAY, "🙏 🤝");
        k(BROKEN, "💔");
        k(FIRE, "🔥 💥");
        k(STAR, "⭐ 🌟 ✨ 💯 ✅ 🏆 🥇");
        k(NO, "❌ ❓ ❗ ⛔ 🚫");
        k(SUN, "☀️ ☀ 🌞");
        k(RAIN, "🌧️ 🌧 ☔ ⛈️");
        k(SWAY, "🌙 🌈 🌸 🌹 🍀 🌲 🌷 🌻");
        k(MUSIC, "🎵 🎶 🎤");
        k(DRINK, "☕ 🍺 🍻 🧋 🍵");
        k(SHOUT, "📢 📣");
        k(2, "😋 🤤");
        k(1, "🤪 😜 😝 😛");
        recent = new HashMap<>();
        cache = new HashMap<>();
        CONF = new int[]{-42401, -16059, -12723049, -11563777, -4883457, -29992};
    }

    public Emo(Context context, String str, boolean z) {
        super(context);
        this.t0 = -1L;
        this.rnd = new Random();
        this.ps = new ArrayList();
        this.pb = new ArrayList();
        this.p = new Paint(3);
        this.sh = new Paint(1);
        this.wp = new Paint(1);
        this.cp = new Paint(1);
        this.e = str;
        Integer num = KIND.get(strip(str));
        this.kind = num == null ? 0 : num.intValue();
        this.loop = z;
        this.vec = Vec.has(str);
        Night.keep(this);
        setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.Emo.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Emo.this.play();
            }
        });
        setOnLongClickListener(new View.OnLongClickListener() { // from class: com.changliao.im.Emo.2
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                Object parent = Emo.this.getParent();
                return (parent instanceof View) && ((View) parent).performLongClick();
            }
        });
    }

    static float beat(float f) {
        float f2 = f % 1.0f;
        return (float) ((Math.exp(-Math.pow((((double) f2) - 0.32d) / 0.07d, 2.0d)) * 0.7d) + Math.exp(-Math.pow((((double) f2) - 0.08d) / 0.07d, 2.0d)));
    }

    static float env(float f, float f2) {
        if (f >= f2) {
            return 0.0f;
        }
        return ((float) Math.exp(((-2.2d) * ((double) f)) / ((double) f2))) * (1.0f - ((f / f2) * 0.3f));
    }

    static Bitmap glyph(String str, int i) {
        String str2 = str + "@" + i;
        Bitmap bitmap = cache.get(str2);
        if (bitmap != null) {
            return bitmap;
        }
        if (cache.size() > 120) {
            cache.clear();
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(Math.max(1, i), Math.max(1, i), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        TextPaint textPaint = new TextPaint(1);
        textPaint.setTextSize(i * 0.8f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
        canvas.drawText(str, i / 2.0f, (i / 2.0f) - ((fontMetrics.descent + fontMetrics.ascent) / 2.0f), textPaint);
        cache.put(str2, bitmapCreateBitmap);
        return bitmapCreateBitmap;
    }

    static boolean isEmoji(String str) {
        int iCodePointAt = str.codePointAt(0);
        if (iCodePointAt >= 126976 && iCodePointAt <= 129791) {
            return true;
        }
        if (iCodePointAt >= 9728 && iCodePointAt <= 10175) {
            return true;
        }
        if (iCodePointAt >= 11008 && iCodePointAt <= 11263) {
            return true;
        }
        if ((iCodePointAt >= 8592 && iCodePointAt <= 8703 && str.contains("️")) || iCodePointAt == 8482 || iCodePointAt == 8505 || iCodePointAt == 12336 || iCodePointAt == 12349 || iCodePointAt == 12951 || iCodePointAt == 12953 || iCodePointAt == 9410) {
            return true;
        }
        if ((iCodePointAt == 169 || iCodePointAt == 174) && str.contains("️")) {
            return true;
        }
        if (iCodePointAt < 8960 || iCodePointAt > 9215) {
            return str.length() >= 2 && str.contains("⃣");
        }
        return true;
    }

    static float jump(float f, float f2) {
        if (f < 0.0f || f > f2) {
            return 0.0f;
        }
        return sin((3.141592653589793d * ((double) f)) / ((double) f2));
    }

    static void k(int i, String str) {
        for (String str2 : str.split(" ")) {
            KIND.put(strip(str2), Integer.valueOf(i));
        }
    }

    static float loopT(float f) {
        return f % 2.2f;
    }

    public static List<String> only(String str) {
        if (str == null) {
            return null;
        }
        String strTrim = str.trim();
        if (strTrim.length() == 0 || strTrim.length() > 40) {
            return null;
        }
        BreakIterator characterInstance = BreakIterator.getCharacterInstance();
        characterInstance.setText(strTrim);
        ArrayList arrayList = new ArrayList();
        int iFirst = characterInstance.first();
        int i = iFirst;
        for (int next = characterInstance.next(); next != -1; next = characterInstance.next()) {
            String strSubstring = strTrim.substring(i, next);
            if (strSubstring.trim().length() != 0) {
                if (!isEmoji(strSubstring)) {
                    return null;
                }
                arrayList.add(strSubstring);
                if (arrayList.size() > 3) {
                    return null;
                }
            }
            i = next;
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return arrayList;
    }

    static float punch(float f) {
        float fSin = 0.0f;
        float fSin2 = f < 0.35f ? sin((((double) f) * 3.141592653589793d) / 0.3499999940395355d) : 0.0f;
        if (f > 0.45f && f < 0.8f) {
            fSin = 0.6f * sin((((double) (f - 0.45f)) * 3.141592653589793d) / 0.3499999940395355d);
        }
        return fSin + fSin2;
    }

    static float sin(double d) {
        return (float) Math.sin(d);
    }

    static String strip(String str) {
        return str.replace("️", "");
    }

    static Bitmap zBitmap(int i) {
        String str = "z@" + i;
        Bitmap bitmap = cache.get(str);
        if (bitmap != null) {
            return bitmap;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(Math.max(1, i), Math.max(1, i), Bitmap.Config.ARGB_8888);
        Paint paint = new Paint(1);
        paint.setColor(-8745729);
        paint.setTextSize(i * 0.9f);
        paint.setFakeBoldText(true);
        paint.setTextAlign(Paint.Align.CENTER);
        new Canvas(bitmapCreateBitmap).drawText("z", i / 2.0f, i * 0.8f, paint);
        cache.put(str, bitmapCreateBitmap);
        return bitmapCreateBitmap;
    }

    void add(String str, int i) {
        float fNextFloat;
        float fNextFloat2;
        float f;
        float fNextFloat3;
        float width = getWidth();
        float height = getHeight();
        float fMin = Math.min(width, height) * 0.66f;
        float fNextFloat4 = width / 2.0f;
        float fNextFloat5 = height / 2.0f;
        float f2 = 0.26f * fMin;
        switch (i) {
            case 1:
                fNextFloat4 += (this.rnd.nextBoolean() ? -1 : 1) * fMin * 0.3f;
                fNextFloat5 -= 0.05f * fMin;
                fNextFloat = (fNextFloat4 < width / 2.0f ? -1 : 1) * fMin * (0.6f + (this.rnd.nextFloat() * 0.6f));
                fNextFloat2 = (-fMin) * 0.9f;
                f = 0.9f;
                fNextFloat3 = fMin * 0.16f;
                break;
            case 2:
                fNextFloat4 += (this.rnd.nextFloat() - 0.5f) * fMin * 0.8f;
                fNextFloat5 -= fMin * 0.2f;
                fNextFloat = (this.rnd.nextFloat() - 0.5f) * fMin * 0.4f;
                fNextFloat2 = (-fMin) * (0.6f + (this.rnd.nextFloat() * 0.4f));
                f = 1.3f;
                fNextFloat3 = (0.14f + (this.rnd.nextFloat() * 0.1f)) * fMin;
                break;
            case 3:
                fNextFloat4 += 0.25f * fMin;
                fNextFloat5 -= 0.1f * fMin;
                fNextFloat = fMin * 0.7f;
                fNextFloat2 = (-fMin) * 0.5f;
                f = 1.0f;
                fNextFloat3 = 0.18f * fMin;
                break;
            case 4:
                fNextFloat4 += fMin * 0.3f;
                fNextFloat5 -= fMin * 0.3f;
                fNextFloat = fMin * 0.25f;
                fNextFloat2 = (-fMin) * 0.45f;
                f = 1.6f;
                fNextFloat3 = fMin * 0.2f;
                break;
            case 5:
                fNextFloat4 += (this.rnd.nextBoolean() ? -1 : 1) * fMin * 0.22f;
                fNextFloat5 += 0.02f * fMin;
                fNextFloat = (this.rnd.nextFloat() - 0.5f) * fMin * 0.2f;
                fNextFloat2 = fMin * 0.3f;
                f = 1.0f;
                fNextFloat3 = 0.14f * fMin;
                break;
            case 6:
                fNextFloat4 += (this.rnd.nextFloat() - 0.5f) * fMin;
                fNextFloat5 += (this.rnd.nextFloat() - 0.5f) * fMin;
                fNextFloat3 = fMin * 0.16f;
                f = 0.5f;
                fNextFloat2 = 0.0f;
                fNextFloat = 0.0f;
                break;
            case CRY /* 7 */:
                fNextFloat4 += (this.rnd.nextFloat() - 0.5f) * fMin * 0.7f;
                fNextFloat5 += 0.25f * fMin;
                fNextFloat2 = fMin * 1.6f;
                fNextFloat3 = 0.1f * fMin;
                f = 0.5f;
                fNextFloat = 0.0f;
                break;
            case ANGRY /* 8 */:
                fNextFloat4 += fMin * 0.2f;
                fNextFloat5 -= fMin * 0.2f;
                fNextFloat = (this.rnd.nextFloat() - 0.3f) * fMin * 0.5f;
                fNextFloat2 = (-fMin) * 0.7f;
                f = 1.2f;
                fNextFloat3 = fMin * 0.2f;
                break;
            case SHOCK /* 9 */:
                fNextFloat4 += (this.rnd.nextFloat() - 0.5f) * fMin * 0.3f;
                fNextFloat5 -= 0.35f * fMin;
                fNextFloat = (this.rnd.nextFloat() - 0.5f) * fMin * 0.2f;
                fNextFloat2 = (-fMin) * 0.5f;
                f = 1.2f;
                fNextFloat3 = fMin * 0.16f;
                break;
            default:
                double dNextDouble = this.rnd.nextDouble() * 3.141592653589793d * 2.0d;
                fNextFloat = 1.1f * ((float) Math.cos(dNextDouble)) * fMin;
                fNextFloat2 = ((float) Math.sin(dNextDouble)) * fMin * 1.1f;
                f = 0.7f;
                fNextFloat3 = fMin * 0.16f;
                break;
        }
        this.pb.add(str.equals("z") ? zBitmap((int) fNextFloat3) : glyph(str, (int) Math.max(4.0f, fNextFloat3)));
        this.ps.add(new float[]{fNextFloat4, fNextFloat5, fNextFloat, fNextFloat2, 0.0f, (this.rnd.nextFloat() - 0.5f) * 180.0f, 0.0f, f, fNextFloat3, i, this.pb.size() - 1, 0.0f});
    }

    void burst(String str, int i) {
        if (this.ps.size() > 40) {
            return;
        }
        for (int i2 = 0; i2 < i; i2++) {
            add(str, PARTY);
        }
    }

    void confetti(int i) {
        if (this.ps.size() > 60) {
            return;
        }
        float width = getWidth();
        float height = getHeight();
        float fMin = 0.66f * Math.min(width, height);
        for (int i2 = 0; i2 < i; i2++) {
            double dNextDouble = (-1.5707963267948966d) + ((this.rnd.nextDouble() - 0.5d) * 2.2d);
            float fNextFloat = (1.2f + (this.rnd.nextFloat() * 1.2f)) * fMin;
            this.ps.add(new float[]{width / 2.0f, height / 2.0f, ((float) Math.cos(dNextDouble)) * fNextFloat, ((float) Math.sin(dNextDouble)) * fNextFloat, this.rnd.nextFloat() * 360.0f, (this.rnd.nextFloat() - 0.5f) * 720.0f, 0.0f, 1.4f, 0.07f * fMin, 11.0f, -1.0f, CONF[this.rnd.nextInt(CONF.length)]});
        }
    }

    boolean drawParticles(Canvas canvas, int i) {
        float f;
        float f2;
        boolean z;
        float fSin;
        long jUptimeMillis = SystemClock.uptimeMillis();
        float fMin = this.lastFrame == 0 ? 0.016f : Math.min(0.05f, (jUptimeMillis - this.lastFrame) / 1000.0f);
        this.lastFrame = jUptimeMillis;
        boolean z2 = false;
        int size = this.ps.size() - 1;
        while (size >= 0) {
            float[] fArr = this.ps.get(size);
            fArr[6] = fArr[6] + fMin;
            if (fArr[6] >= fArr[CRY]) {
                this.ps.remove(size);
                z = z2;
            } else {
                int i2 = (int) fArr[SHOCK];
                if (i2 == THUMB) {
                    f = i * 2.2f;
                } else if (i2 == 1 || i2 == 5) {
                    f = i * 2.4f;
                } else {
                    f = (i2 == CLAP || i2 == 2 || i2 == 4 || i2 == ANGRY || i2 == SHOCK || i2 == PARTY) ? 0.0f : 0.0f;
                }
                fArr[3] = (f * fMin) + fArr[3];
                if (i2 == THUMB) {
                    fArr[2] = fArr[2] * 0.985f;
                    fArr[3] = fArr[3] * 0.985f;
                }
                fArr[0] = fArr[0] + (fArr[2] * fMin);
                fArr[1] = fArr[1] + (fArr[3] * fMin);
                fArr[4] = fArr[4] + (fArr[5] * fMin);
                float f3 = fArr[6] / fArr[CRY];
                if (f3 < 0.15f) {
                    f2 = f3 / 0.15f;
                } else {
                    f2 = f3 > 0.65f ? (1.0f - f3) / 0.35f : 1.0f;
                }
                if (i2 == THUMB || i2 == CLAP) {
                    this.cp.setColor((int) fArr[THUMB]);
                    this.cp.setAlpha((int) (f2 * 255.0f));
                    canvas.save();
                    canvas.rotate(fArr[4], fArr[0], fArr[1]);
                    if (i2 == THUMB) {
                        canvas.drawRect(fArr[0] - fArr[ANGRY], fArr[1] - (fArr[ANGRY] * 0.5f), fArr[0] + fArr[ANGRY], fArr[1] + (fArr[ANGRY] * 0.5f), this.cp);
                    } else {
                        canvas.drawCircle(fArr[0], fArr[1], fArr[ANGRY] * (1.0f - (f3 * 0.6f)), this.cp);
                    }
                    canvas.restore();
                    z = true;
                } else {
                    Bitmap bitmap = this.pb.get((int) fArr[PARTY]);
                    if (i2 == 2 || i2 == 4 || i2 == ANGRY) {
                        fSin = (f3 * 0.6f) + 0.7f;
                    } else {
                        fSin = (i2 == 6 || i2 == PARTY) ? ((float) Math.sin(3.141592653589793d * ((double) f3))) * 1.2f : 1.0f;
                    }
                    this.p.setAlpha((int) (Math.max(0.0f, Math.min(1.0f, f2)) * 255.0f));
                    canvas.save();
                    canvas.translate(fArr[0], fArr[1]);
                    canvas.rotate((i2 == 2 || i2 == 4 || i2 == ANGRY) ? sin(fArr[6] * 5.0f) * 15.0f : 0.0f);
                    canvas.scale(fSin, fSin);
                    canvas.drawBitmap(bitmap, (-bitmap.getWidth()) / 2.0f, (-bitmap.getHeight()) / 2.0f, this.p);
                    canvas.restore();
                    z = true;
                }
            }
            size--;
            z2 = z;
        }
        this.p.setAlpha(255);
        if (this.ps.isEmpty()) {
            this.pb.clear();
        }
        if (!z2) {
            this.lastFrame = 0L;
        }
        return z2;
    }

    void drawWaves(Canvas canvas, float f, float f2, int i, float f3) {
        this.wp.setStyle(Paint.Style.STROKE);
        this.wp.setStrokeCap(Paint.Cap.ROUND);
        this.wp.setStrokeWidth(Math.max(2.0f, i * 0.06f));
        for (int i2 = 0; i2 < 3; i2++) {
            float f4 = (1.4f * f3) - (i2 * 0.18f);
            if (f4 >= 0.0f && f4 <= 1.0f) {
                float f5 = ((0.42f * f4) + 0.18f) * i;
                this.wp.setColor(Color.argb((int) ((1.0f - f4) * 230.0f), 255, 160, 40));
                canvas.drawArc(new RectF(f - f5, f2 - f5, f + f5, f5 + f2), -40.0f, 80.0f, false, this.wp);
            }
        }
    }

    public Emo key(String str) {
        this.key = str;
        return this;
    }

    String kindEmojiSteam() {
        return (strip(this.e).equals("🍺") || strip(this.e).equals("🍻")) ? "\u1fae7" : "💨";
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Long l = this.key == null ? null : recent.get(this.key);
        long jUptimeMillis = SystemClock.uptimeMillis();
        if (l != null && jUptimeMillis - l.longValue() < 2500) {
            this.t0 = l.longValue();
            invalidate();
            return;
        }
        play();
        if (this.key != null) {
            if (recent.size() > 200) {
                recent.clear();
            }
            recent.put(this.key, Long.valueOf(this.t0));
        }
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.t0 = -1L;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        int i;
        float f;
        float f2;
        float fSin;
        float f3;
        int width = getWidth();
        int height = getHeight();
        if (width == 0) {
            return;
        }
        int iMin = (int) (Math.min(width, height) * 0.66f);
        float fUptimeMillis = this.t0 < 0 ? 99.0f : (SystemClock.uptimeMillis() - this.t0) / 1000.0f;
        if (this.vec) {
            float fDur = Vec.dur(this.e);
            boolean z = this.kind == SHOUT;
            float fMin = z ? fUptimeMillis : Math.min(fUptimeMillis, fDur);
            float fMin2 = Math.min(width, height) * 0.86f;
            canvas.save();
            canvas.translate((width / 2.0f) - (fMin2 / 2.0f), (height / 2.0f) - (fMin2 / 2.0f));
            canvas.scale(fMin2 / 100.0f, fMin2 / 100.0f);
            if (!z && width > Ui.dp(40.0f)) {
                this.sh.setColor(570425344);
                canvas.drawOval(new RectF(30.0f, 95.0f, 70.0f, 101.0f), this.sh);
            }
            Vec.draw(canvas, this.e, fMin);
            canvas.restore();
            if (!z) {
                if (fUptimeMillis < fDur) {
                    postInvalidateOnAnimation();
                    return;
                }
                return;
            } else {
                float f4 = fUptimeMillis % 2.2f;
                if (f4 < 0.95f) {
                    postInvalidateOnAnimation();
                    return;
                } else {
                    postInvalidateDelayed((long) ((2.2f - f4) * 1000.0f));
                    return;
                }
            }
        }
        if (this.bmp == null || this.bmp.getWidth() != iMin) {
            this.bmp = glyph(this.e, iMin);
        }
        float fEnv = fUptimeMillis < 2.2f ? env(fUptimeMillis, 2.2f) : 0.0f;
        float f5 = width / 2.0f;
        float f6 = (height / 2.0f) + (this.kind == SHOUT ? 0.0f : height * 0.04f);
        float fSin2 = 0.0f;
        float f7 = 0.0f;
        float f8 = 1.0f;
        float f9 = f6 + (iMin / 2.0f);
        float f10 = iMin / 100.0f;
        switch (this.kind) {
            case 1:
                fSin = sin(28.0f * fUptimeMillis) * 9.0f * fEnv;
                f7 = (-Math.abs(sin(9.0f * fUptimeMillis))) * 10.0f * f10 * fEnv;
                float fSin3 = 1.0f + (fEnv * sin(18.0f * fUptimeMillis) * 0.05f);
                spawn(fUptimeMillis, 2.2f, 0.16f, "💧", 1);
                i = 0;
                f = f9;
                f2 = f5;
                f3 = 1.0f;
                f8 = fSin3;
                break;
            case 2:
                float fBeat = 1.0f + ((fUptimeMillis < 2.2f ? 1 : 0) * 0.22f * beat(fUptimeMillis));
                spawn(fUptimeMillis, 2.2f, 0.22f, "❤️", 2);
                i = 0;
                f = f6;
                f2 = f5;
                fSin = 0.0f;
                f3 = fBeat;
                f8 = fBeat;
                break;
            case 3:
                float fBeat2 = 1.0f + ((fUptimeMillis < 2.2f ? 1 : 0) * beat(fUptimeMillis) * 0.15f);
                spawn(fUptimeMillis, 2.2f, 0.3f, "❤️", 3);
                i = 0;
                f = f6;
                f2 = f5;
                fSin = (-8.0f) * fEnv;
                f3 = fBeat2;
                f8 = fBeat2;
                break;
            case 4:
                float fSin4 = sin(5.0f * fUptimeMillis) * 12.0f * fEnv;
                float f11 = fEnv * (-Math.abs(sin(5.0f * fUptimeMillis))) * 6.0f * f10;
                if (fUptimeMillis > 0.3f && fUptimeMillis < 0.35f) {
                    burst("✨", 3);
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = fSin4;
                    f3 = 1.0f;
                    f7 = f11;
                } else {
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = fSin4;
                    f3 = 1.0f;
                    f7 = f11;
                }
                break;
            case 5:
            default:
                float fJump = jump(fUptimeMillis, 0.7f) + (jump(fUptimeMillis - 0.75f, 0.55f) * 0.5f);
                float f12 = (-fJump) * 16.0f * f10;
                float fMax = 1.0f - (fUptimeMillis < 1.4f ? fEnv * Math.max(0.0f, 0.1f - (fJump * 0.4f)) : 0.0f);
                i = 0;
                f = f9;
                f2 = f5;
                fSin = 0.0f;
                f3 = fMax;
                f8 = 2.0f - fMax;
                f7 = f12;
                break;
            case 6:
                float fSin5 = sin(3.0f * fUptimeMillis) * 6.0f * f10 * (fUptimeMillis < 2.2f ? 1 : 0);
                fSin = sin(((double) fUptimeMillis) * 1.5d) * 6.0f * fEnv;
                spawn(fUptimeMillis, 2.2f, 0.45f, "z", 4);
                i = 0;
                f = f9;
                f2 = f5;
                f3 = 1.0f;
                f7 = fSin5;
                break;
            case CRY /* 7 */:
                fSin2 = sin(34.0f * fUptimeMillis) * 4.0f * f10 * fEnv;
                float fAbs = 1.0f - (fEnv * (Math.abs(sin(6.0f * fUptimeMillis)) * 0.05f));
                spawn(fUptimeMillis, 2.2f, 0.12f, "💧", 5);
                i = 0;
                f = f9;
                f2 = f5;
                fSin = 0.0f;
                f3 = fAbs;
                break;
            case ANGRY /* 8 */:
                float fSin6 = sin(46.0f * fUptimeMillis) * 5.0f * f10 * fEnv;
                float f13 = 1.0f + (0.14f * fEnv);
                int iAbs = (int) (fEnv * 110.0f * Math.abs(sin(8.0f * fUptimeMillis)));
                if (fUptimeMillis > 0.15f && fUptimeMillis < 0.2f) {
                    burst("💢", 3);
                    i = iAbs;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = f13;
                    f8 = f13;
                    fSin2 = fSin6;
                } else {
                    i = iAbs;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = f13;
                    f8 = f13;
                    fSin2 = fSin6;
                }
                break;
            case SHOCK /* 9 */:
                float fEnv2 = fUptimeMillis < 0.25f ? ((fUptimeMillis < 0.25f ? fUptimeMillis / 0.25f : 1.0f) * 0.6f) + 0.7f : 1.0f + (0.3f * env(fUptimeMillis - 0.25f, 0.6f));
                float fSin7 = fUptimeMillis > 0.3f ? fEnv * sin(60.0f * fUptimeMillis) * 3.0f * f10 : 0.0f;
                i = 0;
                f = f6;
                f2 = f5;
                fSin = 0.0f;
                f3 = fEnv2;
                f8 = fEnv2;
                fSin2 = fSin7;
                break;
            case PARTY /* 10 */:
                float fJump2 = jump(fUptimeMillis, 0.9f);
                float f14 = (-fJump2) * 28.0f * f10;
                float f15 = 1.0f + ((1.0f - fJump2) * 0.08f * fEnv);
                float f16 = 1.0f - (fEnv * ((1.0f - fJump2) * 0.08f));
                float f17 = (fUptimeMillis < 0.9f ? 1 : 0) * 12.0f * fJump2;
                if (fUptimeMillis > 0.05f && fUptimeMillis < 0.1f) {
                    confetti(ROLL);
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = f17;
                    f3 = f16;
                    f8 = f15;
                    f7 = f14;
                } else {
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = f17;
                    f3 = f16;
                    f8 = f15;
                    f7 = f14;
                }
                break;
            case THUMB /* 11 */:
                float fPunch = punch(fUptimeMillis);
                float f18 = 1.0f + (0.28f * fPunch);
                i = 0;
                f = (iMin * 0.3f) + f6;
                f2 = f5;
                fSin = (-16.0f) * fPunch;
                f3 = f18;
                f8 = f18;
                break;
            case CLAP /* 12 */:
                float fAbs2 = 1.0f - ((fUptimeMillis < 1.4f ? 1 : 0) * (0.16f * Math.abs(sin(16.0f * fUptimeMillis))));
                float fAbs3 = ((fUptimeMillis < 1.4f ? 1 : 0) * 0.05f * Math.abs(sin(16.0f * fUptimeMillis))) + 1.0f;
                if (fUptimeMillis >= 1.4f) {
                    i = 0;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = fAbs3;
                    f8 = fAbs2;
                } else {
                    spawn(fUptimeMillis, 1.4f, 0.2f, "✨", 6);
                    i = 0;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = fAbs3;
                    f8 = fAbs2;
                }
                break;
            case WAVE /* 13 */:
                i = 0;
                f = (iMin / 2.0f) + f6;
                f2 = (iMin * 0.15f) + f5;
                fSin = sin(13.0f * fUptimeMillis) * 24.0f * fEnv;
                f3 = 1.0f;
                break;
            case BROKEN /* 14 */:
                float fSin8 = fUptimeMillis < 0.8f ? sin(50.0f * fUptimeMillis) * 4.0f * f10 : 0.0f;
                float fEnv3 = (fUptimeMillis <= 0.8f || fUptimeMillis >= 2.2f) ? 0.0f : env(fUptimeMillis - 0.8f, 1.2f) * 8.0f * f10;
                i = 0;
                f = f9;
                f2 = f5;
                fSin = (fUptimeMillis <= 0.8f || fUptimeMillis >= 2.2f) ? 0.0f : 8.0f * env(fUptimeMillis - 0.8f, 1.2f);
                f3 = 1.0f;
                f7 = fEnv3;
                fSin2 = fSin8;
                break;
            case FIRE /* 15 */:
                float fSin9 = 1.0f + ((fUptimeMillis < 2.2f ? 1 : 0) * 0.08f * sin(22.0f * fUptimeMillis));
                float fSin10 = 1.0f - ((fUptimeMillis < 2.2f ? 1 : 0) * (0.05f * sin(22.0f * fUptimeMillis)));
                float fSin11 = sin(9.0f * fUptimeMillis) * 3.0f * fEnv;
                sparks(fUptimeMillis, 2.2f);
                i = 0;
                f = f9;
                f2 = f5;
                fSin = fSin11;
                f3 = fSin9;
                f8 = fSin10;
                break;
            case STAR /* 16 */:
                float fCos = (float) Math.cos(((double) (fUptimeMillis < 0.9f ? fUptimeMillis / 0.9f : 1.0f)) * 3.141592653589793d * 2.0d);
                float fEnv4 = 1.0f + (0.18f * env(fUptimeMillis, 1.2f));
                if (fUptimeMillis > 0.85f && fUptimeMillis < 0.9f) {
                    burst("✨", 5);
                    i = 0;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = fEnv4;
                    f8 = fCos;
                } else {
                    i = 0;
                    f = f6;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = fEnv4;
                    f8 = fCos;
                }
                break;
            case NO /* 17 */:
                float fSin12 = sin(26.0f * fUptimeMillis) * 8.0f * f10 * fEnv;
                i = 0;
                f = f9;
                f2 = f5;
                fSin = sin(26.0f * fUptimeMillis) * 5.0f * fEnv;
                f3 = 1.0f;
                fSin2 = fSin12;
                break;
            case SUN /* 18 */:
                float f19 = fUptimeMillis * 40.0f * (fUptimeMillis < 2.2f ? 1 : 0);
                float fSin13 = 1.0f + (0.06f * sin(4.0f * fUptimeMillis));
                i = 0;
                f = f6;
                f2 = f5;
                fSin = f19;
                f3 = fSin13;
                f8 = fSin13;
                break;
            case RAIN /* 19 */:
                fSin2 = sin(2.0f * fUptimeMillis) * 3.0f * f10 * fEnv;
                spawn(fUptimeMillis, 2.2f, 0.08f, "💧", CRY);
                i = 0;
                f = f9;
                f2 = f5;
                fSin = 0.0f;
                f3 = 1.0f;
                break;
            case SWAY /* 20 */:
                i = 0;
                f = f9;
                f2 = f5;
                fSin = sin(4.0f * fUptimeMillis) * 10.0f * fEnv;
                f3 = 1.0f;
                break;
            case MUSIC /* 21 */:
                float f20 = (-Math.abs(sin(7.0f * fUptimeMillis))) * 8.0f * f10 * fEnv;
                fSin = sin(7.0f * fUptimeMillis) * 10.0f * fEnv;
                spawn(fUptimeMillis, 2.2f, 0.35f, "🎵", ANGRY);
                i = 0;
                f = f9;
                f2 = f5;
                f3 = 1.0f;
                f7 = f20;
                break;
            case DRINK /* 22 */:
                fSin = sin(5.0f * fUptimeMillis) * 9.0f * fEnv;
                spawn(fUptimeMillis, 2.2f, 0.3f, kindEmojiSteam(), SHOCK);
                i = 0;
                f = f9;
                f2 = f5;
                f3 = 1.0f;
                break;
            case SHOUT /* 23 */:
                float fLoopT = loopT(fUptimeMillis);
                float fAbs4 = fLoopT < 0.6f ? (-14.0f) * Math.abs(sin(18.0f * fLoopT)) : 0.0f;
                float fAbs5 = fLoopT < 0.6f ? 1.0f + (0.08f * Math.abs(sin(18.0f * fLoopT))) : 1.0f;
                drawWaves(canvas, f5 + (iMin * 0.32f), f6 - (iMin * 0.08f), iMin, fLoopT);
                i = 0;
                f = f6;
                f2 = f5 - (iMin * 0.2f);
                fSin = fAbs4;
                f3 = fAbs5;
                f8 = fAbs5;
                break;
            case FLEX /* 24 */:
                float f21 = (-Math.abs(sin(7.0f * fUptimeMillis))) * 18.0f * fEnv;
                float fAbs6 = 1.0f + (fEnv * Math.abs(sin(7.0f * fUptimeMillis)) * 0.1f);
                i = 0;
                f = f9;
                f2 = f5 - (iMin * 0.2f);
                fSin = f21;
                f3 = fAbs6;
                f8 = fAbs6;
                break;
            case PRAY /* 25 */:
                float f22 = (-Math.abs(sin(6.0f * fUptimeMillis))) * 6.0f * f10 * fEnv;
                float f23 = (fEnv * 0.05f) + 1.0f;
                if (fUptimeMillis > 0.2f && fUptimeMillis < 0.25f) {
                    burst("✨", 4);
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = f23;
                    f8 = f23;
                    f7 = f22;
                } else {
                    i = 0;
                    f = f9;
                    f2 = f5;
                    fSin = 0.0f;
                    f3 = f23;
                    f8 = f23;
                    f7 = f22;
                }
                break;
            case ROLL /* 26 */:
                float fSin14 = ((fUptimeMillis < 2.2f ? 1 : 0) * (fUptimeMillis < 0.4f ? ((-14.0f) * fUptimeMillis) / 0.4f : -14.0f)) + (sin(3.0f * fUptimeMillis) * 4.0f * fEnv);
                if (fUptimeMillis > 2.2f) {
                    fSin14 = 0.0f;
                }
                float fSin15 = fEnv * sin(3.0f * fUptimeMillis) * 4.0f * f10;
                i = 0;
                f = f9;
                f2 = f5;
                fSin = fSin14;
                f3 = 1.0f;
                fSin2 = fSin15;
                break;
        }
        if (this.kind != SHOUT && width > Ui.dp(40.0f)) {
            float fMin3 = Math.min(1.0f, Math.abs(Math.min(0.0f, f7)) / (iMin * 0.3f));
            float f24 = iMin * 0.3f * (1.0f - (0.4f * fMin3));
            this.sh.setColor(Color.argb((int) ((1.0f - (fMin3 * 0.6f)) * 40.0f), 0, 0, 0));
            canvas.drawOval(new RectF(f5 - f24, (iMin * 0.47f) + f6, f24 + f5, (iMin * 0.53f) + f6), this.sh);
        }
        canvas.save();
        canvas.translate(fSin2, f7);
        canvas.rotate(fSin, f2, f);
        canvas.scale(f8, f3, f2, f);
        this.p.setColorFilter(i > 0 ? new PorterDuffColorFilter(Color.argb(i, 255, 30, 30), PorterDuff.Mode.SRC_ATOP) : null);
        canvas.drawBitmap(this.bmp, f5 - (iMin / 2.0f), f6 - (iMin / 2.0f), this.p);
        this.p.setColorFilter(null);
        canvas.restore();
        boolean zDrawParticles = drawParticles(canvas, iMin);
        if (this.kind == SHOUT) {
            float fLoopT2 = loopT(fUptimeMillis);
            if (fLoopT2 < 0.95f) {
                postInvalidateOnAnimation();
                return;
            } else {
                postInvalidateDelayed((long) ((2.2f - fLoopT2) * 1000.0f));
                return;
            }
        }
        if (fUptimeMillis < 2.2f || zDrawParticles) {
            postInvalidateOnAnimation();
        } else if (this.loop) {
            postDelayed(new Runnable() { // from class: com.changliao.im.Emo.3
                @Override // java.lang.Runnable
                public void run() {
                    if (Emo.this.isAttachedToWindow()) {
                        Emo.this.play();
                    }
                }
            }, 1500L);
        }
    }

    public void play() {
        this.t0 = SystemClock.uptimeMillis();
        this.ps.clear();
        this.lastSpawn = -1.0f;
        invalidate();
    }

    void sparks(float f, float f2) {
        if (f < f2) {
            if (this.lastSpawn < 0.0f || f - this.lastSpawn >= 0.07f) {
                this.lastSpawn = f;
                float width = getWidth();
                float height = getHeight();
                float fMin = Math.min(width, height) * 0.66f;
                List<float[]> list = this.ps;
                float[] fArr = new float[CLAP];
                fArr[0] = (width / 2.0f) + ((this.rnd.nextFloat() - 0.5f) * fMin * 0.5f);
                fArr[1] = (height / 2.0f) - (0.2f * fMin);
                fArr[2] = (this.rnd.nextFloat() - 0.5f) * fMin * 0.4f;
                fArr[3] = (-fMin) * ((this.rnd.nextFloat() * 0.6f) + 0.8f);
                fArr[4] = 0.0f;
                fArr[5] = 0.0f;
                fArr[6] = 0.0f;
                fArr[CRY] = 0.8f;
                fArr[ANGRY] = 0.04f * fMin;
                fArr[SHOCK] = 12.0f;
                fArr[PARTY] = -1.0f;
                fArr[THUMB] = this.rnd.nextBoolean() ? -20448.0f : -38400.0f;
                list.add(fArr);
            }
        }
    }

    void spawn(float f, float f2, float f3, String str, int i) {
        if (f >= f2) {
            return;
        }
        if (this.lastSpawn < 0.0f || f - this.lastSpawn >= f3) {
            this.lastSpawn = f;
            add(str, i);
        }
    }
}
