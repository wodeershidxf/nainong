package com.changliao.im;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
final class Bubbles {
    static final HashMap<String, int[]> B = new HashMap<>();

    static {
        B.put("gold", new int[]{-10864640, -3132, -11413, -1005270});
        B.put("sakura", new int[]{-7723960, -7186, -18737, -28745});
        B.put("ocean", new int[]{-1, -12328746, -14967568, -14001193});
        B.put("aurora", new int[]{-1, -8692481, -12594776, -10835457});
        B.put("neon", new int[]{-1508353, -14999762, -15723747});
        B.put("candy", new int[]{-10802554, -5642, -1445633});
        B.put("night", new int[]{-1, -14473894, -12899718, -15459779});
        B.put("glass", new int[]{Ui.TEXT, -1, -1117449});
        B.put("flame", new int[]{-1, -19641, -41414, -2087842});
        B.put("mint", new int[]{-15901626, -2490384, -8458044, -13642854});
        B.put("peach", new int[]{-8770030, -6186, -18292, -30107});
        B.put("lavender", new int[]{-11916678, -923393, -3296001, -5665803});
        B.put("lemon", new int[]{-10728960, -1071, -6041, -11745});
        B.put("matcha", new int[]{-13678062, -1116200, -4202358, -7553206});
        B.put("choco", new int[]{-1, -6264502, -9552090, -11917803});
        B.put("ruby", new int[]{-1, -41090, -2744497, -7467469});
        B.put("sunset", new int[]{-1, -12431, -33964, -4049298});
        B.put("galaxy", new int[]{-1, -10801199, -14017938, -16052434});
        B.put("cyber", new int[]{-1376257, -1, -1117449});
        B.put("cloud", new int[]{-12952966, -1, -1641729, -3677953});
        B.put("jade", new int[]{-1, -10493008, -15424641, -16028843});
        B.put("ink", new int[]{-14869219, -1, -986896});
        B.put("rainbow", new int[]{-1, -38037, -19605, -9923, -9712777});
        B.put("diamond", new int[]{-13944235, -1, -2100225, -5711617});
        B.put("rose", new int[]{-10868182, -3860, -870232, -2519942});
    }

    Bubbles() {
    }
}
