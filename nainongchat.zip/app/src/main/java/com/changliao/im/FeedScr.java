package com.changliao.im;

import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.util.Linkify;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class FeedScr extends Scr {
    LinearLayout body;
    boolean embedded;
    boolean more;
    final String name;
    final String nk;
    List<J> posts;

    public static class PostScr extends Scr {
        LinearLayout box;
        boolean busy;
        final List<J> imgs = new ArrayList();
        TextView ok;
        EditText ta;
        J vid;

        /* JADX INFO: renamed from: com.changliao.im.FeedScr$PostScr$7, reason: invalid class name */
        class AnonymousClass7 implements Runnable {
            final /* synthetic */ String val$text;
            final /* synthetic */ J val$v;

            AnonymousClass7(J j, String str) {
                this.val$v = j;
                this.val$text = str;
            }

            @Override // java.lang.Runnable
            public void run() {
                J jOf;
                try {
                    ArrayList arrayList = new ArrayList();
                    for (J j : PostScr.this.imgs) {
                        arrayList.add(Up.upload((byte[]) j.get("data"), "p.jpg", j.s("mime"), null));
                    }
                    if (this.val$v != null) {
                        Uri uri = Uri.parse(this.val$v.s("uri"));
                        String strUpload = this.val$v.get("poster") != null ? Up.upload((byte[]) this.val$v.get("poster"), "poster.jpg", "image/jpeg", null) : "";
                        long jL = this.val$v.l("size");
                        if (jL < 0) {
                            jL = PostScr.this.a.getContentResolver().openAssetFileDescriptor(uri, "r").getLength();
                        }
                        jOf = J.of("fid", Up.upload(PostScr.this.a.getContentResolver().openInputStream(uri), jL, "v.mp4", this.val$v.s("mime"), new Up.P() { // from class: com.changliao.im.FeedScr.PostScr.7.1
                            @Override // com.changliao.im.Up.P
                            public void p(final float f) {
                                PostScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.FeedScr.PostScr.7.1.1
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        PostScr.this.ok.setText("上传 " + Math.round(f * 100.0f) + "%");
                                    }
                                });
                            }
                        }), "poster", strUpload, "w", Long.valueOf(this.val$v.l("w")), "h", Long.valueOf(this.val$v.l("h")), "dur", Long.valueOf(this.val$v.l("dur")));
                    } else {
                        jOf = null;
                    }
                    final J jOf2 = J.of("t", "c_post", "text", this.val$text, "imgs", arrayList);
                    if (jOf != null) {
                        jOf2.put("vid", jOf);
                    }
                    PostScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.FeedScr.PostScr.7.2
                        @Override // java.lang.Runnable
                        public void run() {
                            PostScr.this.C.send(jOf2);
                            if (PostScr.this.alive) {
                                PostScr.this.a.back();
                            }
                        }
                    });
                } catch (Throwable th) {
                    PostScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.FeedScr.PostScr.7.3
                        @Override // java.lang.Runnable
                        public void run() {
                            PostScr.this.busy = false;
                            PostScr.this.ok.setText("发表");
                            PostScr.this.err(th.getMessage() == null ? "上传失败" : th.getMessage());
                        }
                    });
                }
            }
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("发表动态", true);
            this.ok = tb("发表", new View.OnClickListener() { // from class: com.changliao.im.FeedScr.PostScr.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    PostScr.this.send();
                }
            });
            LinearLayout linearLayoutScrollPage = scrollPage(linearLayoutPage);
            this.ta = new EditText(this.a);
            this.ta.setHint("分享新鲜事…");
            this.ta.setHintTextColor(-6643285);
            this.ta.setTextSize(16.0f);
            this.ta.setTextColor(Ui.TEXT);
            this.ta.setMinLines(5);
            this.ta.setGravity(48);
            this.ta.setBackground(new G(3, 14.0f));
            this.ta.setPadding(Ui.dp(13.0f), Ui.dp(11.0f), Ui.dp(13.0f), Ui.dp(11.0f));
            this.ta.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
            linearLayoutScrollPage.addView(this.ta, Ui.lpm(-1, -2, 16, 12, 16, 12));
            this.box = Ui.col(this.a);
            linearLayoutScrollPage.addView(this.box);
            render();
            this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.FeedScr.PostScr.2
                @Override // java.lang.Runnable
                public void run() {
                    if (PostScr.this.alive) {
                        PostScr.this.a.showKb(PostScr.this.ta);
                    }
                }
            }, 350L);
            return linearLayoutPage;
        }

        void pick() {
            if (this.imgs.size() >= 9 || this.vid != null) {
                return;
            }
            this.a.push(new GalScr(new GalScr.Got() { // from class: com.changliao.im.FeedScr.PostScr.6
                @Override // com.changliao.im.GalScr.Got
                public void got(List<Uri> list, boolean z) {
                    for (Uri uri : list) {
                        String type = PostScr.this.a.getContentResolver().getType(uri);
                        if (type == null || !type.startsWith("video/")) {
                            if (PostScr.this.imgs.size() >= 9 || PostScr.this.vid != null) {
                                break;
                            }
                            try {
                                Object[] objArrJpeg = Up.jpeg(PostScr.this.a, uri, false);
                                PostScr.this.imgs.add(J.of("data", objArrJpeg[0], "mime", objArrJpeg[3], "bmp", Img.decode((byte[]) objArrJpeg[0], 300)));
                            } catch (Throwable th) {
                                PostScr.this.err("这张图片用不了");
                            }
                        } else if (PostScr.this.imgs.isEmpty() && PostScr.this.vid == null && list.size() <= 1) {
                            Object[] objArrVideo = Up.video(PostScr.this.a, uri);
                            long length = -1;
                            try {
                                length = PostScr.this.a.getContentResolver().openAssetFileDescriptor(uri, "r").getLength();
                            } catch (Throwable th2) {
                            }
                            if (length > 314572800) {
                                PostScr.this.err("视频太大了（最大 300MB）");
                            } else {
                                PostScr postScr = PostScr.this;
                                Object[] objArr = new Object[16];
                                objArr[0] = "uri";
                                objArr[1] = uri.toString();
                                objArr[2] = "mime";
                                objArr[3] = type;
                                objArr[4] = "size";
                                objArr[5] = Long.valueOf(length);
                                objArr[6] = "poster";
                                objArr[7] = objArrVideo[0];
                                objArr[8] = "w";
                                objArr[9] = objArrVideo[1];
                                objArr[10] = "h";
                                objArr[11] = objArrVideo[2];
                                objArr[12] = "dur";
                                objArr[13] = objArrVideo[3];
                                objArr[14] = "bmp";
                                objArr[15] = objArrVideo[0] != null ? Img.decode((byte[]) objArrVideo[0], 400) : null;
                                postScr.vid = J.of(objArr);
                            }
                        } else {
                            PostScr.this.err("视频只能单独发一个，不能和图片一起发");
                        }
                    }
                    PostScr.this.render();
                }
            }).title("选择图片或视频").max(9 - this.imgs.size()).noOrig().ok("确定"));
        }

        void render() {
            this.box.removeAllViews();
            GridLayout gridLayout = new GridLayout(this.a);
            gridLayout.setColumnCount(3);
            gridLayout.setPadding(Ui.dp(16.0f), 0, Ui.dp(16.0f), 0);
            int width = (((this.a.host.getWidth() > 0 ? this.a.wide() ? (int) (this.a.host.getWidth() * 0.64f) : this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels) - Ui.dp(32.0f)) - Ui.dp(12.0f)) / 3;
            for (int i = 0; i < this.imgs.size(); i++) {
                final int idx = i;
                FrameLayout frameLayout = new FrameLayout(this.a);
                frameLayout.setBackground(Ui.round(-1512723, 8.0f));
                ChatScr.clip(frameLayout, 8.0f);
                ImageView imageView = new ImageView(this.a);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageBitmap((Bitmap) this.imgs.get(i).get("bmp"));
                frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                TextView textViewText = Ui.text(this.a, "×", 14.0f, -1);
                textViewText.setGravity(17);
                textViewText.setBackground(Ui.oval(Integer.MIN_VALUE));
                textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.PostScr.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        PostScr.this.imgs.remove(idx);
                        PostScr.this.render();
                    }
                });
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(Ui.dp(22.0f), Ui.dp(22.0f), 8388661);
                layoutParams.setMargins(0, Ui.dp(2.0f), Ui.dp(2.0f), 0);
                frameLayout.addView(textViewText, layoutParams);
                GridLayout.LayoutParams layoutParams2 = new GridLayout.LayoutParams();
                layoutParams2.width = width;
                layoutParams2.height = width;
                layoutParams2.setMargins(0, 0, Ui.dp(6.0f), Ui.dp(6.0f));
                gridLayout.addView(frameLayout, layoutParams2);
            }
            if (this.vid != null) {
                FrameLayout frameLayout2 = new FrameLayout(this.a);
                frameLayout2.setBackground(Ui.round(-14736599, 8.0f));
                ChatScr.clip(frameLayout2, 8.0f);
                ImageView imageView2 = new ImageView(this.a);
                imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView2.setImageBitmap((Bitmap) this.vid.get("bmp"));
                frameLayout2.addView(imageView2, new FrameLayout.LayoutParams(-1, -1));
                TextView textViewText2 = Ui.text(this.a, "▶", 20.0f, -1);
                textViewText2.setGravity(17);
                textViewText2.setBackground(Ui.oval(1711276032));
                frameLayout2.addView(textViewText2, Ui.flp(Ui.dp(42.0f), Ui.dp(42.0f), 17));
                TextView textViewText3 = Ui.text(this.a, "×", 14.0f, -1);
                textViewText3.setGravity(17);
                textViewText3.setBackground(Ui.oval(Integer.MIN_VALUE));
                textViewText3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.PostScr.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        PostScr.this.vid = null;
                        PostScr.this.render();
                    }
                });
                FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(Ui.dp(22.0f), Ui.dp(22.0f), 8388661);
                layoutParams3.setMargins(0, Ui.dp(2.0f), Ui.dp(2.0f), 0);
                frameLayout2.addView(textViewText3, layoutParams3);
                GridLayout.LayoutParams layoutParams4 = new GridLayout.LayoutParams();
                layoutParams4.width = width * 2;
                layoutParams4.height = (width * 3) / 2;
                layoutParams4.setMargins(0, 0, Ui.dp(6.0f), Ui.dp(6.0f));
                gridLayout.addView(frameLayout2, layoutParams4);
            }
            if (this.vid == null && this.imgs.size() < 9) {
                TextView textViewText4 = Ui.text(this.a, "＋", 34.0f, -5196097);
                textViewText4.setGravity(17);
                textViewText4.setBackground(Ui.round(-1512723, 8.0f));
                textViewText4.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.PostScr.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        PostScr.this.pick();
                    }
                });
                GridLayout.LayoutParams layoutParams5 = new GridLayout.LayoutParams();
                layoutParams5.width = width;
                layoutParams5.height = width;
                layoutParams5.setMargins(0, 0, Ui.dp(6.0f), Ui.dp(6.0f));
                gridLayout.addView(textViewText4, layoutParams5);
            }
            this.box.addView(gridLayout);
        }

        void send() {
            if (this.busy) {
                return;
            }
            String strTrim = this.ta.getText().toString().trim();
            if (strTrim.length() == 0 && this.imgs.isEmpty() && this.vid == null) {
                err("写点什么再发表吧");
                return;
            }
            this.busy = true;
            this.ok.setText("发表中…");
            new Thread(new AnonymousClass7(this.vid, strTrim)).start();
        }
    }

    public FeedScr(String str, String str2) {
        this.nk = str;
        this.name = str2;
    }

    static void b(SpannableStringBuilder spannableStringBuilder, String str) {
        int length = spannableStringBuilder.length();
        spannableStringBuilder.append((CharSequence) str);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(-11048043), length, spannableStringBuilder.length(), 33);
        spannableStringBuilder.setSpan(new StyleSpan(1), length, spannableStringBuilder.length(), 33);
    }

    @Override // com.changliao.im.Scr
    public View build() {
        String str;
        if (this.nk == null) {
            str = "动态";
        } else {
            str = (this.name == null ? "" : this.name) + "的动态";
        }
        LinearLayout linearLayoutPage = page(str, !this.embedded);
        if (this.nk == null) {
            ib("pen", new View.OnClickListener() { // from class: com.changliao.im.FeedScr.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FeedScr.this.a.push(new PostScr());
                }
            });
        }
        this.body = scrollPage(linearLayoutPage);
        if (!this.embedded) {
            load(0L);
        }
        render();
        return linearLayoutPage;
    }

    void load(long j) {
        J jOf = J.of("t", "c_feed");
        if (this.nk != null) {
            jOf.put("nick", this.nk);
        }
        if (j > 0) {
            jOf.put("before", Long.valueOf(j));
        }
        this.C.send(jOf);
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        int i = 0;
        boolean zEquals = false;
        if (str.equals("c_feed")) {
            if (this.nk != null) {
                zEquals = this.nk.equals(j.s("who"));
            } else if (j.s("who").length() == 0) {
                zEquals = true;
            }
            if (zEquals) {
                if (j.l("before") <= 0 || this.posts == null) {
                    this.posts = j.objs("l");
                } else {
                    this.posts.addAll(j.objs("l"));
                }
                this.more = j.b("more");
                render();
                return;
            }
            return;
        }
        if (!str.equals("c_post_upd") || this.posts == null) {
            if (!str.equals("c_pgone") || this.posts == null) {
                if (str.equals("c_feed_new") && this.nk == null && this.posts != null) {
                    this.posts.add(0, j.o("p"));
                    render();
                    return;
                }
                return;
            }
            for (int size = this.posts.size() - 1; size >= 0; size--) {
                if (this.posts.get(size).l("id") == j.l("id")) {
                    this.posts.remove(size);
                }
            }
            render();
            return;
        }
        J jO = j.o("p");
        while (true) {
            int i2 = i;
            if (i2 >= this.posts.size()) {
                render();
                return;
            } else {
                if (this.posts.get(i2).l("id") == jO.l("id")) {
                    this.posts.set(i2, jO);
                }
                i = i2 + 1;
            }
        }
    }

    int pageW() {
        if (this.root != null && this.root.getWidth() > 0) {
            return this.root.getWidth();
        }
        int width = this.a.host.getWidth() > 0 ? this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels;
        if (this.a.wide()) {
            return this.embedded ? (int) (width * 0.36f) : (int) (width * 0.64f);
        }
        return width;
    }

    void post(final J j) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        G g = new G(0, 20.0f);
        g.bg = -197122;
        linearLayoutCol.setBackground(g);
        linearLayoutCol.setElevation(Ui.dp(1.5f));
        linearLayoutCol.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(10.0f));
        this.body.addView(linearLayoutCol, Ui.lpm(-1, -2, 12, 10, 12, 0));
        LinearLayout linearLayoutRow = Ui.row(this.a);
        Img.Av av = av(j.s("nick"), j.sn("av"), false);
        av.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FeedScr.this.a.push(new ProfileScr(j.s("nk"), null));
            }
        });
        linearLayoutRow.addView(av, Ui.lpm(Ui.dp(40.0f), Ui.dp(40.0f), 0, 0, 10, 0));
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        linearLayoutCol2.addView(Ui.bold(Ui.text(this.a, j.s("nick"), 15.0f, Ui.TEXT)));
        linearLayoutCol2.addView(Ui.text(this.a, HomeScr.ago(j.l("ts")), 12.0f, Ui.SUB));
        linearLayoutRow.addView(linearLayoutCol2, Ui.lp(0, -2, 1.0f));
        if (j.b("mine")) {
            TextView textViewSm = sm("删除", 0, new View.OnClickListener() { // from class: com.changliao.im.FeedScr.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FeedScr.this.a.confirm("删除这条动态？", null, "删除", true, new Runnable() { // from class: com.changliao.im.FeedScr.4.1
                        @Override // java.lang.Runnable
                        public void run() {
                            FeedScr.this.C.send(J.of("t", "c_pdel", "id", Long.valueOf(j.l("id"))));
                        }
                    });
                }
            });
            textViewSm.setTextColor(Ui.SUB);
            textViewSm.setTextSize(13.0f);
            linearLayoutRow.addView(textViewSm);
        }
        linearLayoutCol.addView(linearLayoutRow);
        if (j.s("text").length() > 0) {
            TextView textViewText = Ui.text(this.a, j.s("text"), 15.0f, Ui.TEXT);
            textViewText.setLineSpacing(0.0f, 1.3f);
            textViewText.setTextIsSelectable(true);
            Linkify.addLinks(textViewText, 1);
            linearLayoutCol.addView(textViewText, Ui.lpm(-1, -2, 0, 10, 0, 4));
        }
        List<Object> listA = j.a("imgs");
        if (!listA.isEmpty()) {
            int iPageW = pageW() - Ui.dp(56.0f);
            int iMin = Math.min(3, listA.size());
            GridLayout gridLayout = new GridLayout(this.a);
            gridLayout.setColumnCount(iMin);
            int iDp = iMin == 1 ? (int) (iPageW * 0.66f) : (iPageW - (Ui.dp(4.0f) * (iMin - 1))) / iMin;
            for (int i = 0; i < listA.size(); i++) {
                final String strValueOf = String.valueOf(listA.get(i));
                ImageView imageView = new ImageView(this.a);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setBackground(Ui.round(-1841430, 6.0f));
                ChatScr.clip(imageView, 6.0f);
                Img.into(imageView, Core.fileUrl(strValueOf, "p.jpg"), 600);
                imageView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        FeedScr.this.a.push(new ImgScr(J.of("id", strValueOf, "name", "p.jpg"), null, null));
                    }
                });
                GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                layoutParams.width = iDp;
                layoutParams.height = iMin == 1 ? Math.min(Ui.dp(320.0f), iDp) : iDp;
                layoutParams.setMargins(0, 0, Ui.dp(4.0f), Ui.dp(4.0f));
                gridLayout.addView(imageView, layoutParams);
            }
            linearLayoutCol.addView(gridLayout, Ui.lpm(-2, -2, 0, 8, 0, 0));
        }
        final J jO = j.o("vid");
        if (jO != null && jO.s("fid").length() > 0) {
            int iPageW2 = (int) ((pageW() - Ui.dp(56.0f)) * 0.66f);
            int iMin2 = Math.min((jO.l("w") <= 0 || jO.l("h") <= 0) ? (iPageW2 * 3) / 4 : (int) ((((long) iPageW2) * jO.l("h")) / jO.l("w")), Ui.dp(360.0f));
            FrameLayout frameLayout = new FrameLayout(this.a);
            frameLayout.setBackground(Ui.round(-14736599, 8.0f));
            ChatScr.clip(frameLayout, 8.0f);
            ImageView imageView2 = new ImageView(this.a);
            imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (jO.s("poster").length() > 0) {
                Img.into(imageView2, Core.fileUrl(jO.s("poster"), "poster.jpg"), 600);
            }
            frameLayout.addView(imageView2, new FrameLayout.LayoutParams(-1, -1));
            TextView textViewText2 = Ui.text(this.a, "▶", 22.0f, -1);
            textViewText2.setGravity(17);
            textViewText2.setBackground(Ui.oval(1711276032));
            textViewText2.setPadding(Ui.dp(4.0f), 0, 0, 0);
            frameLayout.addView(textViewText2, Ui.flp(Ui.dp(52.0f), Ui.dp(52.0f), 17));
            if (jO.l("dur") > 0) {
                TextView textViewText3 = Ui.text(this.a, (jO.l("dur") / 60) + ":" + Ui.pad((int) (jO.l("dur") % 60)), 12.0f, -1);
                textViewText3.setShadowLayer(3.0f, 0.0f, 1.0f, -16777216);
                FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 8388693);
                layoutParamsFlp.rightMargin = Ui.dp(8.0f);
                layoutParamsFlp.bottomMargin = Ui.dp(6.0f);
                frameLayout.addView(textViewText3, layoutParamsFlp);
            }
            frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FeedScr.this.a.push(new VidScr(J.of("id", jO.s("fid"), "name", "v.mp4", "w", Long.valueOf(jO.l("w")), "h", Long.valueOf(jO.l("h")), "dur", Long.valueOf(jO.l("dur")), "poster", jO.s("poster")), null, null));
                }
            });
            linearLayoutCol.addView(frameLayout, Ui.lpm(iPageW2, iMin2, 0, 8, 0, 0));
        }
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setGravity(8388613);
        TextView textViewSm2 = sm("👍 " + (j.b("liked") ? "已赞" : "赞"), 0, new View.OnClickListener() { // from class: com.changliao.im.FeedScr.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FeedScr.this.C.send(J.of("t", "c_plike", "id", Long.valueOf(j.l("id"))));
            }
        });
        textViewSm2.setTextColor(j.b("liked") ? Ui.BLUE : -11642519);
        linearLayoutRow2.addView(textViewSm2);
        TextView textViewSm3 = sm("💬 评论", 0, new View.OnClickListener() { // from class: com.changliao.im.FeedScr.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FeedScr.this.a.ask("评论", "说点什么…", "", false, 300, new MainActivity.Str() { // from class: com.changliao.im.FeedScr.8.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str) {
                        if (str.length() > 0) {
                            FeedScr.this.C.send(J.of("t", "c_pcomment", "id", Long.valueOf(j.l("id")), "text", str));
                        }
                    }
                });
            }
        });
        textViewSm3.setTextColor(-11642519);
        linearLayoutRow2.addView(textViewSm3, Ui.lpm(-2, -2, 12, 0, 0, 0));
        linearLayoutCol.addView(linearLayoutRow2, Ui.lpm(-1, -2, 0, 8, 0, 0));
        List<Object> listA2 = j.a("likes");
        List<J> listObjs = j.objs("comments");
        if (listA2.isEmpty() && listObjs.isEmpty()) {
            return;
        }
        LinearLayout linearLayoutCol3 = Ui.col(this.a);
        linearLayoutCol3.setBackground(Ui.round(Ui.PANEL2, 8.0f));
        linearLayoutCol3.setPadding(Ui.dp(10.0f), Ui.dp(8.0f), Ui.dp(10.0f), Ui.dp(8.0f));
        if (!listA2.isEmpty()) {
            StringBuilder sb = new StringBuilder("👍 ");
            for (int i2 = 0; i2 < listA2.size(); i2++) {
                if (i2 > 0) {
                    sb.append("、");
                }
                sb.append(listA2.get(i2));
            }
            linearLayoutCol3.addView(Ui.text(this.a, sb.toString(), 14.0f, -11048043), Ui.lpm(-2, -2, 0, 0, 0, listObjs.isEmpty() ? 0 : 4));
        }
        for (final J j2 : listObjs) {
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            b(spannableStringBuilder, j2.s("nick"));
            if (j2.s("re").length() > 0) {
                spannableStringBuilder.append((CharSequence) " 回复 ");
                b(spannableStringBuilder, j2.s("re"));
            }
            spannableStringBuilder.append((CharSequence) "：").append((CharSequence) j2.s("text"));
            TextView textViewText4 = Ui.text(this.a, "", 14.0f, Ui.TEXT);
            textViewText4.setText(spannableStringBuilder);
            textViewText4.setPadding(0, Ui.dp(2.0f), 0, Ui.dp(2.0f));
            textViewText4.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FeedScr.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FeedScr.this.a.ask("回复 " + j2.s("nick"), "", "", false, 300, new MainActivity.Str() { // from class: com.changliao.im.FeedScr.9.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str) {
                            if (str.length() > 0) {
                                FeedScr.this.C.send(J.of("t", "c_pcomment", "id", Long.valueOf(j.l("id")), "text", str, "re", j2.s("nk")));
                            }
                        }
                    });
                }
            });
            linearLayoutCol3.addView(textViewText4);
        }
        linearLayoutCol.addView(linearLayoutCol3, Ui.lpm(-1, -2, 0, 8, 0, 0));
    }

    void render() {
        this.body.removeAllViews();
        if (this.nk == null && this.C.info != null) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setPadding(Ui.dp(16.0f), Ui.dp(18.0f), Ui.dp(16.0f), Ui.dp(18.0f));
            linearLayoutRow.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{-2364929, -792321}));
            linearLayoutRow.addView(av(this.C.myNick(), this.C.info.sn("av"), false), Ui.lpm(Ui.dp(66.0f), Ui.dp(66.0f), 0, 0, 14, 0));
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.addView(Ui.bold(Ui.text(this.a, this.C.myNick(), 18.0f, Ui.TEXT)));
            linearLayoutCol.addView(Ui.text(this.a, this.C.info.s("bio").length() > 0 ? this.C.info.s("bio") : "写一句个性签名吧", 13.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 2, 0, 0));
            linearLayoutRow.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
            this.body.addView(linearLayoutRow);
        }
        if (this.posts == null) {
            this.body.addView(empty("加载中…"));
            return;
        }
        if (this.posts.isEmpty()) {
            this.body.addView(empty(this.nk == null ? "好友们还没有发动态\n点右上角发表第一条吧" : "还没有动态"));
            return;
        }
        Iterator<J> it = this.posts.iterator();
        while (it.hasNext()) {
            post(it.next());
        }
        if (this.more) {
            TextView textViewSm = sm("加载更多", 0, new View.OnClickListener() { // from class: com.changliao.im.FeedScr.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    FeedScr.this.load(FeedScr.this.posts.get(FeedScr.this.posts.size() - 1).l("id"));
                }
            });
            textViewSm.setTextColor(Ui.BLUE);
            LinearLayout.LayoutParams layoutParamsLpm = Ui.lpm(-2, -2, 0, 14, 0, 0);
            layoutParamsLpm.gravity = 1;
            this.body.addView(textViewSm, layoutParamsLpm);
        }
    }
}
