package com.changliao.im;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: classes.dex */
public class Up {
    public static final Map<String, String> names = new ConcurrentHashMap();

    public interface P {
        void p(float f);
    }

    public static File download(Context context, String str, String str2, P p) throws Exception {
        File file;
        File externalFilesDir = context.getExternalFilesDir("Download");
        if (externalFilesDir != null) {
            externalFilesDir.mkdirs();
        }
        String strReplace = str2.replace('/', '_').replace('\\', '_');
        File file2 = new File(externalFilesDir, strReplace);
        if (file2.exists() && file2.length() > 0 && App.kv.getString("dl:" + str, "").equals(file2.getName())) {
            return file2;
        }
        if (file2.exists()) {
            int iLastIndexOf = strReplace.lastIndexOf(46);
            file = new File(externalFilesDir, (iLastIndexOf > 0 ? strReplace.substring(0, iLastIndexOf) : strReplace) + "_" + str.substring(0, 6) + (iLastIndexOf > 0 ? strReplace.substring(iLastIndexOf) : ""));
        } else {
            file = file2;
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.fileUrl(str, str2) + "?dl=1").openConnection();
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(60000);
        long contentLength = httpURLConnection.getContentLength();
        InputStream inputStream = httpURLConnection.getInputStream();
        File file3 = new File(file.getPath() + ".part");
        FileOutputStream fileOutputStream = new FileOutputStream(file3);
        byte[] bArr = new byte[65536];
        long j = 0;
        long jCurrentTimeMillis = 0;
        while (true) {
            int i = inputStream.read(bArr);
            if (i <= 0) {
                fileOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();
                file3.renameTo(file);
                App.kv.edit().putString("dl:" + str, file.getName()).apply();
                return file;
            }
            fileOutputStream.write(bArr, 0, i);
            j += (long) i;
            if (p != null && contentLength > 0 && System.currentTimeMillis() - jCurrentTimeMillis > 150) {
                jCurrentTimeMillis = System.currentTimeMillis();
                p.p(j / contentLength);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x007a A[PHI: r8
  0x007a: PHI (r8v2 java.lang.String) = (r8v0 java.lang.String), (r8v3 java.lang.String), (r8v3 java.lang.String) binds: [B:6:0x0017, B:12:0x0031, B:14:0x0037] A[DONT_GENERATE, DONT_INLINE]] */
    public static String[] info(Context context, Uri uri) {
        long j;
        String lastPathSegment;
        long j2;
        String string = "file";
        try {
            Cursor cursorQuery = context.getContentResolver().query(uri, null, null, null, null);
            if (cursorQuery != null) {
                if (cursorQuery.moveToFirst()) {
                    int columnIndex = cursorQuery.getColumnIndex("_display_name");
                    int columnIndex2 = cursorQuery.getColumnIndex("_size");
                    if (columnIndex >= 0 && cursorQuery.getString(columnIndex) != null) {
                        string = cursorQuery.getString(columnIndex);
                    }
                    if (columnIndex2 < 0 || cursorQuery.isNull(columnIndex2)) {
                        j = -1;
                        lastPathSegment = string;
                    } else {
                        j = cursorQuery.getLong(columnIndex2);
                        lastPathSegment = string;
                    }
                } else {
                    j = -1;
                    lastPathSegment = string;
                }
                try {
                    cursorQuery.close();
                } catch (Exception e) {
                    j2 = j;
                }
            } else {
                j = -1;
                lastPathSegment = "file";
            }
            j2 = j;
        } catch (Exception e2) {
            j = -1;
            j2 = j; // jadx: 外层 catch 分支漏掉了 j2 的赋值，原逻辑此处与 j 同步为 -1
            lastPathSegment = string;
        }
        if (lastPathSegment.equals("file") && uri.getLastPathSegment() != null) {
            lastPathSegment = uri.getLastPathSegment();
        }
        String str = names.get(uri.toString());
        if (str == null) {
            str = lastPathSegment;
        }
        return new String[]{str, String.valueOf(j2)};
    }

    public static Object[] jpeg(Context context, Uri uri, boolean z) throws Exception {
        int i;
        byte[] bArr = Img.read(context.getContentResolver().openInputStream(uri));
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        String str = options.outMimeType == null ? "" : options.outMimeType;
        int i2 = options.outWidth;
        int i3 = options.outHeight;
        try {
            int attributeInt = new ExifInterface(new ByteArrayInputStream(bArr)).getAttributeInt("Orientation", 1);
            if (attributeInt == 6) {
                i = 90;
            } else if (attributeInt == 3) {
                i = 180;
            } else {
                i = attributeInt == 8 ? 270 : 0;
            }
        } catch (Throwable th) {
            i = 0;
        }
        if (str.equals("image/gif") || (i == 0 && ((z || (bArr.length < 409600 && Math.max(i2, i3) <= 2048)) && (str.equals("image/jpeg") || str.equals("image/png") || str.equals("image/webp"))))) {
            return new Object[]{bArr, Integer.valueOf(i2), Integer.valueOf(i3), str};
        }
        Bitmap bitmapDecode = Img.decode(bArr, 1920);
        if (bitmapDecode == null) {
            throw new Exception("图片读取失败");
        }
        float fMin = Math.min(1.0f, 1920.0f / Math.max(bitmapDecode.getWidth(), bitmapDecode.getHeight()));
        Matrix matrix = new Matrix();
        matrix.postScale(fMin, fMin);
        if (i != 0) {
            matrix.postRotate(i);
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmapDecode, 0, 0, bitmapDecode.getWidth(), bitmapDecode.getHeight(), matrix, true);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(bitmapCreateBitmap.getWidth(), bitmapCreateBitmap.getHeight(), Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmapCreateBitmap2);
        canvas.drawColor(-1);
        canvas.drawBitmap(bitmapCreateBitmap, 0.0f, 0.0f, (Paint) null);
        bitmapCreateBitmap2.compress(Bitmap.CompressFormat.JPEG, 85, byteArrayOutputStream);
        return new Object[]{byteArrayOutputStream.toByteArray(), Integer.valueOf(bitmapCreateBitmap2.getWidth()), Integer.valueOf(bitmapCreateBitmap2.getHeight()), "image/jpeg"};
    }

    static int parse(String str) {
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String upload(InputStream inputStream, long j, String str, String str2, P p) throws Exception {
        StringBuilder sbAppend = new StringBuilder().append("/c_up?tok=").append(URLEncoder.encode(Core.I.token() == null ? "" : Core.I.token(), "UTF-8")).append("&name=").append(URLEncoder.encode(str, "UTF-8")).append("&mime=");
        if (str2 == null) {
            str2 = "";
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.http() + sbAppend.append(URLEncoder.encode(str2, "UTF-8")).toString()).openConnection();
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("Content-Type", "text/plain");
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(120000);
        httpURLConnection.setFixedLengthStreamingMode(j);
        OutputStream outputStream = httpURLConnection.getOutputStream();
        byte[] bArr = new byte[65536];
        long j2 = 0;
        long jCurrentTimeMillis = 0;
        while (true) {
            int i = inputStream.read(bArr);
            if (i <= 0) {
                break;
            }
            outputStream.write(bArr, 0, i);
            j2 += (long) i;
            if (p != null && System.currentTimeMillis() - jCurrentTimeMillis > 120) {
                jCurrentTimeMillis = System.currentTimeMillis();
                p.p(j > 0 ? j2 / j : 0.0f);
            }
        }
        outputStream.close();
        inputStream.close();
        J jObj = J.obj(new String(Img.read(httpURLConnection.getResponseCode() < 400 ? httpURLConnection.getInputStream() : httpURLConnection.getErrorStream()), "UTF-8"));
        httpURLConnection.disconnect();
        if (jObj == null || !jObj.b("ok")) {
            throw new Exception(jObj == null ? "上传失败" : jObj.s("msg"));
        }
        if (p != null) {
            p.p(1.0f);
        }
        return jObj.s("fid");
    }

    public static String upload(byte[] bArr, String str, String str2, P p) throws Exception {
        return upload(new ByteArrayInputStream(bArr), bArr.length, str, str2, p);
    }

    public static Object[] video(Context context, Uri uri) {
        Object[] objArr;
        int i;
        int i2;
        byte[] byteArray;
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            mediaMetadataRetriever.setDataSource(context, uri);
            int i3 = parse(mediaMetadataRetriever.extractMetadata(18));
            int i4 = parse(mediaMetadataRetriever.extractMetadata(19));
            int i5 = parse(mediaMetadataRetriever.extractMetadata(24));
            if (i5 == 90 || i5 == 270) {
                i = i3;
                i2 = i4;
            } else {
                i = i4;
                i2 = i3;
            }
            int i6 = parse(mediaMetadataRetriever.extractMetadata(9)) / 1000;
            Bitmap frameAtTime = mediaMetadataRetriever.getFrameAtTime(500000L);
            if (frameAtTime != null) {
                float fMin = Math.min(1.0f, 480.0f / Math.max(frameAtTime.getWidth(), frameAtTime.getHeight()));
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(frameAtTime, Math.max(1, (int) (frameAtTime.getWidth() * fMin)), Math.max(1, (int) (fMin * frameAtTime.getHeight())), true);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmapCreateScaledBitmap.compress(Bitmap.CompressFormat.JPEG, 75, byteArrayOutputStream);
                byteArray = byteArrayOutputStream.toByteArray();
            } else {
                byteArray = null;
            }
            objArr = new Object[]{byteArray, Integer.valueOf(i2), Integer.valueOf(i), Integer.valueOf(i6)};
        } catch (Throwable th) {
            objArr = new Object[]{null, 0, 0, 0};
        } finally {
            try {
                mediaMetadataRetriever.release();
            } catch (Throwable th2) {
            }
        }
        return objArr;
    }
}
