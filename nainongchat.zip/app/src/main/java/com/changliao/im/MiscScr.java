package com.changliao.im;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public class MiscScr {
    static final String[][] BUB = {new String[]{"", "默认"}, new String[]{"gold", "流金"}, new String[]{"sakura", "樱花"}, new String[]{"ocean", "深海"}, new String[]{"aurora", "极光"}, new String[]{"neon", "霓虹"}, new String[]{"candy", "糖果"}, new String[]{"night", "星夜"}, new String[]{"glass", "冰晶"}, new String[]{"flame", "烈焰"}, new String[]{"mint", "薄荷"}, new String[]{"peach", "蜜桃"}, new String[]{"lavender", "薰衣草"}, new String[]{"lemon", "柠檬"}, new String[]{"matcha", "抹茶"}, new String[]{"choco", "巧克力"}, new String[]{"ruby", "红宝石"}, new String[]{"sunset", "落日"}, new String[]{"galaxy", "银河"}, new String[]{"cyber", "赛博"}, new String[]{"cloud", "云朵"}, new String[]{"jade", "翡翠"}, new String[]{"ink", "水墨"}, new String[]{"rainbow", "彩虹"}, new String[]{"diamond", "钻石"}, new String[]{"rose", "玫瑰金"}};

    public static class FavScr extends Scr {
        LinearLayout body;
        final String sendTo;

        public FavScr(String str) {
            this.sendTo = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page(this.sendTo != null ? "发送收藏" : "我的收藏", true);
            this.body = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        void render() {
            String strFileIcon;
            View view;
            this.body.removeAllViews();
            List<J> listFavs = MiscScr.favs();
            if (listFavs.isEmpty()) {
                this.body.addView(empty("还没有收藏\n长按消息可以收藏"));
                return;
            }
            for (int i = 0; i < listFavs.size(); i++) {
                final int idx = i;
                final J j = listFavs.get(i);
                final String strS = j.s("k");
                final J jO = j.o("f");
                if (!strS.equals("img") || jO == null) {
                    MainActivity mainActivity = this.a;
                    if (strS.equals("text")) {
                        strFileIcon = "💬";
                    } else if (strS.equals("video")) {
                        strFileIcon = "🎬";
                    } else if (strS.equals("voice")) {
                        strFileIcon = "🎵";
                    } else {
                        strFileIcon = Ui.fileIcon(jO == null ? "" : jO.s("name"));
                    }
                    TextView textViewText = Ui.text(mainActivity, strFileIcon, 22.0f, Ui.TEXT);
                    textViewText.setGravity(17);
                    textViewText.setBackground(Ui.round(-1117965, 10.0f));
                    view = textViewText;
                } else {
                    ImageView imageView = new ImageView(this.a);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    ChatScr.clip(imageView, 8.0f);
                    Img.into(imageView, Core.fileUrl(jO.s("id"), jO.s("name")), 200);
                    view = imageView;
                }
                row(this.body, view, 50, strS.equals("text") ? j.s("text") : jO != null ? jO.s("name") : ChatScr.preview(j), "来自 " + j.s("from") + " · " + Ui.fullWhen(j.l("ts")), null, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.FavScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        if (FavScr.this.sendTo != null) {
                            FavScr.this.a.confirm("发送这条收藏？", strS.equals("text") ? j.s("text") : ChatScr.preview(j), "发送", false, new Runnable() { // from class: com.changliao.im.MiscScr.FavScr.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    if (strS.equals("text") || jO == null) {
                                        FavScr.this.C.send(J.of("t", "c_send", "conv", FavScr.this.sendTo, "k", "text", "text", j.s("text")));
                                    } else {
                                        FavScr.this.C.send(J.of("t", "c_send", "conv", FavScr.this.sendTo, "k", strS, "fid", jO.s("id"), "w", Long.valueOf(jO.l("w")), "h", Long.valueOf(jO.l("h")), "dur", Long.valueOf(jO.l("dur")), "poster", jO.sn("poster")));
                                    }
                                    FavScr.this.a.back();
                                }
                            });
                            return;
                        }
                        MainActivity mainActivity2 = FavScr.this.a;
                        String[] strArr = new String[3];
                        strArr[0] = strS.equals("text") ? "复制" : "查看";
                        strArr[1] = "转发";
                        strArr[2] = "删除";
                        mainActivity2.sheet(null, strArr, 2, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.FavScr.1.2
                            @Override // com.changliao.im.MainActivity.Str
                            public void ok(String str) {
                                if (str.equals("复制")) {
                                    FavScr.this.copy(j.s("text"));
                                    return;
                                }
                                if (str.equals("查看")) {
                                    if (strS.equals("img")) {
                                        FavScr.this.a.push(new ImgScr(jO, null, j));
                                        return;
                                    } else if (strS.equals("video")) {
                                        FavScr.this.a.push(new VidScr(jO, null, j));
                                        return;
                                    } else {
                                        ChatScr.openFileStatic(FavScr.this.a, j, jO, null);
                                        return;
                                    }
                                }
                                if (str.equals("转发")) {
                                    FavScr.this.a.push(new FwdScr(j));
                                    return;
                                }
                                List<J> listFavs2 = MiscScr.favs();
                                if (idx < listFavs2.size()) {
                                    listFavs2.remove(idx);
                                }
                                MiscScr.saveFavs(listFavs2);
                                FavScr.this.render();
                            }
                        });
                    }
                });
            }
        }
    }

    public static class ReportsScr extends Scr {
        List<J> banned;
        LinearLayout body;
        List<J> l;

        interface BanCb {
            void ban(int i, String str);
        }

        static void askWhy(MainActivity mainActivity, final int i, String str, final BanCb banCb) {
            mainActivity.ask("封禁原因（会告诉对方）", "", str, false, 60, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.ReportsScr.2
                @Override // com.changliao.im.MainActivity.Str
                public void ok(String str2) {
                    banCb.ban(i, str2);
                }
            });
        }

        static String left(long j) {
            String str;
            if (j <= 0) {
                return "永久";
            }
            long jCurrentTimeMillis = j - (System.currentTimeMillis() / 1000);
            if (jCurrentTimeMillis <= 0) {
                return "即将解封";
            }
            StringBuilder sbAppend = new StringBuilder().append("还剩 ");
            if (jCurrentTimeMillis >= 86400) {
                str = (jCurrentTimeMillis / 86400) + " 天 " + ((jCurrentTimeMillis % 86400) / 3600) + " 小时";
            } else {
                str = jCurrentTimeMillis >= 3600 ? (jCurrentTimeMillis / 3600) + " 小时 " + ((jCurrentTimeMillis % 3600) / 60) + " 分钟" : Math.max(1L, jCurrentTimeMillis / 60) + " 分钟";
            }
            return sbAppend.append(str).append("（").append(Ui.fullWhen(j)).append(" 自动解封）").toString();
        }

        static int parse(String str) {
            double d;
            Matcher matcher = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)(分钟|分|小时|时|天|日|周|星期|月|年)?").matcher(str.replace(" ", "").replace("个", ""));
            if (!matcher.find()) {
                return -1;
            }
            double d2 = Double.parseDouble(matcher.group(1));
            String strGroup = matcher.group(2) == null ? "天" : matcher.group(2);
            if (strGroup.startsWith("分")) {
                d = 1.0d;
            } else if (strGroup.endsWith("时")) {
                d = 60.0d;
            } else if (strGroup.equals("周") || strGroup.equals("星期")) {
                d = 10080.0d;
            } else if (strGroup.equals("月")) {
                d = 43200.0d;
            } else {
                d = strGroup.equals("年") ? 525600.0d : 1440.0d;
            }
            return (int) Math.round(d * d2);
        }

        static void pickBan(final MainActivity mainActivity, String str, final String str2, final BanCb banCb) {
            final String[] strArr = {"1 小时", "1 天", "3 天", "7 天", "30 天", "永久封禁", "自定义时长…"};
            final int[] iArr = {60, 1440, 4320, 10080, 43200, 0, -1};
            mainActivity.sheet(str, strArr, 5, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.ReportsScr.1
                @Override // com.changliao.im.MainActivity.Str
                public void ok(String str3) {
                    for (int i = 0; i < strArr.length; i++) {
                        if (strArr[i].equals(str3)) {
                            if (iArr[i] >= 0) {
                                ReportsScr.askWhy(mainActivity, iArr[i], str2, banCb);
                                return;
                            }
                            mainActivity.ask("封禁多久？", "输入数字＋单位，例如：2 小时、5 天、45 分钟", "", false, 20, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.ReportsScr.1.1
                                @Override // com.changliao.im.MainActivity.Str
                                public void ok(String str4) {
                                    int i2 = ReportsScr.parse(str4);
                                    if (i2 <= 0) {
                                        mainActivity.toast("没看懂时长，请写成「2 小时」「5 天」「45 分钟」这样", true);
                                    } else {
                                        ReportsScr.askWhy(mainActivity, i2, str2, banCb);
                                    }
                                }
                            });
                        }
                    }
                }
            });
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("举报、申诉与 VIP 申请", true);
            this.body = scrollPage(linearLayoutPage);
            this.C.send(J.of("t", "c_reports"));
            this.C.reportsN = 0;
            this.C.emit("me", null);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("c_reports")) {
                this.l = j.objs("l");
                this.banned = j.objs("banned");
                render();
            } else if (str.equals("c_reports_ping")) {
                this.C.send(J.of("t", "c_reports"));
            }
        }

        void render() {
            String str;
            this.body.removeAllViews();
            if (this.l == null) {
                this.body.addView(empty("加载中…"));
                return;
            }
            if (this.banned != null && !this.banned.isEmpty()) {
                LinearLayout linearLayoutCsec = csec(this.body);
                linearLayoutCsec.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(10.0f));
                linearLayoutCsec.addView(Ui.bold(Ui.text(this.a, "封禁中的用户（" + this.banned.size() + "）", 15.0f, Ui.TEXT)));
                for (final J j : this.banned) {
                    LinearLayout linearLayoutRow = Ui.row(this.a);
                    linearLayoutRow.setPadding(0, Ui.dp(10.0f), 0, 0);
                    TextView textViewText = Ui.text(this.a, j.s("nick") + "（NK " + j.s("nk") + "）\n" + left(j.l("until")) + " · " + j.s("reason"), 13.0f, -11642519);
                    textViewText.setLineSpacing(0.0f, 1.3f);
                    linearLayoutRow.addView(textViewText, Ui.lp(0, -2, 1.0f));
                    linearLayoutRow.addView(sm("解封", 1, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            ReportsScr.this.C.send(J.of("t", "c_rdeal", "nick", j.s("nk"), "act", "unban"));
                        }
                    }));
                    linearLayoutCsec.addView(linearLayoutRow);
                }
            }
            if (this.l.isEmpty()) {
                this.body.addView(empty("暂时没有举报、申诉和 VIP 申请"));
                return;
            }
            for (final J j2 : this.l) {
                if (j2.s("kind").equals("vipreq")) {
                    vipCard(j2);
                } else {
                    final boolean zStartsWith = j2.s("kind").startsWith("u");
                    boolean zEndsWith = j2.s("kind").endsWith("appeal");
                    LinearLayout linearLayoutCsec2 = csec(this.body);
                    linearLayoutCsec2.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f));
                    LinearLayout linearLayoutRow2 = Ui.row(this.a);
                    TextView textViewTag = Ui.tag(this.a, (zStartsWith ? "用户" : "群") + (zEndsWith ? "申诉" : "举报"), zEndsWith ? -13912461 : zStartsWith ? -704705 : Ui.GOLD);
                    ((LinearLayout.LayoutParams) textViewTag.getLayoutParams()).leftMargin = 0;
                    linearLayoutRow2.addView(textViewTag);
                    linearLayoutRow2.addView(Ui.one(Ui.bold(Ui.text(this.a, zStartsWith ? j2.s("tname") : j2.s("gname"), 15.0f, Ui.TEXT))), Ui.lpm(-2, -2, 8, 0, 6, 0));
                    linearLayoutRow2.addView(Ui.text(this.a, zStartsWith ? "NK " + j2.s("tnk") : "群号 " + j2.s("gid"), 12.0f, Ui.SUB), Ui.lp(0, -2, 1.0f));
                    String strS = j2.s("status");
                    MainActivity mainActivity = this.a;
                    if (strS.equals("open")) {
                        str = "待处理";
                    } else if (strS.equals("banned")) {
                        str = "已封禁";
                    } else if (strS.equals("unbanned")) {
                        str = "已解封";
                    } else {
                        str = strS.equals("rejected") ? "已驳回" : "";
                    }
                    linearLayoutRow2.addView(Ui.text(mainActivity, str, 13.0f, strS.equals("open") ? -33536 : Ui.SUB));
                    linearLayoutCsec2.addView(linearLayoutRow2);
                    String str2 = j2.b("banned") ? "封禁中 · " + left(j2.l("until")) : "正常";
                    TextView textViewText2 = Ui.text(this.a, new StringBuilder().append(zEndsWith ? zStartsWith ? "申诉人" : "群主" : "举报人").append("：").append(j2.s("by")).append("（NK ").append(j2.s("byk")).append("） · ").append(Ui.fullWhen(j2.l("ts"))).append("\n").append(zStartsWith ? j2.b("exists") ? "账号状态：" + str2 : "该账号已不存在" : j2.b("exists") ? "群主：" + j2.s("owner") + " · " + j2.l("n") + " 人 · " + str2 : "该群已解散").append(j2.s("reason").length() > 0 ? "\n原因：" + j2.s("reason") : "").append(j2.s("text").length() > 0 ? "\n说明：" + j2.s("text") : "").toString(), 14.0f, -11642519);
                    textViewText2.setLineSpacing(0.0f, 1.35f);
                    linearLayoutCsec2.addView(textViewText2, Ui.lpm(-1, -2, 0, 8, 0, 0));
                    if (j2.b("exists")) {
                        LinearLayout linearLayoutRow3 = Ui.row(this.a);
                        if (j2.b("banned")) {
                            linearLayoutRow3.addView(sm("解除封禁", 1, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.4
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    ReportsScr.this.a.confirm("解除封禁", zStartsWith ? "解除后该用户可以正常使用。" : "解除后该群可以正常聊天。", "解除", false, new Runnable() { // from class: com.changliao.im.MiscScr.ReportsScr.4.1
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            ReportsScr.this.C.send(J.of("t", "c_rdeal", "id", Long.valueOf(j2.l("id")), "act", "unban"));
                                        }
                                    });
                                }
                            }));
                        } else {
                            linearLayoutRow3.addView(sm(zStartsWith ? "封禁该用户" : "封禁该群", 4, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.5
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    ReportsScr.pickBan(ReportsScr.this.a, (zStartsWith ? "封禁「" + j2.s("tname") : "封禁群「" + j2.s("gname")) + "」多久？", j2.s("reason"), new BanCb() { // from class: com.changliao.im.MiscScr.ReportsScr.5.1
                                        @Override // com.changliao.im.MiscScr.ReportsScr.BanCb
                                        public void ban(int i, String str3) {
                                            ReportsScr.this.C.send(J.of("t", "c_rdeal", "id", Long.valueOf(j2.l("id")), "act", "ban", "mins", Integer.valueOf(i), "why", str3));
                                        }
                                    });
                                }
                            }));
                        }
                        if (strS.equals("open")) {
                            linearLayoutRow3.addView(sm("驳回", 0, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.6
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    ReportsScr.this.C.send(J.of("t", "c_rdeal", "id", Long.valueOf(j2.l("id")), "act", "reject"));
                                }
                            }), Ui.lpm(-2, -2, 8, 0, 0, 0));
                        }
                        linearLayoutRow3.addView(sm(zStartsWith ? "查看资料" : "查看群", 0, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.7
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (zStartsWith) {
                                    ReportsScr.this.a.web("profile", "a", j2.s("tnk"));
                                } else if (ReportsScr.this.C.groups.containsKey(j2.s("gid"))) {
                                    ReportsScr.this.a.push(new GroupScr(j2.s("gid")));
                                } else {
                                    ReportsScr.this.a.push(new SearchScr(false));
                                    ReportsScr.this.C.send(J.of("t", "c_gsearch", "q", j2.s("gid")));
                                }
                            }
                        }), Ui.lpm(-2, -2, 8, 0, 0, 0));
                        linearLayoutCsec2.addView(linearLayoutRow3, Ui.lpm(-1, -2, 0, 12, 0, 0));
                    }
                }
            }
        }

        void vipCard(final J j) {
            String str;
            LinearLayout linearLayoutCsec = csec(this.body);
            linearLayoutCsec.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f));
            LinearLayout linearLayoutRow = Ui.row(this.a);
            TextView textViewTag = Ui.tag(this.a, "VIP 申请", Ui.GOLD);
            ((LinearLayout.LayoutParams) textViewTag.getLayoutParams()).leftMargin = 0;
            linearLayoutRow.addView(textViewTag);
            linearLayoutRow.addView(Ui.one(Ui.bold(Ui.text(this.a, j.s("tname"), 15.0f, Ui.TEXT))), Ui.lpm(-2, -2, 8, 0, 6, 0));
            linearLayoutRow.addView(Ui.text(this.a, "NK " + j.s("tnk"), 12.0f, Ui.SUB), Ui.lp(0, -2, 1.0f));
            String strS = j.s("status");
            MainActivity mainActivity = this.a;
            if (strS.equals("open")) {
                str = "待处理";
            } else {
                str = strS.equals("approved") ? "已同意" : "已拒绝";
            }
            linearLayoutRow.addView(Ui.text(mainActivity, str, 13.0f, strS.equals("open") ? -33536 : Ui.SUB));
            linearLayoutCsec.addView(linearLayoutRow);
            TextView textViewText = Ui.text(this.a, "申请时间：" + Ui.fullWhen(j.l("ts")) + (j.b("vip") ? " · 现在已经是 VIP" : "") + (j.s("text").length() > 0 ? "\n申请理由：" + j.s("text") : ""), 14.0f, -11642519);
            textViewText.setLineSpacing(0.0f, 1.35f);
            linearLayoutCsec.addView(textViewText, Ui.lpm(-1, -2, 0, 8, 0, 0));
            LinearLayout linearLayoutRow2 = Ui.row(this.a);
            if (strS.equals("open") && j.b("exists")) {
                linearLayoutRow2.addView(sm("同意", 1, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.8
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ReportsScr.this.a.confirm("同意 VIP 申请", "同意后「" + j.s("tname") + "」会成为 VIP。", "同意", false, new Runnable() { // from class: com.changliao.im.MiscScr.ReportsScr.8.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ReportsScr.this.C.send(J.of("t", "c_rdeal", "id", Long.valueOf(j.l("id")), "act", "vip"));
                            }
                        });
                    }
                }));
                linearLayoutRow2.addView(sm("拒绝", 0, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.9
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ReportsScr.this.C.send(J.of("t", "c_rdeal", "id", Long.valueOf(j.l("id")), "act", "reject"));
                    }
                }), Ui.lpm(-2, -2, 8, 0, 0, 0));
            }
            linearLayoutRow2.addView(sm("查看资料", 0, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.ReportsScr.10
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ReportsScr.this.a.web("profile", "a", j.s("tnk"));
                }
            }), Ui.lpm(-2, -2, linearLayoutRow2.getChildCount() <= 0 ? 0 : 8, 0, 0, 0));
            linearLayoutCsec.addView(linearLayoutRow2, Ui.lpm(-1, -2, 0, 12, 0, 0));
        }
    }

    public static class SettingsScr extends Scr {
        void appSettings() {
            try {
                this.a.startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + this.a.getPackageName())));
            } catch (Throwable th) {
            }
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("设置", true);
            LinearLayout linearLayoutScrollPage = scrollPage(linearLayoutPage);
            LinearLayout linearLayoutCsec = csec(linearLayoutScrollPage);
            sec2(linearLayoutCsec, "消息通知");
            optSw(linearLayoutCsec, "新消息提示音", null, App.kv.getBoolean("sound", true), new Scr.Sw.L() { // from class: com.changliao.im.MiscScr.SettingsScr.1
                @Override // com.changliao.im.Scr.Sw.L
                public void on(boolean z) {
                    App.kv.edit().putBoolean("sound", z).apply();
                }
            });
            optSw(linearLayoutCsec, "后台保持在线", "关掉App也能收到消息和来电", App.kv.getBoolean("keep", true), new Scr.Sw.L() { // from class: com.changliao.im.MiscScr.SettingsScr.2
                @Override // com.changliao.im.Scr.Sw.L
                public void on(boolean z) {
                    App.kv.edit().putBoolean("keep", z).apply();
                    if (z) {
                        App.startBg(SettingsScr.this.a);
                    } else {
                        try {
                            SettingsScr.this.a.stopService(new Intent(SettingsScr.this.a, (Class<?>) Keeper.class));
                        } catch (Throwable th) {
                        }
                    }
                }
            });
            opt(linearLayoutCsec, "后台来电设置", "划掉后台也能接电话", true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.a.push(new BgScr());
                }
            });
            opt(linearLayoutCsec, "通知、相机、麦克风权限", "去允许", true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.appSettings();
                }
            });
            LinearLayout linearLayoutCsec2 = csec(linearLayoutScrollPage);
            final String[] strArr = {"关闭", "开启", "跟随系统"};
            opt(linearLayoutCsec2, "夜间模式", strArr[Night.mode()], true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.a.sheet("夜间模式", strArr, -1, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.SettingsScr.5.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str) {
                            for (int i = 0; i < 3; i++) {
                                if (strArr[i].equals(str) && i != Night.mode()) {
                                    App.kv.edit().putInt("night", i).apply();
                                    SettingsScr.this.a.recreate();
                                }
                            }
                        }
                    });
                }
            });
            final String[] strArr2 = {"自动（配置低的手机自动开启）", "开启", "关闭"};
            opt(linearLayoutCsec2, "流畅模式", (Night.lite(this.a) ? "已开启" : "未开启") + "（去掉阴影和玻璃高光，卡顿时打开）", true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.a.sheet("流畅模式", strArr2, -1, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.SettingsScr.6.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str) {
                            for (int i = 0; i < 3; i++) {
                                if (strArr2[i].equals(str)) {
                                    App.kv.edit().putInt("lite", i).apply();
                                    Night.lite = null;
                                    SettingsScr.this.a.recreate();
                                }
                            }
                        }
                    });
                }
            });
            LinearLayout linearLayoutCsec3 = csec(linearLayoutScrollPage);
            opt(linearLayoutCsec3, "检查更新", "当前版本 v4.6", true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.7
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    Upd.check(SettingsScr.this.a, true);
                }
            });
            opt(linearLayoutCsec3, "清除本地缓存", "草稿、收藏除外", true, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.8
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.a.confirm("清除本地缓存？", "会清除置顶、免打扰、图片缓存等本地设置", "清除", false, new Runnable() { // from class: com.changliao.im.MiscScr.SettingsScr.8.1
                        @Override // java.lang.Runnable
                        public void run() {
                            App.kv.edit().remove("pins").remove("mutes").apply();
                            SettingsScr.this.C.mutes.clear();
                            try {
                                for (File file : new File(SettingsScr.this.a.getCacheDir(), "img").listFiles()) {
                                    file.delete();
                                }
                            } catch (Throwable th) {
                            }
                            SettingsScr.this.C.emit("convs", null);
                            SettingsScr.this.toast("已清除");
                        }
                    });
                }
            });
            TextView textViewBtnGray = Ui.btnGray(this.a, "退出登录", new View.OnClickListener() { // from class: com.changliao.im.MiscScr.SettingsScr.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    SettingsScr.this.a.confirm("退出登录", "确定退出当前账号吗？", "退出", true, new Runnable() { // from class: com.changliao.im.MiscScr.SettingsScr.9.1
                        @Override // java.lang.Runnable
                        public void run() {
                            SettingsScr.this.C.logout();
                        }
                    });
                }
            });
            textViewBtnGray.setTextColor(Ui.RED);
            linearLayoutScrollPage.addView(textViewBtnGray, Ui.lpm(-1, -2, 16, 16, 16, 0));
            return linearLayoutPage;
        }
    }

    public static class VipScr extends Scr {
        LinearLayout body;
        List<J> vipList;

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("VIP中心", true);
            this.body = scrollPage(linearLayoutPage);
            if (this.C.isOwner) {
                this.C.send(J.of("t", "c_viplist"));
            }
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("c_viplist")) {
                this.vipList = j.objs("l");
                render();
            } else if (str.equals("c_vipme")) {
                this.C.vip = j.b("vip");
                this.C.bubble = j.s("bubble");
                render();
                this.C.emit("me", j);
            }
        }

        void render() {
            GradientDrawable gradientDrawable;
            this.body.removeAllViews();
            final boolean z = this.C.vip;
            J j = this.C.info == null ? new J() : this.C.info;
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.setPadding(Ui.dp(18.0f), Ui.dp(20.0f), Ui.dp(18.0f), Ui.dp(20.0f));
            if (z) {
                linearLayoutCol.setBackground(new G(5, 20.0f));
                linearLayoutCol.setElevation(Ui.dp(6.0f));
            } else {
                G.on(linearLayoutCol, 0, 20.0f, 3.0f);
            }
            int i = z ? -10864640 : -11642519;
            linearLayoutCol.addView(Ui.text(this.a, z ? "尊贵 VIP" : "普通用户", 13.0f, i));
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.addView(Ui.bold(Ui.text(this.a, j.s("nick"), 22.0f, z ? -8762624 : Ui.TEXT)));
            if (z) {
                linearLayoutRow.addView(Ui.vipTag(this.a));
            }
            linearLayoutCol.addView(linearLayoutRow, Ui.lpm(-2, -2, 0, 8, 0, 8));
            linearLayoutCol.addView(Ui.text(this.a, z ? "金色名字 · VIP 专属标识 · 全部聊天气泡" : "VIP 不能充值购买，可以向系统申请，审核通过后开通", 13.0f, i));
            if (!z && !this.C.isOwner) {
                TextView textViewBtn = Ui.btn(this.a, "向系统申请 VIP", new View.OnClickListener() { // from class: com.changliao.im.MiscScr.VipScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        VipScr.this.a.ask("申请 VIP", "说说为什么想要 VIP（选填）", "", true, 300, new MainActivity.Str() { // from class: com.changliao.im.MiscScr.VipScr.1.1
                            @Override // com.changliao.im.MainActivity.Str
                            public void ok(String str) {
                                VipScr.this.C.send(J.of("t", "c_vip_req", "text", str));
                            }
                        });
                    }
                });
                textViewBtn.setTextSize(15.0f);
                linearLayoutCol.addView(textViewBtn, Ui.lpm(-1, -2, 0, 14, 0, 0));
            }
            this.body.addView(linearLayoutCol, Ui.lpm(-1, -2, 12, 14, 12, 0));
            sec(this.body, "聊天气泡" + (z ? "" : "（VIP 专属）"));
            GridLayout gridLayout = new GridLayout(this.a);
            int width = this.a.host.getWidth() > 0 ? this.a.wide() ? (int) (this.a.host.getWidth() * 0.64f) : this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels;
            int iMax = Math.max(2, (width - Ui.dp(24.0f)) / Ui.dp(150.0f));
            gridLayout.setColumnCount(iMax);
            gridLayout.setPadding(Ui.dp(12.0f), Ui.dp(4.0f), Ui.dp(6.0f), Ui.dp(16.0f));
            int iDp = ((width - Ui.dp(24.0f)) / iMax) - Ui.dp(10.0f);
            String str = this.C.bubble == null ? "" : this.C.bubble;
            for (final String[] strArr : MiscScr.BUB) {
                LinearLayout linearLayoutCol2 = Ui.col(this.a);
                linearLayoutCol2.setGravity(1);
                linearLayoutCol2.setPadding(Ui.dp(8.0f), Ui.dp(14.0f), Ui.dp(8.0f), Ui.dp(10.0f));
                G.on(linearLayoutCol2, 0, 18.0f, 2.0f);
                if (str.equals(strArr[0])) {
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setCornerRadius(Ui.dp(18.0f));
                    gradientDrawable2.setStroke(Ui.dp(2.0f), Ui.BLUE);
                    linearLayoutCol2.setForeground(gradientDrawable2);
                }
                if (!z && strArr[0].length() > 0) {
                    linearLayoutCol2.setAlpha(0.6f);
                }
                int[] iArr = strArr[0].length() > 0 ? Bubbles.B.get(strArr[0]) : null;
                TextView textViewText = Ui.text(this.a, "你好呀～", 15.0f, iArr != null ? iArr[0] : Ui.TEXT);
                textViewText.setPadding(Ui.dp(13.0f), Ui.dp(9.0f), Ui.dp(13.0f), Ui.dp(9.0f));
                if (iArr != null) {
                    int[] iArr2 = new int[Math.max(2, iArr.length - 1)];
                    for (int i2 = 0; i2 < iArr2.length; i2++) {
                        iArr2[i2] = iArr[Math.min(iArr.length - 1, i2 + 1)];
                    }
                    gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, iArr2);
                } else {
                    gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(-1);
                }
                gradientDrawable.setCornerRadius(Ui.dp(12.0f));
                textViewText.setBackground(gradientDrawable);
                textViewText.setElevation(Ui.dp(2.0f));
                linearLayoutCol2.addView(textViewText);
                linearLayoutCol2.addView(Ui.text(this.a, strArr[1] + ((z || strArr[0].length() <= 0) ? "" : " 🔒"), 13.0f, str.equals(strArr[0]) ? Ui.BLUE : Ui.SUB), Ui.lpm(-2, -2, 0, 8, 0, 0));
                linearLayoutCol2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.MiscScr.VipScr.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (z || strArr[0].length() <= 0) {
                            VipScr.this.C.send(J.of("t", "c_bubble", "id", strArr[0]));
                        } else {
                            VipScr.this.err("聊天气泡是 VIP 专属，可以在上面向系统申请 VIP");
                        }
                    }
                });
                Ui.bounce(linearLayoutCol2);
                GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                layoutParams.width = iDp;
                layoutParams.setMargins(0, 0, Ui.dp(10.0f), Ui.dp(12.0f));
                gridLayout.addView(linearLayoutCol2, layoutParams);
            }
            this.body.addView(gridLayout);
            if (this.C.isOwner) {
                sec(this.body, "VIP 管理");
                LinearLayout linearLayoutRow2 = Ui.row(this.a);
                linearLayoutRow2.setPadding(Ui.dp(14.0f), Ui.dp(4.0f), Ui.dp(14.0f), Ui.dp(10.0f));
                final EditText editTextInput = Ui.input(this.a, "输入对方的 NK号 或昵称", false);
                editTextInput.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(14.0f), Ui.dp(9.0f));
                linearLayoutRow2.addView(editTextInput, Ui.lp(0, -2, 1.0f));
                TextView textViewSm = sm("授予VIP", 5, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.VipScr.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        String strTrim = editTextInput.getText().toString().trim();
                        if (strTrim.length() == 0) {
                            VipScr.this.err("请输入 NK号 或昵称");
                        } else {
                            VipScr.this.C.send(J.of("t", "c_vip", "nick", strTrim, "on", true));
                            editTextInput.setText("");
                        }
                    }
                });
                textViewSm.setTextColor(-9747712);
                linearLayoutRow2.addView(textViewSm, Ui.lpm(-2, -2, 8, 0, 0, 0));
                this.body.addView(linearLayoutRow2);
                if (this.vipList == null || this.vipList.isEmpty()) {
                    this.body.addView(empty("还没有 VIP 用户"));
                    return;
                }
                for (final J j2 : this.vipList) {
                    row(this.body, av(j2.s("nick"), j2.sn("av"), false), 40, j2.s("nick"), "NK " + j2.s("nk"), sm("取消", 0, new View.OnClickListener() { // from class: com.changliao.im.MiscScr.VipScr.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            VipScr.this.a.confirm("取消 VIP", "确定取消 TA 的 VIP 吗？", "取消VIP", true, new Runnable() { // from class: com.changliao.im.MiscScr.VipScr.4.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    VipScr.this.C.send(J.of("t", "c_vip", "nick", j2.s("nk"), "on", false));
                                }
                            });
                        }
                    }), null);
                }
            }
        }
    }

    public static void addFav(MainActivity mainActivity, J j) {
        List<J> listFavs = favs();
        Object[] objArr = new Object[8];
        objArr[0] = "k";
        objArr[1] = j.s("k");
        objArr[2] = "text";
        objArr[3] = j.s("text");
        objArr[4] = "from";
        objArr[5] = j.s("name").length() > 0 ? j.s("name") : j.s("from");
        objArr[6] = "ts";
        objArr[7] = Long.valueOf(j.l("ts") > 0 ? j.l("ts") : System.currentTimeMillis() / 1000);
        J jOf = J.of(objArr);
        if (j.o("f") != null) {
            jOf.put("f", j.o("f"));
        }
        listFavs.add(0, jOf);
        saveFavs(listFavs);
        mainActivity.toast("已收藏", false);
    }

    static List<J> favs() {
        Object obj = J.parse(App.kv.getString("favs", "[]"));
        ArrayList arrayList = new ArrayList();
        if (obj instanceof List) {
            for (Object obj2 : (List) obj) {
                if (obj2 instanceof J) {
                    arrayList.add((J) obj2);
                }
            }
        }
        return arrayList;
    }

    static void saveFavs(List<J> list) {
        while (list.size() > 300) {
            list.remove(list.size() - 1);
        }
        App.kv.edit().putString("favs", J.str(list)).apply();
    }
}
