package com.changliao.im;

import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/* JADX INFO: loaded from: classes.dex */
public class FwdScr extends Scr {
    final J m;

    public FwdScr(J j) {
        this.m = j;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("转发给…", true);
        ScrollView scrollView = new ScrollView(this.a);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.addView(Ui.text(this.a, "最近聊天", 13.0f, Ui.SUB), Ui.lpm(-2, -2, 16, 12, 16, 6));
        for (final J j : this.C.sortedConvs()) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setMinimumHeight(Ui.dp(60.0f));
            linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(8.0f), Ui.dp(14.0f), Ui.dp(8.0f));
            linearLayoutRow.setBackground(new RippleDrawable(ColorStateList.valueOf(303462384), new HomeScr.Row(-1), null));
            Img.Av av = new Img.Av(this.a);
            HomeScr.setConvAvatar(av, j, this.C);
            linearLayoutRow.addView(av, Ui.lpm(Ui.dp(40.0f), Ui.dp(40.0f), 0, 0, 12, 0));
            linearLayoutRow.addView(Ui.one(Ui.text(this.a, HomeScr.title(j), 16.0f, Ui.TEXT)), Ui.lp(0, -2, 1.0f));
            linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FwdScr.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String strPreview;
                    String strS = FwdScr.this.m.s("k");
                    MainActivity mainActivity = FwdScr.this.a;
                    String str = "发送给「" + HomeScr.title(j) + "」";
                    if (strS.equals("text")) {
                        strPreview = FwdScr.this.m.s("text").length() > 60 ? FwdScr.this.m.s("text").substring(0, 60) : FwdScr.this.m.s("text");
                    } else {
                        strPreview = ChatScr.preview(FwdScr.this.m);
                    }
                    mainActivity.confirm(str, strPreview, "发送", false, new Runnable() { // from class: com.changliao.im.FwdScr.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            String strS2 = j.s("conv");
                            J jO = FwdScr.this.m.o("f");
                            if (FwdScr.this.m.s("k").equals("text") || jO == null) {
                                FwdScr.this.C.send(J.of("t", "c_send", "conv", strS2, "k", "text", "text", FwdScr.this.m.s("text")));
                            } else {
                                FwdScr.this.C.send(J.of("t", "c_send", "conv", strS2, "k", FwdScr.this.m.s("k"), "fid", jO.s("id"), "w", Long.valueOf(jO.l("w")), "h", Long.valueOf(jO.l("h")), "dur", Long.valueOf(jO.l("dur")), "poster", jO.sn("poster")));
                            }
                            FwdScr.this.toast("已转发");
                            FwdScr.this.a.back();
                        }
                    });
                }
            });
            linearLayoutCol.addView(linearLayoutRow);
        }
        scrollView.addView(linearLayoutCol);
        linearLayoutPage.addView(scrollView, Ui.lp(-1, 0, 1.0f));
        return linearLayoutPage;
    }
}
