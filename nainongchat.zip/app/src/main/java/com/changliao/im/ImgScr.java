package com.changliao.im;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

/* JADX INFO: loaded from: classes.dex */
public class ImgScr extends Scr {
    final String conv;
    final J f;
    final J m;

    static class Zoom extends View {
        Bitmap b;
        float base;
        final GestureDetector gd;
        final Matrix mx;
        final Paint p;
        float sc;
        final ScaleGestureDetector sg;
        Runnable tap;
        float tx;
        float ty;

        Zoom(Context context) {
            super(context);
            this.mx = new Matrix();
            this.p = new Paint(3);
            this.base = 1.0f;
            this.sc = 1.0f;
            this.sg = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() { // from class: com.changliao.im.ImgScr.Zoom.1
                @Override // android.view.ScaleGestureDetector.SimpleOnScaleGestureListener, android.view.ScaleGestureDetector.OnScaleGestureListener
                public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
                    float fMax = Math.max(1.0f, Math.min(6.0f, Zoom.this.sc * scaleGestureDetector.getScaleFactor()));
                    float f = fMax / Zoom.this.sc;
                    Zoom.this.tx = scaleGestureDetector.getFocusX() - ((scaleGestureDetector.getFocusX() - Zoom.this.tx) * f);
                    Zoom.this.ty = scaleGestureDetector.getFocusY() - (f * (scaleGestureDetector.getFocusY() - Zoom.this.ty));
                    Zoom.this.sc = fMax;
                    Zoom.this.clamp();
                    Zoom.this.invalidate();
                    return true;
                }
            });
            this.gd = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() { // from class: com.changliao.im.ImgScr.Zoom.2
                @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
                public boolean onDoubleTap(MotionEvent motionEvent) {
                    if (Zoom.this.sc > 1.05f) {
                        Zoom.this.sc = 1.0f;
                        Zoom.this.fit();
                    } else {
                        Zoom.this.tx = motionEvent.getX() - ((motionEvent.getX() - Zoom.this.tx) * 2.5f);
                        Zoom.this.ty = motionEvent.getY() - ((motionEvent.getY() - Zoom.this.ty) * 2.5f);
                        Zoom.this.sc = 2.5f;
                        Zoom.this.clamp();
                    }
                    Zoom.this.invalidate();
                    return true;
                }

                @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
                public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
                    if (Zoom.this.sc <= 1.01f) {
                        return true;
                    }
                    Zoom.this.tx -= f;
                    Zoom.this.ty -= f2;
                    Zoom.this.clamp();
                    Zoom.this.invalidate();
                    return true;
                }

                @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
                public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
                    if (Zoom.this.tap == null) {
                        return true;
                    }
                    Zoom.this.tap.run();
                    return true;
                }
            });
        }

        void clamp() {
            float width = this.b.getWidth() * this.base * this.sc;
            float height = this.b.getHeight() * this.base * this.sc;
            if (width <= getWidth()) {
                this.tx = (getWidth() - width) / 2.0f;
            } else {
                this.tx = Math.min(0.0f, Math.max(getWidth() - width, this.tx));
            }
            if (height <= getHeight()) {
                this.ty = (getHeight() - height) / 2.0f;
            } else {
                this.ty = Math.min(0.0f, Math.max(getHeight() - height, this.ty));
            }
        }

        void fit() {
            if (this.b == null || getWidth() == 0) {
                return;
            }
            this.base = Math.min(getWidth() / this.b.getWidth(), getHeight() / this.b.getHeight());
            this.tx = (getWidth() - (this.b.getWidth() * this.base)) / 2.0f;
            this.ty = (getHeight() - (this.b.getHeight() * this.base)) / 2.0f;
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            if (this.b == null) {
                return;
            }
            this.mx.reset();
            this.mx.postScale(this.base * this.sc, this.base * this.sc);
            this.mx.postTranslate(this.tx, this.ty);
            canvas.drawBitmap(this.b, this.mx, this.p);
        }

        @Override // android.view.View
        protected void onSizeChanged(int i, int i2, int i3, int i4) {
            this.sc = 1.0f;
            fit();
        }

        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent motionEvent) {
            this.sg.onTouchEvent(motionEvent);
            this.gd.onTouchEvent(motionEvent);
            return true;
        }

        void set(Bitmap bitmap) {
            this.b = bitmap;
            this.sc = 1.0f;
            fit();
            invalidate();
            setAlpha(0.0f);
            animate().alpha(1.0f).setDuration(180L).start();
        }
    }

    public ImgScr(J j, String str, J j2) {
        this.f = j;
        this.conv = str;
        this.m = j2;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackgroundColor(-16777216);
        final Zoom zoom = new Zoom(this.a);
        frameLayout.addView(zoom, new FrameLayout.LayoutParams(-1, -1));
        final ProgressBar progressBar = new ProgressBar(this.a);
        frameLayout.addView(progressBar, Ui.flp(Ui.dp(40.0f), Ui.dp(40.0f), 17));
        Img.get(Core.fileUrl(this.f.s("id"), this.f.s("name")), 2048, new Img.Cb() { // from class: com.changliao.im.ImgScr.1
            @Override // com.changliao.im.Img.Cb
            public void done(Bitmap bitmap) {
                progressBar.setVisibility(8);
                if (bitmap != null) {
                    zoom.set(bitmap);
                } else {
                    ImgScr.this.toast("图片加载失败");
                }
            }
        });
        zoom.tap = new Runnable() { // from class: com.changliao.im.ImgScr.2
            @Override // java.lang.Runnable
            public void run() {
                ImgScr.this.a.back();
            }
        };
        ImageView imageViewIconBtn = Ui.iconBtn(this.a, "back", -1, 42.0f, new View.OnClickListener() { // from class: com.changliao.im.ImgScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ImgScr.this.a.back();
            }
        });
        imageViewIconBtn.setBackground(Ui.glassDark(21.0f));
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(Ui.dp(42.0f), Ui.dp(42.0f), 8388659);
        layoutParamsFlp.leftMargin = Ui.dp(12.0f);
        layoutParamsFlp.topMargin = Ui.dp(12.0f);
        frameLayout.addView(imageViewIconBtn, layoutParamsFlp);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        ImageView imageViewIconBtn2 = Ui.iconBtn(this.a, "dl", -1, 46.0f, new View.OnClickListener() { // from class: com.changliao.im.ImgScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Save.save(ImgScr.this.a, ImgScr.this.f, "img");
            }
        });
        imageViewIconBtn2.setBackground(Ui.glassDark(23.0f));
        linearLayoutRow.addView(imageViewIconBtn2);
        FrameLayout.LayoutParams layoutParamsFlp2 = Ui.flp(-2, -2, 8388693);
        layoutParamsFlp2.rightMargin = Ui.dp(16.0f);
        layoutParamsFlp2.bottomMargin = Ui.dp(24.0f);
        frameLayout.addView(linearLayoutRow, layoutParamsFlp2);
        return frameLayout;
    }

    @Override // com.changliao.im.Scr
    public boolean dark() {
        return true;
    }

    @Override // com.changliao.im.Scr
    public boolean full() {
        return true;
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        this.a.darkBars(false);
    }

    @Override // com.changliao.im.Scr
    public void onHide() {
        this.a.darkBars(false);
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        this.a.darkBars(true);
    }
}
