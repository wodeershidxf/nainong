package com.changliao.im;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Ico extends Drawable {
    static final HashMap<String, List<Object[]>> CACHE = new HashMap<>();
    int color;
    final List<Object[]> parts;
    final float vb;
    final Paint p = new Paint(1);
    float swMul = 1.0f;
    final Path tmp = new Path();
    final Matrix mx = new Matrix();
    int under = 0;

    static class Tok {
        int i;
        final String s;

        Tok(String str) {
            this.s = str;
        }

        char cmd() {
            sp();
            String str = this.s;
            int i = this.i;
            this.i = i + 1;
            return str.charAt(i);
        }

        boolean flag() {
            sp();
            String str = this.s;
            int i = this.i;
            this.i = i + 1;
            return str.charAt(i) == '1';
        }

        boolean isCmd() {
            sp();
            if (this.i >= this.s.length()) {
                return false;
            }
            char cCharAt = this.s.charAt(this.i);
            return (!Character.isLetter(cCharAt) || cCharAt == 'e' || cCharAt == 'E') ? false : true;
        }

        boolean more() {
            sp();
            return this.i < this.s.length();
        }

        float n() {
            sp();
            int i = this.i;
            if (this.i < this.s.length() && (this.s.charAt(this.i) == '-' || this.s.charAt(this.i) == '+')) {
                this.i++;
            }
            boolean z = false;
            while (this.i < this.s.length()) {
                char cCharAt = this.s.charAt(this.i);
                if (cCharAt >= '0' && cCharAt <= '9') {
                    this.i++;
                } else if (cCharAt == '.' && !z) {
                    z = true;
                    this.i++;
                } else {
                    if ((cCharAt != 'e' && cCharAt != 'E') || this.i + 1 >= this.s.length()) {
                        break;
                    }
                    this.i++;
                    if (this.s.charAt(this.i) == '-' || this.s.charAt(this.i) == '+') {
                        this.i++;
                    }
                }
            }
            if (i != this.i) {
                return Float.parseFloat(this.s.substring(i, this.i));
            }
            this.i++;
            return 0.0f;
        }

        void skip() {
            this.i++;
        }

        void sp() {
            while (this.i < this.s.length()) {
                if (this.s.charAt(this.i) != ' ' && this.s.charAt(this.i) != ',' && this.s.charAt(this.i) != '\n' && this.s.charAt(this.i) != '\t') {
                    return;
                } else {
                    this.i++;
                }
            }
        }
    }

    public Ico(String str, int i) {
        this.color = i;
        Float f = Icons.VB.get(str);
        this.vb = f == null ? 24.0f : f.floatValue();
        List<Object[]> list = CACHE.get(str);
        if (list == null) {
            ArrayList arrayList = new ArrayList();
            String[] strArr = Icons.M.get(str);
            if (strArr != null) {
                for (String str2 : strArr) {
                    String[] strArrSplit = str2.split("\\|", 4);
                    try {
                        arrayList.add(new Object[]{Float.valueOf(Float.parseFloat(strArrSplit[0])), Boolean.valueOf(strArrSplit[1].equals("1")), Boolean.valueOf(strArrSplit[2].equals("1")), parse(strArrSplit[3])});
                    } catch (Throwable th) {
                        Crash.note(th);
                    }
                }
            }
            CACHE.put(str, arrayList);
            list = arrayList;
        }
        this.parts = list;
        this.p.setStrokeCap(Paint.Cap.ROUND);
        this.p.setStrokeJoin(Paint.Join.ROUND);
    }

    static void arc(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean z, boolean z2) {
        double d;
        double d2;
        float f8;
        float f9;
        if (f5 == 0.0f || f6 == 0.0f) {
            path.lineTo(f3, f4);
            return;
        }
        double d3 = ((double) (f - f3)) / 2.0d;
        double d4 = ((double) (f2 - f4)) / 2.0d;
        double radians = Math.toRadians(((double) f7) % 360.0d);
        double dCos = Math.cos(radians);
        double dSin = Math.sin(radians);
        double d5 = (dCos * d3) + (dSin * d4);
        double d6 = (d3 * (-dSin)) + (d4 * dCos);
        float fAbs = Math.abs(f5);
        float fAbs2 = Math.abs(f6);
        double d7 = fAbs * fAbs;
        double d8 = fAbs2 * fAbs2;
        double d9 = d5 * d5;
        double d10 = d6 * d6;
        double d11 = (d9 / d7) + (d10 / d8);
        if (d11 > 1.0d) {
            float fSqrt = (float) (Math.sqrt(d11) * ((double) fAbs));
            float fSqrt2 = (float) (Math.sqrt(d11) * ((double) fAbs2));
            d = fSqrt2 * fSqrt2;
            d2 = fSqrt * fSqrt;
            f8 = fSqrt2;
            f9 = fSqrt;
        } else {
            d = d8;
            d2 = d7;
            f8 = fAbs2;
            f9 = fAbs;
        }
        double d12 = z == z2 ? -1.0d : 1.0d;
        double d13 = (((d2 * d) - (d2 * d10)) - (d * d9)) / ((d * d9) + (d2 * d10));
        if (d13 < 0.0d) {
            d13 = 0.0d;
        }
        double dSqrt = Math.sqrt(d13) * d12;
        double d14 = ((((double) f9) * d6) / ((double) f8)) * dSqrt;
        double d15 = dSqrt * (-((((double) f8) * d5) / ((double) f9)));
        double d16 = (((double) (f + f3)) / 2.0d) + ((dCos * d14) - (dSin * d15));
        double d17 = (((double) (f2 + f4)) / 2.0d) + (dSin * d14) + (dCos * d15);
        double d18 = (d5 - d14) / ((double) f9);
        double d19 = (d6 - d15) / ((double) f8);
        double d20 = ((-d5) - d14) / ((double) f9);
        double d21 = ((-d6) - d15) / ((double) f8);
        double degrees = Math.toDegrees(((double) (d19 < 0.0d ? -1 : 1)) * Math.acos(d18 / Math.sqrt((d18 * d18) + (d19 * d19))));
        double degrees2 = Math.toDegrees(((double) ((d18 * d21) - (d20 * d19) < 0.0d ? -1 : 1)) * Math.acos(Math.max(-1.0d, Math.min(1.0d, ((d19 * d21) + (d18 * d20)) / Math.sqrt(((d18 * d18) + (d19 * d19)) * ((d20 * d20) + (d21 * d21)))))));
        if (!z2 && degrees2 > 0.0d) {
            degrees2 -= 360.0d;
        } else if (z2 && degrees2 < 0.0d) {
            degrees2 += 360.0d;
        }
        double d22 = degrees2 % 360.0d;
        int iCeil = (int) Math.ceil(Math.abs(d22) / 90.0d);
        double radians2 = Math.toRadians(d22 / ((double) iCeil));
        double radians3 = Math.toRadians(degrees % 360.0d);
        double dTan = 1.3333333333333333d * Math.tan(radians2 / 4.0d);
        int i = 0;
        while (true) {
            int i2 = i;
            double d23 = radians3;
            if (i2 >= iCeil) {
                return;
            }
            double dCos2 = Math.cos(d23);
            double dSin2 = Math.sin(d23);
            double dCos3 = Math.cos(d23 + radians2);
            double dSin3 = Math.sin(d23 + radians2);
            double[] dArr = {dCos2 - (dTan * dSin2), (dCos2 * dTan) + dSin2, (dTan * dSin3) + dCos3, dSin3 - (dTan * dCos3), dCos3, dSin3};
            float[] fArr = new float[6];
            for (int i3 = 0; i3 < 6; i3 += 2) {
                double d24 = dArr[i3] * ((double) f9);
                double d25 = dArr[i3 + 1] * ((double) f8);
                fArr[i3] = (float) (((dCos * d24) + d16) - (dSin * d25));
                fArr[i3 + 1] = (float) ((d24 * dSin) + d17 + (d25 * dCos));
            }
            path.cubicTo(fArr[0], fArr[1], fArr[2], fArr[3], fArr[4], fArr[5]);
            radians3 = d23 + radians2;
            i = i2 + 1;
        }
    }

    static float[] nums(String str) {
        Tok tok = new Tok(str);
        float[] fArr = new float[4];
        for (int i = 0; tok.more() && i < 4; i++) {
            fArr[i] = tok.n();
        }
        return fArr;
    }

    static Path parse(String str) {
        char cCmd = 0; // jadx: 原字节码此槽位默认为 0，首次循环前若既非 cmd 也无延续命令则沿用 0
        char c;
        float f;
        float f2;
        float f3;
        float f4;
        Path path = new Path();
        if (str.startsWith("O")) {
            float[] fArrNums = nums(str.substring(1));
            path.addCircle(fArrNums[0], fArrNums[1], fArrNums[2], Path.Direction.CW);
        } else if (str.startsWith("E")) {
            float[] fArrNums2 = nums(str.substring(1));
            path.addOval(new RectF(fArrNums2[0] - fArrNums2[2], fArrNums2[1] - fArrNums2[3], fArrNums2[0] + fArrNums2[2], fArrNums2[3] + fArrNums2[1]), Path.Direction.CW);
        } else {
            Tok tok = new Tok(str);
            float fN = 0.0f;
            float fN2 = 0.0f;
            char c2 = 0;
            char c3 = 0;
            float f5 = 0.0f;
            float f6 = 0.0f;
            float f7 = 0.0f;
            float f8 = 0.0f;
            while (tok.more()) {
                if (tok.isCmd()) {
                    cCmd = tok.cmd();
                } else if (c2 != 0) {
                    cCmd = c2;
                }
                boolean zIsLowerCase = Character.isLowerCase(cCmd);
                char upperCase = Character.toUpperCase(cCmd);
                float f9 = zIsLowerCase ? fN : 0.0f;
                float f10 = zIsLowerCase ? fN2 : 0.0f;
                switch (upperCase) {
                    case 'A':
                        float fN3 = tok.n();
                        float fN4 = tok.n();
                        float fN5 = tok.n();
                        boolean zFlag = tok.flag();
                        boolean zFlag2 = tok.flag();
                        float fN6 = tok.n() + f9;
                        float fN7 = tok.n() + f10;
                        arc(path, fN, fN2, fN6, fN7, fN3, fN4, fN5, zFlag, zFlag2);
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        fN2 = fN7;
                        fN = fN6;
                        break;
                    case 'C':
                        float fN8 = tok.n() + f9;
                        float fN9 = tok.n() + f10;
                        float fN10 = tok.n() + f9;
                        float fN11 = tok.n() + f10;
                        float fN12 = tok.n() + f9;
                        float fN13 = tok.n() + f10;
                        path.cubicTo(fN8, fN9, fN10, fN11, fN12, fN13);
                        c = cCmd;
                        f = fN11;
                        f2 = fN10;
                        f3 = f7;
                        f4 = f8;
                        fN2 = fN13;
                        fN = fN12;
                        break;
                    case 'H':
                        if (!zIsLowerCase) {
                            fN = 0.0f;
                        }
                        fN += tok.n();
                        path.lineTo(fN, fN2);
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        break;
                    case 'L':
                        fN = tok.n() + f9;
                        fN2 = tok.n() + f10;
                        path.lineTo(fN, fN2);
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        break;
                    case 'M':
                        float fN14 = f9 + tok.n();
                        float fN15 = f10 + tok.n();
                        path.moveTo(fN14, fN15);
                        c = zIsLowerCase ? 'l' : 'L';
                        f = f5;
                        f2 = f6;
                        f3 = fN15;
                        f4 = fN14;
                        fN2 = fN15;
                        fN = fN14;
                        break;
                    case 'Q':
                        float fN16 = f9 + tok.n();
                        float fN17 = f10 + tok.n();
                        fN = tok.n() + f9;
                        fN2 = tok.n() + f10;
                        path.quadTo(fN16, fN17, fN, fN2);
                        c = cCmd;
                        f = fN17;
                        f2 = fN16;
                        f3 = f7;
                        f4 = f8;
                        break;
                    case 'S':
                        if (c3 == 'C' || c3 == 'S') {
                            fN = (fN * 2.0f) - f6;
                        }
                        if (c3 == 'C' || c3 == 'S') {
                            fN2 = (fN2 * 2.0f) - f5;
                        }
                        float fN18 = tok.n() + f9;
                        float fN19 = tok.n() + f10;
                        float fN20 = tok.n() + f9;
                        float fN21 = tok.n() + f10;
                        path.cubicTo(fN, fN2, fN18, fN19, fN20, fN21);
                        c = cCmd;
                        f = fN19;
                        f2 = fN18;
                        f3 = f7;
                        f4 = f8;
                        fN2 = fN21;
                        fN = fN20;
                        break;
                    case 'T':
                        float f11 = (c3 == 'Q' || c3 == 'T') ? (fN * 2.0f) - f6 : fN;
                        float f12 = (c3 == 'Q' || c3 == 'T') ? (2.0f * fN2) - f5 : fN2;
                        fN = tok.n() + f9;
                        fN2 = tok.n() + f10;
                        path.quadTo(f11, f12, fN, fN2);
                        c = cCmd;
                        f = f12;
                        f2 = f11;
                        f3 = f7;
                        f4 = f8;
                        break;
                    case 'V':
                        if (!zIsLowerCase) {
                            fN2 = 0.0f;
                        }
                        fN2 += tok.n();
                        path.lineTo(fN, fN2);
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        break;
                    case 'Z':
                        path.close();
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        fN2 = f7;
                        fN = f8;
                        break;
                    default:
                        tok.skip();
                        c = cCmd;
                        f = f5;
                        f2 = f6;
                        f3 = f7;
                        f4 = f8;
                        break;
                }
                if (upperCase != 'Z' || tok.isCmd() || tok.more()) {
                    c3 = upperCase;
                    c2 = c;
                    f5 = f;
                    f6 = f2;
                    f7 = f3;
                    f8 = f4;
                }
            }
        }
        return path;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        float fMin = Math.min(bounds.width(), bounds.height()) / this.vb;
        this.mx.reset();
        this.mx.setScale(fMin, fMin);
        this.mx.postTranslate(bounds.left + ((bounds.width() - (this.vb * fMin)) / 2.0f), ((bounds.height() - (this.vb * fMin)) / 2.0f) + bounds.top);
        this.p.setColor(this.color);
        for (Object[] objArr : this.parts) {
            this.tmp.reset();
            ((Path) objArr[3]).transform(this.mx, this.tmp);
            if (this.under != 0) {
                this.p.setStyle(Paint.Style.FILL);
                this.p.setColor(this.under);
                canvas.drawPath(this.tmp, this.p);
                this.p.setColor(this.color);
            }
            if (((Boolean) objArr[1]).booleanValue()) {
                this.p.setStyle(Paint.Style.FILL);
                canvas.drawPath(this.tmp, this.p);
            }
            if (((Boolean) objArr[2]).booleanValue() && ((Float) objArr[0]).floatValue() > 0.01f) {
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(((Float) objArr[0]).floatValue() * fMin * this.swMul);
                canvas.drawPath(this.tmp, this.p);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        this.p.setAlpha(i);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.p.setColorFilter(colorFilter);
    }

    public Ico stroke(float f) {
        this.swMul = f;
        return this;
    }

    public Ico tint(int i) {
        this.color = i;
        invalidateSelf();
        return this;
    }

    public Ico under(int i) {
        this.under = i;
        invalidateSelf();
        return this;
    }
}
