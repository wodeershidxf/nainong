package com.changliao.im;

import android.text.util.Linkify;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;

/* JADX INFO: loaded from: classes.dex */
public class AnnScr extends Scr {
    LinearLayout body;

    /* JADX INFO: renamed from: com.changliao.im.AnnScr$1, reason: invalid class name */
    class AnonymousClass1 implements View.OnClickListener {

        /* JADX INFO: renamed from: com.changliao.im.AnnScr$1$1, reason: invalid class name and collision with other inner class name */
        class C00011 implements MainActivity.Str {
            C00011() {
            }

            @Override // com.changliao.im.MainActivity.Str
            public void ok(final String str) {
                AnnScr.this.a.ask("公告内容", "发给全服所有用户，在线的人会马上收到", "", true, 3000, new MainActivity.Str() { // from class: com.changliao.im.AnnScr.1.1.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(final String str2) {
                        if (str2.length() == 0) {
                            return;
                        }
                        AnnScr.this.a.confirm("发布全服公告", "所有用户都会收到这条公告，确定发布吗？", "发布", false, new Runnable() { // from class: com.changliao.im.AnnScr.1.1.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                AnnScr.this.C.send(J.of("t", "c_ann_post", "title", str, "text", str2));
                            }
                        });
                    }
                });
            }
        }

        AnonymousClass1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            AnnScr.this.a.ask("公告标题（可不填）", "例如：服务器维护通知", "", false, 40, new C00011());
        }
    }

    /* JADX INFO: renamed from: com.changliao.im.AnnScr$4, reason: invalid class name */
    class AnonymousClass4 implements MainActivity.Str {
        final /* synthetic */ J val$an;

        AnonymousClass4(J j) {
            this.val$an = j;
        }

        @Override // com.changliao.im.MainActivity.Str
        public void ok(final String str) {
            AnnScr.this.a.ask("修改公告内容", "", this.val$an.s("text"), true, 3000, new MainActivity.Str() { // from class: com.changliao.im.AnnScr.4.1
                @Override // com.changliao.im.MainActivity.Str
                public void ok(final String str2) {
                    if (str2.length() == 0) {
                        return;
                    }
                    AnnScr.this.a.confirm("保存修改", "要不要让所有人重新收到这条公告的提醒？\n（选「不用」：只更新内容，已经看过的人不会再弹出）", "重新提醒", "不用", false, new Runnable() { // from class: com.changliao.im.AnnScr.4.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            AnnScr.this.C.send(J.of("t", "c_ann_edit", "id", Long.valueOf(AnonymousClass4.this.val$an.l("id")), "title", str, "text", str2, "again", true));
                        }
                    }, new Runnable() { // from class: com.changliao.im.AnnScr.4.1.2
                        @Override // java.lang.Runnable
                        public void run() {
                            AnnScr.this.C.send(J.of("t", "c_ann_edit", "id", Long.valueOf(AnonymousClass4.this.val$an.l("id")), "title", str, "text", str2, "again", false));
                        }
                    }, null);
                }
            });
        }
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("系统公告", true);
        if (this.C.isOwner) {
            tb("发布", new AnonymousClass1());
        }
        this.body = scrollPage(linearLayoutPage);
        this.C.send(J.of("t", "c_anns"));
        render();
        return linearLayoutPage;
    }

    void edit(J j) {
        this.a.ask("修改公告标题", "", j.s("title"), false, 40, new AnonymousClass4(j));
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("anns")) {
            render();
        }
    }

    void render() {
        this.body.removeAllViews();
        ArrayList<J> arrayList = new ArrayList(this.C.anns);
        Collections.reverse(arrayList);
        if (arrayList.isEmpty()) {
            this.body.addView(empty("还没有公告" + (this.C.isOwner ? "\n点右上角「发布」给全服发公告" : "")));
            return;
        }
        for (final J j : arrayList) {
            LinearLayout linearLayoutCsec = csec(this.body);
            linearLayoutCsec.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f));
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.addView(new Emo(this.a, "📢", true), Ui.lpm(Ui.dp(32.0f), Ui.dp(32.0f), 0, 0, 6, 0));
            linearLayoutRow.addView(Ui.bold(Ui.text(this.a, j.s("title").length() > 0 ? j.s("title") : "系统公告", 16.0f, Ui.TEXT)), Ui.lp(0, -2, 1.0f));
            if (this.C.isOwner) {
                linearLayoutRow.addView(sm("编辑", 0, new View.OnClickListener() { // from class: com.changliao.im.AnnScr.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        AnnScr.this.edit(j);
                    }
                }));
                linearLayoutRow.addView(sm("删除", 0, new View.OnClickListener() { // from class: com.changliao.im.AnnScr.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        AnnScr.this.a.confirm("删除这条公告？", "删除后所有人都看不到了", "删除", true, new Runnable() { // from class: com.changliao.im.AnnScr.3.1
                            @Override // java.lang.Runnable
                            public void run() {
                                AnnScr.this.C.send(J.of("t", "c_ann_del", "id", Long.valueOf(j.l("id"))));
                            }
                        });
                    }
                }), Ui.lpm(-2, -2, 6, 0, 0, 0));
            }
            linearLayoutCsec.addView(linearLayoutRow);
            TextView textViewText = Ui.text(this.a, j.s("text"), 15.0f, Ui.TEXT);
            textViewText.setLineSpacing(0.0f, 1.45f);
            textViewText.setTextIsSelectable(true);
            Linkify.addLinks(textViewText, 1);
            linearLayoutCsec.addView(textViewText, Ui.lpm(-1, -2, 0, 10, 0, 0));
            linearLayoutCsec.addView(Ui.text(this.a, j.l("edited") > 0 ? "已编辑 · " + Ui.fullWhen(j.l("edited")) : Ui.fullWhen(j.l("ts")), 12.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 10, 0, 0));
        }
    }
}
