package com.changliao.im;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Process;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Upd {
    static long asked;
    static boolean busy;
    static File done;
    static J force;
    static View shown;

    public static void check(final MainActivity mainActivity, final boolean z) {
        if (!busy) {
            new Thread(new Runnable() { // from class: com.changliao.im.Upd.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.http() + "/app/version.json?t=" + System.currentTimeMillis()).openConnection();
                        httpURLConnection.setConnectTimeout(8000);
                        httpURLConnection.setReadTimeout(10000);
                        final J jObj = J.obj(new String(Img.read(httpURLConnection.getInputStream()), "UTF-8"));
                        httpURLConnection.disconnect();
                        mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Upd.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Upd.got(mainActivity, jObj, z);
                            }
                        });
                    } catch (Throwable th) {
                        if (z) {
                            mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Upd.1.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    mainActivity.toast("检查更新失败，请稍后再试", true);
                                }
                            });
                        }
                    }
                }
            }).start();
        } else if (z) {
            mainActivity.toast("新版本正在下载，下载完会自动安装", false);
        }
    }

    static void download(final MainActivity mainActivity, final J j) {
        busy = true;
        LinearLayout linearLayoutDlgCard = mainActivity.dlgCard("正在下载新版本", null);
        final ProgressBar progressBar = new ProgressBar(mainActivity, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(1000);
        linearLayoutDlgCard.addView(progressBar, Ui.lpm(-1, Ui.dp(8.0f), 0, 18, 0, 6));
        final TextView textViewText = Ui.text(mainActivity, "0%", 13.0f, Ui.SUB);
        textViewText.setGravity(17);
        linearLayoutDlgCard.addView(textViewText);
        TextView textViewText2 = Ui.text(mainActivity, "下载完会自动打开安装", 12.0f, Ui.SUB);
        textViewText2.setGravity(17);
        textViewText2.setPadding(0, Ui.dp(8.0f), 0, 0);
        linearLayoutDlgCard.addView(textViewText2);
        final FrameLayout frameLayoutMask = mainActivity.mask(linearLayoutDlgCard, true, null);
        lock(mainActivity, frameLayoutMask);
        new Thread(new Runnable() { // from class: com.changliao.im.Upd.7
            @Override // java.lang.Runnable
            public void run() {
                try {
                    File externalFilesDir = mainActivity.getExternalFilesDir("Download");
                    if (externalFilesDir != null) {
                        externalFilesDir.mkdirs();
                    }
                    final File file = new File(externalFilesDir, "NAINONG-Chat-v" + j.s("name") + ".apk");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(Core.http() + "/app/nainong-chat.apk?v=" + j.l("code")).openConnection();
                    httpURLConnection.setConnectTimeout(10000);
                    httpURLConnection.setReadTimeout(30000);
                    final long contentLength = httpURLConnection.getContentLength() > 0 ? httpURLConnection.getContentLength() : j.l("size");
                    InputStream inputStream = httpURLConnection.getInputStream();
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    byte[] bArr = new byte[32768];
                    final long[] j2 = {0};
                    long j3 = 0;
                    while (true) {
                        int i = inputStream.read(bArr);
                        if (i <= 0) {
                            fileOutputStream.close();
                            inputStream.close();
                            httpURLConnection.disconnect();
                            mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Upd.7.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    Upd.busy = false;
                                    mainActivity.dismiss(frameLayoutMask);
                                    Upd.done = file;
                                    Upd.install(mainActivity, file);
                                }
                            });
                            return;
                        }
                        fileOutputStream.write(bArr, 0, i);
                        j2[0] += (long) i;
                        if (System.currentTimeMillis() - j3 > 150) {
                            long jCurrentTimeMillis = System.currentTimeMillis();
                            mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Upd.7.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    if (contentLength <= 0) {
                                        textViewText.setText(Ui.size(j2[0]));
                                    } else {
                                        progressBar.setProgress((int) ((j2[0] * 1000) / contentLength));
                                        textViewText.setText(((j2[0] * 100) / contentLength) + "%  ·  " + Ui.size(j2[0]) + " / " + Ui.size(contentLength));
                                    }
                                }
                            });
                            j3 = jCurrentTimeMillis;
                        }
                    }
                } catch (Throwable th) {
                    mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.Upd.7.3
                        @Override // java.lang.Runnable
                        public void run() {
                            Upd.busy = false;
                            mainActivity.dismiss(frameLayoutMask);
                            mainActivity.toast("下载失败，请检查网络后重试", true);
                            Upd.show(mainActivity);
                        }
                    });
                }
            }
        }).start();
    }

    static void exit(MainActivity mainActivity) {
        try {
            App.stopBg(mainActivity);
        } catch (Throwable th) {
        }
        mainActivity.finishAndRemoveTask();
        new Handler().postDelayed(new Runnable() { // from class: com.changliao.im.Upd.6
            @Override // java.lang.Runnable
            public void run() {
                Process.killProcess(Process.myPid());
            }
        }, 300L);
    }

    static void got(MainActivity mainActivity, J j, boolean z) {
        if (j != null && j.l("code") > 56) {
            force = j;
            show(mainActivity);
        } else if (z) {
            mainActivity.toast("已经是最新版本", false);
        }
    }

    public static void install(final MainActivity mainActivity, final File file) {
        if (mainActivity.getPackageManager().canRequestPackageInstalls()) {
            open(mainActivity, file, "application/vnd.android.package-archive");
        } else {
            mainActivity.confirm("需要一个权限", "安装新版本需要允许「安装未知应用」。\n点「去开启」后，打开开关再返回，就会自动安装。", "去开启", "取消", false, new Runnable() { // from class: com.changliao.im.Upd.9
                @Override // java.lang.Runnable
                public void run() {
                    mainActivity.startFor(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.parse("package:" + mainActivity.getPackageName())), new MainActivity.Res() { // from class: com.changliao.im.Upd.9.1
                        @Override // com.changliao.im.MainActivity.Res
                        public void got(int i, Intent intent) {
                            if (mainActivity.getPackageManager().canRequestPackageInstalls()) {
                                Upd.install(mainActivity, file);
                            } else {
                                mainActivity.toast("没有开启权限，暂时不能安装", true);
                                Upd.show(mainActivity);
                            }
                        }
                    });
                }
            }, new Runnable() { // from class: com.changliao.im.Upd.8
                @Override // java.lang.Runnable
                public void run() {
                    Upd.show(mainActivity);
                }
            });
        }
    }

    static void lock(final MainActivity mainActivity, FrameLayout frameLayout) {
        frameLayout.setOnClickListener(null);
        frameLayout.setTag(new Runnable() { // from class: com.changliao.im.Upd.5
            @Override // java.lang.Runnable
            public void run() {
                mainActivity.moveTaskToBack(true);
            }
        });
    }

    public static void open(MainActivity mainActivity, File file, String str) {
        try {
            Uri uri = Uri.parse("content://" + mainActivity.getPackageName() + ".prov/dl/" + Uri.encode(file.getName()));
            if (str == null || str.length() == 0 || str.equals("application/octet-stream")) {
                str = Prov.mime(file.getName());
            }
            if (str == null) {
                mainActivity.toast("手机上没有能打开这种文件的应用", true);
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(uri, str);
            intent.addFlags(268435457);
            List<ResolveInfo> listQueryIntentActivities = mainActivity.getPackageManager().queryIntentActivities(intent, 0);
            if (listQueryIntentActivities == null || listQueryIntentActivities.isEmpty()) {
                mainActivity.toast("手机上没有能打开这种文件的应用", true);
            } else if (str.equals("application/vnd.android.package-archive")) {
                mainActivity.startActivity(intent);
            } else {
                mainActivity.startActivity(Intent.createChooser(intent, "用其他应用打开").addFlags(268435456));
            }
        } catch (Throwable th) {
            mainActivity.toast("手机上没有能打开这种文件的应用", true);
        }
    }

    public static void resume(MainActivity mainActivity) {
        if (force == null || busy) {
            return;
        }
        if (force.l("code") <= 56) {
            force = null;
        } else {
            show(mainActivity);
        }
    }

    static void show(final MainActivity mainActivity) {
        final J j = force;
        if (j == null || busy || mainActivity.isFinishing()) {
            return;
        }
        if (shown == null || shown.getParent() == null || shown.getContext() != mainActivity) {
            long jL = j.l("size");
            String str = (j.s("notes").length() > 0 ? j.s("notes").trim() : "修复了一些问题，体验更流畅") + (jL > 0 ? "\n\n安装包大小约 " + Ui.size(jL) + "，这是必须的更新，不更新无法继续使用。" : "\n\n这是必须的更新，不更新无法继续使用。");
            LinearLayout linearLayoutDlgCard = mainActivity.dlgCard("发现新版本 v" + j.s("name"), null);
            final int iMin = Math.min((int) (mainActivity.getResources().getDisplayMetrics().heightPixels * 0.45f), Ui.dp(320.0f));
            ScrollView scrollView = new ScrollView(mainActivity) { // from class: com.changliao.im.Upd.2
                @Override // android.widget.ScrollView, android.widget.FrameLayout, android.view.View
                protected void onMeasure(int i, int i2) {
                    super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE));
                }
            };
            TextView textViewText = Ui.text(mainActivity, str, 14.0f, Ui.SUB);
            textViewText.setLineSpacing(0.0f, 1.35f);
            scrollView.addView(textViewText);
            linearLayoutDlgCard.addView(scrollView, Ui.lpm(-1, -2, 0, 10, 0, 0));
            final View[] viewArr = new View[1];
            LinearLayout linearLayoutRow = Ui.row(mainActivity);
            TextView textViewBtnGray = Ui.btnGray(mainActivity, "退出软件", new View.OnClickListener() { // from class: com.changliao.im.Upd.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    Upd.exit(mainActivity);
                }
            });
            TextView textViewBtn = Ui.btn(mainActivity, "立即更新", new View.OnClickListener() { // from class: com.changliao.im.Upd.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    mainActivity.dismiss(viewArr[0]);
                    Upd.shown = null;
                    if (Upd.done != null && Upd.done.exists() && Upd.done.getName().contains("v" + j.s("name") + ".apk")) {
                        Upd.install(mainActivity, Upd.done);
                    } else {
                        Upd.download(mainActivity, j);
                    }
                }
            });
            linearLayoutRow.addView(textViewBtnGray, Ui.lpm(0, Ui.dp(44.0f), 0, 0, 6, 0));
            ((LinearLayout.LayoutParams) textViewBtnGray.getLayoutParams()).weight = 1.0f;
            linearLayoutRow.addView(textViewBtn, Ui.lpm(0, Ui.dp(44.0f), 6, 0, 0, 0));
            ((LinearLayout.LayoutParams) textViewBtn.getLayoutParams()).weight = 1.0f;
            linearLayoutDlgCard.addView(linearLayoutRow, Ui.lpm(-1, -2, 0, 18, 0, 0));
            FrameLayout frameLayoutMask = mainActivity.mask(linearLayoutDlgCard, true, null);
            lock(mainActivity, frameLayoutMask);
            viewArr[0] = frameLayoutMask;
            shown = frameLayoutMask;
        }
    }
}
