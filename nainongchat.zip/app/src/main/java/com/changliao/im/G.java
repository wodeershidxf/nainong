package com.changliao.im;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class G extends Drawable {
    public static final int BLUE = 1;
    public static final int DARK = 2;
    public static final int GOLD = 5;
    public static final int GREEN = 6;
    public static final int INSET = 3;
    static final WeakHashMap<View, Boolean> KEEP = new WeakHashMap<>();
    public static final int LIGHT = 0;
    static boolean LITE = false;
    public static final int RED = 4;
    public boolean btn;
    final int kind;
    final float r;
    final Paint fill = new Paint(1);
    final Paint hl = new Paint(1);
    final Paint edge = new Paint(1);
    final Paint shade = new Paint(1);
    final Paint gloss = new Paint(1);
    final Paint caus = new Paint(1);
    final Paint inner = new Paint(1);
    final Paint hair = new Paint(1);
    final RectF rf = new RectF();
    int lastW = -1;
    int lastH = -1;
    public int bg = Ui.BG;

    public G(int i, float f) {
        this.kind = i;
        this.r = Ui.dp(f);
        this.edge.setStyle(Paint.Style.STROKE);
        this.edge.setStrokeWidth(Math.max(1.0f, Ui.D * 0.9f));
        this.inner.setStyle(Paint.Style.STROKE);
        this.inner.setStrokeWidth(Math.max(1.0f, Ui.D * 0.7f));
        this.hair.setStyle(Paint.Style.STROKE);
        this.hair.setStrokeWidth(Math.max(1.0f, Ui.D * 0.5f));
    }

    static float[] css(float f, float f2, float f3) {
        double radians = Math.toRadians(f);
        float fSin = (float) Math.sin(radians);
        float f4 = (float) (-Math.cos(radians));
        float fAbs = Math.abs(f2 * fSin) + Math.abs(f3 * f4);
        return new float[]{(f2 / 2.0f) - ((fSin * fAbs) / 2.0f), (f3 / 2.0f) - ((f4 * fAbs) / 2.0f), ((fSin * fAbs) / 2.0f) + (f2 / 2.0f), ((f4 * fAbs) / 2.0f) + (f3 / 2.0f)};
    }

    public static void keepClip(ViewGroup viewGroup) {
        KEEP.put(viewGroup, true);
        viewGroup.setClipChildren(true);
        viewGroup.setClipToPadding(true);
    }

    static int mix(int i, float f, int i2) {
        return (((int) ((((i >> 16) & 255) * f) + (((i2 >> 16) & 255) * (1.0f - f)))) << 16) | (-16777216) | (((int) ((((i >> 8) & 255) * f) + (((i2 >> 8) & 255) * (1.0f - f)))) << 8) | ((int) (((i & 255) * f) + ((i2 & 255) * (1.0f - f))));
    }

    public static View on(View view, int i, float f, float f2) {
        int i2;
        if (LITE) {
            f2 = Math.min(f2, 1.0f);
        }
        G g = new G(i, f);
        g.btn = true;
        view.setBackground(new RippleDrawable(ColorStateList.valueOf((i == 1 || i == 4 || i == 6 || i == 2) ? 872415231 : 337016816), g, null));
        if (f2 > 0.0f) {
            view.setElevation(Ui.dp(f2));
            if (Build.VERSION.SDK_INT >= 28) {
                if (i == 1) {
                    i2 = -15309072;
                } else if (i == 4) {
                    i2 = -1691076;
                } else if (i == 6) {
                    i2 = -14702518;
                } else {
                    i2 = i == 2 ? -16777216 : -14796956;
                }
                view.setOutlineSpotShadowColor(i2);
                view.setOutlineAmbientShadowColor(i2);
            }
            unclip(view);
        }
        return view;
    }

    static void unclip(View view) {
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() { // from class: com.changliao.im.G.1
            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewAttachedToWindow(View view2) {
                boolean z;
                ViewParent parent = view2.getParent();
                for (int i = 0; i < 3 && (parent instanceof ViewGroup); i++) {
                    ViewGroup viewGroup = (ViewGroup) parent;
                    if ((viewGroup instanceof AbsListView) || (viewGroup instanceof ScrollView) || (viewGroup instanceof HorizontalScrollView) || G.KEEP.containsKey(viewGroup)) {
                        return;
                    }
                    int i2 = 0;
                    while (true) {
                        if (i2 >= viewGroup.getChildCount()) {
                            z = false;
                            break;
                        }
                        View childAt = viewGroup.getChildAt(i2);
                        if ((childAt instanceof AbsListView) || (childAt instanceof ScrollView)) {
                            z = true;
                            break;
                        }
                        i2++;
                    }
                    if (z) {
                        return;
                    }
                    viewGroup.setClipChildren(false);
                    viewGroup.setClipToPadding(false);
                    if (viewGroup.getClipToOutline()) {
                        return;
                    }
                    parent = viewGroup.getParent();
                }
            }

            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewDetachedFromWindow(View view2) {
            }
        });
    }

    static LinearGradient vg(float f, float f2, int i, int i2) {
        return new LinearGradient(0.0f, f, 0.0f, f2, new int[]{i, i2}, (float[]) null, Shader.TileMode.CLAMP);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        float fWidth = bounds.width();
        float fHeight = bounds.height();
        if (fWidth <= 0.0f || fHeight <= 0.0f) {
            return;
        }
        shaders(fWidth, fHeight);
        canvas.save();
        canvas.translate(bounds.left, bounds.top);
        float fMin = Math.min(this.r, Math.min(fWidth, fHeight) / 2.0f);
        this.rf.set(0.0f, 0.0f, fWidth, fHeight);
        canvas.drawRoundRect(this.rf, fMin, fMin, this.fill);
        if (LITE) {
            canvas.restore();
            return;
        }
        if (this.gloss.getShader() != null) {
            canvas.drawRoundRect(this.rf, fMin, fMin, this.gloss);
        }
        if (this.caus.getShader() != null) {
            canvas.drawRoundRect(this.rf, fMin, fMin, this.caus);
        }
        canvas.drawRoundRect(this.rf, fMin, fMin, this.hl);
        if (this.shade.getShader() != null) {
            canvas.drawRoundRect(this.rf, fMin, fMin, this.shade);
        }
        float strokeWidth = this.hair.getStrokeWidth() / 2.0f;
        if (this.hair.getColor() != 0 && this.hair.getShader() == null && this.kind != 2) {
            this.rf.set(strokeWidth, strokeWidth, fWidth - strokeWidth, fHeight - strokeWidth);
            canvas.drawRoundRect(this.rf, fMin - strokeWidth, fMin - strokeWidth, this.hair);
        }
        float strokeWidth2 = this.edge.getStrokeWidth() / 2.0f;
        this.rf.set(strokeWidth2, strokeWidth2, fWidth - strokeWidth2, fHeight - strokeWidth2);
        if (this.edge.getShader() != null) {
            canvas.drawRoundRect(this.rf, fMin - strokeWidth2, fMin - strokeWidth2, this.edge);
        }
        if (this.inner.getShader() != null) {
            float strokeWidth3 = this.edge.getStrokeWidth() + (this.inner.getStrokeWidth() / 2.0f);
            this.rf.set(strokeWidth3, strokeWidth3, fWidth - strokeWidth3, fHeight - strokeWidth3);
            canvas.drawRoundRect(this.rf, Math.max(0.0f, fMin - strokeWidth3), Math.max(0.0f, fMin - strokeWidth3), this.inner);
        }
        canvas.restore();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        float f;
        Rect bounds = getBounds();
        outline.setRoundRect(bounds, Math.min(this.r, Math.min(bounds.width(), bounds.height()) / 2.0f));
        if (this.kind == 2) {
            f = 0.35f;
        } else {
            f = (this.btn && this.kind == 0 && !LITE) ? 0.45f : 1.0f;
        }
        outline.setAlpha(f);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
    }

    void shaders(float f, float f2) {
        if (f == this.lastW && f2 == this.lastH) {
        }
        this.lastW = (int) f;
        this.lastH = (int) f2;
        float fMax = Math.max(f, f2);
        float[] fArrCss = css(150.0f, f, f2);
        float[] fArrCss2 = css(160.0f, f, f2);
        float[] fArrCss3 = css(135.0f, f, f2);
        this.gloss.setShader(null);
        this.caus.setShader(null);
        this.inner.setShader(null);
        this.hair.setShader(null);
        this.hair.setColor(0);
        switch (this.kind) {
            case BLUE /* 1 */:
                tinted(f, f2, fArrCss2, fArrCss, this.btn ? -346244097 : -11685121, this.btn ? -401180688 : -15304720, this.btn ? -348300043 : -12755723, -1280781057, 1553720319, 1073749624);
                break;
            case DARK /* 2 */:
                this.fill.setShader(vg(0.0f, f2, this.btn ? 822083583 : 704643071, this.btn ? 268435455 : 234881023));
                this.hl.setShader(new RadialGradient(f * 0.25f, (-f2) * 0.12f, fMax * 0.65f, new int[]{1207959551, 16777215}, new float[]{0.0f, 0.85f}, Shader.TileMode.CLAMP));
                this.gloss.setShader(vg(0.0f, 0.5f * f2, 654311423, 16777215));
                this.caus.setShader(vg(0.6f * f2, f2, 16777215, 452984831));
                this.edge.setShader(new LinearGradient(fArrCss[0], fArrCss[1], fArrCss[2], fArrCss[3], new int[]{-1275068417, 352321535, 184549375, 1946157055}, new float[]{0.0f, 0.4f, 0.65f, 1.0f}, Shader.TileMode.CLAMP));
                this.inner.setShader(vg(0.0f, 0.4f * f2, 872415231, 16777215));
                this.shade.setShader(null);
                break;
            case INSET /* 3 */:
            default:
                if (this.btn && !LITE && this.kind == 0) {
                    this.fill.setShader(new LinearGradient(0.0f, 0.0f, 0.0f, f2, new int[]{-1191182337, -1929708289, 1978857471}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
                    this.gloss.setShader(vg(0.0f, 0.5f * f2, 1728053247, 16777215));
                    this.caus.setShader(vg(0.58f * f2, f2, 16777215, -1929379841));
                    this.hair.setColor(471742308);
                } else {
                    this.fill.setShader(vg(0.0f, f2, mix(-1, 0.62f, this.bg), mix(-591361, 0.34f, this.bg)));
                    if (this.kind == 0) {
                        this.gloss.setShader(vg(0.0f, 0.45f * f2, 872415231, 16777215));
                    }
                }
                this.hl.setShader(new RadialGradient(f * 0.25f, (-f2) * 0.12f, fMax * 0.7f, new int[]{-218103809, 16777215}, new float[]{0.0f, 0.8f}, Shader.TileMode.CLAMP));
                this.edge.setShader(new LinearGradient(fArrCss[0], fArrCss[1], fArrCss[2], fArrCss[3], new int[]{-1, 1308622847, 1388303346, -218103809}, new float[]{0.0f, 0.36f, 0.64f, 1.0f}, Shader.TileMode.CLAMP));
                if (this.kind != 3) {
                    this.inner.setShader(vg(0.0f, 0.5f * f2, -2130706433, 16777215));
                }
                if (this.kind != 3) {
                    this.shade.setShader(vg(f2 - Ui.dp(10.0f), f2, 7904200, this.btn ? 611883976 : 779656136));
                } else {
                    this.shade.setShader(vg(0.0f, Ui.dp(4.0f), 438187876, 1980260));
                }
                break;
            case RED /* 4 */:
                tinted(f, f2, fArrCss2, fArrCss, this.btn ? -335575689 : -34197, this.btn ? -386909891 : -1033923, this.btn ? -337632162 : -2087842, -1275084094, 1392488616, 1081606176);
                break;
            case GOLD /* 5 */:
                this.fill.setShader(new LinearGradient(fArrCss3[0], fArrCss3[1], fArrCss3[2], fArrCss3[3], new int[]{-8054, -739526, -1860837}, new float[]{0.0f, 0.6f, 1.0f}, Shader.TileMode.CLAMP));
                this.hl.setShader(new RadialGradient(f * 0.3f, (-f2) * 0.1f, fMax * 0.55f, new int[]{-2095, 16777215}, (float[]) null, Shader.TileMode.CLAMP));
                this.gloss.setShader(vg(0.0f, 0.5f * f2, 1090519039, 16777215));
                this.edge.setShader(new LinearGradient(fArrCss[0], fArrCss[1], fArrCss[2], fArrCss[3], new int[]{-855638017, 452984831, -2130710336}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
                this.shade.setShader(null);
                break;
            case GREEN /* 6 */:
                tinted(f, f2, fArrCss2, fArrCss, this.btn ? -346103686 : -10559366, this.btn ? -399456942 : -13580974, this.btn ? -350246838 : -14702518, -1279068721, 1387659208, 1073764894);
                break;
        }
    }

    void tinted(float f, float f2, float[] fArr, float[] fArr2, int i, int i2, int i3, int i4, int i5, int i6) {
        float fMax = Math.max(f, f2);
        this.fill.setShader(new LinearGradient(fArr[0], fArr[1], fArr[2], fArr[3], new int[]{i, i2, i3}, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP));
        this.hl.setShader(new RadialGradient(0.26f * f, (-f2) * 0.16f, 0.62f * fMax, new int[]{-1929379841, 16777215}, (float[]) null, Shader.TileMode.CLAMP));
        this.gloss.setShader(vg(0.0f, 0.62f * f2, 1090519039, 16777215));
        this.caus.setShader(vg(0.55f * f2, f2, 16777215, i5));
        this.edge.setShader(new LinearGradient(fArr2[0], fArr2[1], fArr2[2], fArr2[3], new int[]{-218103809, 654311423, 352321535, i4}, new float[]{0.0f, 0.4f, 0.62f, 1.0f}, Shader.TileMode.CLAMP));
        this.inner.setShader(vg(0.0f, 0.45f * f2, 1728053247, 16777215));
        this.hair.setShader(null);
        this.hair.setColor(i6);
        this.shade.setShader(vg(0.62f * f2, f2, 0, i6));
    }
}
