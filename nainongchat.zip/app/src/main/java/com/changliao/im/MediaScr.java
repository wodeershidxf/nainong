package com.changliao.im;

import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class MediaScr extends Scr {
    final String conv;
    final String gid;
    final Runnable go = new Runnable() { // from class: com.changliao.im.MediaScr.2
        @Override // java.lang.Runnable
        public void run() {
            String strTrim = MediaScr.this.q.getText().toString().trim();
            if (strTrim.length() > 0) {
                MediaScr.this.C.send(J.of("t", "c_search", "conv", MediaScr.this.conv, "q", strTrim));
            } else {
                MediaScr.this.search = null;
                MediaScr.this.render();
            }
        }
    };
    List<J> media;
    EditText q;
    LinearLayout res;
    J search;
    String tab;

    public MediaScr(String str, String str2, String str3) {
        this.conv = str;
        this.gid = str2;
        this.tab = str3 == null ? "img" : str3;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page(this.gid != null ? "群文件 / 相册" : "查找聊天记录", true);
        if (this.gid == null) {
            this.q = searchBox(linearLayoutPage, "搜索聊天内容");
            this.q.addTextChangedListener(new TextWatcher() { // from class: com.changliao.im.MediaScr.1
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                    MediaScr.this.a.h.removeCallbacks(MediaScr.this.go);
                    MediaScr.this.a.h.postDelayed(MediaScr.this.go, 300L);
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }
            });
            this.C.send(J.of("t", "c_media", "conv", this.conv));
        } else {
            this.C.send(J.of("t", "c_gfiles", "gid", this.gid));
        }
        this.res = scrollPage(linearLayoutPage);
        render();
        return linearLayoutPage;
    }

    void fileList(List<J> list) {
        for (final J j : list) {
            final J jO = j.o("f");
            if (jO != null) {
                TextView textViewText = Ui.text(this.a, j.s("k").equals("video") ? "🎬" : j.s("k").equals("voice") ? "🎵" : Ui.fileIcon(jO.s("name")), 24.0f, Ui.TEXT);
                textViewText.setGravity(17);
                textViewText.setBackground(Ui.round(-1117965, 10.0f));
                row(this.res, textViewText, 50, jO.s("name"), Ui.size(jO.l("size")) + " · " + (j.s("name").length() > 0 ? j.s("name") : j.s("from")) + " · " + Ui.fullWhen(j.l("ts")), null, new View.OnClickListener() { // from class: com.changliao.im.MediaScr.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (j.s("k").equals("video")) {
                            MediaScr.this.a.push(new VidScr(jO, MediaScr.this.conv, j));
                        } else {
                            ChatScr.openFileStatic(MediaScr.this.a, j, jO, MediaScr.this.conv);
                        }
                    }
                });
            }
        }
    }

    View grid(List<J> list) {
        GridLayout gridLayout = new GridLayout(this.a);
        gridLayout.setColumnCount(4);
        gridLayout.setPadding(Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f));
        int width = (((this.a.host.getWidth() > 0 ? this.a.wide() ? (int) (this.a.host.getWidth() * 0.64f) : this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels) - Ui.dp(6.0f)) / 4) - Ui.dp(3.0f);
        for (final J j : list) {
            final J jO = j.o("f");
            if (jO != null) {
                FrameLayout frameLayout = new FrameLayout(this.a);
                frameLayout.setBackgroundColor(j.s("k").equals("video") ? -13421773 : -1841430);
                ImageView imageView = new ImageView(this.a);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                String strS = j.s("k").equals("video") ? jO.s("poster") : jO.s("id");
                if (strS.length() > 0) {
                    Img.into(imageView, Core.fileUrl(strS, j.s("k").equals("video") ? "p.jpg" : jO.s("name")), 300);
                }
                frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                if (j.s("k").equals("video")) {
                    TextView textViewText = Ui.text(this.a, "▶", 22.0f, -1);
                    textViewText.setShadowLayer(Ui.dp(4.0f), 0.0f, Ui.dp(1.0f), -16777216);
                    frameLayout.addView(textViewText, new FrameLayout.LayoutParams(-2, -2, 17));
                }
                frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.MediaScr.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (j.s("k").equals("img")) {
                            MediaScr.this.a.push(new ImgScr(jO, MediaScr.this.conv, j));
                        } else {
                            MediaScr.this.a.push(new VidScr(jO, MediaScr.this.conv, j));
                        }
                    }
                });
                GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                layoutParams.width = width;
                layoutParams.height = width;
                layoutParams.setMargins(Ui.dp(1.5f), Ui.dp(1.5f), Ui.dp(1.5f), Ui.dp(1.5f));
                gridLayout.addView(frameLayout, layoutParams);
            }
        }
        return gridLayout;
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("c_media") && this.conv.equals(j.s("conv"))) {
            this.media = j.objs("l");
            render();
            return;
        }
        if (str.equals("c_gfiles") && this.gid != null && this.gid.equals(j.s("gid"))) {
            this.media = j.objs("l");
            render();
        } else if (str.equals("c_search") && this.conv.equals(j.s("conv"))) {
            this.search = j;
            render();
        }
    }

    void render() {
        int iIndexOf;
        this.res.removeAllViews();
        if (this.gid == null && this.search != null && this.q.getText().toString().trim().length() > 0) {
            String strS = this.search.s("q");
            List<J> listObjs = this.search.objs("l");
            if (listObjs.isEmpty()) {
                this.res.addView(empty("没有找到相关的聊天记录"));
                return;
            }
            for (J j : listObjs) {
                SpannableString spannableString = new SpannableString(j.s("text"));
                String lowerCase = j.s("text").toLowerCase();
                String lowerCase2 = strS.toLowerCase();
                int length = 0;
                while (lowerCase2.length() > 0 && (iIndexOf = lowerCase.indexOf(lowerCase2, length)) >= 0) {
                    spannableString.setSpan(new ForegroundColorSpan(Ui.BLUE), iIndexOf, lowerCase2.length() + iIndexOf, 0);
                    spannableString.setSpan(new StyleSpan(1), iIndexOf, lowerCase2.length() + iIndexOf, 0);
                    length = iIndexOf + lowerCase2.length();
                }
                LinearLayout linearLayout = (LinearLayout) row(this.res, av(j.s("name").length() > 0 ? j.s("name") : j.s("from"), j.sn("av"), false), 40, j.s("name").length() > 0 ? j.s("name") : j.s("from"), spannableString, Ui.text(this.a, Ui.fullWhen(j.l("ts")), 12.0f, Ui.SUB), null).getChildAt(1);
                if (linearLayout.getChildCount() > 1) {
                    TextView textView = (TextView) linearLayout.getChildAt(1);
                    textView.setSingleLine(false);
                    textView.setMaxLines(4);
                }
            }
            return;
        }
        if (this.media == null) {
            this.res.addView(empty("加载中…"));
            return;
        }
        List<J> arrayList = new ArrayList<>();
        List<J> arrayList2 = new ArrayList<>();
        ArrayList arrayList3 = new ArrayList();
        for (J j2 : this.media) {
            String strS2 = j2.s("k");
            if (strS2.equals("img")) {
                arrayList.add(j2);
            } else if (strS2.equals("video")) {
                arrayList2.add(j2);
            } else {
                arrayList3.add(j2);
            }
        }
        if (this.gid != null) {
            if (this.media.isEmpty()) {
                this.res.addView(empty("群里还没有发过文件和图片"));
                return;
            }
            if (!arrayList.isEmpty()) {
                sec(this.res, "相册");
                this.res.addView(grid(arrayList));
            }
            List<J> arrayList4 = new ArrayList<>(arrayList2);
            arrayList4.addAll(arrayList3);
            if (arrayList4.isEmpty()) {
                return;
            }
            sec(this.res, "文件");
            fileList(arrayList4);
            return;
        }
        sec(this.res, "按类型查找");
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(12.0f), Ui.dp(4.0f), Ui.dp(12.0f), Ui.dp(10.0f));
        for (final String[] strArr : new String[][]{new String[]{"img", "图片"}, new String[]{"video", "视频"}, new String[]{"file", "文件"}}) {
            linearLayoutRow.addView(Ui.chip(this.a, strArr[1], this.tab.equals(strArr[0]), new View.OnClickListener() { // from class: com.changliao.im.MediaScr.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MediaScr.this.tab = strArr[0];
                    MediaScr.this.render();
                }
            }), Ui.lpm(-2, -2, 0, 0, 8, 0));
        }
        this.res.addView(linearLayoutRow);
        List<J> list = this.tab.equals("img") ? arrayList : this.tab.equals("video") ? arrayList2 : arrayList3;
        if (!list.isEmpty()) {
            if (this.tab.equals("file")) {
                fileList(list);
                return;
            } else {
                this.res.addView(grid(list));
                return;
            }
        }
        this.res.addView(empty(new StringBuilder().append("没有").append(this.tab.equals("img") ? "图片" : this.tab.equals("video") ? "视频" : "文件").toString()));
    }
}
