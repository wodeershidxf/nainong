package com.changliao.im;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class ProfileScr extends Scr {
    LinearLayout body;
    FrameLayout fr;
    final String gid;
    final String nk;
    J p;

    /* JADX INFO: renamed from: com.changliao.im.ProfileScr$12, reason: invalid class name */
    class AnonymousClass12 implements View.OnClickListener {
        final /* synthetic */ boolean val$v;

        AnonymousClass12(boolean z) {
            this.val$v = z;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ProfileScr.this.a.confirm(this.val$v ? "取消 VIP" : "授予 VIP", this.val$v ? "确定取消「" + ProfileScr.this.p.s("nick") + "」的 VIP 吗？" : "授予「" + ProfileScr.this.p.s("nick") + "」VIP 后，TA 会有金色名字、VIP 标识，并能使用全部聊天气泡。", this.val$v ? "取消VIP" : "授予", this.val$v, new Runnable() { // from class: com.changliao.im.ProfileScr.12.1
                @Override // java.lang.Runnable
                public void run() {
                    Core core = ProfileScr.this.C;
                    Object[] objArr = new Object[6];
                    objArr[0] = "t";
                    objArr[1] = "c_vip";
                    objArr[2] = "nick";
                    objArr[3] = ProfileScr.this.nk;
                    objArr[4] = "on";
                    objArr[5] = Boolean.valueOf(AnonymousClass12.this.val$v ? false : true);
                    core.send(J.of(objArr));
                    ProfileScr.this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.ProfileScr.12.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ProfileScr.this.C.sendQ(J.of("t", "c_profile", "nick", ProfileScr.this.nk));
                        }
                    }, 500L);
                }
            });
        }
    }

    /* JADX INFO: renamed from: com.changliao.im.ProfileScr$2, reason: invalid class name */
    class AnonymousClass2 implements View.OnClickListener {
        final /* synthetic */ boolean val$adminMenu;

        AnonymousClass2(boolean z) {
            this.val$adminMenu = z;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ArrayList arrayList = new ArrayList();
            if (this.val$adminMenu) {
                arrayList.add("群成员管理…");
            }
            if (!ProfileScr.this.p.b("me")) {
                arrayList.add("举报该用户");
            }
            if (ProfileScr.this.C.isOwner && !ProfileScr.this.p.b("me") && !ProfileScr.this.p.b("isowner")) {
                arrayList.add(ProfileScr.this.p.b("banned") ? "解除封禁" : "封禁该用户");
            }
            if (arrayList.size() == 1 && this.val$adminMenu) {
                GroupScr.memberMenu(ProfileScr.this.a, ProfileScr.this.gid, ProfileScr.this.nk);
            } else {
                ProfileScr.this.a.sheet(ProfileScr.this.p.s("nick"), (String[]) arrayList.toArray(new String[0]), arrayList.indexOf("封禁该用户"), new MainActivity.Str() { // from class: com.changliao.im.ProfileScr.2.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str) {
                        if (str.startsWith("群成员管理")) {
                            GroupScr.memberMenu(ProfileScr.this.a, ProfileScr.this.gid, ProfileScr.this.nk);
                            return;
                        }
                        if (str.equals("举报该用户")) {
                            ProfileScr.this.report();
                        } else if (str.equals("封禁该用户")) {
                            MiscScr.ReportsScr.pickBan(ProfileScr.this.a, "封禁「" + ProfileScr.this.p.s("nick") + "」多久？", "", new MiscScr.ReportsScr.BanCb() { // from class: com.changliao.im.ProfileScr.2.1.1
                                @Override // com.changliao.im.MiscScr.ReportsScr.BanCb
                                public void ban(int i, String str2) {
                                    ProfileScr.this.C.send(J.of("t", "c_rdeal", "nick", ProfileScr.this.nk, "act", "ban", "mins", Integer.valueOf(i), "why", str2));
                                    ProfileScr.this.C.send(J.of("t", "c_profile", "nick", ProfileScr.this.nk));
                                }
                            });
                        } else if (str.equals("解除封禁")) {
                            ProfileScr.this.a.confirm("解除封禁", "解除后 TA 可以正常使用。", "解除", false, new Runnable() { // from class: com.changliao.im.ProfileScr.2.1.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    ProfileScr.this.C.send(J.of("t", "c_rdeal", "nick", ProfileScr.this.nk, "act", "unban"));
                                    ProfileScr.this.C.send(J.of("t", "c_profile", "nick", ProfileScr.this.nk));
                                }
                            });
                        }
                    }
                });
            }
        }
    }

    public ProfileScr(String str, String str2) {
        this.nk = str;
        this.gid = (str2 == null || str2.length() == 0) ? null : str2;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        this.fr = new FrameLayout(this.a);
        this.fr.setBackgroundColor(Ui.BG);
        ScrollView scrollView = new ScrollView(this.a);
        this.body = Ui.col(this.a);
        scrollView.addView(this.body);
        this.fr.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayoutBar = bar("", true);
        linearLayoutBar.setBackgroundColor(0);
        this.fr.addView(linearLayoutBar, new FrameLayout.LayoutParams(-1, -2, 48));
        this.C.send(J.of("t", "c_profile", "nick", this.nk));
        if (this.gid != null) {
            this.C.sendQ(J.of("t", "c_ginfo", "gid", this.gid));
        }
        render();
        return this.fr;
    }

    J mem() {
        J j = this.gid == null ? null : this.C.ginfo.get(this.gid);
        if (j == null) {
            return null;
        }
        for (J j2 : j.objs("members")) {
            if (j2.s("nk").equals(this.nk)) {
                return j2;
            }
        }
        return null;
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("c_profile") && this.nk.equals(j.s("nk"))) {
            this.p = j;
            render();
            return;
        }
        if (str.equals("c_liked") && this.p != null && this.nk.equals(j.s("nk"))) {
            this.p.put("likes", Long.valueOf(j.l("likes")));
            this.p.put("liked", true);
            render();
            toast("点赞成功 👍");
            return;
        }
        if (!((str.equals("ginfo") && this.gid != null && this.gid.equals(j.s("gid"))) || str.equals("friends")) || this.p == null) {
            return;
        }
        this.C.sendQ(J.of("t", "c_profile", "nick", this.nk));
        render();
    }

    void render() {
        this.body.removeAllViews();
        this.right.removeAllViews();
        if (this.p == null) {
            TextView textViewEmpty = empty("加载中…");
            textViewEmpty.setPadding(0, Ui.dp(140.0f), 0, 0);
            this.body.addView(textViewEmpty);
            return;
        }
        J j = this.gid == null ? null : this.C.ginfo.get(this.gid);
        J jMem = mem();
        boolean z = (j == null || jMem == null || (!j.s("myrole").equals("owner") && !j.s("myrole").equals("admin"))) ? false : true;
        if (z || !this.p.b("me")) {
            ib("menu", new AnonymousClass2(z));
        }
        View view = new View(this.a);
        view.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{-7358209, -3692801, -15658}));
        this.body.addView(view, Ui.lp(-1, Ui.dp(170.0f)));
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setClipChildren(false);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        G g = new G(0, 16.0f);
        g.bg = -1;
        linearLayoutCol.setBackground(g);
        linearLayoutCol.setElevation(Ui.dp(3.0f));
        linearLayoutCol.setPadding(Ui.dp(18.0f), Ui.dp(46.0f), Ui.dp(18.0f), Ui.dp(16.0f));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = Ui.dp(38.0f);
        frameLayout.addView(linearLayoutCol, layoutParams);
        Img.Av av = new Img.Av(this.a);
        av.set(this.p.s("nick"), this.p.sn("av"), false);
        av.setOnline(this.p.b("online"));
        av.setBackground(Ui.oval(-1));
        int iDp = Ui.dp(4.0f);
        av.setPadding(iDp, iDp, iDp, iDp);
        av.setElevation(Ui.dp(5.0f));
        av.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                if (ProfileScr.this.p.has("av")) {
                    ProfileScr.this.a.push(new ImgScr(J.of("id", ProfileScr.this.p.s("av"), "name", "avatar.jpg"), null, null));
                }
            }
        });
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(Ui.dp(86.0f), Ui.dp(86.0f));
        layoutParams2.leftMargin = Ui.dp(14.0f);
        frameLayout.addView(av, layoutParams2);
        TextView textViewText = Ui.text(this.a, "👍 " + this.p.l("likes"), 14.0f, this.p.b("liked") ? -1 : Ui.SUB);
        textViewText.setPadding(Ui.dp(12.0f), Ui.dp(5.0f), Ui.dp(12.0f), Ui.dp(5.0f));
        if (this.p.b("liked")) {
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{-30065, -42401});
            gradientDrawable.setCornerRadius(Ui.dp(16.0f));
            textViewText.setBackground(gradientDrawable);
            textViewText.setElevation(Ui.dp(3.0f));
        } else {
            G.on(textViewText, 0, 16.0f, 2.0f);
        }
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                if (ProfileScr.this.p.b("me")) {
                    ProfileScr.this.toast("不能给自己点赞哦");
                } else if (ProfileScr.this.p.b("liked")) {
                    ProfileScr.this.toast("今天已经赞过TA了");
                } else {
                    ProfileScr.this.C.send(J.of("t", "c_like", "nick", ProfileScr.this.nk));
                }
            }
        });
        Ui.bounce(textViewText);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2, 8388661);
        layoutParams3.topMargin = Ui.dp(50.0f);
        layoutParams3.rightMargin = Ui.dp(18.0f);
        frameLayout.addView(textViewText, layoutParams3);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.addView(Ui.bold(Ui.text(this.a, this.p.s("nick"), 22.0f, this.p.b("vip") ? -3569152 : Ui.TEXT)));
        if (this.p.b("vip")) {
            linearLayoutRow.addView(Ui.vipTag(this.a));
        }
        if (jMem != null && jMem.s("card").length() > 0) {
            linearLayoutRow.addView(Ui.text(this.a, " · 群昵称：" + jMem.s("card"), 13.0f, Ui.SUB));
        }
        linearLayoutCol.addView(linearLayoutRow, Ui.lpm(-2, -2, 0, 10, 0, 0));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.addView(Ui.text(this.a, "NK号：" + this.p.s("nk"), 13.0f, Ui.SUB));
        TextView textViewSm = sm("复制", 0, new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                ProfileScr.this.copy(ProfileScr.this.p.s("nk"));
            }
        });
        textViewSm.setTextColor(Ui.BLUE);
        textViewSm.setTextSize(13.0f);
        textViewSm.setPadding(Ui.dp(12.0f), Ui.dp(4.0f), Ui.dp(12.0f), Ui.dp(4.0f));
        linearLayoutRow2.addView(textViewSm, Ui.lpm(-2, -2, 8, 0, 0, 0));
        linearLayoutCol.addView(linearLayoutRow2, Ui.lpm(-2, -2, 0, 4, 0, 0));
        linearLayoutCol.addView(Ui.text(this.a, this.p.s("bio").length() > 0 ? this.p.s("bio") : "这个人很懒，什么都没留下", 14.0f, -11642519), Ui.lpm(-2, -2, 0, 10, 0, 0));
        String string = this.p.b("online") ? "● 在线" : HomeScr.ago(this.p.l("last")) + "来过";
        if (jMem != null) {
            string = new StringBuilder().append(string).append(" · ").append(jMem.s("role").equals("owner") ? "群主" : jMem.s("role").equals("admin") ? "管理员" : "群成员").append(jMem.l("mute") > 0 ? " · 禁言中" : "").toString();
        }
        linearLayoutCol.addView(Ui.text(this.a, string, 12.0f, this.p.b("online") ? Ui.GREEN : Ui.SUB), Ui.lpm(-2, -2, 0, 8, 0, 0));
        this.body.addView(frameLayout, Ui.lpm(-1, -2, 12, -84, 12, 0));
        LinearLayout linearLayoutCsec = csec(this.body);
        opt(linearLayoutCsec, this.p.b("me") ? "我的动态" : "TA的动态", "", true, new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                ProfileScr.this.a.push(new FeedScr(ProfileScr.this.nk, ProfileScr.this.p.s("nick")));
            }
        });
        if (!this.p.b("me") && this.p.a("groups").size() > 0) {
            StringBuilder sb = new StringBuilder();
            for (Object obj : this.p.a("groups")) {
                if (sb.length() > 0) {
                    sb.append("、");
                }
                sb.append(obj);
            }
            opt(linearLayoutCsec, "共同群聊", sb.toString(), false, null);
        }
        LinearLayout linearLayoutRow3 = Ui.row(this.a);
        linearLayoutRow3.setPadding(Ui.dp(12.0f), Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(6.0f));
        if (this.p.b("me")) {
            linearLayoutRow3.addView(Ui.btn(this.a, "编辑资料", new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.7
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    ProfileScr.this.a.push(new MyInfoScr());
                }
            }), Ui.lp(0, -2, 1.0f));
        } else if (this.p.b("friend")) {
            linearLayoutRow3.addView(Ui.btnGray(this.a, "音视频通话", new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.8
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    ProfileScr.this.a.sheet(null, new String[]{"语音通话", "视频通话"}, -1, new MainActivity.Str() { // from class: com.changliao.im.ProfileScr.8.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str) {
                            Call.dial(ProfileScr.this.a, ProfileScr.this.nk, ProfileScr.this.p.s("nick"), ProfileScr.this.p.sn("av"), str.startsWith("视频"));
                        }
                    });
                }
            }), Ui.lpm(0, -2, 0, 0, 12, 0));
            ((LinearLayout.LayoutParams) linearLayoutRow3.getChildAt(0).getLayoutParams()).weight = 1.0f;
            linearLayoutRow3.addView(Ui.btn(this.a, "发消息", new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    ProfileScr.this.C.send(J.of("t", "c_open", "nick", ProfileScr.this.nk));
                }
            }), Ui.lp(0, -2, 1.0f));
        } else {
            TextView textViewBtn = Ui.btn(this.a, this.p.b("sent") ? "已发送申请 · 点击撤回" : "加为好友", new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.10
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (ProfileScr.this.p.b("sent")) {
                        ProfileScr.this.a.confirm("撤回好友申请", "撤回后对方就看不到你的申请了", "撤回", false, new Runnable() { // from class: com.changliao.im.ProfileScr.10.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ProfileScr.this.C.send(J.of("t", "fr_remove", "nick", ProfileScr.this.nk));
                                ProfileScr.this.p.put("sent", false);
                                ProfileScr.this.a.toast("已撤回好友申请", false);
                                ProfileScr.this.render();
                            }
                        });
                        return;
                    }
                    ProfileScr.this.C.send(J.of("t", "fr_add", "nick", ProfileScr.this.nk));
                    ProfileScr.this.p.put("sent", true);
                    ProfileScr.this.render();
                }
            });
            if (this.p.b("sent")) {
                textViewBtn.setAlpha(0.5f);
            }
            linearLayoutRow3.addView(textViewBtn, Ui.lp(0, -2, 1.0f));
        }
        this.body.addView(linearLayoutRow3);
        if (this.p.b("friend")) {
            TextView textViewSm2 = sm("删除好友", 0, new View.OnClickListener() { // from class: com.changliao.im.ProfileScr.11
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    ProfileScr.this.a.confirm("删除好友", "确定删除「" + ProfileScr.this.p.s("nick") + "」吗？", "删除", true, new Runnable() { // from class: com.changliao.im.ProfileScr.11.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ProfileScr.this.C.send(J.of("t", "fr_remove", "nick", ProfileScr.this.nk));
                            ProfileScr.this.a.popTo(HomeScr.class);
                        }
                    });
                }
            });
            textViewSm2.setTextColor(Ui.RED);
            LinearLayout.LayoutParams layoutParamsLpm = Ui.lpm(-2, -2, 0, 4, 0, 20);
            layoutParamsLpm.gravity = 1;
            this.body.addView(textViewSm2, layoutParamsLpm);
        }
        if (!this.C.isOwner || this.p.b("me")) {
            return;
        }
        boolean zB = this.p.b("vip");
        TextView textViewSm3 = sm(zB ? "取消 TA 的 VIP" : "授予 TA VIP", zB ? 0 : 5, new AnonymousClass12(zB));
        if (!zB) {
            textViewSm3.setTextColor(-9747712);
        }
        LinearLayout.LayoutParams layoutParamsLpm2 = Ui.lpm(-2, -2, 0, 4, 0, 24);
        layoutParamsLpm2.gravity = 1;
        this.body.addView(textViewSm3, layoutParamsLpm2);
    }

    void report() {
        this.a.sheet("举报原因", new String[]{"辱骂、人身攻击", "色情低俗", "诈骗", "广告刷屏", "冒充他人", "其他"}, -1, new MainActivity.Str() { // from class: com.changliao.im.ProfileScr.1
            @Override // com.changliao.im.MainActivity.Str
            public void ok(final String str) {
                ProfileScr.this.a.ask("补充说明（选填）", "写清楚发生了什么，方便系统处理", "", true, 300, new MainActivity.Str() { // from class: com.changliao.im.ProfileScr.1.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        ProfileScr.this.C.send(J.of("t", "c_report", "nick", ProfileScr.this.nk, "reason", str, "text", str2));
                    }
                });
            }
        });
    }
}
