package com.changliao.im;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public class FloatCall extends FrameLayout {
    static WindowManager.LayoutParams sysLp;
    static final Runnable sysTick = new Runnable() { // from class: com.changliao.im.FloatCall.5
        @Override // java.lang.Runnable
        public void run() {
            FloatCall floatCall = FloatCall.sysView;
            if (floatCall == null) {
                return;
            }
            if (Call.cur == null || Call.cur.state == 4) {
                FloatCall.hideSys();
            } else {
                floatCall.upd();
                floatCall.postDelayed(this, 1000L);
            }
        }
    };
    static FloatCall sysView;
    int attached;
    Img.Av av;
    ImageView camI;
    final Context ctx;
    TextView idx;
    Listener l;
    ImageView micI;
    final boolean sys;
    TextView time;
    TextureView tv;
    boolean videoMode;

    interface Listener {
        void moved(float f, float f2);

        void tap();

        void up();
    }

    static final class Slash extends Drawable {
        final Drawable d;
        final boolean on;
        final Paint p = new Paint(1);

        Slash(Drawable drawable, boolean z, int i) {
            this.d = drawable;
            this.on = z;
            this.p.setColor(i);
            this.p.setStrokeWidth(Ui.dp(1.8f));
            this.p.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            this.d.draw(canvas);
            if (this.on) {
                Rect bounds = getBounds();
                float fMin = Math.min(bounds.width(), bounds.height()) * 0.42f;
                float fExactCenterX = bounds.exactCenterX();
                float fExactCenterY = bounds.exactCenterY();
                canvas.drawLine(fExactCenterX - fMin, fExactCenterY - fMin, fExactCenterX + fMin, fMin + fExactCenterY, this.p);
            }
        }

        @Override // android.graphics.drawable.Drawable
        public int getIntrinsicHeight() {
            return this.d.getIntrinsicHeight();
        }

        @Override // android.graphics.drawable.Drawable
        public int getIntrinsicWidth() {
            return this.d.getIntrinsicWidth();
        }

        @Override // android.graphics.drawable.Drawable
        public int getOpacity() {
            return -3;
        }

        @Override // android.graphics.drawable.Drawable
        protected void onBoundsChange(Rect rect) {
            this.d.setBounds(rect);
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int i) {
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter colorFilter) {
        }
    }

    public FloatCall(Context context, boolean z) {
        super(context);
        this.attached = -2;
        this.ctx = context;
        this.sys = z;
        build();
        final int scaledTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.FloatCall.1
            boolean drag;
            float lx;
            float ly;
            float sx;
            float sy;

            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getActionMasked()) {
                    case G.LIGHT /* 0 */:
                        float rawX = motionEvent.getRawX();
                        this.lx = rawX;
                        this.sx = rawX;
                        float rawY = motionEvent.getRawY();
                        this.ly = rawY;
                        this.sy = rawY;
                        this.drag = false;
                        FloatCall.this.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90L).start();
                        return true;
                    case G.BLUE /* 1 */:
                    case G.INSET /* 3 */:
                        FloatCall.this.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160L).start();
                        if (FloatCall.this.l == null) {
                            return true;
                        }
                        if (this.drag) {
                            FloatCall.this.l.up();
                            return true;
                        }
                        if (motionEvent.getActionMasked() != 1) {
                            return true;
                        }
                        FloatCall.this.l.tap();
                        return true;
                    case G.DARK /* 2 */:
                        if (!this.drag && Math.hypot(motionEvent.getRawX() - this.sx, motionEvent.getRawY() - this.sy) > scaledTouchSlop) {
                            this.drag = true;
                        }
                        if (this.drag && FloatCall.this.l != null) {
                            FloatCall.this.l.moved(motionEvent.getRawX() - this.lx, motionEvent.getRawY() - this.ly);
                        }
                        this.lx = motionEvent.getRawX();
                        this.ly = motionEvent.getRawY();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    static boolean canOverlay(Context context) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
    }

    static void hideSys() {
        FloatCall floatCall = sysView;
        sysView = null;
        if (floatCall == null) {
            return;
        }
        try {
            ((WindowManager) floatCall.ctx.getSystemService("window")).removeView(floatCall);
        } catch (Throwable th) {
        }
    }

    static void showSys(Context context) {
        final Context applicationContext = context.getApplicationContext();
        if (sysView != null || Call.cur == null || Call.cur.state == 4 || !canOverlay(applicationContext)) {
            return;
        }
        try {
            final WindowManager windowManager = (WindowManager) applicationContext.getSystemService("window");
            final FloatCall floatCall = new FloatCall(applicationContext, true);
            if (Night.active) {
                floatCall.setLayerType(2, Night.darkP);
            }
            final WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 520, -3);
            layoutParams.gravity = 8388659;
            layoutParams.x = App.kv.getInt("floatX", applicationContext.getResources().getDisplayMetrics().widthPixels - Ui.dp(130.0f));
            layoutParams.y = App.kv.getInt("floatY", Ui.dp(120.0f));
            floatCall.l = new Listener() { // from class: com.changliao.im.FloatCall.6
                @Override // com.changliao.im.FloatCall.Listener
                public void moved(float f, float f2) {
                    WindowManager.LayoutParams layoutParams2 = layoutParams;
                    layoutParams2.x = (int) (layoutParams2.x + f);
                    WindowManager.LayoutParams layoutParams3 = layoutParams;
                    layoutParams3.y = (int) (layoutParams3.y + f2);
                    try {
                        windowManager.updateViewLayout(floatCall, layoutParams);
                    } catch (Throwable th) {
                    }
                }

                @Override // com.changliao.im.FloatCall.Listener
                public void tap() {
                    Intent intent = new Intent(applicationContext, (Class<?>) MainActivity.class);
                    intent.addFlags(268566528);
                    intent.putExtra("openCall", true);
                    applicationContext.startActivity(intent);
                }

                @Override // com.changliao.im.FloatCall.Listener
                public void up() {
                    int i = applicationContext.getResources().getDisplayMetrics().widthPixels;
                    int width = floatCall.getWidth();
                    final int iDp = layoutParams.x + (width / 2) < i / 2 ? Ui.dp(8.0f) : (i - width) - Ui.dp(8.0f);
                    final int i2 = layoutParams.x;
                    ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
                    valueAnimatorOfFloat.setDuration(260L);
                    valueAnimatorOfFloat.setInterpolator(new DecelerateInterpolator(2.0f));
                    valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.changliao.im.FloatCall.6.1
                        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                        public void onAnimationUpdate(ValueAnimator valueAnimator) {
                            layoutParams.x = (int) ((((Float) valueAnimator.getAnimatedValue()).floatValue() * (iDp - i2)) + i2);
                            try {
                                windowManager.updateViewLayout(floatCall, layoutParams);
                            } catch (Throwable th) {
                            }
                        }
                    });
                    valueAnimatorOfFloat.start();
                    App.kv.edit().putInt("floatX", iDp).putInt("floatY", layoutParams.y).apply();
                }
            };
            windowManager.addView(floatCall, layoutParams);
            sysView = floatCall;
            sysLp = layoutParams;
            floatCall.setScaleX(0.6f);
            floatCall.setScaleY(0.6f);
            floatCall.setAlpha(0.0f);
            floatCall.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(220L).start();
            floatCall.postDelayed(sysTick, 1000L);
        } catch (Throwable th) {
            Crash.note(th);
            sysView = null;
        }
    }

    static int videoSid(Call call) {
        if (call.rtc == null) {
            return -1;
        }
        if (!call.group) {
            return (call.remoteSid < 0 || !call.rtc.hasVideo(call.remoteSid)) ? -1 : call.remoteSid;
        }
        for (Integer num : call.peers.keySet()) {
            if (call.rtc.hasVideo(num.intValue())) {
                return num.intValue();
            }
        }
        return -1;
    }

    void build() {
        removeAllViews();
        this.attached = -2;
        this.videoMode = wantVideo();
        final float fDp = Ui.dp(14.0f);
        setOutlineProvider(new ViewOutlineProvider() { // from class: com.changliao.im.FloatCall.2
            @Override // android.view.ViewOutlineProvider
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), fDp);
            }
        });
        setClipToOutline(true);
        setElevation(Ui.dp(10.0f));
        if (this.videoMode) {
            setBackground(Ui.round(-16777216, 14.0f));
            FrameLayout frameLayout = new FrameLayout(this.ctx);
            this.av = new Img.Av(this.ctx);
            Call call = Call.cur;
            if (call != null) {
                this.av.set(call.name, call.av, call.group, call.gid);
            }
            frameLayout.addView(this.av, new FrameLayout.LayoutParams(Ui.dp(52.0f), Ui.dp(52.0f), 17));
            this.tv = new TextureView(this.ctx);
            this.tv.setAlpha(0.0f);
            frameLayout.addView(this.tv, new FrameLayout.LayoutParams(-1, -1));
            Night.keep(this.tv);
            this.idx = Ui.text(this.ctx, "", 11.0f, -1);
            this.idx.setShadowLayer(3.0f, 0.0f, 1.0f, -16777216);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 8388691);
            layoutParams.leftMargin = Ui.dp(6.0f);
            layoutParams.bottomMargin = Ui.dp(40.0f);
            frameLayout.addView(this.idx, layoutParams);
            this.time = Ui.text(this.ctx, "", 11.0f, -1);
            this.time.setShadowLayer(3.0f, 0.0f, 1.0f, -16777216);
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2, 49);
            layoutParams2.topMargin = Ui.dp(6.0f);
            frameLayout.addView(this.time, layoutParams2);
            LinearLayout linearLayoutRow = Ui.row(this.ctx);
            linearLayoutRow.setGravity(17);
            linearLayoutRow.setBackgroundColor(-1728053248);
            this.micI = new ImageView(this.ctx);
            this.camI = new ImageView(this.ctx);
            this.micI.setPadding(0, Ui.dp(6.0f), 0, Ui.dp(6.0f));
            this.camI.setPadding(0, Ui.dp(6.0f), 0, Ui.dp(6.0f));
            linearLayoutRow.addView(this.micI, Ui.lp(0, -1, 1.0f));
            linearLayoutRow.addView(this.camI, Ui.lp(0, -1, 1.0f));
            frameLayout.addView(linearLayoutRow, new FrameLayout.LayoutParams(-1, Ui.dp(36.0f), 80));
            addView(frameLayout, new FrameLayout.LayoutParams(Ui.dp(104.0f), Ui.dp(164.0f)));
        } else {
            setBackground(Ui.round(-1, 14.0f));
            LinearLayout linearLayoutCol = Ui.col(this.ctx);
            linearLayoutCol.setGravity(1);
            ImageView imageView = new ImageView(this.ctx);
            imageView.setImageDrawable(new Ico("phone", -14775297));
            linearLayoutCol.addView(imageView, Ui.lpm(Ui.dp(30.0f), Ui.dp(30.0f), 0, 14, 0, 0));
            this.time = Ui.text(this.ctx, "", 13.0f, -14775297);
            this.time.setGravity(17);
            linearLayoutCol.addView(this.time, Ui.lpm(-2, -2, 0, 6, 0, 10));
            LinearLayout linearLayoutRow2 = Ui.row(this.ctx);
            linearLayoutRow2.setGravity(17);
            linearLayoutRow2.setBackgroundColor(-854793);
            this.micI = new ImageView(this.ctx);
            this.camI = new ImageView(this.ctx);
            linearLayoutRow2.addView(this.micI, Ui.lp(0, Ui.dp(26.0f), 1.0f));
            linearLayoutRow2.addView(this.camI, Ui.lp(0, Ui.dp(26.0f), 1.0f));
            this.micI.setPadding(0, Ui.dp(4.0f), 0, Ui.dp(4.0f));
            this.camI.setPadding(0, Ui.dp(4.0f), 0, Ui.dp(4.0f));
            linearLayoutCol.addView(linearLayoutRow2, new LinearLayout.LayoutParams(-1, Ui.dp(32.0f)));
            addView(linearLayoutCol, new FrameLayout.LayoutParams(Ui.dp(76.0f), -2));
        }
        this.micI.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FloatCall.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Call call2 = Call.cur;
                if (call2 != null) {
                    call2.setMute(!call2.muted);
                }
                FloatCall.this.upd();
            }
        });
        this.camI.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.FloatCall.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Call call2 = Call.cur;
                if (call2 == null || !call2.video) {
                    return;
                }
                call2.setCam(!call2.camOn);
                FloatCall.this.upd();
            }
        });
        upd();
    }

    void upd() {
        String strTime;
        int i;
        Call call = Call.cur;
        if (call == null) {
            return;
        }
        if (wantVideo() != this.videoMode) {
            build();
            return;
        }
        if (call.state == 3) {
            strTime = call.time();
        } else {
            strTime = call.state == 1 ? "来电" : "等待接听";
        }
        TextView textView = this.time;
        if (call.sharing && call.state == 3) {
            strTime = "共享中 " + strTime;
        }
        textView.setText(strTime);
        boolean z = !call.muted;
        boolean z2 = call.video && call.camOn;
        ImageView imageView = this.micI;
        String str = z ? "mic" : "micoff";
        if (this.videoMode) {
            i = z ? -1 : -42406;
        } else {
            i = z ? -14775297 : -6642769;
        }
        imageView.setImageDrawable(new Ico(str, i));
        this.camI.setImageDrawable(new Slash(new Ico("video", this.videoMode ? -1 : -6642769), !z2, this.videoMode ? -1 : -6642769));
        if (this.videoMode) {
            int iVideoSid = videoSid(call);
            if (this.idx != null) {
                this.idx.setText(call.group ? String.valueOf(call.peers.size() + 1) : "1");
            }
            if (iVideoSid >= 0 && iVideoSid != this.attached && call.rtc != null) {
                call.rtc.attach(iVideoSid, this.tv);
                this.attached = iVideoSid;
            }
            boolean z3 = iVideoSid >= 0;
            this.tv.setAlpha(z3 ? 1.0f : 0.0f);
            this.av.setVisibility(z3 ? 8 : 0);
        }
    }

    boolean wantVideo() {
        Call call = Call.cur;
        if (call == null) {
            return false;
        }
        return call.video || call.sharing || (call.rtc != null && videoSid(call) >= 0);
    }
}
