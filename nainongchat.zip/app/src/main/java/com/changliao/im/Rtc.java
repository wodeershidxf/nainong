package com.changliao.im;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.AutomaticGainControl;
import android.media.audiofx.NoiseSuppressor;
import android.media.projection.MediaProjection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
final class Rtc {
    static final int FRAME = 640;
    static final int K_AUDIO = 1;
    static final int K_VIDEO = 2;
    static final int RATE = 16000;
    final AudioManager am;
    CameraManager.AvailabilityCallback avail;
    CameraDevice cam;
    Handler camH;
    volatile boolean camOff;
    HandlerThread camT;
    byte[] csd;
    final Context ctx;
    MediaCodec enc;
    volatile int encGen;
    Surface encSurf;
    final boolean group;
    volatile long lastSent;
    Surface localSurf;
    TextureView localV;
    MediaProjection mp;
    volatile boolean muted;
    int oldMode;
    volatile boolean running;
    int sensor;
    CameraCaptureSession ses;
    int sesGen;
    volatile boolean sharing;
    volatile boolean speaker;
    boolean toldBusy;
    volatile Ui ui;
    VirtualDisplay vdisp;
    int vh;
    final boolean video;
    int vseq;
    int vw;
    volatile boolean wantKey;
    volatile boolean front = true;
    final ConcurrentHashMap<Integer, Strm> strms = new ConcurrentHashMap<>();
    final ConcurrentHashMap<Integer, Dec> decs = new ConcurrentHashMap<>();
    volatile boolean camFront = true;

    static final class Adpcm {
        static final int[] IDX = {-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8};
        static final int[] STEP = {7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767};

        Adpcm() {
        }

        static void decode(byte[] bArr, int i, int i2, int i3, short[] sArr) {
            if (i3 > 88) {
                i3 = 88;
            }
            for (int i4 = 0; i4 < sArr.length; i4++) {
                int i5 = (bArr[(i4 >> 1) + i] >> ((i4 & 1) * 4)) & 15;
                int i6 = STEP[i3];
                int i7 = i6 >> 3;
                if ((i5 & 4) != 0) {
                    i7 += i6;
                }
                if ((i5 & 2) != 0) {
                    i7 += i6 >> 1;
                }
                if ((i5 & 1) != 0) {
                    i7 += i6 >> 2;
                }
                if ((i5 & 8) != 0) {
                    i7 = -i7;
                }
                i2 += i7;
                if (i2 > 32767) {
                    i2 = 32767;
                } else if (i2 < -32768) {
                    i2 = -32768;
                }
                i3 += IDX[i5];
                if (i3 < 0) {
                    i3 = 0;
                } else if (i3 > 88) {
                    i3 = 88;
                }
                sArr[i4] = (short) i2;
            }
        }

        static void encode(short[] sArr, int[] iArr, byte[] bArr, int i) {
            int i2;
            int i3 = iArr[0];
            int i4 = iArr[1];
            for (int i5 = 0; i5 < sArr.length; i5++) {
                int i6 = STEP[i4];
                int i7 = sArr[i5] - i3;
                if (i7 < 0) {
                    i2 = 8;
                    i7 = -i7;
                } else {
                    i2 = 0;
                }
                int i8 = i6 >> 3;
                if (i7 >= i6) {
                    i2 |= 4;
                    i7 -= i6;
                    i8 += i6;
                }
                int i9 = i6 >> 1;
                if (i7 >= i9) {
                    i2 |= 2;
                    i7 -= i9;
                    i8 += i9;
                }
                int i10 = i9 >> 1;
                if (i7 >= i10) {
                    i2 |= 1;
                    i8 += i10;
                }
                if ((i2 & 8) != 0) {
                    i8 = -i8;
                }
                i3 += i8;
                if (i3 > 32767) {
                    i3 = 32767;
                } else if (i3 < -32768) {
                    i3 = -32768;
                }
                i4 += IDX[i2];
                if (i4 < 0) {
                    i4 = 0;
                } else if (i4 > 88) {
                    i4 = 88;
                }
                if ((i5 & 1) == 0) {
                    bArr[(i5 >> 1) + i] = (byte) i2;
                } else {
                    int i11 = (i5 >> 1) + i;
                    bArr[i11] = (byte) (((byte) (i2 << 4)) | bArr[i11]);
                }
            }
            iArr[0] = i3;
            iArr[1] = i4;
        }
    }

    final class Dec {
        long askAt;
        int ch;
        int cw;
        volatile boolean dead;
        volatile int h;
        volatile long last;
        MediaCodec mc;
        volatile boolean mirror;
        volatile int rot;
        volatile boolean screen;
        volatile boolean shown;
        final int sid;
        volatile Surface surf;
        volatile TextureView view;
        volatile int w;
        final LinkedBlockingQueue<byte[]> q = new LinkedBlockingQueue<>();
        int lastSeq = -1;
        boolean needKey = true;

        Dec(int i) {
            this.sid = i;
            new Thread(new Runnable() { // from class: com.changliao.im.Rtc.Dec.1
                @Override // java.lang.Runnable
                public void run() {
                    Dec.this.loop();
                }
            }, "rtc-dec").start();
        }

        void ask() {
            long jCurrentTimeMillis = System.currentTimeMillis();
            if (jCurrentTimeMillis - this.askAt < 1000) {
                return;
            }
            this.askAt = jCurrentTimeMillis;
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.Dec.3
                @Override // java.lang.Runnable
                public void run() {
                    Ui ui = Rtc.this.ui;
                    if (ui != null) {
                        ui.needKey(Dec.this.sid);
                    }
                }
            });
        }

        void attach(TextureView textureView) {
            this.view = textureView;
            if (textureView.isAvailable()) {
                this.surf = new Surface(textureView.getSurfaceTexture());
            }
            textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() { // from class: com.changliao.im.Rtc.Dec.2
                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
                    Dec.this.surf = new Surface(surfaceTexture);
                    Dec.this.fitIt();
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                    Dec.this.surf = null;
                    return true;
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
                    Dec.this.fitIt();
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
                }
            });
            fitIt();
        }

        void close() {
            this.dead = true;
            this.q.offer(new byte[0]);
        }

        void fitIt() {
            TextureView textureView = this.view;
            if (textureView == null || this.w <= 0) {
                return;
            }
            Rtc.fit(textureView, this.w, this.h, this.rot, false, !this.screen);
        }

        /* JADX WARN: Code duplicated, block: B:60:0x00d4  */
        /* JADX WARN: Code duplicated, block: B:62:0x00de  */
        /* JADX WARN: Code duplicated, block: B:65:0x00e5  */
        /* JADX WARN: Code duplicated, block: B:78:0x010f  */
        /* JADX WARN: Code duplicated, block: B:79:0x0111  */
        void loop() {
            int i;
            boolean z;
            boolean z2;
            Surface surface;
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            Surface surface2 = null;
            while (!this.dead && Rtc.this.running) {
                try {
                    byte[] bArrPoll = this.q.poll(300L, TimeUnit.MILLISECONDS);
                    if (this.dead) {
                        break;
                    }
                    if (bArrPoll != null && bArrPoll.length >= 7) {
                        int i2 = bArrPoll[1] & 255;
                        int i3 = (bArrPoll[2] & 3) * 90;
                        int i4 = ((bArrPoll[3] & 255) << 8) | (bArrPoll[4] & 255);
                        int i5 = (bArrPoll[5] & 255) * 16;
                        int i6 = (bArrPoll[6] & 255) * 16;
                        boolean z3 = (i2 & 1) != 0;
                        byte[] bArrCopyOfRange = null;
                        if ((i2 & 2) != 0) {
                            int i7 = (bArrPoll[8] & 255) | ((bArrPoll[7] & 255) << 8);
                            bArrCopyOfRange = Arrays.copyOfRange(bArrPoll, 9, i7 + 9);
                            i = i7 + 9;
                        } else {
                            i = 7;
                        }
                        boolean z4 = this.lastSeq >= 0 && i4 != ((this.lastSeq + 1) & 65535);
                        this.lastSeq = i4;
                        if (z4) {
                            this.needKey = true;
                        }
                        Surface surface3 = this.surf;
                        if (this.mc != null && (surface3 != surface2 || i5 != this.cw || i6 != this.ch)) {
                            rel();
                            this.needKey = true;
                        }
                        if (this.needKey && !z3) {
                            ask();
                        } else if (surface3 != null) {
                            if (i3 == this.rot && i5 == this.w && i6 == this.h) {
                                if (((i2 & 4) != 0) != this.mirror) {
                                    this.rot = i3;
                                    this.w = i5;
                                    this.h = i6;
                                    if ((i2 & 4) != 0) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    this.mirror = z;
                                    if ((i2 & 8) != 0) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    this.screen = z2;
                                    Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.Dec.4
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            Dec.this.fitIt();
                                            Ui ui = Rtc.this.ui;
                                            if (ui != null) {
                                                ui.videoInfo(Dec.this.sid);
                                            }
                                        }
                                    });
                                } else {
                                    if (((i2 & 8) != 0) != this.screen) {
                                        this.rot = i3;
                                        this.w = i5;
                                        this.h = i6;
                                        if ((i2 & 4) != 0) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        this.mirror = z;
                                        if ((i2 & 8) != 0) {
                                            z2 = true;
                                        } else {
                                            z2 = false;
                                        }
                                        this.screen = z2;
                                        Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.Dec.4
                                            @Override // java.lang.Runnable
                                            public void run() {
                                                Dec.this.fitIt();
                                                Ui ui = Rtc.this.ui;
                                                if (ui != null) {
                                                    ui.videoInfo(Dec.this.sid);
                                                }
                                            }
                                        });
                                    }
                                }
                            } else {
                                this.rot = i3;
                                this.w = i5;
                                this.h = i6;
                                if ((i2 & 4) != 0) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                this.mirror = z;
                                if ((i2 & 8) != 0) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                this.screen = z2;
                                Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.Dec.4
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        Dec.this.fitIt();
                                        Ui ui = Rtc.this.ui;
                                        if (ui != null) {
                                            ui.videoInfo(Dec.this.sid);
                                        }
                                    }
                                });
                            }
                            try {
                                if (this.mc != null) {
                                    surface3 = surface2;
                                } else if (bArrCopyOfRange == null) {
                                    ask();
                                } else {
                                    MediaFormat mediaFormatCreateVideoFormat = MediaFormat.createVideoFormat("video/avc", i5, i6);
                                    int[] iArrSplitCsd = Rtc.splitCsd(bArrCopyOfRange);
                                    if (iArrSplitCsd != null) {
                                        mediaFormatCreateVideoFormat.setByteBuffer("csd-0", ByteBuffer.wrap(Arrays.copyOfRange(bArrCopyOfRange, 0, iArrSplitCsd[0])));
                                        mediaFormatCreateVideoFormat.setByteBuffer("csd-1", ByteBuffer.wrap(Arrays.copyOfRange(bArrCopyOfRange, iArrSplitCsd[0], bArrCopyOfRange.length)));
                                    } else {
                                        mediaFormatCreateVideoFormat.setByteBuffer("csd-0", ByteBuffer.wrap(bArrCopyOfRange));
                                    }
                                    this.mc = MediaCodec.createDecoderByType("video/avc");
                                    this.mc.configure(mediaFormatCreateVideoFormat, surface3, (MediaCrypto) null, 0);
                                    this.mc.start();
                                    try {
                                        this.cw = i5;
                                        this.ch = i6;
                                    } catch (Throwable th) {
                                        th = th;
                                        surface = surface3;
                                        Crash.note(th);
                                        rel();
                                        this.needKey = true;
                                    }
                                }
                                this.needKey = false;
                                int iDequeueInputBuffer = this.mc.dequeueInputBuffer(30000L);
                                if (iDequeueInputBuffer >= 0) {
                                    ByteBuffer inputBuffer = this.mc.getInputBuffer(iDequeueInputBuffer);
                                    inputBuffer.clear();
                                    int iMin = Math.min(inputBuffer.remaining(), bArrPoll.length - i);
                                    inputBuffer.put(bArrPoll, i, iMin);
                                    this.mc.queueInputBuffer(iDequeueInputBuffer, 0, iMin, System.nanoTime() / 1000, z3 ? 1 : 0);
                                } else {
                                    this.needKey = true;
                                }
                                while (true) {
                                    int iDequeueOutputBuffer = this.mc.dequeueOutputBuffer(bufferInfo, 0L);
                                    if (iDequeueOutputBuffer >= 0) {
                                        this.mc.releaseOutputBuffer(iDequeueOutputBuffer, true);
                                        this.shown = true;
                                    } else if (iDequeueOutputBuffer == -1) {
                                        break;
                                    }
                                }
                                surface = surface3;
                            } catch (Throwable th2) {
                                surface = surface2;
                            }
                            surface2 = surface;
                        }
                    }
                } catch (InterruptedException e) {
                }
            }
            rel();
        }

        void rel() {
            try {
                if (this.mc != null) {
                    this.mc.stop();
                    this.mc.release();
                }
            } catch (Throwable th) {
            }
            this.mc = null;
        }
    }

    static final class Strm {
        volatile long last;
        final ArrayDeque<short[]> q = new ArrayDeque<>();
        boolean prime = true;

        Strm() {
        }

        synchronized void put(short[] sArr) {
            this.q.add(sArr);
            while (this.q.size() > 8) {
                this.q.poll();
            }
        }

        /* JADX WARN: Code duplicated, block: B:15:0x001e A[Catch: all -> 0x0022, TRY_LEAVE, TryCatch #0 {, blocks: (B:3:0x0001, B:5:0x0005, B:12:0x0012, B:13:0x0014, B:15:0x001e), top: B:20:0x0001 }] */
        synchronized short[] take() {
            short[] sArrPoll;
            if (!this.prime) {
                sArrPoll = this.q.poll();
                if (sArrPoll == null) {
                    this.prime = true;
                }
            } else if (this.q.size() < 2) {
                sArrPoll = null;
            } else {
                this.prime = false;
                sArrPoll = this.q.poll();
                if (sArrPoll == null) {
                    this.prime = true;
                }
            }
            return sArrPoll;
        }
    }

    interface Ui {
        void needKey(int i);

        void newVideo(int i);

        void videoInfo(int i);
    }

    Rtc(Context context, boolean z, boolean z2) {
        this.ctx = context.getApplicationContext();
        this.video = z;
        this.group = z2;
        this.am = (AudioManager) this.ctx.getSystemService("audio");
    }

    static void fit(TextureView textureView, int i, int i2, int i3, boolean z, boolean z2) {
        float width = textureView.getWidth();
        float height = textureView.getHeight();
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        float f = width / 2.0f;
        float f2 = height / 2.0f;
        float f3 = i3 % 180 == 0 ? i : i2;
        float f4 = i3 % 180 == 0 ? i2 : i;
        float fMax = z2 ? Math.max(width / f3, height / f4) : Math.min(width / f3, height / f4);
        Matrix matrix = new Matrix();
        matrix.setScale(i / width, i2 / height, f, f2);
        matrix.postRotate(i3, f, f2);
        matrix.postScale((z ? -1 : 1) * fMax, fMax, f, f2);
        textureView.setTransform(matrix);
    }

    static int[] splitCsd(byte[] bArr) {
        for (int i = 4; i + 3 < bArr.length; i++) {
            if (bArr[i] == 0 && bArr[i + 1] == 0 && (bArr[i + 2] == 1 || (bArr[i + 2] == 0 && bArr[i + 3] == 1))) {
                return new int[]{i};
            }
        }
        return null;
    }

    void attach(int i, TextureView textureView) {
        Dec dec = this.decs.get(Integer.valueOf(i));
        if (dec != null) {
            dec.attach(textureView);
        }
    }

    void busy() {
        if (this.toldBusy) {
            return;
        }
        this.toldBusy = true;
        Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.15
            @Override // java.lang.Runnable
            public void run() {
                Core.I.emit("toast", J.of("msg", "摄像头被其他应用占用了，空出来后会自动恢复画面", "err", true));
            }
        });
    }

    String camId(boolean z) throws Exception {
        CameraManager cameraManager = (CameraManager) this.ctx.getSystemService("camera");
        String str = null;
        for (String str2 : cameraManager.getCameraIdList()) {
            Integer num = (Integer) cameraManager.getCameraCharacteristics(str2).get(CameraCharacteristics.LENS_FACING);
            if (str == null) {
                str = str2;
            }
            if (num != null) {
                if ((num.intValue() == 0) == z) {
                    return str2;
                }
            }
        }
        return str;
    }

    void camThread() {
        if (this.camT != null) {
            return;
        }
        this.camT = new HandlerThread("rtc-cam");
        this.camT.start();
        this.camH = new Handler(this.camT.getLooper());
    }

    void closeCam() {
        try {
            if (this.ses != null) {
                this.ses.close();
            }
        } catch (Throwable th) {
        }
        try {
            if (this.cam != null) {
                this.cam.close();
            }
        } catch (Throwable th2) {
        }
        this.ses = null;
        this.cam = null;
    }

    int dispDeg() {
        try {
            int rotation = ((WindowManager) this.ctx.getSystemService("window")).getDefaultDisplay().getRotation();
            if (rotation == 1) {
                return 90;
            }
            if (rotation == 2) {
                return 180;
            }
            return rotation == 3 ? 270 : 0;
        } catch (Throwable th) {
            return 0;
        }
    }

    void encLoop(int i, MediaCodec mediaCodec, Surface surface, int i2, int i3, boolean z) {
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        long j = 0;
        int iOutRot = 0;
        while (this.running && i == this.encGen) {
            try {
                if (this.wantKey) {
                    this.wantKey = false;
                    Bundle bundle = new Bundle();
                    bundle.putInt("request-sync", 0);
                    mediaCodec.setParameters(bundle);
                }
                int iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo, 100000L);
                if (iDequeueOutputBuffer >= 0) {
                    ByteBuffer outputBuffer = mediaCodec.getOutputBuffer(iDequeueOutputBuffer);
                    byte[] bArr = new byte[bufferInfo.size];
                    if (outputBuffer != null) {
                        outputBuffer.position(bufferInfo.offset);
                        outputBuffer.get(bArr);
                    }
                    mediaCodec.releaseOutputBuffer(iDequeueOutputBuffer, false);
                    if ((bufferInfo.flags & 2) != 0) {
                        this.csd = bArr;
                    } else if (z || !this.camOff) {
                        if (i != this.encGen) {
                            break;
                        }
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        if (!z && jCurrentTimeMillis - j > 800) {
                            iOutRot = outRot();
                            j = jCurrentTimeMillis;
                        }
                        boolean z2 = (bufferInfo.flags & 1) != 0;
                        byte[] bArr2 = (!z2 || this.csd == null) ? null : this.csd;
                        int length = (bArr2 != null ? bArr2.length + 2 : 0) + 7;
                        byte[] bArr3 = new byte[bArr.length + length];
                        bArr3[0] = 2;
                        bArr3[1] = (byte) ((z ? 8 : 0) | (z2 ? 1 : 0) | (bArr2 != null ? 2 : 0) | ((z || !this.camFront) ? 0 : 4));
                        bArr3[2] = (byte) (z ? 0 : iOutRot / 90);
                        bArr3[3] = (byte) (this.vseq >> 8);
                        bArr3[4] = (byte) this.vseq;
                        this.vseq++;
                        bArr3[5] = (byte) (i2 / 16);
                        bArr3[6] = (byte) (i3 / 16);
                        if (bArr2 != null) {
                            bArr3[7] = (byte) (bArr2.length >> 8);
                            bArr3[8] = (byte) bArr2.length;
                            System.arraycopy(bArr2, 0, bArr3, 9, bArr2.length);
                        }
                        System.arraycopy(bArr, 0, bArr3, length, bArr.length);
                        if (!Core.I.sendBin(bArr3)) {
                            this.wantKey = true;
                        }
                    }
                }
            } catch (IllegalStateException e) {
                break;
            } catch (Throwable th) {
                Crash.note(th);
                break;
            }
        }
        try {
            mediaCodec.stop();
            mediaCodec.release();
        } catch (Throwable th2) {
        }
        try {
            surface.release();
        } catch (Throwable th3) {
        }
        if (this.enc == mediaCodec) {
            this.enc = null;
        }
    }

    void fitLocal() {
        TextureView textureView = this.localV;
        if (textureView == null || this.vw == 0) {
            return;
        }
        boolean z = this.sensor % 180 != 0;
        fit(textureView, z ? this.vh : this.vw, z ? this.vw : this.vh, (360 - dispDeg()) % 360, false, true);
    }

    void flip() {
        if (!this.video || this.camH == null) {
            return;
        }
        this.front = !this.front;
        this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.22
            @Override // java.lang.Runnable
            public void run() {
                Rtc.this.closeCam();
                Rtc.this.openCam();
            }
        });
    }

    void forget(int i) {
        this.strms.remove(Integer.valueOf(i));
        Dec decRemove = this.decs.remove(Integer.valueOf(i));
        if (decRemove != null) {
            decRemove.close();
        }
    }

    boolean hasVideo(int i) {
        Dec dec = this.decs.get(Integer.valueOf(i));
        return dec != null && dec.shown && System.currentTimeMillis() - dec.last < 1500;
    }

    void key() {
        this.wantKey = true;
    }

    void localReady(SurfaceTexture surfaceTexture) {
        if (this.vw == 0) {
            return;
        }
        surfaceTexture.setDefaultBufferSize(this.vw, this.vh);
        this.localSurf = new Surface(surfaceTexture);
        fitLocal();
        if (this.camH != null) {
            this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.21
                @Override // java.lang.Runnable
                public void run() {
                    Rtc.this.restartSession();
                }
            });
        }
    }

    void lost(CameraDevice cameraDevice) {
        try {
            cameraDevice.close();
        } catch (Throwable th) {
        }
        boolean z = this.cam == cameraDevice || this.cam == null;
        if (this.cam == cameraDevice) {
            this.cam = null;
            this.ses = null;
        }
        if (z && this.running && !this.camOff) {
            busy();
        }
    }

    void makeEnc(final int i, final int i2, int i3, final boolean z) throws Exception {
        MediaFormat mediaFormatCreateVideoFormat = MediaFormat.createVideoFormat("video/avc", i, i2);
        mediaFormatCreateVideoFormat.setInteger("color-format", 2130708361);
        mediaFormatCreateVideoFormat.setInteger("bitrate", i3);
        mediaFormatCreateVideoFormat.setInteger("frame-rate", 15);
        mediaFormatCreateVideoFormat.setInteger("i-frame-interval", 2);
        if (z) {
            mediaFormatCreateVideoFormat.setLong("repeat-previous-frame-after", 300000L);
        }
        final MediaCodec mediaCodecCreateEncoderByType = MediaCodec.createEncoderByType("video/avc");
        mediaCodecCreateEncoderByType.configure(mediaFormatCreateVideoFormat, (Surface) null, (MediaCrypto) null, 1);
        final Surface surfaceCreateInputSurface = mediaCodecCreateEncoderByType.createInputSurface();
        mediaCodecCreateEncoderByType.start();
        final int i4 = this.encGen + 1;
        this.encGen = i4;
        this.enc = mediaCodecCreateEncoderByType;
        this.encSurf = surfaceCreateInputSurface;
        this.csd = null;
        new Thread(new Runnable() { // from class: com.changliao.im.Rtc.7
            @Override // java.lang.Runnable
            public void run() {
                Rtc.this.encLoop(i4, mediaCodecCreateEncoderByType, surfaceCreateInputSurface, i, i2, z);
            }
        }, "rtc-enc").start();
    }

    boolean meTalking() {
        return !this.muted && System.currentTimeMillis() - this.lastSent < 400;
    }

    void onBin(byte[] bArr) {
        if (!this.running || bArr.length < 6) {
            return;
        }
        final int i = (bArr[3] & 255) | ((bArr[0] & 255) << 24) | ((bArr[1] & 255) << 16) | ((bArr[2] & 255) << 8);
        int i2 = bArr[4] & 255;
        if (i2 == 1) {
            if (bArr.length >= 330) {
                Strm strm = this.strms.get(Integer.valueOf(i));
                if (strm == null) {
                    strm = new Strm();
                    this.strms.put(Integer.valueOf(i), strm);
                }
                strm.last = System.currentTimeMillis();
                short[] sArr = new short[FRAME];
                Adpcm.decode(bArr, 10, (short) (((bArr[7] & 255) << 8) | (bArr[8] & 255)), bArr[9] & 255, sArr);
                strm.put(sArr);
                return;
            }
            return;
        }
        if (i2 == 2) {
            Dec dec = this.decs.get(Integer.valueOf(i));
            if (dec == null) {
                dec = new Dec(i);
                this.decs.put(Integer.valueOf(i), dec);
                Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.4
                    @Override // java.lang.Runnable
                    public void run() {
                        Ui ui = Rtc.this.ui;
                        if (ui != null) {
                            ui.newVideo(i);
                        }
                    }
                });
            }
            dec.last = System.currentTimeMillis();
            dec.q.offer(Arrays.copyOfRange(bArr, 4, bArr.length));
            if (dec.q.size() > 30) {
                dec.q.clear();
            }
        }
    }

    void openCam() {
        if (!this.running || this.camOff || this.enc == null || this.sharing) {
            return;
        }
        try {
            CameraManager cameraManager = (CameraManager) this.ctx.getSystemService("camera");
            String strCamId = camId(this.front);
            Integer num = (Integer) cameraManager.getCameraCharacteristics(strCamId).get(CameraCharacteristics.SENSOR_ORIENTATION);
            this.sensor = num == null ? 90 : num.intValue();
            Integer num2 = (Integer) cameraManager.getCameraCharacteristics(strCamId).get(CameraCharacteristics.LENS_FACING);
            this.camFront = num2 != null && num2.intValue() == 0;
            cameraManager.openCamera(strCamId, new CameraDevice.StateCallback() { // from class: com.changliao.im.Rtc.12
                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onDisconnected(CameraDevice cameraDevice) {
                    Rtc.this.lost(cameraDevice);
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onError(CameraDevice cameraDevice, int i) {
                    Rtc.this.lost(cameraDevice);
                }

                @Override // android.hardware.camera2.CameraDevice.StateCallback
                public void onOpened(CameraDevice cameraDevice) {
                    if (!Rtc.this.running || Rtc.this.camOff) {
                        cameraDevice.close();
                    } else {
                        Rtc.this.cam = cameraDevice;
                        Rtc.this.session();
                    }
                }
            }, this.camH);
            watch(cameraManager);
        } catch (CameraAccessException e) {
            busy();
        } catch (SecurityException e2) {
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.13
                @Override // java.lang.Runnable
                public void run() {
                    Core.I.emit("toast", J.of("msg", "请在系统设置里允许本 App 使用摄像头", "err", true));
                }
            });
        } catch (Throwable th) {
            Crash.note(th);
        }
        Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.14
            @Override // java.lang.Runnable
            public void run() {
                Rtc.this.fitLocal();
            }
        });
    }

    int outRot() {
        int iDispDeg = (360 - dispDeg()) % 360;
        return this.camFront ? ((this.sensor - iDispDeg) + 360) % 360 : (iDispDeg + this.sensor) % 360;
    }

    Size pickSize() throws Exception {
        ArrayList<Size> arrayList;
        CameraManager cameraManager = (CameraManager) this.ctx.getSystemService("camera");
        int i = this.group ? 76800 : 307200;
        ArrayList<Size> arrayList2 = null;
        String[] cameraIdList = cameraManager.getCameraIdList();
        int length = cameraIdList.length;
        int i2 = 0;
        while (i2 < length) {
            StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) cameraManager.getCameraCharacteristics(cameraIdList[i2]).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (streamConfigurationMap == null) {
                arrayList = arrayList2;
            } else {
                Size[] outputSizes = streamConfigurationMap.getOutputSizes(MediaCodec.class);
                if (outputSizes == null) {
                    arrayList = arrayList2;
                } else {
                    arrayList = new ArrayList(Arrays.asList(outputSizes));
                    if (arrayList2 != null) {
                        ArrayList arrayList3 = new ArrayList();
                        for (Size size : arrayList) {
                            if (arrayList2.contains(size)) {
                                arrayList3.add(size);
                            }
                        }
                        arrayList = !arrayList3.isEmpty() ? arrayList3 : arrayList2;
                    }
                }
            }
            i2++;
            arrayList2 = arrayList;
        }
        Size size2 = new Size(this.group ? 320 : FRAME, this.group ? 240 : 480);
        if (arrayList2 == null) {
            return size2;
        }
        long j = Long.MAX_VALUE;
        Size size3 = size2;
        for (Size size4 : arrayList2) {
            if (size4.getWidth() % 16 == 0 && size4.getHeight() % 16 == 0 && size4.getWidth() <= 1280) {
                long jAbs = Math.abs((((long) size4.getWidth()) * ((long) size4.getHeight())) - ((long) i)) + ((long) (size4.getWidth() * 3 == size4.getHeight() * 4 ? 0 : i / 4));
                if (jAbs < j) {
                    j = jAbs;
                } else {
                    size4 = size3;
                }
                size3 = size4;
            }
        }
        return size3;
    }

    /* JADX WARN: Code duplicated, block: B:60:0x00c8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:? A[SYNTHETIC] */
    void playLoop() throws Throwable {
        Throwable th;
        AudioTrack audioTrack;
        Throwable th2;
        AudioTrack audioTrack2 = null;
        try {
            AudioTrack audioTrack3 = new AudioTrack(new AudioAttributes.Builder().setUsage(2).setContentType(1).build(), new AudioFormat.Builder().setSampleRate(RATE).setChannelMask(4).setEncoding(2).build(), Math.max(AudioTrack.getMinBufferSize(RATE, 4, 2), 2560), 1, 0);
            try {
                audioTrack3.play();
                int[] iArr = new int[FRAME];
                short[] sArr = new short[FRAME];
                while (this.running) {
                    Arrays.fill(iArr, 0);
                    Iterator<Strm> it = this.strms.values().iterator();
                    while (it.hasNext()) {
                        short[] sArrTake = it.next().take();
                        if (sArrTake != null) {
                            for (int i = 0; i < FRAME; i++) {
                                iArr[i] = iArr[i] + sArrTake[i];
                            }
                        }
                    }
                    for (int i2 = 0; i2 < FRAME; i2++) {
                        int i3 = iArr[i2];
                        if (i3 > 32767) {
                            i3 = 32767;
                        } else if (i3 < -32768) {
                            i3 = -32768;
                        }
                        sArr[i2] = (short) i3;
                    }
                    int i4 = 0;
                    while (i4 < FRAME && this.running) {
                        int iWrite = audioTrack3.write(sArr, i4, 640 - i4);
                        if (iWrite <= 0) {
                            break;
                        } else {
                            i4 += iWrite;
                        }
                    }
                }
                if (audioTrack3 != null) {
                    try {
                        audioTrack3.stop();
                        audioTrack3.release();
                    } catch (Throwable th3) {
                    }
                }
            } catch (Throwable th4) {
                th = th4;
                audioTrack = audioTrack3;
                try {
                    Crash.note(th);
                    if (audioTrack != null) {
                        try {
                            audioTrack.stop();
                            audioTrack.release();
                        } catch (Throwable th5) {
                        }
                    }
                } catch (Throwable th6) {
                    th2 = th6;
                    audioTrack2 = audioTrack;
                    if (audioTrack2 != null) {
                        throw th2;
                    }
                    audioTrack2.stop();
                    audioTrack2.release();
                    throw th2;
                }
            }
        } catch (Throwable th7) {
            th = th7;
            audioTrack = null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:143:0x015c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:146:0x0154 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:187:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:94:0x0161 A[Catch: Throwable -> 0x016a, TryCatch #11 {Throwable -> 0x016a, blocks: (B:92:0x015c, B:94:0x0161, B:96:0x0166), top: B:143:0x015c }] */
    /* JADX WARN: Code duplicated, block: B:96:0x0166 A[Catch: Throwable -> 0x016a, TRY_LEAVE, TryCatch #11 {Throwable -> 0x016a, blocks: (B:92:0x015c, B:94:0x0161, B:96:0x0166), top: B:143:0x015c }] */
    void recLoop() throws Throwable {
        // jadx 把 try/catch 里的局部变量提升到了方法顶，且丢掉了赋值顺序信息；
        // 显式给 default 值以通过 javac 的 definite-assignment 检查（原字节码这些槽位在读取前必已赋值）
        Throwable th = null;
        AutomaticGainControl automaticGainControl = null;
        NoiseSuppressor noiseSuppressor = null;
        AcousticEchoCanceler acousticEchoCanceler = null;
        AudioRecord audioRecord = null;
        Throwable th2 = null;
        AutomaticGainControl automaticGainControl2 = null;
        AcousticEchoCanceler acousticEchoCancelerCreate = null;
        NoiseSuppressor noiseSuppressorCreate = null;
        int i = 0;
        AutomaticGainControl automaticGainControlCreate = null;
        try {
            AudioRecord audioRecord2 = new AudioRecord(7, RATE, 16, 2, Math.max(AudioRecord.getMinBufferSize(RATE, 16, 2), 5120));
            try {
                try {
                    if (audioRecord2.getState() != 1) {
                        throw new IllegalStateException("麦克风打不开");
                    }
                    int audioSessionId = audioRecord2.getAudioSessionId();
                    try {
                        if (AcousticEchoCanceler.isAvailable()) {
                            acousticEchoCancelerCreate = AcousticEchoCanceler.create(audioSessionId);
                            if (acousticEchoCancelerCreate != null) {
                                try {
                                    acousticEchoCancelerCreate.setEnabled(true);
                                } catch (Throwable th3) {
                                    th = th3;
                                    automaticGainControl = null;
                                    noiseSuppressor = null;
                                    acousticEchoCanceler = acousticEchoCancelerCreate;
                                    audioRecord = audioRecord2;
                                    if (audioRecord != null) {
                                        try {
                                            audioRecord.stop();
                                            audioRecord.release();
                                        } catch (Throwable th4) {
                                        }
                                    }
                                    if (acousticEchoCanceler != null) {
                                        try {
                                            acousticEchoCanceler.release();
                                        } catch (Throwable th5) {
                                            throw th;
                                        }
                                    }
                                    if (noiseSuppressor != null) {
                                        noiseSuppressor.release();
                                    }
                                    if (automaticGainControl == null) {
                                        throw th;
                                    }
                                    automaticGainControl.release();
                                    throw th;
                                }
                            }
                        } else {
                            acousticEchoCancelerCreate = null;
                        }
                        acousticEchoCanceler = acousticEchoCancelerCreate;
                    } catch (Throwable th6) {
                        acousticEchoCancelerCreate = null;
                    }
                    try {
                        if (NoiseSuppressor.isAvailable()) {
                            noiseSuppressorCreate = NoiseSuppressor.create(audioSessionId);
                            if (noiseSuppressorCreate != null) {
                                try {
                                    noiseSuppressorCreate.setEnabled(true);
                                } catch (Throwable th7) {
                                    noiseSuppressor = noiseSuppressorCreate;
                                }
                            }
                        } else {
                            noiseSuppressorCreate = null;
                        }
                        noiseSuppressor = noiseSuppressorCreate;
                    } catch (Throwable th8) {
                        th = th8;
                        automaticGainControl = null;
                        noiseSuppressor = null;
                        audioRecord = audioRecord2;
                    }
                    try {
                        if (AutomaticGainControl.isAvailable() && (automaticGainControlCreate = AutomaticGainControl.create(audioSessionId)) != null) {
                            try {
                                automaticGainControlCreate.setEnabled(true);
                            } catch (Throwable th9) {
                                th = th9;
                                automaticGainControl = automaticGainControlCreate;
                                audioRecord = audioRecord2;
                                if (audioRecord != null) {
                                    audioRecord.stop();
                                    audioRecord.release();
                                }
                                if (acousticEchoCanceler != null) {
                                    acousticEchoCanceler.release();
                                }
                                if (noiseSuppressor != null) {
                                    noiseSuppressor.release();
                                }
                                if (automaticGainControl == null) {
                                    throw th;
                                }
                                automaticGainControl.release();
                                throw th;
                            }
                        }
                        try {
                            audioRecord2.startRecording();
                            short[] sArr = new short[FRAME];
                            int[] iArr = new int[2];
                            int i2 = 0;
                            int i3 = 0;
                            while (this.running) {
                                int i4 = 0;
                                while (i4 < FRAME && this.running) {
                                    int i5 = audioRecord2.read(sArr, i4, 640 - i4);
                                    if (i5 <= 0) {
                                        Thread.sleep(5L);
                                    } else {
                                        i4 += i5;
                                    }
                                }
                                if (!this.running) {
                                    break;
                                }
                                if (this.muted) {
                                    i2 = 0;
                                } else {
                                    long jAbs = 0;
                                    for (int i6 = 0; i6 < FRAME; i6 += 4) {
                                        jAbs += (long) Math.abs((int) sArr[i6]);
                                    }
                                    if (jAbs / 160 > 120) {
                                        i = 12;
                                    } else if (i2 > 0) {
                                        i = i2 - 1;
                                    } else {
                                        iArr[0] = 0;
                                        iArr[1] = 0;
                                    }
                                    byte[] bArr = new byte[326];
                                    bArr[0] = 1;
                                    bArr[1] = (byte) (i3 >> 8);
                                    bArr[2] = (byte) i3;
                                    i3++;
                                    bArr[3] = (byte) (iArr[0] >> 8);
                                    bArr[4] = (byte) iArr[0];
                                    bArr[5] = (byte) iArr[1];
                                    Adpcm.encode(sArr, iArr, bArr, 6);
                                    Core.I.sendBin(bArr);
                                    this.lastSent = System.currentTimeMillis();
                                    i2 = i;
                                }
                            }
                            if (audioRecord2 != null) {
                                try {
                                    audioRecord2.stop();
                                    audioRecord2.release();
                                } catch (Throwable th10) {
                                }
                            }
                            if (acousticEchoCanceler != null) {
                                try {
                                    acousticEchoCanceler.release();
                                } catch (Throwable th11) {
                                    return;
                                }
                            }
                            if (noiseSuppressor != null) {
                                noiseSuppressor.release();
                            }
                            if (automaticGainControlCreate != null) {
                                automaticGainControlCreate.release();
                            }
                        } catch (Throwable th12) {
                            th2 = th12;
                            automaticGainControl2 = automaticGainControlCreate;
                            audioRecord = audioRecord2;
                            try {
                                Crash.note(th2);
                                Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.5
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        Core.I.emit("toast", J.of("msg", "麦克风打不开：请在系统设置里允许本 App 使用麦克风", "err", true));
                                    }
                                });
                                if (audioRecord != null) {
                                    try {
                                        audioRecord.stop();
                                        audioRecord.release();
                                    } catch (Throwable th13) {
                                    }
                                }
                                if (acousticEchoCanceler != null) {
                                    try {
                                        acousticEchoCanceler.release();
                                    } catch (Throwable th14) {
                                        return;
                                    }
                                }
                                if (noiseSuppressor != null) {
                                    noiseSuppressor.release();
                                }
                                if (automaticGainControl2 != null) {
                                    automaticGainControl2.release();
                                }
                            } catch (Throwable th15) {
                                th = th15;
                                automaticGainControl = automaticGainControl2;
                                if (audioRecord != null) {
                                    audioRecord.stop();
                                    audioRecord.release();
                                }
                                if (acousticEchoCanceler != null) {
                                    acousticEchoCanceler.release();
                                }
                                if (noiseSuppressor != null) {
                                    noiseSuppressor.release();
                                }
                                if (automaticGainControl == null) {
                                    throw th;
                                }
                                automaticGainControl.release();
                                throw th;
                            }
                        }
                    } catch (Throwable th16) {
                        th = th16;
                        automaticGainControl = null;
                        audioRecord = audioRecord2;
                        if (audioRecord != null) {
                            audioRecord.stop();
                            audioRecord.release();
                        }
                        if (acousticEchoCanceler != null) {
                            acousticEchoCanceler.release();
                        }
                        if (noiseSuppressor != null) {
                            noiseSuppressor.release();
                        }
                        if (automaticGainControl == null) {
                            throw th;
                        }
                        automaticGainControl.release();
                        throw th;
                    }
                } catch (Throwable th17) {
                    th2 = th17;
                    automaticGainControl2 = null;
                    noiseSuppressor = null;
                    acousticEchoCanceler = null;
                    audioRecord = audioRecord2;
                }
            } catch (Throwable th18) {
                th = th18;
                automaticGainControl = null;
                noiseSuppressor = null;
                acousticEchoCanceler = null;
                audioRecord = audioRecord2;
            }
        } catch (Throwable th19) {
            th = th19;
            automaticGainControl = null;
            noiseSuppressor = null;
            acousticEchoCanceler = null;
            audioRecord = null;
        }
    }

    void restartSession() {
        if (this.cam == null) {
            return;
        }
        try {
            if (this.ses != null) {
                this.ses.close();
            }
        } catch (Throwable th) {
        }
        this.ses = null;
        session();
    }

    void session() {
        final CameraDevice cameraDevice = this.cam;
        if (cameraDevice == null) {
            return;
        }
        final int i = this.sesGen + 1;
        this.sesGen = i;
        try {
            final ArrayList arrayList = new ArrayList();
            arrayList.add(this.encSurf);
            if (this.localSurf != null) {
                arrayList.add(this.localSurf);
            }
            cameraDevice.createCaptureSession(arrayList, new CameraCaptureSession.StateCallback() { // from class: com.changliao.im.Rtc.17
                @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                    if (i == Rtc.this.sesGen && Rtc.this.running) {
                        Rtc.this.busy();
                    }
                }

                @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                    if (Rtc.this.cam != cameraDevice || i != Rtc.this.sesGen || !Rtc.this.running) {
                        try {
                            cameraCaptureSession.close();
                            return;
                        } catch (Throwable th) {
                            return;
                        }
                    }
                    Rtc.this.ses = cameraCaptureSession;
                    try {
                        CaptureRequest.Builder builderCreateCaptureRequest = cameraDevice.createCaptureRequest(3);
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            builderCreateCaptureRequest.addTarget((Surface) it.next());
                        }
                        builderCreateCaptureRequest.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range(10, 15));
                        builderCreateCaptureRequest.set(CaptureRequest.CONTROL_AF_MODE, 3);
                        cameraCaptureSession.setRepeatingRequest(builderCreateCaptureRequest.build(), null, Rtc.this.camH);
                        Rtc.this.wantKey = true;
                    } catch (IllegalStateException e) {
                    } catch (Throwable th2) {
                        Crash.note(th2);
                    }
                }
            }, this.camH);
        } catch (CameraAccessException e) {
            lost(cameraDevice);
        } catch (IllegalStateException e2) {
            lost(cameraDevice);
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    void setCam(boolean z) {
        this.camOff = !z;
        if (this.camH == null) {
            return;
        }
        this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.23
            @Override // java.lang.Runnable
            public void run() {
                Rtc.this.closeCam();
                if (Rtc.this.camOff) {
                    return;
                }
                Rtc.this.openCam();
            }
        });
    }

    void setLocal(TextureView textureView) {
        this.localV = textureView;
        if (textureView != null) {
            if (textureView.isAvailable()) {
                localReady(textureView.getSurfaceTexture());
            }
            textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() { // from class: com.changliao.im.Rtc.20
                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
                    Rtc.this.localReady(surfaceTexture);
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                    if (Rtc.this.localV == null || Rtc.this.localV.getSurfaceTexture() != surfaceTexture) {
                        return true;
                    }
                    Rtc.this.localSurf = null;
                    if (Rtc.this.camH == null) {
                        return true;
                    }
                    Rtc.this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.20.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Rtc.this.restartSession();
                        }
                    });
                    return true;
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
                    Rtc.this.fitLocal();
                }

                @Override // android.view.TextureView.SurfaceTextureListener
                public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
                }
            });
        } else {
            this.localSurf = null;
            if (this.camH != null) {
                this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.19
                    @Override // java.lang.Runnable
                    public void run() {
                        Rtc.this.restartSession();
                    }
                });
            }
        }
    }

    void setSpeaker(boolean z) {
        this.speaker = z;
        try {
            this.am.setSpeakerphoneOn(z);
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    void start() {
        if (this.running) {
            return;
        }
        this.running = true;
        try {
            this.oldMode = this.am.getMode();
            this.am.setMode(3);
        } catch (Throwable th) {
            Crash.note(th);
        }
        setSpeaker(this.video);
        Ws.binL = new Ws.Bin() { // from class: com.changliao.im.Rtc.1
            @Override // com.changliao.im.Ws.Bin
            public void bin(byte[] bArr) {
                Rtc.this.onBin(bArr);
            }
        };
        Thread thread = new Thread(new Runnable() { // from class: com.changliao.im.Rtc.2
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Rtc.this.recLoop();
                } catch (Throwable th) {
                    throw new RuntimeException(th);
                }
            }
        }, "rtc-rec");
        Thread thread2 = new Thread(new Runnable() { // from class: com.changliao.im.Rtc.3
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Rtc.this.playLoop();
                } catch (Throwable th) {
                    throw new RuntimeException(th);
                }
            }
        }, "rtc-play");
        thread.setPriority(10);
        thread2.setPriority(10);
        thread.start();
        thread2.start();
        if (this.video) {
            startVideo();
        }
    }

    void startScreen(MediaProjection mediaProjection, int i, int i2, int i3) {
        try {
            camThread();
            int i4 = this.encGen;
            this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.8
                @Override // java.lang.Runnable
                public void run() {
                    Rtc.this.closeCam();
                }
            });
            float fMin = Math.min(1.0f, (this.group ? 960.0f : 1280.0f) / Math.max(i, i2));
            int iMax = Math.max(160, Math.round((i * fMin) / 16.0f) * 16);
            int iMax2 = Math.max(160, Math.round((fMin * i2) / 16.0f) * 16);
            this.sharing = true;
            makeEnc(iMax, iMax2, this.group ? 700000 : 1400000, true);
            this.mp = mediaProjection;
            mediaProjection.registerCallback(new MediaProjection.Callback() { // from class: com.changliao.im.Rtc.9
                @Override // android.media.projection.MediaProjection.Callback
                public void onStop() {
                    Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.9.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Rtc.this.stopScreen();
                            Call call = Call.cur;
                            if (call != null) {
                                call.sharing = false;
                                call.changed();
                            }
                        }
                    });
                }
            }, this.camH);
            this.vdisp = mediaProjection.createVirtualDisplay("nk-share", iMax, iMax2, i3, 16, this.encSurf, null, this.camH);
        } catch (Throwable th) {
            Crash.note(th);
            this.sharing = false;
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.10
                @Override // java.lang.Runnable
                public void run() {
                    Core.I.emit("toast", J.of("msg", "共享屏幕失败了，请再试一次", "err", true));
                }
            });
        }
    }

    void startVideo() {
        try {
            camThread();
            Size sizePickSize = pickSize();
            this.vw = sizePickSize.getWidth();
            this.vh = sizePickSize.getHeight();
            makeEnc(this.vw, this.vh, this.group ? 280000 : 650000, false);
            openCam();
        } catch (Throwable th) {
            Crash.note(th);
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Rtc.6
                @Override // java.lang.Runnable
                public void run() {
                    Core.I.emit("toast", J.of("msg", "摄像头打不开，先用语音通话", "err", true));
                }
            });
        }
    }

    void stop() {
        if (this.running) {
            this.running = false;
            Ws.binL = null;
            try {
                if (this.vdisp != null) {
                    this.vdisp.release();
                }
                if (this.mp != null) {
                    this.mp.stop();
                }
            } catch (Throwable th) {
            }
            this.vdisp = null;
            this.mp = null;
            this.sharing = false;
            stopVideo();
            Iterator<Dec> it = this.decs.values().iterator();
            while (it.hasNext()) {
                it.next().close();
            }
            this.decs.clear();
            try {
                this.am.setSpeakerphoneOn(false);
                this.am.setMode(this.oldMode == 3 ? 0 : this.oldMode);
            } catch (Throwable th2) {
            }
        }
    }

    void stopScreen() {
        if (this.sharing) {
            this.sharing = false;
            try {
                if (this.vdisp != null) {
                    this.vdisp.release();
                }
            } catch (Throwable th) {
            }
            try {
                if (this.mp != null) {
                    this.mp.stop();
                }
            } catch (Throwable th2) {
            }
            this.vdisp = null;
            this.mp = null;
            this.encGen++;
            this.enc = null;
            if (this.video && this.running) {
                try {
                    makeEnc(this.vw, this.vh, this.group ? 280000 : 650000, false);
                    if (this.camH != null) {
                        this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.11
                            @Override // java.lang.Runnable
                            public void run() {
                                Rtc.this.openCam();
                            }
                        });
                    }
                } catch (Throwable th3) {
                    Crash.note(th3);
                }
            }
        }
    }

    void stopVideo() {
        final HandlerThread handlerThread = this.camT;
        try {
            if (this.avail != null) {
                ((CameraManager) this.ctx.getSystemService("camera")).unregisterAvailabilityCallback(this.avail);
            }
        } catch (Throwable th) {
        }
        this.avail = null;
        if (this.camH != null) {
            this.camH.post(new Runnable() { // from class: com.changliao.im.Rtc.18
                @Override // java.lang.Runnable
                public void run() {
                    Rtc.this.closeCam();
                    if (handlerThread != null) {
                        handlerThread.quitSafely();
                    }
                }
            });
        }
        this.camH = null;
        this.camT = null;
    }

    boolean talking(int i) {
        Strm strm = this.strms.get(Integer.valueOf(i));
        return strm != null && System.currentTimeMillis() - strm.last < 400;
    }

    void watch(CameraManager cameraManager) {
        if (this.avail != null) {
            return;
        }
        this.avail = new CameraManager.AvailabilityCallback() { // from class: com.changliao.im.Rtc.16
            @Override // android.hardware.camera2.CameraManager.AvailabilityCallback
            public void onCameraAvailable(String str) {
                if (!Rtc.this.running || Rtc.this.camOff || Rtc.this.cam != null || Rtc.this.camH == null) {
                    return;
                }
                Rtc.this.camH.postDelayed(new Runnable() { // from class: com.changliao.im.Rtc.16.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (Rtc.this.running && !Rtc.this.camOff && Rtc.this.cam == null) {
                            Rtc.this.toldBusy = false;
                            Rtc.this.openCam();
                        }
                    }
                }, 400L);
            }
        };
        try {
            cameraManager.registerAvailabilityCallback(this.avail, this.camH);
        } catch (Throwable th) {
            this.avail = null;
        }
    }
}
