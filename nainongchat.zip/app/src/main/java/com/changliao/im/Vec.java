package com.changliao.im;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
final class Vec {
    static final int BEAM = 2;
    static final int BLUSH = 5;
    static final int BROKEN = 31;
    static final int CHECK = 34;
    static final int COFFEE = 45;
    static final int COOL = 8;
    static final int CROSS = 35;
    static final int DROOL = 22;
    static final Paint F;
    static final int FIRE = 32;
    static final int GIFT = 48;
    static final int GRIN = 1;
    static final int HALO = 19;
    static final int HEART = 30;
    static final int HEARTEYES = 6;
    static final int HUG = 16;
    static final int HUNDRED = 42;
    static final HashMap<String, Integer> ID = new HashMap<>();
    static final int INK = -10733038;
    static final int JOY = 3;
    static final int KISS = 7;
    static final int MEGA = 43;
    static final int MOON = 38;
    static final int MOUTH = -8770030;
    static final int NOTE = 46;
    static final Path P;
    static final int PARTY = 15;
    static final int PLEAD = 20;
    static final int POPPER = 40;
    static final int QUESTION = 44;
    static final RectF R;
    static final int RAGE = 13;
    static final int RAIN = 37;
    static final int RAINBOW = 39;
    static final int ROFL = 4;
    static final int ROLL = 17;
    static final Paint S;
    static final int SCREAM = 14;
    static final int SKIN1 = -6528;
    static final int SKIN2 = -14275;
    static final int SKIN3 = -877795;
    static final int SLEEP = 11;
    static final int SMIRK = 10;
    static final int SOB = 12;
    static final int SPARKLE = 47;
    static final int STAR = 33;
    static final int STARS = 24;
    static final int STEAM = 21;
    static final int SUN = 36;
    static final int SWEAT = 18;
    static final int THINK = 9;
    static final int TONGUE = -38037;
    static final int YUM = 23;
    static final int ZZZ = 41;

    static {
        m(1, "😀 😃 😄");
        m(2, "😁 😆");
        m(3, "😂 😹");
        m(4, "🤣");
        m(5, "😊 ☺️ 🙂");
        m(6, "😍 😻 🥰");
        m(KISS, "😘 😚");
        m(COOL, "😎");
        m(THINK, "🤔 🧐");
        m(SMIRK, "😏");
        m(SLEEP, "😴 😪 🥱");
        m(SOB, "😭 😢");
        m(RAGE, "😡 😠 🤬");
        m(SCREAM, "😱 😨 😰");
        m(PARTY, "🥳");
        m(HUG, "🤗");
        m(ROLL, "🙄");
        m(SWEAT, "😅");
        m(HALO, "😇");
        m(PLEAD, "🥺");
        m(STEAM, "😤");
        m(DROOL, "🤤");
        m(YUM, "😋 😛 😜 😝 🤪");
        m(STARS, "🤩");
        m(HEART, "❤️ ❤ 💖 💗 💓 💕");
        m(BROKEN, "💔");
        m(FIRE, "🔥");
        m(STAR, "⭐ 🌟");
        m(CHECK, "✅ ✔️");
        m(CROSS, "❌ ❎");
        m(SUN, "☀️ 🌞");
        m(RAIN, "🌧️ ☔");
        m(MOON, "🌙");
        m(RAINBOW, "🌈");
        m(POPPER, "🎉 🎊");
        m(ZZZ, "💤");
        m(HUNDRED, "💯");
        m(MEGA, "📢 📣");
        m(QUESTION, "❓ ❔");
        m(COFFEE, "☕");
        m(NOTE, "🎵 🎶");
        m(SPARKLE, "✨");
        m(GIFT, "🎁");
        F = new Paint(1);
        S = new Paint(1);
        S.setStyle(Paint.Style.STROKE);
        S.setStrokeCap(Paint.Cap.ROUND);
        S.setStrokeJoin(Paint.Join.ROUND);
        P = new Path();
        R = new RectF();
    }

    Vec() {
    }

    static int a(int i, float f) {
        return (Math.round(cl(f) * 255.0f) << STARS) | (16777215 & i);
    }

    static float back(float f) {
        float fCl = cl(f);
        return (((float) Math.pow(fCl - 1.0f, 2.0d)) * 1.9f) + ((1.9f + 1.0f) * ((float) Math.pow(fCl - 1.0f, 3.0d))) + 1.0f;
    }

    static float bell(float f, float f2, float f3) {
        if (f < f2 || f > f3) {
            return 0.0f;
        }
        return sn((3.141592653589793d * ((double) (f - f2))) / ((double) (f3 - f2)));
    }

    static void bigHeart(Canvas canvas, int i, int i2) {
        Path path = new Path();
        path.moveTo(50.0f, 88.0f);
        path.cubicTo(40.0f, 78.0f, 8.0f, 60.0f, 8.0f, 36.0f);
        path.cubicTo(8.0f, 20.0f, 20.0f, 10.0f, 32.0f, 10.0f);
        path.cubicTo(41.0f, 10.0f, 47.0f, 15.0f, 50.0f, 22.0f);
        path.cubicTo(53.0f, 15.0f, 59.0f, 10.0f, 68.0f, 10.0f);
        path.cubicTo(80.0f, 10.0f, 92.0f, 20.0f, 92.0f, 36.0f);
        path.cubicTo(92.0f, 60.0f, 60.0f, 78.0f, 50.0f, 88.0f);
        path.close();
        F.setShader(new LinearGradient(0.0f, 10.0f, 0.0f, 88.0f, i, i2, Shader.TileMode.CLAMP));
        canvas.drawPath(path, F);
        F.setShader(null);
        fill(1728053247);
        R.set(18.0f, 18.0f, 38.0f, 34.0f);
        canvas.save();
        canvas.rotate(-30.0f, 28.0f, 26.0f);
        canvas.drawOval(R, F);
        canvas.restore();
        fill(-1711276033);
        canvas.drawCircle(42.0f, 22.0f, 2.4f, F);
    }

    static float blink(float f, float f2) {
        float fAbs = Math.abs(f - f2);
        if (fAbs > 0.09f) {
            return 1.0f;
        }
        return fAbs / 0.09f;
    }

    static void brows(Canvas canvas, float f, float f2, int i) {
        stroke(i, 3.6f);
        canvas.save();
        canvas.rotate(f, 31.0f, f2);
        canvas.drawLine(23.0f, f2, 39.0f, f2, S);
        canvas.restore();
        canvas.save();
        canvas.rotate(-f, 69.0f, f2);
        canvas.drawLine(61.0f, f2, 77.0f, f2, S);
        canvas.restore();
    }

    static void cheeks(Canvas canvas, float f) {
        if (f <= 0.0f) {
            return;
        }
        F.setShader(new RadialGradient(27.0f, 64.0f, 9.0f, a(-34182, 0.55f * f), 16743034, Shader.TileMode.CLAMP));
        canvas.drawCircle(27.0f, 64.0f, 9.0f, F);
        F.setShader(new RadialGradient(73.0f, 64.0f, 9.0f, a(-34182, 0.55f * f), 16743034, Shader.TileMode.CLAMP));
        canvas.drawCircle(73.0f, 64.0f, 9.0f, F);
        F.setShader(null);
    }

    static float cl(float f) {
        if (f < 0.0f) {
            return 0.0f;
        }
        if (f > 1.0f) {
            return 1.0f;
        }
        return f;
    }

    static void closedEyes(Canvas canvas, float f) {
        stroke(INK, 3.6f);
        P.reset();
        P.moveTo(23.0f, f);
        P.quadTo(31.0f, f + 6.0f, 39.0f, f);
        canvas.drawPath(P, S);
        P.reset();
        P.moveTo(61.0f, f);
        P.quadTo(69.0f, f + 6.0f, 77.0f, f);
        canvas.drawPath(P, S);
    }

    static void cloud(Canvas canvas, float f, float f2, float f3, int i, int i2) {
        Path path = new Path();
        path.addCircle(f - (18.0f * f3), (4.0f * f3) + f2, 16.0f * f3, Path.Direction.CW);
        path.addCircle((2.0f * f3) + f, f2 - (6.0f * f3), 22.0f * f3, Path.Direction.CW);
        path.addCircle((22.0f * f3) + f, (4.0f * f3) + f2, 15.0f * f3, Path.Direction.CW);
        Path path2 = new Path();
        path2.addRoundRect(new RectF(f - (34.0f * f3), (2.0f * f3) + f2, (37.0f * f3) + f, (20.0f * f3) + f2), 10.0f * f3, 10.0f * f3, Path.Direction.CW);
        path.op(path2, Path.Op.UNION);
        F.setShader(new LinearGradient(0.0f, f2 - (28.0f * f3), 0.0f, (20.0f * f3) + f2, i, i2, Shader.TileMode.CLAMP));
        canvas.drawPath(path, F);
        F.setShader(null);
    }

    static void confetti(Canvas canvas, float f, float f2, float f3, int i) {
        int[] iArr = {-42401, -16059, -12723049, -11563777, -4883457, -29992};
        for (int i2 = 0; i2 < i; i2++) {
            float fRnd = 0.15f + (rnd(i2) * 0.5f);
            float fSeg = seg(f, fRnd, 1.4f + fRnd);
            if (fSeg > 0.0f && fSeg < 1.0f) {
                float fRnd2 = (float) ((-1.5707963267948966d) + ((double) ((rnd(i2 + 50) - 0.5f) * 2.6f)));
                float fRnd3 = (rnd(i2 + THINK) * 40.0f) + 40.0f;
                float fCs = (cs(fRnd2) * fRnd3 * fSeg) + f2;
                float fSn = (sn(fRnd2) * fRnd3 * fSeg) + f3 + (70.0f * fSeg * fSeg);
                fill(a(iArr[i2 % iArr.length], 1.0f - seg(fSeg, 0.7f, 1.0f)));
                canvas.save();
                canvas.translate(fCs, fSn);
                canvas.rotate(720.0f * fSeg * (rnd(i2 + 3) - 0.5f));
                canvas.scale(1.0f, Math.abs(cs((fSeg * 12.0f) + i2)));
                canvas.drawRect(-3.0f, -1.6f, 3.0f, 1.6f, F);
                canvas.restore();
            }
        }
    }

    static float cs(double d) {
        return (float) Math.cos(d);
    }

    static void draw(Canvas canvas, String str, float f) {
        Integer num = ID.get(Emo.strip(str));
        if (num == null) {
            return;
        }
        if (num.intValue() < HEART) {
            face(canvas, num.intValue(), f);
        } else {
            other(canvas, num.intValue(), f);
        }
    }

    static void drawPart(Canvas canvas, Path path, float f) {
        if (f <= 0.0f) {
            return;
        }
        PathMeasure pathMeasure = new PathMeasure(path, false);
        Path path2 = new Path();
        pathMeasure.getSegment(0.0f, pathMeasure.getLength() * cl(f), path2, true);
        canvas.drawPath(path2, S);
    }

    static void drop(Canvas canvas, float f, float f2, float f3, int i) {
        P.reset();
        P.moveTo(f, f2 - f3);
        P.cubicTo((f3 * 0.9f) + f, f2 - (f3 * 0.1f), (f3 * 0.7f) + f, (f3 * 0.8f) + f2, f, f2 + (f3 * 0.8f));
        P.cubicTo(f - (f3 * 0.7f), (f3 * 0.8f) + f2, f - (f3 * 0.9f), f2 - (f3 * 0.1f), f, f2 - f3);
        P.close();
        F.setShader(new LinearGradient(f, f2 - f3, f, f2 + f3, -4199681, i, Shader.TileMode.CLAMP));
        canvas.drawPath(P, F);
        F.setShader(null);
        fill(-1711276033);
        canvas.drawCircle(f - (0.25f * f3), (0.15f * f3) + f2, 0.18f * f3, F);
    }

    static float dur(String str) {
        Integer num = ID.get(Emo.strip(str));
        return (num == null || num.intValue() == MEGA) ? 2.2f : 2.6f;
    }

    static float eio(float f) {
        float fCl = cl(f);
        return fCl < 0.5f ? fCl * 4.0f * fCl * fCl : 1.0f - (((float) Math.pow((fCl * (-2.0f)) + 2.0f, 3.0d)) / 2.0f);
    }

    static float eo(float f) {
        float fCl = cl(f);
        return 1.0f - ((1.0f - fCl) * ((1.0f - fCl) * (1.0f - fCl)));
    }

    static void eyes(Canvas canvas, float f, float f2, float f3) {
        fill(INK);
        float fMax = 7.5f * Math.max(0.08f, f);
        R.set((31.0f + f2) - 4.6f, (44.0f + f3) - fMax, 31.0f + f2 + 4.6f, 44.0f + f3 + fMax);
        canvas.drawOval(R, F);
        R.set((69.0f + f2) - 4.6f, (44.0f + f3) - fMax, 69.0f + f2 + 4.6f, fMax + 44.0f + f3);
        canvas.drawOval(R, F);
        if (f > 0.5f) {
            fill(-855638017);
            canvas.drawCircle(32.6f + f2, 40.5f + f3, 1.6f, F);
            canvas.drawCircle(70.6f + f2, 40.5f + f3, 1.6f, F);
        }
    }

    static void face(Canvas canvas, int i, float f) {
        float fSn;
        float f2;
        float f3 = f < 2.6f ? 1.0f : 0.0f;
        float fSn2 = 0.0f;
        float fAbs = 1.0f;
        float fSn3 = 0.0f;
        switch (i) {
            case 1:
            case 2:
                fSn3 = ((-bell(f, 0.1f, 0.5f)) * 8.0f) - (bell(f, 0.55f, 0.85f) * 4.0f);
                fAbs = 1.0f - (bell(f, 0.45f, 0.6f) * 0.06f);
                fSn = 0.0f;
                f2 = 2.0f - fAbs;
                break;
            case 3:
                fSn2 = sn(30.0f * f) * 7.0f * (1.0f - seg(f, 1.6f, 2.4f)) * f3;
                fSn3 = (-Math.abs(sn(15.0f * f))) * 3.0f * f3;
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case 4:
                fSn2 = ((1.0f - eio(seg(f, 2.0f, 2.5f))) * (-38.0f) * eio(seg(f, 0.0f, 0.5f))) + (((f <= 0.5f || f >= 2.0f) ? 0 : 1) * 6.0f * sn(30.0f * f));
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case 5:
            case ROLL /* 17 */:
            case SWEAT /* 18 */:
            case HALO /* 19 */:
            case DROOL /* 22 */:
            default:
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case 6:
                float fAbs2 = 1.0f + (0.03f * Math.abs(sn(9.0f * f)) * f3);
                fSn = 0.0f;
                fAbs = fAbs2;
                f2 = fAbs2;
                break;
            case KISS /* 7 */:
                fSn2 = (-6.0f) * bell(f, 0.2f, 1.2f);
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case COOL /* 8 */:
                fSn2 = sn(4.0f * f) * 4.0f * f3;
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case THINK /* 9 */:
                fSn2 = ((-10.0f) * eio(seg(f, 0.0f, 0.4f))) + (sn(2.5f * f) * 2.0f * f3);
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case SMIRK /* 10 */:
                fSn2 = 6.0f * eio(seg(f, 0.0f, 0.35f)) * (1.0f - eio(seg(f, 2.1f, 2.5f)));
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case SLEEP /* 11 */:
                fSn3 = 1.5f * sn(2.4f * f);
                fSn2 = sn(1.2f * f) * 4.0f;
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case SOB /* 12 */:
                fSn3 = sn(22.0f * f) * 0.8f * f3;
                fAbs = 1.0f - ((Math.abs(sn(8.0f * f)) * 0.025f) * f3);
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case RAGE /* 13 */:
                fSn = ((f <= 0.3f || f >= 2.0f) ? 0 : 1) * 1.6f * sn(60.0f * f);
                float fSeg = 1.0f + (0.06f * seg(f, 0.0f, 0.4f) * (1.0f - seg(f, 2.1f, 2.5f)));
                fAbs = fSeg;
                f2 = fSeg;
                break;
            case SCREAM /* 14 */:
                float fBell = 1.0f - (0.1f * bell(f, 0.05f, 0.35f));
                float fBell2 = (0.14f * bell(f, 0.05f, 0.35f)) + 1.0f;
                fSn = ((f <= 0.4f || f >= 2.2f) ? 0 : 1) * 1.2f * sn(70.0f * f);
                fAbs = fBell2;
                f2 = fBell;
                break;
            case PARTY /* 15 */:
                fSn3 = 10.0f * (-bell(f, 0.2f, 0.7f));
                fSn2 = bell(f, 0.2f, 0.7f) * (-8.0f);
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case HUG /* 16 */:
                float fBell3 = 1.0f + (0.05f * bell(f, 0.3f, 1.1f));
                fAbs = 1.0f - (0.04f * bell(f, 0.3f, 1.1f));
                fSn = 0.0f;
                f2 = fBell3;
                break;
            case PLEAD /* 20 */:
                fSn = sn(40.0f * f) * 0.4f * f3;
                f2 = 1.0f;
                break;
            case STEAM /* 21 */:
                float fBell4 = 1.0f + (0.05f * bell(f, 0.2f, 0.5f)) + (0.05f * bell(f, 1.1f, 1.4f));
                fSn = 0.0f;
                fAbs = fBell4;
                f2 = fBell4;
                break;
            case YUM /* 23 */:
                fSn2 = sn(6.0f * f) * 4.0f * f3;
                fSn = 0.0f;
                f2 = 1.0f;
                break;
            case STARS /* 24 */:
                fSn3 = 6.0f * (-bell(f, 0.1f, 0.5f));
                fSn = 0.0f;
                f2 = 1.0f;
                break;
        }
        canvas.save();
        canvas.translate(fSn, fSn3);
        canvas.rotate(fSn2, 50.0f, i == 4 ? 52.0f : 92.0f);
        canvas.scale(f2, fAbs, 50.0f, 96.0f);
        if (i == RAGE) {
            float fMax = Math.max(0.03f, eo(seg(f, 0.2f, 1.0f)) * (1.0f - (seg(f, 2.2f, 2.6f) * 0.6f)));
            head(canvas, SKIN1, SKIN2, SKIN3);
            canvas.save();
            P.reset();
            P.addCircle(50.0f, 52.0f, 44.0f, Path.Direction.CW);
            canvas.clipPath(P);
            F.setShader(new LinearGradient(0.0f, 96.0f, 0.0f, 96.0f - (fMax * 90.0f), new int[]{-1559010, -856534994, 15880238}, new float[]{0.0f, 0.7f, 1.0f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0.0f, 0.0f, 100.0f, 100.0f, F);
            F.setShader(null);
            canvas.restore();
        } else if (i == SCREAM) {
            head(canvas, -1444865, -8070, SKIN3);
            canvas.save();
            P.reset();
            P.addCircle(50.0f, 52.0f, 44.0f, Path.Direction.CW);
            canvas.clipPath(P);
            F.setShader(new LinearGradient(0.0f, 8.0f, 0.0f, 55.0f, -294672129, 7317759, Shader.TileMode.CLAMP));
            canvas.drawRect(0.0f, 0.0f, 100.0f, 100.0f, F);
            F.setShader(null);
            canvas.restore();
        } else {
            head(canvas, SKIN1, SKIN2, SKIN3);
        }
        float fMin = Math.min(blink(f, 1.7f), (blink(f, 0.9f) >= 1.0f || i != 5) ? 1.0f : blink(f, 0.9f));
        switch (i) {
            case 1:
                eyes(canvas, fMin, 0.0f, 0.0f);
                openSmile(canvas, 0.55f + (0.3f * bell(f, 0.1f, 0.6f)), 1.0f, true);
                break;
            case 2:
                happyEyes(canvas, 42.0f, 2.0f * bell(f, 0.1f, 0.6f));
                openSmile(canvas, 0.5f + (0.25f * Math.abs(sn(9.0f * f)) * f3), 1.05f, true);
                cheeks(canvas, 0.6f);
                break;
            case 3:
            case 4:
                xEyes(canvas);
                openSmile(canvas, 0.6f + (0.35f * Math.abs(sn(15.0f * f)) * f3), 1.05f, true);
                for (int i2 = 0; i2 < 5; i2++) {
                    float f4 = ((1.3f * f) + (i2 / 5.0f)) % 1.0f;
                    if (f <= 2.6f - 0.3f || f4 <= 0.9f) {
                        float f5 = 1.0f - f4;
                        float f6 = 22.0f - (26.0f * f4);
                        float f7 = 78.0f + (26.0f * f4);
                        float f8 = (44.0f - (14.0f * f4)) + (f4 * f4 * 40.0f);
                        if (f > 2.6f) {
                            drop(canvas, 20.0f, 52.0f, 5.0f, -11553025);
                            drop(canvas, 80.0f, 52.0f, 5.0f, -11553025);
                        } else {
                            F.setAlpha(255);
                            canvas.save();
                            canvas.translate(f6, f8);
                            canvas.rotate((-50.0f) + (60.0f * f4));
                            drop(canvas, 0.0f, 0.0f, 6.0f * (0.6f + (0.5f * f5)), -11553025);
                            canvas.restore();
                            canvas.save();
                            canvas.translate(f7, f8);
                            canvas.rotate(50.0f - (f4 * 60.0f));
                            drop(canvas, 0.0f, 0.0f, ((f5 * 0.5f) + 0.6f) * 6.0f, -11553025);
                            canvas.restore();
                        }
                        break;
                    }
                }
                drop(canvas, 20.0f, 52.0f, 5.0f, -11553025);
                drop(canvas, 80.0f, 52.0f, 5.0f, -11553025);
                break;
            case 5:
                closedEyes(canvas, 44.0f);
                cheeks(canvas, 0.5f + (0.5f * eo(seg(f, 0.1f, 0.8f))));
                smile(canvas, 66.0f, 15.0f, 12.0f + (3.0f * bell(f, 0.1f, 0.8f)), 4.0f);
                break;
            case 6:
                float fExp = 1.0f + (0.28f * ((float) (Math.exp(-Math.pow(((f % 0.9f) - 0.08f) / 0.07f, 2.0d)) + (0.7d * Math.exp(-Math.pow(((f % 0.9f) - 0.3f) / 0.07f, 2.0d))))) * f3);
                canvas.save();
                canvas.scale(fExp, fExp, 31.0f, 44.0f);
                heart(canvas, 31.0f, 46.0f, 22.0f, -53683);
                canvas.restore();
                canvas.save();
                canvas.scale(fExp, fExp, 69.0f, 44.0f);
                heart(canvas, 69.0f, 46.0f, 22.0f, -53683);
                canvas.restore();
                fill(-1426063361);
                canvas.drawCircle(26.0f, 40.0f, 2.2f, F);
                canvas.drawCircle(64.0f, 40.0f, 2.2f, F);
                openSmile(canvas, 0.45f, 0.95f, true);
                for (int i3 = 0; i3 < 5 && f < 2.6f; i3++) {
                    float fSeg2 = seg(f, 0.2f + (i3 * 0.35f), 1.4f + (i3 * 0.35f));
                    if (fSeg2 > 0.0f && fSeg2 < 1.0f) {
                        F.setAlpha(255);
                        canvas.save();
                        canvas.translate(50.0f + ((rnd(i3) - 0.5f) * 80.0f) + (sn((8.0f * fSeg2) + i3) * 4.0f), 30.0f - (40.0f * fSeg2));
                        canvas.scale(0.4f + (0.4f * fSeg2), 0.4f + (0.4f * fSeg2));
                        heart(canvas, 0.0f, 0.0f, 16.0f, a(-41862, 1.0f - fSeg2));
                        canvas.restore();
                    }
                }
                break;
            case KISS /* 7 */:
                eyes(canvas, 1.0f, 0.0f, 0.0f);
                stroke(INK, 3.6f);
                P.reset();
                P.moveTo(61.0f, 44.0f);
                P.quadTo(69.0f, 38.0f + (4.0f * bell(f, 0.2f, 1.1f)), 77.0f, 44.0f);
                canvas.drawPath(P, S);
                canvas.save();
                canvas.translate(0.0f, 0.0f);
                float fBell5 = bell(f, 0.15f, 1.1f);
                stroke(MOUTH, 4.2f);
                P.reset();
                P.moveTo(48.0f, 62.0f);
                P.quadTo(57.0f + (3.0f * fBell5), 64.0f, 50.0f, 69.0f);
                P.quadTo((fBell5 * 3.0f) + 57.0f, 73.0f, 48.0f, 76.0f);
                canvas.drawPath(P, S);
                canvas.restore();
                cheeks(canvas, 0.7f);
                float fSeg3 = seg(f, 0.55f, 2.0f);
                if (fSeg3 > 0.0f && fSeg3 < 1.0f) {
                    heart(canvas, 60.0f + (34.0f * fSeg3), (70.0f - (30.0f * fSeg3)) + (sn(10.0f * fSeg3) * 3.0f), 8.0f + (14.0f * eo(fSeg3)), a(-53683, 1.0f - seg(fSeg3, 0.7f, 1.0f)));
                }
                break;
            case COOL /* 8 */:
                fill(-14801872);
                P.reset();
                P.moveTo(16.0f, 36.0f);
                P.lineTo(84.0f, 36.0f);
                P.lineTo(82.0f, 41.0f);
                P.cubicTo(80.0f, 56.0f, 60.0f, 58.0f, 56.0f, 46.0f);
                P.lineTo(44.0f, 46.0f);
                P.cubicTo(40.0f, 58.0f, 20.0f, 56.0f, 18.0f, 41.0f);
                P.close();
                canvas.drawPath(P, F);
                canvas.save();
                canvas.clipPath(P);
                float fSeg4 = (-30.0f) + (160.0f * seg(f % 2.6f, 0.3f, 1.0f));
                F.setShader(new LinearGradient(fSeg4 - 10.0f, 30.0f, fSeg4 + 10.0f, 60.0f, new int[]{16777215, -1711276033, 16777215}, (float[]) null, Shader.TileMode.CLAMP));
                canvas.drawRect(0.0f, 0.0f, 100.0f, 100.0f, F);
                F.setShader(null);
                canvas.restore();
                smile(canvas, 68.0f, 14.0f, 7.0f + (3.0f * bell(f, 0.2f, 1.2f)), 4.0f);
                break;
            case THINK /* 9 */:
                eyes(canvas, fMin, 2.0f, -1.0f);
                stroke(INK, 3.4f);
                canvas.save();
                canvas.rotate(-10.0f, 69.0f, 33.0f);
                canvas.drawLine(61.0f, 31.0f - (3.0f * bell(f, 0.4f, 1.8f)), 77.0f, 33.0f - (3.0f * bell(f, 0.4f, 1.8f)), S);
                canvas.restore();
                stroke(INK, 3.4f);
                canvas.drawLine(24.0f, 35.0f, 38.0f, 34.0f, S);
                stroke(MOUTH, 4.0f);
                canvas.drawLine(40.0f, 70.0f, 58.0f, 67.0f, S);
                float fEo = eo(seg(f, 0.1f, 0.5f));
                canvas.save();
                canvas.translate(0.0f, (1.0f - fEo) * 18.0f);
                fill(-13492);
                R.set(30.0f, 76.0f, 58.0f, 92.0f);
                canvas.drawRoundRect(R, 8.0f, 8.0f, F);
                stroke(1721783818, 1.4f);
                canvas.drawRoundRect(R, 8.0f, 8.0f, S);
                fill(-13492);
                P.reset();
                P.moveTo(50.0f, 78.0f);
                P.lineTo(62.0f, 62.0f + (sn(6.0f * f) * 1.5f));
                P.lineTo(67.0f, 65.0f);
                P.lineTo(57.0f, 82.0f);
                P.close();
                canvas.drawPath(P, F);
                canvas.restore();
                break;
            case SMIRK /* 10 */:
                eyes(canvas, 0.55f, 4.0f, 1.0f);
                brows(canvas, 0.0f, 33.0f - (3.0f * bell(f, 0.2f, 1.6f)), INK);
                stroke(MOUTH, 4.0f);
                P.reset();
                P.moveTo(40.0f, 69.0f);
                P.quadTo(56.0f, 72.0f, 66.0f, 61.0f - (2.0f * bell(f, 0.2f, 1.6f)));
                canvas.drawPath(P, S);
                break;
            case SLEEP /* 11 */:
                closedEyes(canvas, 46.0f);
                float fSn4 = 0.5f + (0.5f * sn(2.4f * f));
                fill(MOUTH);
                R.set(46.0f - (2.0f * fSn4), 68.0f, 54.0f + (2.0f * fSn4), (fSn4 * 3.0f) + 74.0f);
                canvas.drawOval(R, F);
                float f9 = (f % 2.4f) / 2.4f;
                F.setShader(new RadialGradient(58.0f, 64.0f, 4.0f + (8.0f * f9), 1435555839, -859838209, Shader.TileMode.CLAMP));
                canvas.drawCircle(60.0f, 62.0f, 3.0f + (8.0f * f9), F);
                F.setShader(null);
                stroke(-1426063361, 1.2f);
                canvas.drawArc(new RectF(56.0f, 58.0f - (4.0f * f9), 62.0f + (4.0f * f9), 64.0f), 200.0f, 60.0f, false, S);
                zzz(canvas, f, 74.0f, 22.0f);
                break;
            case SOB /* 12 */:
                stroke(INK, 4.0f);
                P.reset();
                P.moveTo(22.0f, 46.0f);
                P.quadTo(30.0f, 38.0f, 38.0f, 44.0f);
                canvas.drawPath(P, S);
                P.reset();
                P.moveTo(78.0f, 46.0f);
                P.quadTo(70.0f, 38.0f, 62.0f, 44.0f);
                canvas.drawPath(P, S);
                float fEo2 = eo(seg(f, 0.05f, 0.5f));
                int i4 = -1;
                while (true) {
                    int i5 = i4;
                    if (i5 > 1) {
                        float fAbs3 = 0.7f + (0.3f * Math.abs(sn(8.0f * f)));
                        P.reset();
                        P.moveTo(36.0f, 72.0f);
                        P.cubicTo(38.0f, 60.0f - (6.0f * fAbs3), 62.0f, 60.0f - (fAbs3 * 6.0f), 64.0f, 72.0f);
                        P.quadTo(50.0f, 76.0f, 36.0f, 72.0f);
                        P.close();
                        fill(MOUTH);
                        canvas.drawPath(P, F);
                        canvas.save();
                        canvas.clipPath(P);
                        fill(TONGUE);
                        R.set(42.0f, 66.0f, 58.0f, 78.0f);
                        canvas.drawOval(R, F);
                        canvas.restore();
                    } else {
                        float f10 = (i5 * PLEAD) + 50;
                        canvas.save();
                        P.reset();
                        P.addCircle(50.0f, 52.0f, 44.0f, Path.Direction.CW);
                        canvas.clipPath(P);
                        F.setShader(new LinearGradient(0.0f, 46.0f, 0.0f, 100.0f, -295254273, -868377616, Shader.TileMode.CLAMP));
                        P.reset();
                        P.moveTo(f10 - 5.0f, 47.0f);
                        P.lineTo(5.0f + f10, 47.0f);
                        for (int i6 = 0; i6 <= SMIRK; i6++) {
                            P.lineTo(5.0f + f10 + (sn((12.0f * f) + i6) * 1.2f), 47.0f + (i6 * 5.5f * fEo2));
                        }
                        for (int i7 = SMIRK; i7 >= 0; i7--) {
                            P.lineTo((f10 - 5.0f) + (sn((12.0f * f) + i7 + 2.0f) * 1.2f), 47.0f + (i7 * 5.5f * fEo2));
                        }
                        P.close();
                        canvas.drawPath(P, F);
                        F.setShader(null);
                        stroke(-1996488705, 1.6f);
                        int i8 = 0;
                        while (true) {
                            int i9 = i8;
                            if (i9 < 3) {
                                float f11 = 50.0f + ((((40.0f * f) + (i9 * HUG)) % 48.0f) * fEo2);
                                canvas.drawLine(f10 - 2.0f, f11, f10 - 2.0f, f11 + 4.0f, S);
                                i8 = i9 + 1;
                            } else {
                                break; // jadx 丢掉的循环出口
                            }
                        }
                        canvas.restore();
                        i4 = i5 + 2;
                    }
                    break;
                }
                break;
            case RAGE /* 13 */:
                brows(canvas, 22.0f, 33.0f, -12969464);
                fill(INK);
                R.set(27.0f, 41.0f, 36.0f, 50.0f);
                canvas.drawOval(R, F);
                R.set(64.0f, 41.0f, 73.0f, 50.0f);
                canvas.drawOval(R, F);
                fill(MOUTH);
                R.set(34.0f, 64.0f, 66.0f, 76.0f);
                canvas.drawRoundRect(R, 5.0f, 5.0f, F);
                fill(-1);
                R.set(36.0f, 66.0f, 64.0f, 74.0f);
                canvas.drawRoundRect(R, 3.0f, 3.0f, F);
                stroke(-5201776, 1.0f);
                int i10 = 1;
                while (true) {
                    int i11 = i10;
                    if (i11 >= 5) {
                        canvas.drawLine(36.0f, 70.0f, 64.0f, 70.0f, S);
                        float fBell6 = bell(f, 0.5f, 1.1f) + bell(f, 1.3f, 1.9f);
                        if (fBell6 > 0.0f) {
                            stroke(-1563874, 3.0f);
                            canvas.save();
                            canvas.translate(78.0f, 20.0f);
                            canvas.scale(0.6f + (0.5f * fBell6), (fBell6 * 0.5f) + 0.6f);
                            canvas.drawLine(-6.0f, -2.0f, -2.0f, -2.0f, S);
                            canvas.drawLine(-2.0f, -6.0f, -2.0f, -2.0f, S);
                            canvas.drawLine(2.0f, -6.0f, 2.0f, -2.0f, S);
                            canvas.drawLine(2.0f, -2.0f, 6.0f, -2.0f, S);
                            canvas.drawLine(-6.0f, 2.0f, -2.0f, 2.0f, S);
                            canvas.drawLine(-2.0f, 2.0f, -2.0f, 6.0f, S);
                            canvas.drawLine(2.0f, 2.0f, 2.0f, 6.0f, S);
                            canvas.drawLine(2.0f, 2.0f, 6.0f, 2.0f, S);
                            canvas.restore();
                        }
                    } else {
                        canvas.drawLine((i11 * 5.6f) + 36.0f, 66.0f, (i11 * 5.6f) + 36.0f, 74.0f, S);
                        i10 = i11 + 1;
                    }
                    break;
                }
                break;
            case SCREAM /* 14 */:
                fill(-1);
                R.set(22.0f, 32.0f, 40.0f, 54.0f);
                canvas.drawOval(R, F);
                R.set(60.0f, 32.0f, 78.0f, 54.0f);
                canvas.drawOval(R, F);
                fill(INK);
                float fBell7 = 2.2f + (1.2f * bell(f, 0.05f, 0.4f));
                canvas.drawCircle(31.0f, 43.0f, fBell7, F);
                canvas.drawCircle(69.0f, 43.0f, fBell7, F);
                float fBell8 = 0.6f + (0.4f * bell(f, 0.05f, 0.5f));
                fill(MOUTH);
                R.set(42.0f, 62.0f, 58.0f, (fBell8 * 22.0f) + 62.0f);
                canvas.drawOval(R, F);
                float fEo3 = eo(seg(f, 0.15f, 0.5f));
                fill(-13492);
                canvas.save();
                canvas.translate((-14.0f) * (1.0f - fEo3), 0.0f);
                R.set(4.0f, 50.0f, 22.0f, 84.0f);
                canvas.drawRoundRect(R, 9.0f, 9.0f, F);
                canvas.restore();
                canvas.save();
                canvas.translate((1.0f - fEo3) * 14.0f, 0.0f);
                R.set(78.0f, 50.0f, 96.0f, 84.0f);
                canvas.drawRoundRect(R, 9.0f, 9.0f, F);
                canvas.restore();
                break;
            case PARTY /* 15 */:
                happyEyes(canvas, 44.0f, 0.0f);
                cheeks(canvas, 0.6f);
                float fEo4 = eo(seg(f, 0.3f, 0.7f)) * (1.0f - eio(seg(f, 1.8f, 2.3f)));
                stroke(-13730305, 5.0f);
                P.reset();
                P.moveTo(56.0f, 70.0f);
                if (fEo4 > 0.05f) {
                    P.quadTo(56.0f + (18.0f * fEo4), 74.0f, 58.0f + (32.0f * fEo4), 66.0f - (fEo4 * 4.0f));
                    canvas.drawPath(P, S);
                }
                fill(-45715);
                R.set(44.0f, 64.0f, 58.0f, 76.0f);
                canvas.drawOval(R, F);
                P.reset();
                P.moveTo(30.0f, 18.0f);
                P.lineTo(60.0f, 25.0f);
                P.lineTo(38.0f, -6.0f);
                P.close();
                canvas.save();
                canvas.rotate(-18.0f, 46.0f, 20.0f);
                F.setShader(new LinearGradient(30.0f, 0.0f, 62.0f, 20.0f, -6591489, -11563777, Shader.TileMode.CLAMP));
                canvas.drawPath(P, F);
                F.setShader(null);
                stroke(-10163, 3.0f);
                canvas.drawLine(33.0f, 12.0f, 54.0f, 17.0f, S);
                canvas.drawLine(35.0f, 3.0f, 49.0f, 6.0f, S);
                fill(-45715);
                canvas.drawCircle(38.0f, -6.0f, 4.5f, F);
                canvas.restore();
                confetti(canvas, f, 50.0f, 30.0f, SWEAT);
                break;
            case HUG /* 16 */:
                happyEyes(canvas, 42.0f, 1.0f);
                cheeks(canvas, 0.8f);
                smile(canvas, 62.0f, 14.0f, 10.0f, 4.0f);
                float fEo5 = eo(seg(f, 0.2f, 0.6f)) * (1.0f - (eio(seg(f, 2.0f, 2.5f)) * 0.6f));
                fill(-13492);
                stroke(1721783818, 1.4f);
                canvas.save();
                canvas.translate((-12.0f) * (1.0f - fEo5), 4.0f * (1.0f - fEo5));
                canvas.rotate((-20.0f) * (1.0f - fEo5), 20.0f, 82.0f);
                R.set(6.0f, 72.0f, 36.0f, 92.0f);
                canvas.drawRoundRect(R, 10.0f, 10.0f, F);
                canvas.drawRoundRect(R, 10.0f, 10.0f, S);
                canvas.restore();
                canvas.save();
                canvas.translate(12.0f * (1.0f - fEo5), 4.0f * (1.0f - fEo5));
                canvas.rotate((1.0f - fEo5) * 20.0f, 80.0f, 82.0f);
                R.set(64.0f, 72.0f, 94.0f, 92.0f);
                canvas.drawRoundRect(R, 10.0f, 10.0f, F);
                canvas.drawRoundRect(R, 10.0f, 10.0f, S);
                canvas.restore();
                break;
            case ROLL /* 17 */:
                fill(-1);
                R.set(22.0f, 34.0f, 40.0f, 54.0f);
                canvas.drawOval(R, F);
                R.set(60.0f, 34.0f, 78.0f, 54.0f);
                canvas.drawOval(R, F);
                float fEio = (float) (4.71238898038469d + (6.283185307179586d * ((double) eio(seg(f, 0.3f, 1.3f)))));
                float fCs = cs(fEio) * 4.0f;
                float fSn5 = sn(fEio) * 5.0f;
                if (f > 1.3f) {
                    fCs = 0.0f;
                    fSn5 = -5.0f;
                }
                fill(INK);
                canvas.drawCircle(31.0f + fCs, 44.0f + fSn5, 3.6f, F);
                canvas.drawCircle(fCs + 69.0f, fSn5 + 44.0f, 3.6f, F);
                stroke(MOUTH, 4.0f);
                canvas.drawLine(40.0f, 70.0f, 60.0f, 70.0f, S);
                break;
            case SWEAT /* 18 */:
                happyEyes(canvas, 44.0f, 0.0f);
                openSmile(canvas, 0.55f, 1.0f, true);
                drop(canvas, 80.0f, (eio(seg(f % 2.6f, 0.2f, 2.0f)) * 26.0f) + 16.0f, 8.5f, -11553025);
                break;
            case HALO /* 19 */:
                closedEyes(canvas, 44.0f);
                cheeks(canvas, 0.5f);
                smile(canvas, 64.0f, 15.0f, 11.0f, 4.0f);
                float fSn6 = (-2.0f) + (sn(3.0f * f) * 2.5f);
                S.setShader(null);
                S.setColor(1442837408);
                S.setStrokeWidth(9.0f);
                R.set(22.0f, fSn6 - 6.0f, 78.0f, fSn6 + 8.0f);
                canvas.drawOval(R, S);
                S.setColor(-10163);
                S.setStrokeWidth(4.0f);
                canvas.drawOval(R, S);
                break;
            case PLEAD /* 20 */:
                fill(INK);
                R.set(21.0f, 34.0f, 41.0f, 56.0f);
                canvas.drawOval(R, F);
                R.set(59.0f, 34.0f, 79.0f, 56.0f);
                canvas.drawOval(R, F);
                fill(-1);
                canvas.drawCircle(34.0f, 41.0f, 4.2f, F);
                canvas.drawCircle(72.0f, 41.0f, 4.2f, F);
                canvas.drawCircle(27.0f, 50.0f, 2.0f, F);
                canvas.drawCircle(65.0f, 50.0f, 2.0f, F);
                float fEo6 = eo(seg(f, 0.4f, 1.4f));
                if (fEo6 > 0.0f) {
                    F.setShader(new LinearGradient(0.0f, 50.0f, 0.0f, 58.0f, 6735615, -865679617, Shader.TileMode.CLAMP));
                    R.set(21.0f, 50.0f, 41.0f, 50.0f + (7.0f * fEo6));
                    canvas.drawOval(R, F);
                    R.set(59.0f, 50.0f, 79.0f, 50.0f + (7.0f * fEo6));
                    canvas.drawOval(R, F);
                    F.setShader(null);
                }
                brows(canvas, -14.0f, 30.0f, INK);
                stroke(MOUTH, 3.6f);
                P.reset();
                P.moveTo(42.0f, 72.0f);
                int i12 = 1;
                while (true) {
                    int i13 = i12;
                    if (i13 > 4) {
                        canvas.drawPath(P, S);
                    } else {
                        P.lineTo((i13 * 4) + HUNDRED, (i13 % 2 == 0 ? 0.0f : -2.5f) + 70.0f + (sn((40.0f * f) + i13) * 0.8f));
                        i12 = i13 + 1;
                    }
                    break;
                }
                break;
            case STEAM /* 21 */:
                brows(canvas, 18.0f, 34.0f, INK);
                closedEyes(canvas, 44.0f);
                stroke(MOUTH, 4.0f);
                canvas.drawLine(42.0f, 72.0f, 58.0f, 72.0f, S);
                int i14 = -1;
                while (true) {
                    int i15 = i14;
                    if (i15 <= 1) {
                        for (int i16 = 0; i16 < 2; i16++) {
                            float fSeg5 = seg(f, 0.2f + (i16 * 0.9f), 0.9f + (i16 * 0.9f));
                            if (fSeg5 > 0.0f && fSeg5 < 1.0f) {
                                float f12 = 50.0f + (i15 * (10.0f + (26.0f * fSeg5)));
                                float f13 = 66.0f + (8.0f * fSeg5);
                                float f14 = 5.0f + (7.0f * fSeg5);
                                fill(a(-4603185, 0.9f * (1.0f - fSeg5)));
                                canvas.drawCircle(f12, 1.0f + f13, f14, F);
                                canvas.drawCircle((i15 * f14 * 0.8f) + f12, f13 - 1.0f, 0.7f * f14, F);
                                fill(a(-723207, 1.0f - fSeg5));
                                canvas.drawCircle(f12, f13, 0.9f * f14, F);
                                canvas.drawCircle((i15 * f14 * 0.8f) + f12, f13 - 2.0f, 0.62f * f14, F);
                            }
                        }
                        i14 = i15 + 2;
                    }
                    break;
                }
                break;
            case DROOL /* 22 */:
                closedEyes(canvas, 44.0f);
                smile(canvas, 64.0f, 14.0f, 10.0f, 4.0f);
                float f15 = (f % 2.6f) / 2.6f;
                float fEio2 = 6.0f + (20.0f * eio(seg(f15, 0.0f, 0.7f)));
                F.setShader(new LinearGradient(0.0f, 68.0f, 0.0f, 68.0f + fEio2, -292628225, -11553025, Shader.TileMode.CLAMP));
                P.reset();
                P.moveTo(60.0f, 68.0f);
                P.quadTo(63.0f, 68.0f + (0.6f * fEio2), 61.0f, 68.0f + fEio2);
                P.quadTo(58.0f, 68.0f + (0.6f * fEio2), 57.0f, 68.0f);
                P.close();
                canvas.drawPath(P, F);
                F.setShader(null);
                if (f15 > 0.7f) {
                    drop(canvas, 61.0f, 68.0f + fEio2 + ((f15 - 0.7f) * 60.0f), 3.6f, -11553025);
                }
                break;
            case YUM /* 23 */:
                happyEyes(canvas, 44.0f, 0.0f);
                cheeks(canvas, 0.6f);
                smile(canvas, 64.0f, 15.0f, 11.0f, 4.0f);
                float fBell9 = bell(f, 0.2f, 1.8f);
                float fSn7 = 50.0f + (9.0f * sn(((double) seg(f, 0.2f, 1.8f)) * 3.141592653589793d * 2.0d));
                fill(TONGUE);
                R.set(fSn7 - 7.0f, 66.0f, 7.0f + fSn7, 72.0f + (10.0f * fBell9));
                canvas.drawRoundRect(R, 7.0f, 7.0f, F);
                stroke(-2078648, 1.4f);
                canvas.drawLine(fSn7, 70.0f, fSn7, 74.0f + (fBell9 * 8.0f), S);
                break;
            case STARS /* 24 */:
                float fAbs4 = 12.5f + (3.5f * Math.abs(sn(6.0f * f)) * f3);
                float f16 = 120.0f * f * f3;
                star(canvas, 31.0f, 44.0f, fAbs4, f16, -16121);
                star(canvas, 69.0f, 44.0f, fAbs4, -f16, -16121);
                star(canvas, 31.0f, 44.0f, fAbs4 * 0.5f, f16, -2659);
                star(canvas, 69.0f, 44.0f, fAbs4 * 0.5f, -f16, -2659);
                openSmile(canvas, 0.65f, 1.05f, true);
                sparkles(canvas, f, 6);
                break;
        }
        canvas.restore();
    }

    static void fill(int i) {
        F.setShader(null);
        F.setColor(i);
    }

    static void flame(Canvas canvas, float f, float f2, int i, int i2, float f3, float f4) {
        float f5 = 34.0f * f2;
        float f6 = 78.0f * f2;
        float f7 = 92.0f - f3;
        float fSn = sn(9.0f * f) * 5.0f * f4 * f2;
        float fSn2 = sn((13.0f * f) + 1.0f) * 4.0f * f4 * f2;
        float fSn3 = sn(7.0f * f) * 7.0f * f4 * f2;
        Path path = new Path();
        path.moveTo(50.0f, f7);
        path.cubicTo((50.0f - f5) - fSn2, f7 - 4.0f, (50.0f - (0.9f * f5)) + fSn, f7 - (0.55f * f6), (50.0f - (0.25f * f5)) + fSn, f7 - (0.72f * f6));
        path.cubicTo(50.0f - (0.2f * f5), f7 - (0.55f * f6), 50.0f - (0.05f * f5), f7 - (0.62f * f6), 50.0f + fSn3, f7 - f6);
        path.cubicTo((0.55f * f5) + 50.0f + fSn2, f7 - (0.7f * f6), ((0.95f * f5) + 50.0f) - fSn, f7 - (0.45f * f6), (0.85f * f5) + 50.0f, f7 - (0.22f * f6));
        path.cubicTo((0.8f * f5) + 50.0f, f7 - 4.0f, (0.3f * f5) + 50.0f, f7, 50.0f, f7);
        path.close();
        F.setShader(new LinearGradient(0.0f, f7 - f6, 0.0f, f7, i2, i, Shader.TileMode.CLAMP));
        F.setShader(new LinearGradient(0.0f, f7, 0.0f, f7 - f6, i, i2, Shader.TileMode.CLAMP));
        canvas.drawPath(path, F);
        F.setShader(null);
    }

    static void happyEyes(Canvas canvas, float f, float f2) {
        stroke(INK, 4.4f);
        P.reset();
        P.moveTo(23.0f, f + 4.0f);
        P.quadTo(31.0f, (f - 6.0f) - f2, 39.0f, f + 4.0f);
        canvas.drawPath(P, S);
        P.reset();
        P.moveTo(61.0f, f + 4.0f);
        P.quadTo(69.0f, (f - 6.0f) - f2, 77.0f, f + 4.0f);
        canvas.drawPath(P, S);
    }

    static void happyEyesAt(Canvas canvas, float f, float f2, float f3) {
        stroke(INK, 3.2f);
        P.reset();
        P.moveTo(f - ((14.0f * f3) * 1.4f), f2 + 2.0f);
        P.quadTo(f - ((9.0f * f3) * 1.4f), f2 - 5.0f, f - ((4.0f * f3) * 1.4f), f2 + 2.0f);
        canvas.drawPath(P, S);
        P.reset();
        P.moveTo((4.0f * f3 * 1.4f) + f, f2 + 2.0f);
        P.quadTo((9.0f * f3 * 1.4f) + f, f2 - 5.0f, (14.0f * f3 * 1.4f) + f, f2 + 2.0f);
        canvas.drawPath(P, S);
    }

    static boolean has(String str) {
        return ID.containsKey(Emo.strip(str));
    }

    static void head(Canvas canvas, int i, int i2, int i3) {
        F.setShader(new RadialGradient(50.0f, 52.0f, 46.0f, new int[]{i, i2, i3}, new float[]{0.0f, 0.62f, 1.0f}, Shader.TileMode.CLAMP));
        F.setShader(new RadialGradient(42.0f, 36.0f, 58.0f, new int[]{i, i2, i3}, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(50.0f, 52.0f, 44.0f, F);
        F.setShader(null);
        stroke(866145802, 1.2f);
        canvas.drawCircle(50.0f, 52.0f, 43.6f, S);
        fill(1442840575);
        R.set(22.0f, 18.0f, 52.0f, 34.0f);
        canvas.save();
        canvas.rotate(-24.0f, 37.0f, 26.0f);
        canvas.drawOval(R, F);
        canvas.restore();
    }

    static void heart(Canvas canvas, float f, float f2, float f3, int i) {
        P.reset();
        P.moveTo(f, (0.35f * f3) + f2);
        P.cubicTo(f - (0.1f * f3), f2 - (0.05f * f3), f - (0.55f * f3), f2 - (0.05f * f3), f - (0.5f * f3), f2 - (0.32f * f3));
        P.cubicTo(f - (0.45f * f3), f2 - (0.62f * f3), f - (0.08f * f3), f2 - (0.62f * f3), f, f2 - (0.32f * f3));
        P.cubicTo((0.08f * f3) + f, f2 - (0.62f * f3), (0.45f * f3) + f, f2 - (0.62f * f3), (0.5f * f3) + f, f2 - (0.32f * f3));
        P.cubicTo((0.55f * f3) + f, f2 - (0.05f * f3), (0.1f * f3) + f, f2 - (0.05f * f3), f, f2 + (0.35f * f3));
        P.close();
        fill(i);
        canvas.drawPath(P, F);
    }

    static void m(int i, String str) {
        for (String str2 : str.split(" ")) {
            ID.put(Emo.strip(str2), Integer.valueOf(i));
        }
    }

    static void megaphone(Canvas canvas, float f) {
        float f2 = f % 2.2f;
        float fAbs = f2 < 0.7f ? Math.abs(sn(22.0f * f2)) * (1.0f - (f2 / 0.7f)) : 0.0f;
        canvas.save();
        canvas.rotate(((-14.0f) * fAbs) - 8.0f, 40.0f, 60.0f);
        canvas.scale(1.0f + (0.06f * fAbs), (fAbs * 0.06f) + 1.0f, 30.0f, 55.0f);
        Path path = new Path();
        path.moveTo(18.0f, 44.0f);
        path.lineTo(66.0f, 22.0f);
        path.lineTo(66.0f, 82.0f);
        path.lineTo(18.0f, 64.0f);
        path.close();
        F.setShader(new LinearGradient(18.0f, 22.0f, 66.0f, 82.0f, -30107, -2079430, Shader.TileMode.CLAMP));
        canvas.drawPath(path, F);
        F.setShader(null);
        fill(1157627903);
        Path path2 = new Path();
        path2.moveTo(20.0f, 46.0f);
        path2.lineTo(64.0f, 26.0f);
        path2.lineTo(64.0f, 34.0f);
        path2.lineTo(20.0f, 52.0f);
        path2.close();
        canvas.drawPath(path2, F);
        F.setShader(new LinearGradient(60.0f, 20.0f, 76.0f, 84.0f, -15440, -4705750, Shader.TileMode.CLAMP));
        R.set(60.0f, 20.0f, 76.0f, 84.0f);
        canvas.drawOval(R, F);
        F.setShader(null);
        fill(-8774120);
        R.set(64.0f, 28.0f, 73.0f, 76.0f);
        canvas.drawOval(R, F);
        fill(-10788240);
        R.set(10.0f, 46.0f, 22.0f, 62.0f);
        canvas.drawRoundRect(R, 4.0f, 4.0f, F);
        fill(-12696497);
        R.set(30.0f, 62.0f, 40.0f, 82.0f);
        canvas.save();
        canvas.rotate(-10.0f, 35.0f, 62.0f);
        canvas.drawRoundRect(R, 4.0f, 4.0f, F);
        canvas.restore();
        canvas.restore();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 3) {
                return;
            }
            float f3 = (1.4f * f2) - (i2 * 0.18f);
            if (f3 >= 0.0f && f3 <= 1.0f) {
                float f4 = 10.0f + (26.0f * f3);
                stroke(a(-26066, 1.0f - f3), 4.4f);
                R.set(66.0f - f4, (50.0f - f4) - 6.0f, 66.0f + f4, (f4 + 50.0f) - 6.0f);
                canvas.drawArc(R, -40.0f, 70.0f, false, S);
            }
            i = i2 + 1;
        }
    }

    static void openSmile(Canvas canvas, float f, float f2, boolean z) {
        float f3 = 50.0f - (23.0f * f2);
        float f4 = 50.0f + (23.0f * f2);
        float f5 = (18.0f * f) + 71.0f;
        P.reset();
        P.moveTo(f3, 61.0f);
        P.quadTo(50.0f, 1.5f + 61.0f, f4, 61.0f);
        P.cubicTo(f4, f5, f3, f5, f3, 61.0f);
        P.close();
        fill(MOUTH);
        canvas.drawPath(P, F);
        canvas.save();
        canvas.clipPath(P);
        if (z) {
            fill(-1);
            R.set(f3 - 2.0f, 61.0f - 4.0f, f4 + 2.0f, 6.5f + 61.0f);
            canvas.drawRect(R, F);
        }
        fill(TONGUE);
        R.set(50.0f - (12.0f * f2), (f5 - (10.0f * f)) - 6.0f, (12.0f * f2) + 50.0f, f5 + 8.0f);
        canvas.drawOval(R, F);
        canvas.restore();
    }

    static void other(Canvas canvas, int i, float f) {
        float f2 = f < 2.6f ? 1.0f : 0.0f;
        switch (i) {
            case HEART /* 30 */:
                float f3 = f % 1.0f;
                float fExp = 1.0f + (0.2f * ((float) (Math.exp(-Math.pow((f3 - 0.1f) / 0.07f, 2.0d)) + (0.75d * Math.exp(-Math.pow((f3 - 0.34f) / 0.07f, 2.0d))))) * f2);
                float fSeg = seg(f3, 0.08f, 0.7f);
                if (f2 > 0.0f && fSeg > 0.0f && fSeg < 1.0f) {
                    stroke(a(-45715, 0.5f * (1.0f - fSeg)), 2.5f);
                    canvas.drawCircle(50.0f, 50.0f, (fSeg * 22.0f) + 30.0f, S);
                }
                canvas.save();
                canvas.scale(fExp, fExp, 50.0f, 55.0f);
                bigHeart(canvas, -43920, -2091718);
                canvas.restore();
                for (int i2 = 0; i2 < 6 && f < 2.6f; i2++) {
                    float fSeg2 = seg(f, 0.3f + (i2 * 0.3f), 1.5f + (i2 * 0.3f));
                    if (fSeg2 > 0.0f && fSeg2 < 1.0f) {
                        heart(canvas, 50.0f + ((rnd(i2) - 0.5f) * 90.0f) + (sn((9.0f * fSeg2) + i2) * 4.0f), 22.0f - (36.0f * fSeg2), 8.0f + (6.0f * fSeg2), a(-34160, 1.0f - fSeg2));
                    }
                }
                break;
            case BROKEN /* 31 */:
                float fSeg3 = seg(f, 0.35f, 0.75f);
                float fEo = eo(seg(f, 0.75f, 1.3f)) * (1.0f - eio(seg(f, 2.1f, 2.6f)));
                float fSn = f < 0.35f ? sn(70.0f * f) * 1.5f : 0.0f;
                Path path = new Path();
                int i3 = -1;
                while (true) {
                    int i4 = i3;
                    if (i4 <= 1) {
                        canvas.save();
                        canvas.translate((i4 * KISS * fEo) + fSn, 5.0f * fEo);
                        canvas.rotate(i4 * SOB * fEo, 50.0f, 80.0f);
                        path.reset();
                        if (i4 < 0) {
                            path.moveTo(-10.0f, -10.0f);
                            path.lineTo(50.0f, -10.0f);
                        } else {
                            path.moveTo(110.0f, -10.0f);
                            path.lineTo(50.0f, -10.0f);
                        }
                        path.lineTo(50.0f, 28.0f);
                        path.lineTo(44.0f, 42.0f);
                        path.lineTo(56.0f, 54.0f);
                        path.lineTo(46.0f, 66.0f);
                        path.lineTo(52.0f, 78.0f);
                        path.lineTo(50.0f, 110.0f);
                        path.lineTo(i4 < 0 ? -10.0f : 110.0f, 110.0f);
                        path.close();
                        if (fEo > 0.0f) {
                            canvas.clipPath(path);
                        }
                        bigHeart(canvas, -43920, -2091718);
                        canvas.restore();
                        i3 = i4 + 2;
                    } else if (fEo <= 0.0f && fSeg3 > 0.0f) {
                        stroke(-10878958, 2.6f);
                        Path path2 = new Path();
                        path2.moveTo(50.0f, 28.0f);
                        path2.lineTo(44.0f, 42.0f);
                        path2.lineTo(56.0f, 54.0f);
                        path2.lineTo(46.0f, 66.0f);
                        path2.lineTo(52.0f, 78.0f);
                        PathMeasure pathMeasure = new PathMeasure(path2, false);
                        Path path3 = new Path();
                        pathMeasure.getSegment(0.0f, fSeg3 * pathMeasure.getLength(), path3, true);
                        canvas.drawPath(path3, S);
                        break;
                    }
                }
                break;
            case FIRE /* 32 */:
                float f4 = f2 > 0.0f ? 1.0f : 0.3f;
                flame(canvas, f, 1.0f, -49889, -30177, 0.0f, f4);
                flame(canvas, f + 0.3f, 0.74f, -30177, -14020, 4.0f, f4);
                flame(canvas, f + 0.7f, 0.46f, -7558, -1834, 8.0f, f4);
                int i5 = 0;
                while (true) {
                    int i6 = i5;
                    if (i6 < SMIRK && f < 2.6f) {
                        float fRnd = ((0.9f * f) + rnd(i6)) % 1.0f;
                        float fSn2 = (sn((8.0f * fRnd) + i6) * 4.0f) + 50.0f + ((rnd(i6 + 4) - 0.5f) * 40.0f);
                        float f5 = 60.0f - (64.0f * fRnd);
                        fill(a(i6 % 2 == 0 ? -20448 : -38400, 1.0f - fRnd));
                        canvas.drawCircle(fSn2, f5, 1.6f + ((1.0f - fRnd) * 1.4f), F);
                        i5 = i6 + 1;
                    } else {
                        break; // jadx 丢掉的循环出口
                    }
                }
                break;
            case STAR /* 33 */:
                float fEio = eio(seg(f, 0.1f, 0.9f));
                canvas.save();
                canvas.scale(cs(((double) fEio) * 3.141592653589793d * 2.0d), 1.0f, 50.0f, 50.0f);
                float fBell = 1.0f + (0.15f * bell(f, 0.85f, 1.25f));
                canvas.scale(fBell, fBell, 50.0f, 52.0f);
                P.reset();
                int i7 = 0;
                while (true) {
                    int i8 = i7;
                    if (i8 >= SMIRK) {
                        P.close();
                        F.setShader(new LinearGradient(20.0f, 15.0f, 80.0f, 90.0f, SKIN1, -22497, Shader.TileMode.CLAMP));
                        canvas.drawPath(P, F);
                        F.setShader(null);
                        stroke(1437624832, 1.4f);
                        canvas.drawPath(P, S);
                        canvas.save();
                        canvas.clipPath(P);
                        float fSeg4 = (-30.0f) + (160.0f * seg(f, 1.0f, 1.6f));
                        F.setShader(new LinearGradient(fSeg4 - 12.0f, 20.0f, fSeg4 + 12.0f, 80.0f, new int[]{16777215, -855638017, 16777215}, (float[]) null, Shader.TileMode.CLAMP));
                        canvas.drawRect(0.0f, 0.0f, 100.0f, 100.0f, F);
                        F.setShader(null);
                        canvas.restore();
                        canvas.restore();
                        sparkles(canvas, f, KISS);
                    } else {
                        double radians = Math.toRadians((i8 * SUN) - 90);
                        float f6 = i8 % 2 == 0 ? 42.0f : 19.0f;
                        float fCos = 50.0f + (((float) Math.cos(radians)) * f6);
                        float fSin = (f6 * ((float) Math.sin(radians))) + 54.0f;
                        if (i8 == 0) {
                            P.moveTo(fCos, fSin);
                        } else {
                            P.lineTo(fCos, fSin);
                        }
                        i7 = i8 + 1;
                    }
                    break;
                }
                break;
            case CHECK /* 34 */:
            case CROSS /* 35 */:
                boolean z = i == CHECK;
                float fBack = back(seg(f, 0.0f, 0.4f));
                canvas.save();
                canvas.scale(fBack, fBack, 50.0f, 50.0f);
                if (!z) {
                    canvas.rotate(((f <= 0.9f || f >= 1.5f) ? 0 : 1) * 6.0f * sn(30.0f * f), 50.0f, 50.0f);
                }
                F.setShader(new LinearGradient(0.0f, 8.0f, 0.0f, 92.0f, z ? -11870592 : TONGUE, z ? -15293622 : -2024146, Shader.TileMode.CLAMP));
                R.set(8.0f, 8.0f, 92.0f, 92.0f);
                canvas.drawRoundRect(R, 22.0f, 22.0f, F);
                F.setShader(null);
                fill(872415231);
                R.set(14.0f, 12.0f, 86.0f, 44.0f);
                canvas.drawRoundRect(R, 18.0f, 18.0f, F);
                stroke(-1, 11.0f);
                Path path4 = new Path();
                if (z) {
                    path4.moveTo(27.0f, 52.0f);
                    path4.lineTo(43.0f, 68.0f);
                    path4.lineTo(74.0f, 34.0f);
                    drawPart(canvas, path4, eo(seg(f, 0.3f, 0.8f)));
                } else {
                    path4.moveTo(31.0f, 31.0f);
                    path4.lineTo(69.0f, 69.0f);
                    drawPart(canvas, path4, eo(seg(f, 0.3f, 0.6f)));
                    Path path5 = new Path();
                    path5.moveTo(69.0f, 31.0f);
                    path5.lineTo(31.0f, 69.0f);
                    drawPart(canvas, path5, eo(seg(f, 0.55f, 0.85f)));
                }
                canvas.restore();
                if (z) {
                    sparkles(canvas, f, 4);
                }
                break;
            case SUN /* 36 */:
                canvas.save();
                canvas.rotate(40.0f * f, 50.0f, 50.0f);
                for (int i9 = 0; i9 < SOB; i9++) {
                    float fSn3 = 12.0f + (4.0f * sn((5.0f * f) + i9));
                    canvas.save();
                    canvas.rotate(i9 * HEART, 50.0f, 50.0f);
                    fill(-20448);
                    P.reset();
                    P.moveTo(46.0f, 14.0f);
                    P.lineTo(50.0f, (14.0f - (fSn3 * 0.6f)) - 4.0f);
                    P.lineTo(54.0f, 14.0f);
                    P.close();
                    canvas.drawPath(P, F);
                    canvas.restore();
                }
                canvas.restore();
                F.setShader(new RadialGradient(44.0f, 42.0f, 34.0f, new int[]{-3168, -13261, -24804}, (float[]) null, Shader.TileMode.CLAMP));
                canvas.drawCircle(50.0f, 50.0f, 30.0f, F);
                F.setShader(null);
                happyEyesAt(canvas, 50.0f, 46.0f, 0.55f);
                stroke(MOUTH, 2.8f);
                P.reset();
                P.moveTo(42.0f, 57.0f);
                P.quadTo(50.0f, 63.0f + (2.0f * sn(4.0f * f)), 58.0f, 57.0f);
                canvas.drawPath(P, S);
                break;
            case RAIN /* 37 */:
                int i10 = 0;
                while (true) {
                    int i11 = i10;
                    if (i11 >= SOB) {
                        cloud(canvas, 50.0f, 40.0f + (sn(2.5f * f) * 2.0f), 1.0f, -1840654, -4602668);
                    } else {
                        float fRnd2 = ((1.3f * f) + rnd(i11)) % 1.0f;
                        float fRnd3 = (rnd(i11 + HEART) * 48.0f) + 26.0f;
                        float f7 = (38.0f * fRnd2) + 56.0f;
                        stroke(a(-11553025, 1.0f - seg(fRnd2, 0.85f, 1.0f)), 2.4f);
                        canvas.drawLine(fRnd3, f7, fRnd3 - 2.0f, f7 + 6.0f, S);
                        if (fRnd2 > 0.85f) {
                            float fSeg5 = seg(fRnd2, 0.85f, 1.0f);
                            stroke(a(-11553025, 1.0f - fSeg5), 1.6f);
                            R.set(fRnd3 - (6.0f * fSeg5), 94.0f - (2.0f * fSeg5), (fSeg5 * 6.0f) + fRnd3, 96.0f);
                            canvas.drawOval(R, S);
                        }
                        i10 = i11 + 1;
                    }
                    break;
                }
                break;
            case MOON /* 38 */:
                int i12 = 0;
                while (true) {
                    int i13 = i12;
                    if (i13 >= 5) {
                        canvas.save();
                        canvas.rotate((-15.0f) + (sn(2.0f * f) * 8.0f), 50.0f, 50.0f);
                        P.reset();
                        P.addCircle(50.0f, 50.0f, 34.0f, Path.Direction.CW);
                        Path path6 = new Path();
                        path6.addCircle(64.0f, 40.0f, 30.0f, Path.Direction.CW);
                        P.op(path6, Path.Op.DIFFERENCE);
                        F.setShader(new LinearGradient(20.0f, 20.0f, 70.0f, 90.0f, -3936, SKIN2, Shader.TileMode.CLAMP));
                        canvas.drawPath(P, F);
                        F.setShader(null);
                        canvas.restore();
                    } else {
                        float fAbs = 0.4f + (0.6f * Math.abs(sn((3.0f * f) + (i13 * 1.7f))));
                        star(canvas, 14.0f + (rnd(i13) * 72.0f), 10.0f + (rnd(i13 + 5) * 80.0f), (3.0f * fAbs) + 1.0f, 0.0f, a(-3168, fAbs));
                        i12 = i13 + 1;
                    }
                    break;
                }
                break;
            case RAINBOW /* 39 */:
                int[] iArr = {-45747, -24804, -10742, -11870592, -11563777, -6591489};
                float fEio2 = 180.0f * eio(seg(f, 0.1f, 1.1f));
                int i14 = 0;
                while (true) {
                    int i15 = i14;
                    if (i15 >= iArr.length) {
                        S.setStrokeCap(Paint.Cap.ROUND);
                        float fEo2 = eo(seg(f, 0.9f, 1.3f));
                        canvas.save();
                        canvas.scale(fEo2, fEo2, 14.0f, 72.0f);
                        cloud(canvas, 14.0f, 72.0f, 0.38f, -1, -2235154);
                        canvas.restore();
                        canvas.save();
                        canvas.scale(fEo2, fEo2, 86.0f, 72.0f);
                        cloud(canvas, 86.0f, 72.0f, 0.38f, -1, -2235154);
                        canvas.restore();
                    } else {
                        float f8 = 42 - (i15 * 5);
                        stroke(iArr[i15], 5.4f);
                        S.setStrokeCap(Paint.Cap.BUTT);
                        R.set(50.0f - f8, 72.0f - f8, 50.0f + f8, f8 + 72.0f);
                        canvas.drawArc(R, 180.0f, fEio2, false, S);
                        i14 = i15 + 1;
                    }
                    break;
                }
                break;
            case POPPER /* 40 */:
                float fBell2 = bell(f, 0.0f, 0.3f);
                float fSeg6 = seg(f, 0.3f, 0.4f);
                canvas.save();
                canvas.translate(-12.0f, 4.0f);
                canvas.scale(1.35f, 1.35f, 30.0f, 90.0f);
                canvas.rotate((30.0f + (8.0f * fBell2)) - (6.0f * bell(f, 0.3f, 0.55f)), 30.0f, 78.0f);
                canvas.scale(1.0f, 1.0f - (fBell2 * 0.1f), 30.0f, 90.0f);
                P.reset();
                P.moveTo(30.0f, 90.0f);
                P.lineTo(14.0f, 44.0f);
                P.lineTo(46.0f, 44.0f);
                P.close();
                F.setShader(new LinearGradient(14.0f, 44.0f, 46.0f, 90.0f, -16059, -30177, Shader.TileMode.CLAMP));
                canvas.drawPath(P, F);
                F.setShader(null);
                stroke(-2079430, 3.0f);
                canvas.drawLine(20.0f, 58.0f, 40.0f, 58.0f, S);
                canvas.drawLine(24.0f, 72.0f, 36.0f, 72.0f, S);
                canvas.restore();
                if (fSeg6 > 0.0f) {
                    int[] iArr2 = {-45715, -11563777, -12723049, -4883457};
                    int i16 = 0;
                    while (true) {
                        int i17 = i16;
                        if (i17 >= 4) {
                            confetti(canvas, f - 0.25f, 58.0f, 42.0f, HEART);
                        } else {
                            float fEo3 = eo(seg(f, 0.32f + (i17 * 0.05f), 1.2f));
                            stroke(a(iArr2[i17], 1.0f - seg(f, 2.0f, 2.5f)), 3.0f);
                            Path path7 = new Path();
                            path7.moveTo(56.0f, 46.0f);
                            float f9 = (i17 * THINK) + 66;
                            float f10 = (i17 * THINK) + 4;
                            path7.cubicTo(62.0f, (i17 * 4) + HEART, (f9 - 8.0f) + (sn((6.0f * f) + i17) * 4.0f), 14.0f + f10, f9, f10);
                            drawPart(canvas, path7, fEo3);
                            i16 = i17 + 1;
                        }
                    }
                }
                break;
            case ZZZ /* 41 */:
                canvas.save();
                canvas.scale(2.2f, 2.2f, 30.0f, 80.0f);
                zzz(canvas, f, 30.0f, 80.0f);
                canvas.restore();
                break;
            case HUNDRED /* 42 */:
                float fSeg7 = seg(f, 0.0f, 0.35f);
                float fEio3 = (1.8f - (0.8f * eio(fSeg7))) + (0.1f * bell(f, 0.35f, 0.55f));
                canvas.save();
                canvas.rotate(-12.0f, 50.0f, 50.0f);
                canvas.scale(fEio3, fEio3, 50.0f, 50.0f);
                Paint paint = F;
                paint.setShader(null);
                paint.setColor(a(-2024146, fSeg7));
                paint.setTextSize(46.0f);
                paint.setFakeBoldText(true);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSkewX(-0.15f);
                canvas.drawText("100", 50.0f, 60.0f, paint);
                paint.setFakeBoldText(false);
                paint.setTextSkewX(0.0f);
                stroke(-2024146, 4.5f);
                Path path8 = new Path();
                path8.moveTo(16.0f, 70.0f);
                path8.lineTo(84.0f, 70.0f);
                drawPart(canvas, path8, eo(seg(f, 0.45f, 0.75f)));
                Path path9 = new Path();
                path9.moveTo(22.0f, 79.0f);
                path9.lineTo(78.0f, 79.0f);
                drawPart(canvas, path9, eo(seg(f, 0.65f, 0.95f)));
                canvas.restore();
                if (f > 0.35f && f < 0.7f) {
                    float fSeg8 = seg(f, 0.35f, 0.7f);
                    stroke(a(-2024146, 0.5f * (1.0f - fSeg8)), 2.0f);
                    canvas.drawCircle(50.0f, 50.0f, (fSeg8 * 24.0f) + 30.0f, S);
                    break;
                }
                break;
            case MEGA /* 43 */:
                megaphone(canvas, f);
                break;
            case QUESTION /* 44 */:
                float fAbs2 = Math.abs(sn(5.0f * f)) * f2;
                canvas.save();
                canvas.translate(0.0f, (-fAbs2) * 10.0f);
                canvas.rotate(sn(5.0f * f) * 10.0f * f2, 50.0f, 90.0f);
                Paint paint2 = F;
                paint2.setShader(new LinearGradient(0.0f, 10.0f, 0.0f, 90.0f, TONGUE, -2024146, Shader.TileMode.CLAMP));
                paint2.setTextSize(86.0f);
                paint2.setFakeBoldText(true);
                paint2.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("?", 50.0f, 84.0f, paint2);
                paint2.setShader(null);
                paint2.setFakeBoldText(false);
                canvas.restore();
                break;
            case COFFEE /* 45 */:
                int i18 = 0;
                while (true) {
                    int i19 = i18;
                    if (i19 >= 3) {
                        fill(-1);
                        R.set(22.0f, 46.0f, 70.0f, 86.0f);
                        canvas.drawRoundRect(R, 10.0f, 10.0f, F);
                        stroke(-1, 5.0f);
                        R.set(62.0f, 54.0f, 80.0f, 72.0f);
                        canvas.drawArc(R, -90.0f, 180.0f, false, S);
                        stroke(570425344, 1.2f);
                        R.set(22.0f, 46.0f, 70.0f, 86.0f);
                        canvas.drawRoundRect(R, 10.0f, 10.0f, S);
                        fill(-8762838);
                        R.set(25.0f, 47.0f, 67.0f, 54.0f);
                        canvas.drawOval(R, F);
                        fill(-1511949);
                        R.set(14.0f, 84.0f, 78.0f, 92.0f);
                        canvas.drawOval(R, F);
                    } else {
                        float f11 = ((0.6f * f) + (i19 / 3.0f)) % 1.0f;
                        stroke(a(-4669236, (f11 < 0.2f ? f11 / 0.2f : 1.0f - ((f11 - 0.2f) / 0.8f)) * 0.9f), 3.0f);
                        Path path10 = new Path();
                        float f12 = (i19 * SOB) + MOON;
                        path10.moveTo(f12, 40.0f - (14.0f * f11));
                        for (int i20 = 1; i20 <= 6; i20++) {
                            path10.lineTo((sn((i20 * 1.2f) + (4.0f * f) + i19) * 3.0f) + f12, (40.0f - (14.0f * f11)) - (i20 * 4));
                        }
                        canvas.drawPath(path10, S);
                        i18 = i19 + 1;
                    }
                    break;
                }
                break;
            case NOTE /* 46 */:
                int i21 = 0;
                while (true) {
                    int i22 = i21;
                    if (i22 < 2) {
                        float fAbs3 = Math.abs(sn((6.0f * f) + (i22 * 1.6f))) * f2;
                        canvas.save();
                        canvas.translate(i22 * HEART, ((-fAbs3) * 8.0f) + (i22 * 6));
                        canvas.rotate(sn((6.0f * f) + i22) * 10.0f * f2, 35.0f, 80.0f);
                        fill(i22 == 0 ? -11563777 : -4883457);
                        R.set(20.0f, 66.0f, 38.0f, 80.0f);
                        canvas.save();
                        canvas.rotate(-20.0f, 29.0f, 73.0f);
                        canvas.drawOval(R, F);
                        canvas.restore();
                        stroke(i22 == 0 ? -11563777 : -4883457, 4.0f);
                        canvas.drawLine(36.0f, 72.0f, 36.0f, 26.0f, S);
                        canvas.drawLine(36.0f, 26.0f, 48.0f, 34.0f, S);
                        canvas.restore();
                        i21 = i22 + 1;
                    }
                    break;
                }
                break;
            case SPARKLE /* 47 */:
                sparkles(canvas, f % 2.6f, SMIRK);
                star4(canvas, 50.0f, 50.0f, 26.0f * (1.0f + (0.2f * sn(6.0f * f))), -10163);
                star4(canvas, 26.0f, 28.0f, 10.0f * Math.abs(sn(4.0f * f)), -3168);
                star4(canvas, 74.0f, 72.0f, 12.0f * Math.abs(sn((4.0f * f) + 1.0f)), -3168);
                break;
            case GIFT /* 48 */:
                float fSn4 = f < 0.8f ? sn(40.0f * f) * 3.0f * seg(f, 0.0f, 0.2f) : 0.0f;
                float fEo4 = eo(seg(f, 0.8f, 1.1f)) * (1.0f - eio(seg(f, 2.1f, 2.5f)));
                canvas.save();
                canvas.translate(fSn4, 0.0f);
                F.setShader(new LinearGradient(0.0f, 44.0f, 0.0f, 92.0f, -38005, -2091718, Shader.TileMode.CLAMP));
                R.set(16.0f, 46.0f, 84.0f, 92.0f);
                canvas.drawRoundRect(R, 6.0f, 6.0f, F);
                F.setShader(null);
                fill(-10163);
                canvas.drawRect(45.0f, 46.0f, 55.0f, 92.0f, F);
                canvas.save();
                canvas.translate((-6.0f) * fEo4, (-22.0f) * fEo4);
                canvas.rotate((-24.0f) * fEo4, 12.0f, 40.0f);
                F.setShader(new LinearGradient(0.0f, 32.0f, 0.0f, 48.0f, -34155, -1038257, Shader.TileMode.CLAMP));
                R.set(12.0f, 34.0f, 88.0f, 48.0f);
                canvas.drawRoundRect(R, 5.0f, 5.0f, F);
                F.setShader(null);
                fill(-10163);
                canvas.drawRect(45.0f, 34.0f, 55.0f, 48.0f, F);
                stroke(-10163, 5.0f);
                P.reset();
                P.moveTo(50.0f, 34.0f);
                P.cubicTo(36.0f, 18.0f, 30.0f, 30.0f, 50.0f, 34.0f);
                P.cubicTo(70.0f, 30.0f, 64.0f, 18.0f, 50.0f, 34.0f);
                canvas.drawPath(P, S);
                canvas.restore();
                canvas.restore();
                if (fEo4 > 0.5f) {
                    sparkles(canvas, f - 1.0f, COOL);
                }
                break;
        }
    }

    static float rnd(int i) {
        double dSin = Math.sin((((double) i) * 127.1d) + 311.7d) * 43758.5453d;
        return (float) (dSin - Math.floor(dSin));
    }

    static float seg(float f, float f2, float f3) {
        return cl((f - f2) / (f3 - f2));
    }

    static void smile(Canvas canvas, float f, float f2, float f3, float f4) {
        stroke(MOUTH, f4);
        P.reset();
        P.moveTo(50.0f - f2, f);
        P.quadTo(50.0f, f + f3, 50.0f + f2, f);
        canvas.drawPath(P, S);
    }

    static float sn(double d) {
        return (float) Math.sin(d);
    }

    static void sparkles(Canvas canvas, float f, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            float fRnd = rnd(i2 + PLEAD) * 1.8f;
            float fSeg = seg(f, fRnd, fRnd + 0.5f);
            if (fSeg > 0.0f && fSeg < 1.0f) {
                float fRnd2 = ((rnd(i2) - 0.5f) * 100.0f) + 50.0f;
                float fRnd3 = ((rnd(i2 + KISS) - 0.5f) * 100.0f) + 50.0f;
                float fSn = sn(3.141592653589793d * ((double) fSeg)) * 5.0f;
                fill(-3168);
                P.reset();
                P.moveTo(fRnd2, fRnd3 - (fSn * 1.8f));
                P.quadTo(fRnd2, fRnd3, (fSn * 1.8f) + fRnd2, fRnd3);
                P.quadTo(fRnd2, fRnd3, fRnd2, (fSn * 1.8f) + fRnd3);
                P.quadTo(fRnd2, fRnd3, fRnd2 - (fSn * 1.8f), fRnd3);
                P.quadTo(fRnd2, fRnd3, fRnd2, fRnd3 - (fSn * 1.8f));
                P.close();
                canvas.drawPath(P, F);
            }
        }
    }

    static void star(Canvas canvas, float f, float f2, float f3, float f4, int i) {
        P.reset();
        int i2 = 0;
        while (true) {
            int i3 = i2;
            if (i3 >= SMIRK) {
                P.close();
                fill(i);
                canvas.drawPath(P, F);
                return;
            }
            double radians = Math.toRadians((f4 - 90.0f) + (i3 * SUN));
            float f5 = i3 % 2 == 0 ? f3 : 0.45f * f3;
            float fCos = (((float) Math.cos(radians)) * f5) + f;
            float fSin = (f5 * ((float) Math.sin(radians))) + f2;
            if (i3 == 0) {
                P.moveTo(fCos, fSin);
            } else {
                P.lineTo(fCos, fSin);
            }
            i2 = i3 + 1;
        }
    }

    static void star4(Canvas canvas, float f, float f2, float f3, int i) {
        fill(i);
        P.reset();
        P.moveTo(f, f2 - f3);
        P.quadTo(f, f2, f + f3, f2);
        P.quadTo(f, f2, f, f2 + f3);
        P.quadTo(f, f2, f - f3, f2);
        P.quadTo(f, f2, f, f2 - f3);
        P.close();
        canvas.drawPath(P, F);
    }

    static void stroke(int i, float f) {
        S.setShader(null);
        S.setColor(i);
        S.setStrokeWidth(f);
    }

    static void xEyes(Canvas canvas) {
        stroke(INK, 4.4f);
        P.reset();
        P.moveTo(22.0f, 36.0f);
        P.lineTo(36.0f, 43.0f);
        P.lineTo(22.0f, 49.0f);
        canvas.drawPath(P, S);
        P.reset();
        P.moveTo(78.0f, 36.0f);
        P.lineTo(64.0f, 43.0f);
        P.lineTo(78.0f, 49.0f);
        canvas.drawPath(P, S);
    }

    static void zzz(Canvas canvas, float f, float f2, float f3) {
        Paint paint = F;
        paint.setShader(null);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setFakeBoldText(true);
        for (int i = 0; i < 3; i++) {
            float f4 = ((0.55f * f) + (i / 3.0f)) % 1.0f;
            paint.setColor(a(-9470721, f4 < 0.15f ? f4 / 0.15f : 1.0f - ((f4 - 0.15f) / 0.85f)));
            paint.setTextSize(9.0f + (10.0f * f4));
            canvas.drawText("Z", (14.0f * f4) + f2 + (sn(6.0f * f4) * 2.0f), f3 - (f4 * 22.0f), paint);
        }
        paint.setFakeBoldText(false);
    }
}
