package com.changliao.im;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class J extends LinkedHashMap<String, Object> {

    static class P {
        int i;
        final String s;

        P(String str) {
            this.s = str;
        }

        String str() {
            this.i++;
            StringBuilder sb = new StringBuilder();
            while (true) {
                String str = this.s;
                int i = this.i;
                this.i = i + 1;
                char cCharAt = str.charAt(i);
                if (cCharAt == '\"') {
                    return sb.toString();
                }
                if (cCharAt == '\\') {
                    String str2 = this.s;
                    int i2 = this.i;
                    this.i = i2 + 1;
                    char cCharAt2 = str2.charAt(i2);
                    switch (cCharAt2) {
                        case 'b':
                            sb.append('\b');
                            break;
                        case 'f':
                            sb.append('\f');
                            break;
                        case 'n':
                            sb.append('\n');
                            break;
                        case 'r':
                            sb.append('\r');
                            break;
                        case 't':
                            sb.append('\t');
                            break;
                        case 'u':
                            sb.append((char) Integer.parseInt(this.s.substring(this.i, this.i + 4), 16));
                            this.i += 4;
                            break;
                        default:
                            sb.append(cCharAt2);
                            break;
                    }
                } else {
                    sb.append(cCharAt);
                }
            }
        }

        Object val() {
            String str;
            int i;
            String str2;
            int i2;
            ws();
            char cCharAt = this.s.charAt(this.i);
            if (cCharAt == '{') {
                this.i++;
                J j = new J();
                ws();
                if (this.s.charAt(this.i) == '}') {
                    this.i++;
                    return j;
                }
                do {
                    ws();
                    String str3 = str();
                    ws();
                    this.i++;
                    j.put(str3, val());
                    ws();
                    str2 = this.s;
                    i2 = this.i;
                    this.i = i2 + 1;
                } while (str2.charAt(i2) != '}');
                return j;
            }
            if (cCharAt == '[') {
                this.i++;
                ArrayList arrayList = new ArrayList();
                ws();
                if (this.s.charAt(this.i) == ']') {
                    this.i++;
                    return arrayList;
                }
                do {
                    arrayList.add(val());
                    ws();
                    str = this.s;
                    i = this.i;
                    this.i = i + 1;
                } while (str.charAt(i) != ']');
                return arrayList;
            }
            if (cCharAt == '\"') {
                return str();
            }
            if (this.s.startsWith("true", this.i)) {
                this.i += 4;
                return Boolean.TRUE;
            }
            if (this.s.startsWith("false", this.i)) {
                this.i += 5;
                return Boolean.FALSE;
            }
            if (this.s.startsWith("null", this.i)) {
                this.i += 4;
                return null;
            }
            int i3 = this.i;
            boolean z = false;
            while (this.i < this.s.length()) {
                char cCharAt2 = this.s.charAt(this.i);
                if ((cCharAt2 < '0' || cCharAt2 > '9') && cCharAt2 != '-' && cCharAt2 != '+') {
                    if (cCharAt2 != '.' && cCharAt2 != 'e' && cCharAt2 != 'E') {
                        break;
                    }
                    z = true;
                    this.i++;
                } else {
                    this.i++;
                }
            }
            String strSubstring = this.s.substring(i3, this.i);
            if (!z) {
                try {
                    return Long.valueOf(Long.parseLong(strSubstring));
                } catch (Exception e) {
                }
            }
            return Double.valueOf(Double.parseDouble(strSubstring));
        }

        void ws() {
            while (this.i < this.s.length()) {
                char cCharAt = this.s.charAt(this.i);
                if (cCharAt != ' ' && cCharAt != '\n' && cCharAt != '\r' && cCharAt != '\t') {
                    return;
                } else {
                    this.i++;
                }
            }
        }
    }

    public static J obj(String str) {
        try {
            Object obj = parse(str);
            if (obj instanceof J) {
                return (J) obj;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public static J of(Object... objArr) {
        J j = new J();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 + 1 >= objArr.length) {
                return j;
            }
            j.put((String) objArr[i2], objArr[i2 + 1]);
            i = i2 + 2;
        }
    }

    public static Object parse(String str) {
        P p = new P(str);
        p.ws();
        return p.val();
    }

    static void q(StringBuilder sb, String str) {
        sb.append('\"');
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            switch (cCharAt) {
                case '\t':
                    sb.append("\\t");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                default:
                    if (cCharAt < ' ') {
                        sb.append(String.format("\\u%04x", Integer.valueOf(cCharAt)));
                    } else {
                        sb.append(cCharAt);
                    }
                    break;
            }
        }
        sb.append('\"');
    }

    public static String str(Object obj) {
        StringBuilder sb = new StringBuilder();
        w(sb, obj);
        return sb.toString();
    }

    static void w(StringBuilder sb, Object obj) {
        boolean z = true;
        if (obj == null) {
            sb.append("null");
            return;
        }
        if (obj instanceof String) {
            q(sb, (String) obj);
            return;
        }
        if ((obj instanceof Boolean) || (obj instanceof Integer) || (obj instanceof Long)) {
            sb.append(obj);
            return;
        }
        if (obj instanceof Number) {
            double dDoubleValue = ((Number) obj).doubleValue();
            if (dDoubleValue != Math.floor(dDoubleValue) || Math.abs(dDoubleValue) >= 1.0E15d) {
                sb.append(dDoubleValue);
                return;
            } else {
                sb.append((long) dDoubleValue);
                return;
            }
        }
        if (obj instanceof Map) {
            sb.append('{');
            boolean z2 = true;
            for (Map.Entry entry : (java.util.Set<Map.Entry>) ((Map) obj).entrySet()) {
                if (!z2) {
                    sb.append(',');
                }
                q(sb, (String) entry.getKey());
                sb.append(':');
                w(sb, entry.getValue());
                z2 = false;
            }
            sb.append('}');
            return;
        }
        if (obj instanceof List) {
            sb.append('[');
            Iterator it = ((List) obj).iterator();
            while (it.hasNext()) {
                if (!z) {
                    sb.append(',');
                }
                w(sb, it.next());
                z = false;
            }
            sb.append(']');
            return;
        }
        if (!(obj instanceof Object[])) {
            q(sb, String.valueOf(obj));
            return;
        }
        ArrayList arrayList = new ArrayList();
        for (Object obj2 : (Object[]) obj) {
            arrayList.add(obj2);
        }
        w(sb, arrayList);
    }

    public List<Object> a(String str) {
        Object obj = get(str);
        return obj instanceof List ? (List) obj : new ArrayList();
    }

    public boolean b(String str) {
        Object obj = get(str);
        if (obj == null) {
            return false;
        }
        if (obj instanceof Boolean) {
            return ((Boolean) obj).booleanValue();
        }
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue() != 0.0d;
        }
        String strValueOf = String.valueOf(obj);
        return strValueOf.length() > 0 && !strValueOf.equals("false");
    }

    public double d(String str) {
        Object obj = get(str);
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue();
        }
        return 0.0d;
    }

    public boolean has(String str) {
        return get(str) != null;
    }

    public int i(String str) {
        return (int) l(str);
    }

    public long l(String str) {
        Object obj = get(str);
        if (obj instanceof Number) {
            return ((Number) obj).longValue();
        }
        if (obj instanceof Boolean) {
            return ((Boolean) obj).booleanValue() ? 1L : 0L;
        }
        try {
            return Long.parseLong(String.valueOf(obj));
        } catch (Exception e) {
            return 0L;
        }
    }

    public J o(String str) {
        Object obj = get(str);
        if (obj instanceof J) {
            return (J) obj;
        }
        return null;
    }

    public List<J> objs(String str) {
        ArrayList arrayList = new ArrayList();
        for (Object obj : a(str)) {
            if (obj instanceof J) {
                arrayList.add((J) obj);
            }
        }
        return arrayList;
    }

    public String s(String str) {
        Object obj = get(str);
        if (obj == null) {
            return "";
        }
        return ((obj instanceof Double) && ((Double) obj).doubleValue() == Math.floor(((Double) obj).doubleValue())) ? String.valueOf(((Double) obj).longValue()) : String.valueOf(obj);
    }

    public J set(String str, Object obj) {
        put(str, obj);
        return this;
    }

    public String sn(String str) {
        if (get(str) == null) {
            return null;
        }
        return s(str);
    }

    @Override // java.util.AbstractMap
    public String toString() {
        return str(this);
    }
}
