package com.changliao.im;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class HomeScr extends Scr {
    static final int NAV_H = 58;
    View banB;
    FrameLayout body;
    ListView convList;
    LinearLayout ctBody;
    LinearLayout ctList;
    boolean dirty;
    FrameLayout drawer;
    FeedScr feed;
    View ind;
    Img.Av meAv;
    View meDot;
    TextView meNick;
    TextView meSt;
    View tabCt;
    View tabFeed;
    View tabMsgs;
    final ConvAdapter adapter = new ConvAdapter();
    final TextView[] navLbl = new TextView[3];
    final ImageView[] navIco = new ImageView[3];
    final TextView[] navBadge = new TextView[3];
    final FrameLayout[] navCell = new FrameLayout[3];
    String seg = "friends";
    int tab = 0;
    final Runnable doRefresh = new Runnable() { // from class: com.changliao.im.HomeScr.30
        @Override // java.lang.Runnable
        public void run() {
            HomeScr.this.dirty = false;
            HomeScr.this.refresh();
            if (HomeScr.this.tab == 1) {
                HomeScr.this.renderContacts();
            }
        }
    };

    class ConvAdapter extends BaseAdapter {
        List<J> l = new ArrayList();

        ConvAdapter() {
        }

        J get(int i) {
            if (i < 0 || i >= this.l.size()) {
                return null;
            }
            return this.l.get(i);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return this.l.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return this.l.get(i);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            Holder holder;
            if (view == null) {
                Holder holder2 = HomeScr.this.new Holder();
                view = holder2.make();
                holder = holder2;
            } else {
                holder = (Holder) view.getTag();
            }
            holder.bind(this.l.get(i));
            return view;
        }

        void set(List<J> list) {
            this.l = list;
            notifyDataSetChanged();
        }
    }

    class Holder {
        Img.Av av;
        TextView badge;
        ImageView mute;
        TextView name;
        TextView pv;
        LinearLayout root;
        TextView time;

        Holder() {
        }

        void bind(J j) {
            int i;
            boolean z = false;
            String strS = j.s("conv");
            HomeScr.setConvAvatar(this.av, j, HomeScr.this.C);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(HomeScr.title(j));
            boolean z2 = j.b("vip") && strS.startsWith("p:") && !Core.isSelf(strS);
            if (z2) {
                spannableStringBuilder.setSpan(new ForegroundColorSpan(-3569152), 0, spannableStringBuilder.length(), 33);
            }
            if (strS.startsWith("g:") && j.l("n") > 0) {
                int length = spannableStringBuilder.length();
                spannableStringBuilder.append((CharSequence) " (").append((CharSequence) String.valueOf(j.l("n"))).append((CharSequence) ")");
                spannableStringBuilder.setSpan(new ForegroundColorSpan(Ui.SUB), length, spannableStringBuilder.length(), 33);
                spannableStringBuilder.setSpan(new AbsoluteSizeSpan(13, true), length, spannableStringBuilder.length(), 33);
            }
            this.name.setText(spannableStringBuilder);
            this.name.setTypeface(z2 ? Scr.bold : null);
            this.time.setText(Ui.when(j.l("ts")));
            String strS2 = j.s("pv");
            SpannableStringBuilder spannableStringBuilder2 = new SpannableStringBuilder();
            if (j.b("atme")) {
                red(spannableStringBuilder2, "[有人@我] ");
            }
            if (j.l("reqs") > 0) {
                red(spannableStringBuilder2, "[" + j.l("reqs") + " 条入群申请] ");
            }
            String string = App.kv.getString("draft:" + strS, null);
            if (string == null || string.trim().length() <= 0 || strS.equals(HomeScr.this.C.openConv)) {
                string = strS2;
            } else {
                red(spannableStringBuilder2, "[草稿] ");
            }
            spannableStringBuilder2.append((CharSequence) string.replace('\n', ' '));
            this.pv.setText(spannableStringBuilder2);
            boolean zContains = HomeScr.this.C.mutes.contains(strS);
            this.mute.setVisibility(zContains ? 0 : 8);
            long jL = j.l("unread");
            this.badge.setVisibility(jL > 0 ? 0 : 8);
            this.badge.setText(jL > 99 ? "99+" : String.valueOf(jL));
            this.badge.setBackground(Ui.round(zContains ? -3880754 : Ui.RED, 10.0f));
            if (HomeScr.this.a.wide() && strS.equals(HomeScr.this.C.openConv)) {
                z = true;
            }
            if (z) {
                i = -1643792;
            } else {
                i = HomeScr.this.C.pins().contains(strS) ? -1446929 : -1;
            }
            this.root.setBackground(new RippleDrawable(ColorStateList.valueOf(303462384), new Row(i), null));
        }

        View make() {
            LinearLayout linearLayoutRow = Ui.row(HomeScr.this.a);
            linearLayoutRow.setMinimumHeight(Ui.dp(72.0f));
            linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
            this.av = new Img.Av(HomeScr.this.a);
            linearLayoutRow.addView(this.av, Ui.lpm(Ui.dp(50.0f), Ui.dp(50.0f), 0, 0, 12, 0));
            LinearLayout linearLayoutCol = Ui.col(HomeScr.this.a);
            this.name = Ui.one(Ui.text(HomeScr.this.a, "", 16.0f, Ui.TEXT));
            linearLayoutCol.addView(this.name);
            this.pv = Ui.one(Ui.text(HomeScr.this.a, "", 14.0f, Ui.SUB));
            linearLayoutCol.addView(this.pv, Ui.lpm(-1, -2, 0, 2, 0, 0));
            linearLayoutRow.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
            LinearLayout linearLayoutCol2 = Ui.col(HomeScr.this.a);
            linearLayoutCol2.setGravity(8388629);
            linearLayoutCol2.setPadding(Ui.dp(8.0f), Ui.dp(4.0f), 0, Ui.dp(4.0f));
            this.time = Ui.text(HomeScr.this.a, "", 12.0f, -5656648);
            this.time.setSingleLine(true);
            linearLayoutCol2.setMinimumWidth(Ui.dp(52.0f));
            linearLayoutCol2.addView(this.time, new LinearLayout.LayoutParams(-2, -2));
            LinearLayout linearLayoutRow2 = Ui.row(HomeScr.this.a);
            linearLayoutRow2.setGravity(8388629);
            this.mute = new ImageView(HomeScr.this.a);
            this.mute.setImageDrawable(new Ico("micoff", -3880754));
            linearLayoutRow2.addView(this.mute, Ui.lpm(Ui.dp(15.0f), Ui.dp(15.0f), 0, 0, 4, 0));
            this.badge = Ui.badge(HomeScr.this.a, "");
            linearLayoutRow2.addView(this.badge);
            linearLayoutCol2.addView(linearLayoutRow2, Ui.lpm(-2, Ui.dp(19.0f), 0, 6, 0, 0));
            linearLayoutRow.addView(linearLayoutCol2, Ui.lp(-2, -1));
            linearLayoutRow.setTag(this);
            this.root = linearLayoutRow;
            return linearLayoutRow;
        }

        void red(SpannableStringBuilder spannableStringBuilder, String str) {
            int length = spannableStringBuilder.length();
            spannableStringBuilder.append((CharSequence) str);
            spannableStringBuilder.setSpan(new ForegroundColorSpan(Ui.RED), length, spannableStringBuilder.length(), 33);
        }
    }

    static class Row extends Drawable {
        final int bg;
        final Paint p = new Paint();

        Row(int i) {
            this.bg = i;
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            canvas.drawColor(this.bg);
            this.p.setColor(-986637);
            canvas.drawRect(bounds.left, bounds.bottom - Math.max(1, Ui.dp(1.0f)), bounds.right, bounds.bottom, this.p);
        }

        @Override // android.graphics.drawable.Drawable
        public int getOpacity() {
            return -1;
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int i) {
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter colorFilter) {
        }
    }

    static String ago(long j) {
        if (j <= 0) {
            return "很久以前";
        }
        long jCurrentTimeMillis = (System.currentTimeMillis() / 1000) - j;
        if (jCurrentTimeMillis < 60) {
            return "刚刚";
        }
        if (jCurrentTimeMillis < 3600) {
            return (jCurrentTimeMillis / 60) + " 分钟前";
        }
        return jCurrentTimeMillis < 86400 ? (jCurrentTimeMillis / 3600) + " 小时前" : (jCurrentTimeMillis / 86400) + " 天前";
    }

    public static void setConvAvatar(Img.Av av, J j, Core core) {
        String strS = j.s("conv");
        if (core.isHall(strS) && !j.has("av")) {
            av.setIcon("globe", -20163, -34257);
        } else if (Core.isSelf(strS)) {
            av.setIcon("file", -11555586, -14779408);
        } else if (strS.startsWith("g:")) {
            av.set(j.s("title"), j.sn("av"), true, strS);
        } else {
            av.set(j.s("title"), j.sn("av"), false);
        }
        av.setOnline(strS.startsWith("p:") && !Core.isSelf(strS) && j.b("online"));
    }

    static String title(J j) {
        return Core.isSelf(j.s("conv")) ? "文件传输助手" : j.s("title");
    }

    static Drawable topLine() {
        return topLineColor(-419430401);
    }

    static Drawable topLineColor(final int i) {
        return new Drawable() { // from class: com.changliao.im.HomeScr.22
            final Paint p = new Paint();

            @Override // android.graphics.drawable.Drawable
            public void draw(Canvas canvas) {
                Rect bounds = getBounds();
                this.p.setColor(i);
                canvas.drawRect(bounds.left, bounds.top, bounds.right, bounds.top + Math.max(1, Ui.dp(1.0f)), this.p);
            }

            @Override // android.graphics.drawable.Drawable
            public int getOpacity() {
                return -3;
            }

            @Override // android.graphics.drawable.Drawable
            public void setAlpha(int i2) {
            }

            @Override // android.graphics.drawable.Drawable
            public void setColorFilter(ColorFilter colorFilter) {
            }
        };
    }

    void act(final String str) {
        if (str.equals("night")) {
            toast("夜间模式还在做，下个版本加上");
        } else {
            closeDrawer(new Runnable() { // from class: com.changliao.im.HomeScr.29
                @Override // java.lang.Runnable
                public void run() {
                    if (str.equals("self")) {
                        HomeScr.this.C.send(J.of("t", "c_open", "self", 1));
                    } else if (str.equals("logout")) {
                        HomeScr.this.a.confirm("退出登录", "退出后不会再收到消息，确定退出吗？", "退出", true, new Runnable() { // from class: com.changliao.im.HomeScr.29.1
                            @Override // java.lang.Runnable
                            public void run() {
                                HomeScr.this.C.logout();
                            }
                        });
                    } else {
                        HomeScr.this.a.web(str, new String[0]);
                    }
                }
            });
        }
    }

    void badge(int i, int i2) {
        if (this.navBadge[i] == null) {
            return;
        }
        this.navBadge[i].setVisibility(i2 > 0 ? 0 : 8);
        this.navBadge[i].setText(i2 > 99 ? "99+" : String.valueOf(i2));
    }

    @Override // com.changliao.im.Scr
    public View build() {
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackgroundColor(Ui.BG);
        this.body = new FrameLayout(this.a);
        this.tabMsgs = buildMsgs();
        this.tabCt = buildContacts();
        this.body.addView(this.tabMsgs, new FrameLayout.LayoutParams(-1, -1));
        this.body.addView(this.tabCt, new FrameLayout.LayoutParams(-1, -1));
        this.tabCt.setVisibility(8);
        this.feed = new FeedScr(null, null);
        this.feed.embedded = true;
        this.feed.a = this.a;
        this.tabFeed = this.feed.build();
        this.feed.root = this.tabFeed;
        this.feed.alive = true;
        this.body.addView(this.tabFeed, new FrameLayout.LayoutParams(-1, -1));
        this.tabFeed.setVisibility(8);
        this.C.add(this.feed);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.bottomMargin = Ui.dp(58.0f);
        frameLayout.addView(this.body, layoutParams);
        frameLayout.addView(buildNav(), new FrameLayout.LayoutParams(-1, Ui.dp(58.0f), 80));
        refresh();
        return frameLayout;
    }

    View buildContacts() {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        LinearLayout linearLayout = topBar();
        linearLayout.addView(Ui.one(Ui.bold(Ui.text(this.a, "联系人", 18.0f, Ui.TEXT))), Ui.lp(0, -2, 1.0f));
        linearLayout.addView(hib("cross", new View.OnClickListener() { // from class: com.changliao.im.HomeScr.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.plusMenu();
            }
        }));
        linearLayoutCol.addView(linearLayout);
        ScrollView scrollView = new ScrollView(this.a);
        this.ctBody = Ui.col(this.a);
        scrollView.addView(this.ctBody);
        linearLayoutCol.addView(scrollView, Ui.lp(-1, 0, 1.0f));
        return linearLayoutCol;
    }

    View buildMsgs() {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        LinearLayout linearLayout = topBar();
        LinearLayout linearLayoutRow = Ui.row(this.a);
        this.meAv = new Img.Av(this.a);
        linearLayoutRow.addView(this.meAv, Ui.lp(Ui.dp(36.0f), Ui.dp(36.0f)));
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        linearLayoutCol2.setPadding(Ui.dp(10.0f), 0, 0, 0);
        this.meNick = Ui.one(Ui.bold(Ui.text(this.a, "", 17.0f, Ui.TEXT)));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        this.meDot = new View(this.a);
        linearLayoutRow2.addView(this.meDot, Ui.lpm(Ui.dp(7.0f), Ui.dp(7.0f), 0, 0, 4, 0));
        this.meSt = Ui.text(this.a, "", 12.0f, Ui.SUB);
        linearLayoutRow2.addView(this.meSt);
        linearLayoutCol2.addView(this.meNick);
        linearLayoutCol2.addView(linearLayoutRow2);
        linearLayoutRow.addView(linearLayoutCol2, Ui.lp(0, -2, 1.0f));
        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.openDrawer();
            }
        });
        linearLayout.addView(linearLayoutRow, Ui.lp(0, -2, 1.0f));
        linearLayout.addView(hib("cross", new View.OnClickListener() { // from class: com.changliao.im.HomeScr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.plusMenu();
            }
        }));
        linearLayoutCol.addView(linearLayout);
        LinearLayout linearLayoutRow3 = Ui.row(this.a);
        linearLayoutRow3.setGravity(17);
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico("search", Ui.SUB));
        linearLayoutRow3.addView(imageView, Ui.lpm(Ui.dp(18.0f), Ui.dp(18.0f), 0, 0, 6, 0));
        linearLayoutRow3.addView(Ui.text(this.a, "搜索", 15.0f, Ui.SUB));
        linearLayoutRow3.setBackground(new RippleDrawable(ColorStateList.valueOf(337016816), new G(3, 14.0f), null));
        linearLayoutRow3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.a.web("search", new String[0]);
            }
        });
        linearLayoutCol.addView(linearLayoutRow3, Ui.lpm(-1, Ui.dp(38.0f), 14, 2, 14, 10));
        this.banB = banBar();
        linearLayoutCol.addView(this.banB, Ui.lpm(-1, -2, 14, 0, 14, 10));
        this.convList = new ListView(this.a);
        this.convList.setDivider(null);
        this.convList.setSelector(new ColorDrawable(0));
        this.convList.setCacheColorHint(0);
        this.convList.setAdapter((ListAdapter) this.adapter);
        this.convList.setClipToPadding(false);
        this.convList.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.changliao.im.HomeScr.4
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                J j2 = HomeScr.this.adapter.get(i);
                if (j2 != null) {
                    HomeScr.this.a.openChat(j2.s("conv"));
                }
            }
        });
        this.convList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: com.changliao.im.HomeScr.5
            @Override // android.widget.AdapterView.OnItemLongClickListener
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
                J j2 = HomeScr.this.adapter.get(i);
                if (j2 == null) {
                    return true;
                }
                HomeScr.this.a.vib(15);
                HomeScr.this.convMenu(j2);
                return true;
            }
        });
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.addView(this.convList, new FrameLayout.LayoutParams(-1, -1));
        TextView textViewEmpty = empty("还没有聊天\n点右上角 ＋ 加好友、建群");
        frameLayout.addView(textViewEmpty, new FrameLayout.LayoutParams(-1, -2));
        this.convList.setEmptyView(textViewEmpty);
        linearLayoutCol.addView(frameLayout, Ui.lp(-1, 0, 1.0f));
        return linearLayoutCol;
    }

    View buildNav() {
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackground(new LayerDrawable(new Drawable[]{new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-394500, -591879}), topLine()}));
        frameLayout.setElevation(Ui.dp(6.0f));
        this.ind = new View(this.a);
        G g = new G(0, 18.0f);
        g.bg = -526086;
        this.ind.setBackground(g);
        frameLayout.addView(this.ind, new FrameLayout.LayoutParams(0, Ui.dp(46.0f), 48));
        ((FrameLayout.LayoutParams) this.ind.getLayoutParams()).topMargin = Ui.dp(6.0f);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        String[] strArr = {"msg", "ct", "feed"};
        String[] strArr2 = {"消息", "联系人", "动态"};
        int i = 0;
        while (true) {
            final int i2 = i;
            if (i2 >= 3) {
                frameLayout.addView(linearLayoutRow, new FrameLayout.LayoutParams(-1, -1));
                frameLayout.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.changliao.im.HomeScr.21
                    @Override // android.view.View.OnLayoutChangeListener
                    public void onLayoutChange(View view, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
                        HomeScr.this.moveInd(false);
                        HomeScr.this.placeBadges();
                    }
                });
                setNavColors();
                return frameLayout;
            }
            FrameLayout frameLayout2 = new FrameLayout(this.a);
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.setGravity(17);
            ImageView imageView = new ImageView(this.a);
            imageView.setImageDrawable(new Ico(strArr[i2], -11642519));
            linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(26.0f), Ui.dp(26.0f)));
            TextView textViewText = Ui.text(this.a, strArr2[i2], 11.0f, -11642519);
            linearLayoutCol.addView(textViewText, Ui.lpm(-2, -2, 0, 2, 0, 0));
            frameLayout2.addView(linearLayoutCol, new FrameLayout.LayoutParams(-1, -1));
            TextView textViewBadge = Ui.badge(this.a, "");
            textViewBadge.setTextSize(11.0f);
            textViewBadge.setLayoutParams(new FrameLayout.LayoutParams(-2, Ui.dp(18.0f), 8388659));
            textViewBadge.setMinWidth(Ui.dp(18.0f));
            textViewBadge.setPadding(Ui.dp(5.0f), 0, Ui.dp(5.0f), 0);
            textViewBadge.setBackground(Ui.round(Ui.RED, 9.0f));
            textViewBadge.setElevation(Ui.dp(3.0f));
            frameLayout2.addView(textViewBadge);
            textViewBadge.setVisibility(8);
            frameLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.20
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    HomeScr.this.go(i2);
                }
            });
            this.navLbl[i2] = textViewText;
            this.navIco[i2] = imageView;
            this.navBadge[i2] = textViewBadge;
            this.navCell[i2] = frameLayout2;
            linearLayoutRow.addView(frameLayout2, Ui.lp(0, -1, 1.0f));
            i = i2 + 1;
        }
    }

    void closeDrawer(final Runnable runnable) {
        final FrameLayout frameLayout = this.drawer;
        if (frameLayout == null) {
            return;
        }
        this.drawer = null;
        frameLayout.setTag(null);
        View childAt = frameLayout.getChildAt(0);
        childAt.animate().translationX(-childAt.getWidth()).setDuration(260L).start();
        frameLayout.animate().alpha(0.0f).setDuration(260L).withEndAction(new Runnable() { // from class: com.changliao.im.HomeScr.25
            @Override // java.lang.Runnable
            public void run() {
                HomeScr.this.a.overlay.removeView(frameLayout);
                if (runnable != null) {
                    runnable.run();
                }
            }
        }).start();
    }

    void convMenu(J j) {
        final String strS = j.s("conv");
        final boolean zContains = this.C.pins().contains(strS);
        final boolean zContains2 = this.C.mutes.contains(strS);
        ArrayList arrayList = new ArrayList();
        arrayList.add(zContains ? "取消置顶" : "置顶");
        arrayList.add(zContains2 ? "取消免打扰" : "消息免打扰");
        if (j.l("unread") > 0) {
            arrayList.add("标为已读");
        }
        arrayList.add("从列表中删除");
        this.a.sheet(title(j), (String[]) arrayList.toArray(new String[0]), arrayList.size() - 1, new MainActivity.Str() { // from class: com.changliao.im.HomeScr.7
            @Override // com.changliao.im.MainActivity.Str
            public void ok(String str) {
                if (str.endsWith("置顶")) {
                    HomeScr.this.C.setPin(strS, zContains ? false : true);
                    return;
                }
                if (str.endsWith("免打扰")) {
                    HomeScr.this.C.setMute(strS, zContains2 ? false : true);
                } else if (str.equals("标为已读")) {
                    HomeScr.this.C.markRead(strS, true);
                } else {
                    HomeScr.this.C.hide(strS);
                    HomeScr.this.C.markRead(strS, true);
                }
            }
        });
    }

    View dBtn(String str, String str2, final String str3) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setGravity(17);
        linearLayoutCol.setPadding(Ui.dp(10.0f), Ui.dp(8.0f), Ui.dp(10.0f), Ui.dp(8.0f));
        linearLayoutCol.setMinimumWidth(Ui.dp(64.0f));
        G.on(linearLayoutCol, 0, 16.0f, 3.0f);
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, -11642519));
        linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(26.0f), Ui.dp(26.0f)));
        linearLayoutCol.addView(Ui.text(this.a, str2, 13.0f, -11642519), Ui.lpm(-2, -2, 0, 4, 0, 0));
        Ui.bounce(linearLayoutCol);
        linearLayoutCol.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.28
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.act(str3);
            }
        });
        linearLayoutCol.setLayoutParams(Ui.lpm(-2, -2, 0, 0, 22, 0));
        return linearLayoutCol;
    }

    View dItem(View view, String str, String str2, final String str3) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f));
        G.on(linearLayoutRow, 0, 16.0f, 1.5f);
        linearLayoutRow.addView(view, Ui.lpm(Ui.dp(24.0f), Ui.dp(24.0f), 0, 0, 14, 0));
        linearLayoutRow.addView(Ui.text(this.a, str, 16.0f, Ui.TEXT), Ui.lp(-2, -2));
        linearLayoutRow.addView(new View(this.a), Ui.lp(0, 1, 1.0f));
        if (str2 != null) {
            TextView textViewBadge = Ui.badge(this.a, str2);
            linearLayoutRow.addView(textViewBadge);
            ((LinearLayout.LayoutParams) textViewBadge.getLayoutParams()).rightMargin = Ui.dp(6.0f);
        }
        linearLayoutRow.addView(Ui.text(this.a, "›", 20.0f, -4143924));
        Ui.bounce(linearLayoutRow);
        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.27
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                HomeScr.this.act(str3);
            }
        });
        linearLayoutRow.setLayoutParams(Ui.lpm(-1, -2, 0, 0, 0, 6));
        return linearLayoutRow;
    }

    View entry(String str, int i, int i2, String str2, int i3, View.OnClickListener onClickListener) {
        Img.Av av = new Img.Av(this.a);
        av.setIcon(str, i, i2);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(16.0f), Ui.dp(12.0f));
        G.on(linearLayoutRow, 0, 18.0f, 3.0f);
        linearLayoutRow.addView(av, Ui.lpm(Ui.dp(40.0f), Ui.dp(40.0f), 0, 0, 12, 0));
        linearLayoutRow.addView(Ui.text(this.a, str2, 16.0f, Ui.TEXT), Ui.lp(0, -2, 1.0f));
        if (i3 > 0) {
            TextView textViewBadge = Ui.badge(this.a, String.valueOf(i3));
            linearLayoutRow.addView(textViewBadge);
            ((LinearLayout.LayoutParams) textViewBadge.getLayoutParams()).rightMargin = Ui.dp(6.0f);
        }
        linearLayoutRow.addView(Ui.text(this.a, "›", 20.0f, -4143924));
        linearLayoutRow.setOnClickListener(onClickListener);
        Ui.bounce(linearLayoutRow);
        linearLayoutRow.setLayoutParams(Ui.lpm(-1, -2, 12, 8, 12, 0));
        return linearLayoutRow;
    }

    void fillCt(LinearLayout linearLayout) {
        linearLayout.removeAllViews();
        List<J> listObjs = this.C.fr.objs("friends");
        ArrayList<J> arrayList = new ArrayList(this.C.groups.values());
        if (this.seg.equals("groups")) {
            if (arrayList.isEmpty()) {
                linearLayout.addView(empty("还没有加入群聊"));
            }
            for (final J j : arrayList) {
                linearLayout.addView(person(j.s("name"), j.sn("av"), "g:" + j.s("gid"), true, false, false, j.l("n") + " 人 · 群号 " + j.s("gid"), Ui.roleTag(this.a, j.s("role")), new View.OnClickListener() { // from class: com.changliao.im.HomeScr.13
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        HomeScr.this.a.openChat("g:" + j.s("gid"));
                    }
                }));
            }
            return;
        }
        ArrayList<J> arrayList2 = new ArrayList(listObjs);
        Collections.sort(arrayList2, new Comparator<J>() { // from class: com.changliao.im.HomeScr.14
            @Override // java.util.Comparator
            public int compare(J j2, J j3) {
                if (j2.b("online") != j3.b("online")) {
                    return j2.b("online") ? -1 : 1;
                }
                return j2.s("nick").compareTo(j3.s("nick"));
            }
        });
        if (arrayList2.isEmpty()) {
            linearLayout.addView(empty("还没有好友，点上面的搜索框找人"));
        }
        for (final J j2 : arrayList2) {
            linearLayout.addView(person(j2.s("nick"), j2.sn("av"), null, false, j2.b("online"), j2.b("vip"), (j2.b("online") ? "[在线] " : "[离线] ") + j2.s("bio"), j2.b("vip") ? Ui.vipTag(this.a) : null, new View.OnClickListener() { // from class: com.changliao.im.HomeScr.15
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    HomeScr.this.a.web("profile", "a", j2.s("nk"));
                }
            }));
        }
    }

    void fillDrawer(ScrollView scrollView) {
        scrollView.removeAllViews();
        J j = this.C.info == null ? new J() : this.C.info;
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setPadding(Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f));
        scrollView.addView(linearLayoutCol);
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        linearLayoutCol2.setPadding(Ui.dp(18.0f), Ui.dp(18.0f), Ui.dp(18.0f), Ui.dp(18.0f));
        G g = new G(0, 16.0f);
        g.bg = -1;
        linearLayoutCol2.setBackground(g);
        linearLayoutCol2.setElevation(Ui.dp(3.0f));
        Img.Av av = new Img.Av(this.a);
        av.set(j.s("nick"), j.sn("av"), false);
        av.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.26
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.closeDrawer(new Runnable() { // from class: com.changliao.im.HomeScr.26.1
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity mainActivity = HomeScr.this.a;
                        String[] strArr = new String[2];
                        strArr[0] = "a";
                        strArr[1] = HomeScr.this.C.info == null ? "" : HomeScr.this.C.info.s("nk");
                        mainActivity.web("profile", strArr);
                    }
                });
            }
        });
        linearLayoutCol2.addView(av, Ui.lp(Ui.dp(78.0f), Ui.dp(78.0f)));
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.addView(Ui.one(Ui.bold(Ui.text(this.a, j.s("nick"), 21.0f, this.C.vip ? -3569152 : Ui.TEXT))));
        if (this.C.vip) {
            linearLayoutRow.addView(Ui.vipTag(this.a));
        }
        linearLayoutCol2.addView(linearLayoutRow, Ui.lpm(-2, -2, 0, 10, 0, 0));
        linearLayoutCol2.addView(Ui.text(this.a, "NK号：" + j.s("nk"), 13.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 2, 0, 0));
        linearLayoutCol2.addView(Ui.text(this.a, j.s("bio").length() > 0 ? j.s("bio") : "这个人很懒，什么都没留下", 14.0f, -11642519), Ui.lpm(-2, -2, 0, 8, 0, 0));
        linearLayoutCol2.addView(Ui.text(this.a, "👍 " + j.l("likes") + " 个赞", 13.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 10, 0, 0));
        linearLayoutCol.addView(linearLayoutCol2, Ui.lpm(-1, -2, 0, 30, 0, 14));
        Iterator<J> it = this.C.anns.iterator();
        boolean z = false;
        while (it.hasNext()) {
            z = !Ann.done(it.next()) ? true : z;
        }
        linearLayoutCol.addView(dItem(icon("user"), "我的资料", null, "myinfo"));
        linearLayoutCol.addView(dItem(icon("feed"), "我的动态", null, "myfeed"));
        linearLayoutCol.addView(dItem(icon("hall"), "系统公告", z ? "新" : null, "anns"));
        TextView textViewText = Ui.text(this.a, "V", 14.0f, -9747712);
        textViewText.setTypeface(Typeface.create(Typeface.DEFAULT, 3));
        textViewText.setGravity(17);
        textViewText.setBackground(Ui.grad(8.0f, -8054, -739526, -1860837));
        View viewDItem = dItem(textViewText, "VIP中心", null, "vip");
        if (this.C.vip) {
            ((LinearLayout) viewDItem).addView(Ui.vipTag(this.a), 2);
        }
        linearLayoutCol.addView(viewDItem);
        linearLayoutCol.addView(dItem(icon("star"), "我的收藏", null, "favs"));
        linearLayoutCol.addView(dItem(icon("file"), "文件传输助手", null, "self"));
        linearLayoutCol.addView(dItem(icon("bug"), this.C.isOwner ? "Bug反馈处理" : "Bug反馈", (!this.C.isOwner || this.C.bugN <= 0) ? null : String.valueOf(this.C.bugN), "bugs"));
        if (this.C.isOwner) {
            linearLayoutCol.addView(dItem(icon("gear"), "举报、申诉与 VIP 申请", this.C.reportsN > 0 ? String.valueOf(this.C.reportsN) : null, "reports"));
        }
        linearLayoutCol.addView(new View(this.a), Ui.lp(1, 0, 1.0f));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setPadding(Ui.dp(8.0f), Ui.dp(14.0f), Ui.dp(8.0f), 0);
        linearLayoutRow2.addView(dBtn("gear", "设置", "settings"));
        linearLayoutRow2.addView(dBtn("moon", "夜间", "night"));
        linearLayoutRow2.addView(dBtn("out", "退出", "logout"));
        linearLayoutCol.addView(linearLayoutRow2);
    }

    void go(int i) {
        View view;
        if (i == 2) {
            this.C.feedUnread = 0;
            this.C.emit("me", null);
        }
        if (i == this.tab) {
            if (i == 2) {
                this.feed.load(0L);
                return;
            }
            return;
        }
        this.tab = i;
        this.tabMsgs.setVisibility(i == 0 ? 0 : 8);
        this.tabCt.setVisibility(i == 1 ? 0 : 8);
        this.tabFeed.setVisibility(i != 2 ? 8 : 0);
        if (i == 0) {
            view = this.tabMsgs;
        } else {
            view = i == 1 ? this.tabCt : this.tabFeed;
        }
        view.setAlpha(0.3f);
        view.animate().alpha(1.0f).setDuration(180L).setInterpolator(new DecelerateInterpolator()).start();
        if (i == 1) {
            renderContacts();
        }
        if (i == 2) {
            this.feed.load(0L);
        }
        setNavColors();
        moveInd(true);
    }

    ImageView hib(String str, View.OnClickListener onClickListener) {
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, Ui.TEXT));
        int iDp = Ui.dp(8.0f);
        imageView.setPadding(iDp, iDp, iDp, iDp);
        G.on(imageView, 0, 15.0f, 2.0f);
        imageView.setOnClickListener(onClickListener);
        Ui.bounce(imageView);
        imageView.setLayoutParams(Ui.lp(Ui.dp(42.0f), Ui.dp(42.0f)));
        return imageView;
    }

    ImageView icon(String str) {
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, Ui.BLUE));
        return imageView;
    }

    void moveInd(boolean z) {
        FrameLayout frameLayout = this.navCell[this.tab];
        if (frameLayout == null || frameLayout.getWidth() == 0) {
            return;
        }
        int width = frameLayout.getWidth() - Ui.dp(16.0f);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.ind.getLayoutParams();
        if (layoutParams.width != width) {
            layoutParams.width = width;
            this.ind.setLayoutParams(layoutParams);
        }
        float left = frameLayout.getLeft() + Ui.dp(8.0f);
        if (z) {
            this.ind.animate().translationX(left).setDuration(520L).setInterpolator(new OvershootInterpolator(1.3f)).start();
        } else {
            this.ind.setTranslationX(left);
        }
    }

    void moveSeg(FrameLayout frameLayout, View view, TextView[] textViewArr, int i, boolean z) {
        int width = (frameLayout.getWidth() - frameLayout.getPaddingLeft()) - frameLayout.getPaddingRight();
        if (width <= 0) {
            return;
        }
        int iDp = (width - Ui.dp(4.0f)) / 2;
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        if (layoutParams.width != iDp) {
            layoutParams.width = iDp;
            view.setLayoutParams(layoutParams);
        }
        float fDp = i == 0 ? 0.0f : Ui.dp(4.0f) + iDp;
        if (z) {
            view.animate().translationX(fDp).setDuration(320L).setInterpolator(new OvershootInterpolator(0.9f)).start();
        } else {
            view.setTranslationX(fDp);
        }
        int i2 = 0;
        while (i2 < 2) {
            final TextView textView = textViewArr[i2];
            boolean z2 = i2 == i;
            int currentTextColor = textView.getCurrentTextColor();
            int i3 = z2 ? Ui.TEXT : Ui.SUB;
            textView.setTypeface(z2 ? LoginScr.bold : null);
            if (z) {
                ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(currentTextColor), Integer.valueOf(i3));
                valueAnimatorOfObject.setDuration(260L);
                valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.changliao.im.HomeScr.18
                    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        textView.setTextColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
                    }
                });
                valueAnimatorOfObject.start();
            } else {
                textView.setTextColor(i3);
            }
            i2++;
        }
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("ban")) {
            updBan(this.banB);
            return;
        }
        if ((str.equals("convs") || str.equals("conn") || str.equals("me") || str.equals("friends") || str.equals("groups")) && !this.dirty) {
            this.dirty = true;
            this.a.h.postDelayed(this.doRefresh, 60L);
        }
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        if (this.feed != null) {
            this.feed.alive = false;
            this.C.remove(this.feed);
        }
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        refresh();
        if (this.tab == 1) {
            renderContacts();
        }
    }

    void openDrawer() {
        if (this.drawer != null) {
            return;
        }
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackgroundColor(1493172224);
        ScrollView scrollView = new ScrollView(this.a);
        scrollView.setFillViewport(true);
        scrollView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1117189, -723207, -591879, -591879, -591879}));
        scrollView.setElevation(Ui.dp(16.0f));
        int iMin = Math.min((int) (this.a.getResources().getDisplayMetrics().widthPixels * 0.84f), Ui.dp(380.0f));
        frameLayout.addView(scrollView, new FrameLayout.LayoutParams(iMin, -1, 8388611));
        final Runnable runnable = new Runnable() { // from class: com.changliao.im.HomeScr.23
            @Override // java.lang.Runnable
            public void run() {
                HomeScr.this.closeDrawer(null);
            }
        };
        frameLayout.setTag(runnable);
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.24
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                runnable.run();
            }
        });
        scrollView.setClickable(true);
        this.drawer = frameLayout;
        fillDrawer(scrollView);
        this.a.overlay.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.setAlpha(0.0f);
        frameLayout.animate().alpha(1.0f).setDuration(300L).start();
        scrollView.setTranslationX(-iMin);
        scrollView.animate().translationX(0.0f).setDuration(320L).setInterpolator(new DecelerateInterpolator(2.2f)).start();
    }

    View person(String str, String str2, String str3, boolean z, boolean z2, boolean z3, String str4, View view, View.OnClickListener onClickListener) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setMinimumHeight(Ui.dp(72.0f));
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
        linearLayoutRow.setBackground(new RippleDrawable(ColorStateList.valueOf(303462384), new Row(-1), null));
        Img.Av av = new Img.Av(this.a);
        if (str3 != null) {
            av.set(str, str2, z, str3);
        } else {
            av.set(str, str2, z);
        }
        av.setOnline(z2);
        linearLayoutRow.addView(av, Ui.lpm(Ui.dp(50.0f), Ui.dp(50.0f), 0, 0, 12, 0));
        LinearLayout linearLayoutCol = Ui.col(this.a);
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        TextView textViewOne = Ui.one(Ui.text(this.a, str, 16.0f, z3 ? -3569152 : Ui.TEXT));
        if (z3) {
            textViewOne.setTypeface(bold);
        }
        linearLayoutRow2.addView(textViewOne);
        if (view != null) {
            linearLayoutRow2.addView(view);
        }
        linearLayoutCol.addView(linearLayoutRow2);
        linearLayoutCol.addView(Ui.one(Ui.text(this.a, str4, 14.0f, Ui.SUB)), Ui.lpm(-1, -2, 0, 2, 0, 0));
        linearLayoutRow.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
        linearLayoutRow.setOnClickListener(onClickListener);
        return linearLayoutRow;
    }

    void placeBadges() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 3) {
                return;
            }
            if (this.navCell[i2] != null) {
                int width = this.navCell[i2].getWidth();
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.navBadge[i2].getLayoutParams();
                int iDp = (width / 2) + Ui.dp(6.0f);
                int iDp2 = Ui.dp(4.0f);
                if (layoutParams.leftMargin != iDp || layoutParams.topMargin != iDp2) {
                    layoutParams.leftMargin = iDp;
                    layoutParams.topMargin = iDp2;
                    this.navBadge[i2].setLayoutParams(layoutParams);
                }
            }
            i = i2 + 1;
        }
    }

    void plusMenu() {
        this.a.sheet(null, new String[]{"创建群聊", "加好友/群", "传文件", "奶龙聊天室", "发表动态"}, -1, new MainActivity.Str() { // from class: com.changliao.im.HomeScr.6
            @Override // com.changliao.im.MainActivity.Str
            public void ok(String str) {
                if (str.equals("创建群聊")) {
                    HomeScr.this.a.web("newgroup", new String[0]);
                    return;
                }
                if (str.equals("加好友/群")) {
                    HomeScr.this.a.web("search", new String[0]);
                    return;
                }
                if (str.equals("传文件")) {
                    HomeScr.this.C.send(J.of("t", "c_open", "self", 1));
                } else if (str.equals("奶龙聊天室")) {
                    HomeScr.this.a.openChat("g:" + HomeScr.this.C.hall);
                } else {
                    HomeScr.this.a.push(new FeedScr.PostScr());
                }
            }
        });
    }

    void refresh() {
        this.adapter.set(this.C.sortedConvs());
        J j = this.C.info;
        if (this.meNick != null) {
            this.meNick.setText(j == null ? "NAINONG Chat" : j.s("nick"));
            this.meNick.setTextColor(this.C.vip ? -3569152 : Ui.TEXT);
            if (j != null) {
                this.meAv.set(j.s("nick"), j.sn("av"), false);
            }
            this.meSt.setText(this.C.connected ? "在线" : "连接中…");
            this.meDot.setBackground(Ui.oval(this.C.connected ? Ui.GREEN : -3880754));
        }
        int iL = 0;
        for (J j2 : this.C.convs.values()) {
            iL = this.C.mutes.contains(j2.s("conv")) ? iL : (int) (j2.l("reqs") + j2.l("unread") + ((long) iL));
        }
        badge(0, iL);
        badge(1, this.C.fr.a("incoming").size());
        badge(2, this.C.feedUnread);
    }

    void renderContacts() {
        if (this.ctBody == null) {
            return;
        }
        this.ctBody.removeAllViews();
        TextView textViewText = Ui.text(this.a, "搜索 NK号 / 昵称 / 群号", 16.0f, -6643285);
        textViewText.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(14.0f), Ui.dp(9.0f));
        textViewText.setBackground(new RippleDrawable(ColorStateList.valueOf(337016816), new G(3, 14.0f), null));
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.a.web("search", new String[0]);
            }
        });
        this.ctBody.addView(textViewText, Ui.lpm(-1, -2, 14, 10, 14, 2));
        this.ctBody.addView(entry("newf", -30147, -30147, "新朋友", this.C.fr.a("incoming").size(), new View.OnClickListener() { // from class: com.changliao.im.HomeScr.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.a.web("newfriends", new String[0]);
            }
        }));
        this.ctBody.addView(entry("file", -11555586, -14779408, "文件传输助手", 0, new View.OnClickListener() { // from class: com.changliao.im.HomeScr.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.C.send(J.of("t", "c_open", "self", 1));
            }
        }));
        this.ctBody.addView(entry("globe", -20163, -34257, "奶龙聊天室", 0, new View.OnClickListener() { // from class: com.changliao.im.HomeScr.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                HomeScr.this.a.openChat("g:" + HomeScr.this.C.hall);
            }
        }));
        this.ctBody.addView(segView("好友 " + this.C.fr.objs("friends").size(), "群聊 " + new ArrayList(this.C.groups.values()).size()), Ui.lpm(-1, -2, 14, 8, 14, 8));
        this.ctList = Ui.col(this.a);
        fillCt(this.ctList);
        this.ctBody.addView(this.ctList);
        this.ctBody.addView(Ui.space(this.a, 24));
    }

    View segView(String str, String str2) {
        final FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackground(LoginScr.segBg());
        frameLayout.setPadding(Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f));
        LinearLayout linearLayoutRow = Ui.row(this.a);
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 2) {
                break;
            }
            View view = new View(this.a);
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{1811939327, 704643071});
            gradientDrawable.setCornerRadius(Ui.dp(10.0f));
            gradientDrawable.setStroke(Math.max(1, Ui.dp(1.0f)), -1929379841);
            view.setBackground(gradientDrawable);
            LinearLayout.LayoutParams layoutParamsLpm = Ui.lpm(0, -1, i2 == 0 ? 0 : 2, 0, i2 == 0 ? 2 : 0, 0);
            layoutParamsLpm.weight = 1.0f;
            linearLayoutRow.addView(view, layoutParamsLpm);
            i = i2 + 1;
        }
        frameLayout.addView(linearLayoutRow, new FrameLayout.LayoutParams(-1, -1));
        final View view2 = new View(this.a);
        G.on(view2, 0, 10.0f, 2.0f);
        frameLayout.addView(view2, new FrameLayout.LayoutParams(0, -1));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        final TextView[] textViewArr = new TextView[2];
        final String[] strArr = {"friends", "groups"};
        int i3 = 0;
        while (i3 < 2) {
            final int i3f = i3;
            TextView textViewText = Ui.text(this.a, i3 == 0 ? str : str2, 14.0f, Ui.SUB);
            textViewText.setGravity(17);
            textViewText.setPadding(0, Ui.dp(7.0f), 0, Ui.dp(7.0f));
            boolean zEquals = this.seg.equals(strArr[i3]);
            textViewText.setTextColor(zEquals ? Ui.TEXT : Ui.SUB);
            textViewText.setTypeface(zEquals ? LoginScr.bold : null);
            textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.HomeScr.16
                @Override // android.view.View.OnClickListener
                public void onClick(View view3) {
                    if (HomeScr.this.seg.equals(strArr[i3f])) {
                        return;
                    }
                    HomeScr.this.seg = strArr[i3f];
                    HomeScr.this.moveSeg(frameLayout, view2, textViewArr, i3f, true);
                    HomeScr.this.swapCt();
                }
            });
            textViewArr[i3] = textViewText;
            linearLayoutRow2.addView(textViewText, Ui.lp(0, -2, 1.0f));
            i3++;
        }
        frameLayout.addView(linearLayoutRow2, new FrameLayout.LayoutParams(-1, -2));
        linearLayoutRow2.setElevation(Ui.dp(3.0f));
        frameLayout.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.changliao.im.HomeScr.17
            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11) {
                if (i6 - i4 != i10 - i8) {
                    HomeScr.this.moveSeg(frameLayout, view2, textViewArr, HomeScr.this.seg.equals("groups") ? 1 : 0, false);
                }
            }
        });
        return frameLayout;
    }

    void setNavColors() {
        int i = 0;
        while (i < 3) {
            boolean z = i == this.tab;
            int i2 = z ? -14774017 : -11642519;
            this.navLbl[i].setTextColor(i2);
            ((Ico) this.navIco[i].getDrawable()).tint(i2).under(z ? 639537407 : 0);
            if (z) {
                this.navIco[i].setScaleX(0.8f);
                this.navIco[i].setScaleY(0.8f);
                this.navIco[i].animate().scaleX(1.0f).scaleY(1.0f).setDuration(450L).setInterpolator(new OvershootInterpolator(3.0f)).start();
            }
            i++;
        }
    }

    void swapCt() {
        final LinearLayout linearLayout = this.ctList;
        if (linearLayout == null) {
            return;
        }
        final float f = this.seg.equals("groups") ? 1.0f : -1.0f;
        linearLayout.animate().alpha(0.0f).translationX((-f) * Ui.dp(24.0f)).setDuration(120L).withEndAction(new Runnable() { // from class: com.changliao.im.HomeScr.19
            @Override // java.lang.Runnable
            public void run() {
                HomeScr.this.fillCt(linearLayout);
                linearLayout.setTranslationX(f * Ui.dp(24.0f));
                linearLayout.animate().alpha(1.0f).translationX(0.0f).setDuration(220L).setInterpolator(new DecelerateInterpolator(2.0f)).start();
            }
        }).start();
    }

    LinearLayout topBar() {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setMinimumHeight(Ui.dp(56.0f));
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(8.0f), Ui.dp(6.0f));
        return linearLayoutRow;
    }
}
