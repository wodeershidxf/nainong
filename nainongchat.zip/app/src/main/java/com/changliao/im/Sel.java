package com.changliao.im;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.text.Layout;
import android.text.Spannable;
import android.text.style.BackgroundColorSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Sel {
    static Sel cur;
    final MainActivity a;
    final Act cb;
    int e;
    final Handle h1;
    final Handle h2;
    final BackgroundColorSpan hi;
    final List<String[]> items;
    View menu;
    final FrameLayout mk;
    LinearLayout pm;
    int s;
    final Spannable sp;
    final TextView tv;

    public interface Act {
        void act(String str, String str2, boolean z);
    }

    final class Handle extends View {
        float dy;
        int lineH;
        final Paint p;
        final boolean start;

        Handle(Context context, boolean z) {
            super(context);
            this.lineH = Ui.dp(20.0f);
            this.p = new Paint(1);
            this.start = z;
            this.p.setColor(Ui.BLUE);
            setElevation(Ui.dp(2.0f));
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float width = getWidth() / 2.0f;
            float fDp = Ui.dp(6.0f);
            float fDp2 = Ui.dp(2.0f);
            float fDp3 = Ui.dp(14.0f);
            if (this.start) {
                canvas.drawRect(width - (fDp2 / 2.0f), fDp3 - fDp, width + (fDp2 / 2.0f), getHeight(), this.p);
                canvas.drawCircle(width, fDp3 - fDp, fDp, this.p);
            } else {
                canvas.drawRect(width - (fDp2 / 2.0f), 0.0f, width + (fDp2 / 2.0f), this.lineH + fDp, this.p);
                canvas.drawCircle(width, this.lineH + fDp, fDp, this.p);
            }
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent motionEvent) {
            int[] iArr = new int[2];
            Sel.this.a.overlay.getLocationOnScreen(iArr);
            float rawX = motionEvent.getRawX() - iArr[0];
            float rawY = motionEvent.getRawY() - iArr[1];
            switch (motionEvent.getActionMasked()) {
                case G.LIGHT /* 0 */:
                    float[] fArrAt = Sel.this.at(this.start ? Sel.this.s : Sel.this.e, this.start ? false : true);
                    this.dy = ((fArrAt[2] + fArrAt[1]) / 2.0f) - rawY;
                    Sel.this.hideMenu();
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case G.BLUE /* 1 */:
                case G.INSET /* 3 */:
                    Sel.this.showMenu();
                    return true;
                case G.DARK /* 2 */:
                    Sel.this.drag(this.start, rawX, rawY + this.dy);
                    return true;
                default:
                    return true;
            }
        }
    }

    Sel(MainActivity mainActivity, TextView textView, boolean z, List<String[]> list, Act act) {
        this.a = mainActivity;
        this.tv = textView;
        this.items = list;
        this.cb = act;
        this.sp = (Spannable) textView.getText();
        this.hi = new BackgroundColorSpan(z ? 1728053247 : 1293318128);
        this.s = 0;
        this.e = this.sp.length();
        this.mk = new FrameLayout(mainActivity);
        this.mk.setClickable(true);
        this.mk.setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.Sel.1
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() != 0) {
                    return true;
                }
                Sel.this.close();
                return true;
            }
        });
        this.mk.setTag(new Runnable() { // from class: com.changliao.im.Sel.2
            @Override // java.lang.Runnable
            public void run() {
                Sel.this.close();
            }
        });
        this.h1 = new Handle(mainActivity, true);
        this.h2 = new Handle(mainActivity, false);
        this.mk.addView(this.h1, new FrameLayout.LayoutParams(Ui.dp(32.0f), Ui.dp(40.0f)));
        this.mk.addView(this.h2, new FrameLayout.LayoutParams(Ui.dp(32.0f), Ui.dp(40.0f)));
        mainActivity.overlay.addView(this.mk, new FrameLayout.LayoutParams(-1, -1));
        apply();
        this.mk.post(new Runnable() { // from class: com.changliao.im.Sel.3
            @Override // java.lang.Runnable
            public void run() {
                Sel.this.place();
                Sel.this.showMenu();
            }
        });
        mainActivity.vib(15);
    }

    static void lay(View view, int i, int i2, int i3, int i4) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        layoutParams.leftMargin = i;
        layoutParams.topMargin = i2;
        layoutParams.width = i3;
        layoutParams.height = i4;
        view.setLayoutParams(layoutParams);
    }

    public static void start(MainActivity mainActivity, TextView textView, boolean z, List<String[]> list, Act act) {
        if (cur != null) {
            cur.close();
        }
        CharSequence text = textView.getText();
        if (text == null || text.length() == 0) {
            return;
        }
        if (!(text instanceof Spannable)) {
            textView.setText(text, TextView.BufferType.SPANNABLE);
        }
        if (!(textView.getText() instanceof Spannable) || textView.getLayout() == null) {
            return;
        }
        cur = new Sel(mainActivity, textView, z, list, act);
    }

    boolean all() {
        return this.s == 0 && this.e == this.sp.length();
    }

    void apply() {
        this.sp.removeSpan(this.hi);
        if (this.e > this.s) {
            this.sp.setSpan(this.hi, this.s, this.e, 33);
        }
    }

    float[] at(int i, boolean z) {
        float primaryHorizontal;
        Layout layout = this.tv.getLayout();
        int lineForOffset = layout.getLineForOffset(i);
        if (!z || i <= 0 || lineForOffset <= 0 || i != layout.getLineStart(lineForOffset)) {
            primaryHorizontal = layout.getPrimaryHorizontal(i);
        } else {
            lineForOffset--;
            primaryHorizontal = layout.getLineRight(lineForOffset);
        }
        int[] iArrOrg = org();
        return new float[]{primaryHorizontal + iArrOrg[0], iArrOrg[1] + layout.getLineTop(lineForOffset), layout.getLineBottom(lineForOffset) + iArrOrg[1]};
    }

    public void close() {
        if (cur == this) {
            cur = null;
        }
        this.mk.setTag(null);
        this.sp.removeSpan(this.hi);
        this.mk.animate().alpha(0.0f).setDuration(120L).withEndAction(new Runnable() { // from class: com.changliao.im.Sel.6
            @Override // java.lang.Runnable
            public void run() {
                Sel.this.a.overlay.removeView(Sel.this.mk);
            }
        }).start();
    }

    void drag(boolean z, float f, float f2) {
        Layout layout = this.tv.getLayout();
        if (layout == null) {
            return;
        }
        int[] iArrOrg = org();
        int offsetForHorizontal = layout.getOffsetForHorizontal(layout.getLineForVertical((int) Math.max(0.0f, Math.min(layout.getHeight() - 1, f2 - iArrOrg[1]))), f - iArrOrg[0]);
        if (z) {
            int iMin = Math.min(offsetForHorizontal, this.e - 1);
            if (iMin != this.s && iMin >= 0) {
                this.s = iMin;
                this.a.vib(5);
            }
        } else {
            int iMax = Math.max(offsetForHorizontal, this.s + 1);
            if (iMax != this.e && iMax <= this.sp.length()) {
                this.e = iMax;
                this.a.vib(5);
            }
        }
        apply();
        place();
    }

    void hideMenu() {
        if (this.menu == null) {
            return;
        }
        final View view = this.menu;
        this.menu = null;
        view.animate().alpha(0.0f).setDuration(100L).withEndAction(new Runnable() { // from class: com.changliao.im.Sel.4
            @Override // java.lang.Runnable
            public void run() {
                Sel.this.mk.removeView(view);
            }
        }).start();
    }

    int[] org() {
        int[] iArr = new int[2];
        this.tv.getLocationInWindow(iArr);
        int[] iArr2 = new int[2];
        this.a.overlay.getLocationInWindow(iArr2);
        return new int[]{((iArr[0] - iArr2[0]) + this.tv.getTotalPaddingLeft()) - this.tv.getScrollX(), ((iArr[1] - iArr2[1]) + this.tv.getTotalPaddingTop()) - this.tv.getScrollY()};
    }

    void pick(String str) {
        if (str.equals("全选")) {
            this.s = 0;
            this.e = this.sp.length();
            apply();
            place();
            showMenu();
            return;
        }
        String strText = text();
        boolean zAll = all();
        close();
        try {
            this.cb.act(str, strText, zAll);
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    void place() {
        if (this.tv.getLayout() == null) {
            return;
        }
        float[] fArrAt = at(this.s, false);
        float[] fArrAt2 = at(this.e, true);
        this.h1.lineH = (int) (fArrAt[2] - fArrAt[1]);
        this.h2.lineH = (int) (fArrAt2[2] - fArrAt2[1]);
        int iDp = Ui.dp(32.0f);
        int iDp2 = Ui.dp(14.0f);
        lay(this.h1, ((int) fArrAt[0]) - (iDp / 2), ((int) fArrAt[1]) - iDp2, iDp, this.h1.lineH + iDp2);
        lay(this.h2, ((int) fArrAt2[0]) - (iDp / 2), (int) fArrAt2[1], iDp, iDp2 + this.h2.lineH);
        this.h1.invalidate();
        this.h2.invalidate();
    }

    void showMenu() {
        if (this.menu != null) {
            this.mk.removeView(this.menu);
        }
        this.pm = Ui.row(this.a);
        this.pm.setPadding(Ui.dp(6.0f), Ui.dp(6.0f), Ui.dp(6.0f), Ui.dp(6.0f));
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-231063993, -265934544});
        gradientDrawable.setCornerRadius(Ui.dp(16.0f));
        this.pm.setBackground(new LayerDrawable(new Drawable[]{gradientDrawable, new G(2, 16.0f)}));
        this.pm.setElevation(Ui.dp(14.0f));
        for (final String[] strArr : this.items) {
            if (!strArr[0].equals("selall") || !all()) {
                LinearLayout linearLayoutCol = Ui.col(this.a);
                linearLayoutCol.setGravity(17);
                linearLayoutCol.setPadding(Ui.dp(10.0f), Ui.dp(8.0f), Ui.dp(10.0f), Ui.dp(8.0f));
                linearLayoutCol.setMinimumWidth(Ui.dp(56.0f));
                int i = strArr[0].equals("undo") ? -30070 : -1;
                ImageView imageView = new ImageView(this.a);
                imageView.setImageDrawable(new Ico(strArr[0], i));
                linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(24.0f), Ui.dp(24.0f)));
                linearLayoutCol.addView(Ui.text(this.a, strArr[1], 12.0f, i), Ui.lpm(-2, -2, 0, 4, 0, 0));
                linearLayoutCol.setBackground(Ui.ripple(new ColorDrawable(0), 10.0f));
                linearLayoutCol.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.Sel.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        Sel.this.pick(strArr[1]);
                    }
                });
                this.pm.addView(linearLayoutCol);
            }
        }
        ChatScr.HorizontalScroll horizontalScroll = new ChatScr.HorizontalScroll(this.a);
        horizontalScroll.addView(this.pm);
        this.pm.measure(0, 0);
        int width = this.a.overlay.getWidth();
        int height = this.a.overlay.getHeight();
        int iMin = Math.min(this.pm.getMeasuredWidth(), width - Ui.dp(16.0f));
        int measuredHeight = this.pm.getMeasuredHeight();
        float[] fArrAt = at(this.s, false);
        float[] fArrAt2 = at(this.e, true);
        int[] iArrOrg = org();
        float fMax = Math.max(iArrOrg[0], Math.min(iArrOrg[0] + this.tv.getWidth(), (fArrAt[0] + fArrAt2[0]) / 2.0f));
        int iMax = Math.max(Ui.dp(8.0f), Math.min((width - iMin) - Ui.dp(8.0f), ((int) fMax) - (iMin / 2)));
        int iDp = (((int) fArrAt[1]) - measuredHeight) - Ui.dp(22.0f);
        boolean z = iDp < Ui.dp(56.0f);
        if (z) {
            iDp = ((int) fArrAt2[2]) + Ui.dp(22.0f);
        }
        int iMax2 = Math.max(Ui.dp(8.0f), Math.min((height - measuredHeight) - Ui.dp(8.0f), iDp));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(iMin, measuredHeight);
        layoutParams.leftMargin = iMax;
        layoutParams.topMargin = iMax2;
        this.mk.addView(horizontalScroll, layoutParams);
        this.menu = horizontalScroll;
        this.pm.setPivotX(Math.max(0.0f, Math.min(iMin, fMax - iMax)));
        this.pm.setPivotY(z ? 0.0f : measuredHeight);
        this.pm.setScaleX(0.8f);
        this.pm.setScaleY(0.8f);
        this.pm.setAlpha(0.0f);
        this.pm.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(260L).setInterpolator(new OvershootInterpolator(1.8f)).start();
    }

    String text() {
        return this.sp.subSequence(Math.max(0, this.s), Math.min(this.sp.length(), this.e)).toString();
    }
}
