package com.changliao.im;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public class Core {
    public boolean authed = true; // PATCH(需求2): 认证闸门默认放行，不再等 auth_ok
    public J ban;
    public int bugN;
    int cidN;
    public boolean connected;
    long failN;
    public int feedUnread;
    public boolean foreground;
    private boolean hbOn;
    public J info;
    public boolean isOwner;
    private long lastRx;
    public String openConv;
    private boolean reconn;
    public int reportsN;
    private int retry;
    private boolean started;
    public boolean vip;
    private Ws ws;
    public static final Core I = new Core();
    public static Executor main = new Executor() { // from class: com.changliao.im.Core.1
        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            runnable.run();
        }
    };
    public static Kv kv = new Kv() { // from class: com.changliao.im.Core.2
        final Map<String, String> m = new HashMap();

        @Override // com.changliao.im.Core.Kv
        public String get(String str) {
            return this.m.get(str);
        }

        @Override // com.changliao.im.Core.Kv
        public void put(String str, String str2) {
            if (str2 == null) {
                this.m.remove(str);
            } else {
                this.m.put(str, str2);
            }
        }
    };
    public static Timer timer = new Timer() { // from class: com.changliao.im.Core.3
        @Override // com.changliao.im.Core.Timer
        public void later(final Runnable runnable, final long j) {
            Thread thread = new Thread(new Runnable() { // from class: com.changliao.im.Core.3.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(j);
                        Core.main.execute(runnable);
                    } catch (Exception e) {
                    }
                }
            });
            thread.setDaemon(true);
            thread.start();
        }
    };
    public String bubble = "";
    public String hall = "10000";
    public final LinkedHashMap<String, J> convs = new LinkedHashMap<>();
    public final Map<String, List<J>> msgs = new HashMap();
    public final Map<String, Boolean> more = new HashMap();
    public final Map<String, J> groups = new LinkedHashMap();
    public final Map<String, J> ginfo = new HashMap();
    public J fr = J.of("friends", new ArrayList(), "incoming", new ArrayList(), "outgoing", new ArrayList());
    public List<J> anns = new ArrayList();
    public List<J> wc = new ArrayList();
    public List<Object> stk = new ArrayList();
    public final Set<String> mutes = new HashSet();
    private final CopyOnWriteArrayList<L> ls = new CopyOnWriteArrayList<>();
    private final Runnable hb = new Runnable() { // from class: com.changliao.im.Core.4
        @Override // java.lang.Runnable
        public void run() {
            Core.timer.later(this, 20000L);
            if (Core.this.ws == null || !Core.this.connected) {
                return;
            }
            if (System.currentTimeMillis() - Core.this.lastRx > 55000) {
                Core.this.ws.close();
            } else if (Core.this.authed) {
                Core.this.sendQ(J.of("t", "c_hb"));
            }
        }
    };
    final LinkedHashMap<String, J> pend = new LinkedHashMap<>();

    /* JADX INFO: renamed from: com.changliao.im.Core$6, reason: invalid class name */
    class AnonymousClass6 implements Ws.L {
        AnonymousClass6() {
        }

        @Override // com.changliao.im.Ws.L
        public void closed(final Ws ws, String str) {
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Core.6.3
                @Override // java.lang.Runnable
                public void run() {
                    if (Core.this.ws != ws) {
                        return;
                    }
                    Core.this.connected = false;
                    Core.this.ws = null;
                    Core.access$208(Core.this);
                    Core.this.emit("conn", null);
                    Core.timer.later(new Runnable() { // from class: com.changliao.im.Core.6.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (Core.this.ws == null) {
                                Core.this.connect();
                            }
                        }
                    }, Math.min(8000L, 1200 * ((long) Core.this.retry)));
                }
            });
        }

        @Override // com.changliao.im.Ws.L
        public void open(final Ws ws) {
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Core.6.1
                @Override // java.lang.Runnable
                public void run() {
                    if (Core.this.ws != ws) {
                        return;
                    }
                    Core.this.connected = true;
                    Core.this.retry = 0;
                    Core.this.reconn = true;
                    Core.this.lastRx = System.currentTimeMillis();
                    Core.this.emit("conn", null);
                    Core.this.send(J.of("t", "acct_hello", "tok", Core.this.token()));
                }
            });
        }

        @Override // com.changliao.im.Ws.L
        public void text(final Ws ws, String str) {
            final J jObj = J.obj(str);
            if (jObj == null) {
                return;
            }
            Core.main.execute(new Runnable() { // from class: com.changliao.im.Core.6.2
                @Override // java.lang.Runnable
                public void run() {
                    if (Core.this.ws != ws) {
                        return;
                    }
                    Core.this.lastRx = System.currentTimeMillis();
                    try {
                        Core.this.onMsg(jObj);
                    } catch (Throwable th) {
                        Crash.note(th);
                    }
                }
            });
        }
    }

    public interface Kv {
        String get(String str);

        void put(String str, String str2);
    }

    public interface L {
        void on(String str, J j);
    }

    public interface Timer {
        void later(Runnable runnable, long j);
    }

    static /* synthetic */ int access$208(Core core) {
        int i = core.retry;
        core.retry = i + 1;
        return i;
    }

    public static String avUrl(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        return http() + "/cf/" + str + "/a.jpg";
    }

    static String defHost() {
        int[] iArr = {54, 102, 102, 52, 32, 47, 43};
        int[] iArr2 = {14, 72, 87, 1, 22, 1, 24, 0, 72, 87, 13, 26, 23, 28, 0, 83};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < iArr2.length; i++) {
            sb.append((char) (iArr2[i] ^ iArr[i % iArr.length]));
        }
        return sb.toString();
    }

    public static String fileUrl(String str, String str2) {
        try {
            StringBuilder sbAppend = new StringBuilder().append(http()).append("/cf/").append(str).append("/");
            if (str2 == null || str2.length() == 0) {
                str2 = "f";
            }
            return sbAppend.append(URLEncoder.encode(str2, "UTF-8").replace("+", "%20")).toString();
        } catch (Exception e) {
            return http() + "/cf/" + str + "/f";
        }
    }

    public static String hostPort() {
        String str = kv.get("server");
        return (str == null || str.length() <= 0) ? defHost() : str;
    }

    public static String http() {
        return "http://" + hostPort();
    }

    public static boolean isSelf(String str) {
        if (str == null || !str.startsWith("p:")) {
            return false;
        }
        String[] strArrSplit = str.substring(2).split("\\|");
        return strArrSplit.length == 2 && strArrSplit[0].equals(strArrSplit[1]);
    }

    public void add(L l) {
        if (this.ls.contains(l)) {
            return;
        }
        this.ls.add(l);
    }

    public boolean banned() {
        return this.ban != null && (this.ban.l("until") == 0 || this.ban.l("until") > System.currentTimeMillis() / 1000);
    }

    void confirm(String str, J j) {
        String strS = j.s("k");
        Iterator<Map.Entry<String, J>> it = this.pend.entrySet().iterator();
        while (it.hasNext()) {
            J value = it.next().getValue();
            if (value.s("conv").equals(str) && value.s("k").equals(strS) && (!strS.equals("text") || value.s("text").equals(j.s("text")))) {
                it.remove();
                return;
            }
        }
        for (J j2 : fails(str)) {
            if (j2.b("fail") && j2.s("why").equals("timeout") && j2.s("k").equals(strS) && (!strS.equals("text") || j2.s("text").equals(j.s("text")))) {
                dropFail(j2);
                emit("hist", J.of("conv", str, "keep", true));
                return;
            }
        }
    }

    void connect() {
        String strSubstring;
        int i = 80;
        String strHostPort = hostPort();
        int iLastIndexOf = strHostPort.lastIndexOf(58);
        if (iLastIndexOf > 0) {
            strSubstring = strHostPort.substring(0, iLastIndexOf);
            try {
                i = Integer.parseInt(strHostPort.substring(iLastIndexOf + 1));
            } catch (Exception e) {
            }
        } else {
            strSubstring = strHostPort;
        }
        this.connected = false;
        emit("conn", null);
        Ws ws = new Ws(strSubstring, i, new AnonymousClass6());
        this.ws = ws;
        ws.start();
    }

    void dropFail(J j) {
        String strS = j.s("conv");
        long jL = j.l("id");
        List<J> listFails = fails(strS);
        for (int size = listFails.size() - 1; size >= 0; size--) {
            if (listFails.get(size).l("id") == jL || listFails.get(size).l("id") == jL - 1) {
                listFails.remove(size);
            }
        }
        saveFails(strS, listFails);
        List<J> list = this.msgs.get(strS);
        if (list != null) {
            for (int size2 = list.size() - 1; size2 >= 0; size2--) {
                if (list.get(size2).l("id") == jL || list.get(size2).l("id") == jL - 1) {
                    list.remove(size2);
                }
            }
        }
    }

    void emit(String str, J j) {
        Iterator<L> it = this.ls.iterator();
        while (it.hasNext()) {
            try {
                it.next().on(str, j);
            } catch (Throwable th) {
                Crash.note(th);
            }
        }
    }

    public void enter() {
        this.authed = true;
        send(J.of("t", "c_hello", "native", 1));
        emit("enter", null);
    }

    public void failLocal(J j) {
        StringBuilder sbAppend = new StringBuilder().append("L").append(Long.toString(System.currentTimeMillis(), 36));
        int i = this.cidN + 1;
        this.cidN = i;
        String string = sbAppend.append(Integer.toString(i, 36)).toString();
        j.put("cid", string);
        this.pend.put(string, j);
        failed(J.of("conv", j.s("conv"), "cid", string, "why", "offline"));
    }

    void failed(J j) {
        String str;
        String strS;
        J jRemove = this.pend.remove(j.s("cid"));
        String strS2 = j.s("conv");
        String strS3 = j.s("why");
        if (jRemove == null) {
            Object[] objArr = new Object[4];
            objArr[0] = "msg";
            objArr[1] = j.s("msg").length() > 0 ? j.s("msg") : "消息发送失败";
            objArr[2] = "err";
            objArr[3] = true;
            emit("toast", J.of(objArr));
            return;
        }
        long jCurrentTimeMillis = System.currentTimeMillis() / 1000;
        String strS4 = jRemove.s("k");
        Object[] objArr2 = new Object[28];
        objArr2[0] = "id";
        long jCurrentTimeMillis2 = System.currentTimeMillis() * 4;
        long j2 = this.failN + 1;
        this.failN = j2;
        objArr2[1] = Long.valueOf(-(jCurrentTimeMillis2 + ((j2 % 2) * 2)));
        objArr2[2] = "conv";
        objArr2[3] = strS2;
        objArr2[4] = "mine";
        objArr2[5] = true;
        objArr2[6] = "ts";
        objArr2[7] = Long.valueOf(jCurrentTimeMillis);
        objArr2[8] = "k";
        objArr2[9] = strS4;
        objArr2[10] = "text";
        objArr2[11] = jRemove.s("text");
        objArr2[12] = "fail";
        objArr2[13] = true;
        objArr2[14] = "why";
        objArr2[15] = strS3;
        objArr2[16] = "send";
        objArr2[17] = jRemove;
        objArr2[18] = "from";
        objArr2[19] = myNick();
        objArr2[20] = "name";
        objArr2[21] = myNick();
        objArr2[22] = "av";
        objArr2[23] = this.info == null ? null : this.info.sn("av");
        objArr2[24] = "vip";
        objArr2[25] = Boolean.valueOf(this.vip);
        objArr2[26] = "bubble";
        objArr2[27] = this.bubble;
        J jOf = J.of(objArr2);
        if (jRemove.has("fid")) {
            Object[] objArr3 = new Object[14];
            objArr3[0] = "id";
            objArr3[1] = jRemove.s("fid");
            objArr3[2] = "w";
            objArr3[3] = Long.valueOf(jRemove.l("w"));
            objArr3[4] = "h";
            objArr3[5] = Long.valueOf(jRemove.l("h"));
            objArr3[6] = "dur";
            objArr3[7] = Long.valueOf(jRemove.l("dur"));
            objArr3[8] = "stk";
            objArr3[9] = Boolean.valueOf(jRemove.b("stk"));
            objArr3[10] = "name";
            objArr3[11] = strS4.equals("file") ? "文件" : "";
            objArr3[12] = "size";
            objArr3[13] = 0;
            J jOf2 = J.of(objArr3);
            if (jRemove.has("poster")) {
                jOf2.put("poster", jRemove.s("poster"));
            }
            jOf.put("f", jOf2);
        }
        if (strS3.equals("notfriend")) {
            str = "对方已不是你的好友，消息未送达。请先加为好友再聊天。";
        } else if (strS3.equals("err")) {
            str = "消息发送失败：" + j.s("msg");
        } else {
            str = strS3.equals("offline") ? "没有连上服务器，消息没有发出去。点红色感叹号可以重发。" : "网络不好，消息可能没有发出去。点红色感叹号可以重发。";
        }
        J jOf3 = J.of("id", Long.valueOf(jOf.l("id") - 1), "conv", strS2, "ts", Long.valueOf(jCurrentTimeMillis), "k", "sys", "text", str, "ftip", true);
        List<J> listFails = fails(strS2);
        listFails.add(jOf);
        listFails.add(jOf3);
        saveFails(strS2, listFails);
        List list = this.msgs.get(strS2);
        if (list != null) {
            list.add(jOf);
            list.add(jOf3);
        }
        J j3 = this.convs.get(strS2);
        if (j3 != null) {
            StringBuilder sbAppend = new StringBuilder().append("[发送失败] ");
            if (strS4.equals("text")) {
                strS = jRemove.s("text");
            } else if (strS4.equals("img")) {
                strS = "[图片]";
            } else if (strS4.equals("video")) {
                strS = "[视频]";
            } else {
                strS = strS4.equals("voice") ? "[语音]" : "[文件]";
            }
            j3.put("pv", sbAppend.append(strS).toString());
            j3.put("ts", Long.valueOf(jCurrentTimeMillis));
        }
        if (strS3.equals("err") && j.s("msg").length() > 0) {
            emit("toast", J.of("msg", j.s("msg"), "err", true));
        }
        emit("msg", J.of("m", jOf));
        emit("convs", null);
    }

    List<J> fails(String str) {
        Object obj = J.parse(kv.get(new StringBuilder().append("fail:").append(str).toString()) == null ? "[]" : kv.get("fail:" + str));
        ArrayList arrayList = new ArrayList();
        if (obj instanceof List) {
            for (Object obj2 : (List) obj) {
                if (obj2 instanceof J) {
                    arrayList.add((J) obj2);
                }
            }
        }
        return arrayList;
    }

    public boolean hidden(String str) {
        String str2 = kv.get("hide:" + str);
        J j = this.convs.get(str);
        return (str2 == null || j == null || j.l("ts") > Long.parseLong(str2)) ? false : true;
    }

    public void hide(String str) {
        J j = this.convs.get(str);
        kv.put("hide:" + str, String.valueOf(j == null ? System.currentTimeMillis() / 1000 : j.l("ts")));
        emit("convs", null);
    }

    public boolean isHall(String str) {
        return ("g:" + this.hall).equals(str);
    }

    public void logout() {
        send(J.of("t", "acct_logout", "tok", token()));
        kv.put("tok", null);
        this.authed = false;
        this.info = null;
        this.convs.clear();
        this.msgs.clear();
        this.groups.clear();
        this.ginfo.clear();
        emit("need", null);
    }

    public void markRead(String str, boolean z) {
        J j = this.convs.get(str);
        if (j == null) {
            return;
        }
        if (j.l("unread") > 0 || j.b("atme") || z) {
            j.put("unread", 0L);
            j.put("atme", false);
            sendQ(J.of("t", "c_read", "conv", str));
            emit("convs", null);
        }
    }

    void mergeFails(String str, List<J> list) {
        for (J j : fails(str)) {
            int size = list.size();
            int i = 0;
            while (true) {
                if (i >= list.size()) {
                    i = size;
                    break;
                } else if (list.get(i).l("ts") > j.l("ts")) {
                    break;
                } else {
                    i++;
                }
            }
            Iterator<J> it = list.iterator();
            boolean z = false;
            while (it.hasNext()) {
                z = it.next().l("id") == j.l("id") ? true : z;
            }
            if (!z) {
                list.add(i, j);
            }
        }
    }

    public String myNick() {
        return this.info == null ? "" : this.info.s("nick");
    }

    void onChat(J j) {
        boolean z;
        J jO = j.o("m");
        if (jO == null) {
            return;
        }
        String strS = jO.s("conv");
        J jOf = this.convs.get(strS);
        if (jOf == null) {
            jOf = J.of("conv", strS, "title", j.s("title"));
            this.convs.put(strS, jOf);
        }
        J j2 = jOf;
        if (j.has("title")) {
            j2.put("title", j.s("title"));
        }
        j2.put("pv", j.s("pv"));
        j2.put("ts", Long.valueOf(jO.l("ts")));
        boolean z2 = strS.equals(this.openConv) && this.foreground;
        boolean zEquals = jO.s("k").equals("sys");
        if (!jO.b("mine") && !z2 && !zEquals) {
            j2.put("unread", Long.valueOf(j2.l("unread") + 1));
            if (jO.b("atme")) {
                j2.put("atme", true);
            }
        }
        if (jO.b("mine")) {
            confirm(strS, jO);
        }
        List<J> list = this.msgs.get(strS);
        if (list != null) {
            Iterator<J> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    z = false;
                    break;
                } else if (it.next().l("id") == jO.l("id")) {
                    z = true;
                    break;
                }
            }
            if (!z) {
                list.add(jO);
            }
        }
        emit("msg", j);
        emit("convs", j);
        if (z2) {
            markRead(strS, true);
        }
        if (jO.b("mine") || z2 || zEquals) {
            return;
        }
        if (!this.mutes.contains(strS) || jO.b("atme")) {
            emit("note", J.of("title", j2.s("title"), "text", (jO.b("atme") ? "[有人@我] " : "") + j.s("pv"), "conv", strS, "fg", Boolean.valueOf(this.foreground)));
        }
    }

    void onMsg(J j) {
        boolean z;
        String strS = j.s("t");
        if (strS.equals("acct_need")) {
            // PATCH(需求2): 服务端要求认证时不再回登录页，直接本地放行进聊天
            enter();
            return;
        }
        if (strS.equals("auth_ok")) {
            if (j.has("token")) {
                kv.put("tok", j.s("token"));
            }
            kv.put("email", j.s("email"));
            return;
        }
        if (strS.equals("acct_ok")) {
            if (j.has("token")) {
                kv.put("tok", j.s("token"));
            }
            kv.put("email", j.s("email"));
            boolean z2 = this.authed;
            this.info = J.of("email", j.s("email"), "nick", j.s("nick"), "role", j.s("role"), "has_pw", Boolean.valueOf(j.b("has_pw")), "av", j.sn("av"), "nk", j.s("nk"), "bio", j.s("bio"), "likes", Long.valueOf(j.l("likes")), "vip", Boolean.valueOf(this.vip));
            emit("poll", null);
            if (z2) {
                if (this.reconn) {
                    this.reconn = false;
                    send(J.of("t", "c_hello", "native", 1));
                }
                if (j.has("msg")) {
                    emit("toast", J.of("msg", j.s("msg")));
                }
                emit("me", j);
                return;
            }
            this.reconn = false;
            // PATCH(需求2): nick / pw 补全步骤一并跳过 —— 原来这里是 need_nick / need_pw 分支，
            // 会 reset 回 LoginScr 卡住；改为直接 enter() 进聊天。
            enter();
            return;
        }
        if (strS.equals("auth_sent")) {
            emit("auth_msg", J.of("msg", "验证码已发到 " + j.s("email") + "，请查收（也看看垃圾邮件）", "ok", true));
            return;
        }
        if (strS.equals("auth_err") || strS.equals("acct_err")) {
            if (this.authed) {
                emit("toast", J.of("msg", j.s("msg"), "err", true));
                return;
            } else {
                emit("auth_msg", J.of("msg", j.s("msg"), "ok", false));
                return;
            }
        }
        if (strS.equals("acct_msg") || strS.equals("c_ok") || strS.equals("c_toast")) {
            emit("toast", J.of("msg", j.s("msg")));
            return;
        }
        if (strS.equals("c_err")) {
            emit("toast", J.of("msg", j.s("msg"), "err", true));
            return;
        }
        if (strS.equals("c_me")) {
            if (this.info != null) {
                this.info.put("av", j.sn("av"));
                if (j.has("bio")) {
                    this.info.put("bio", j.s("bio"));
                }
            }
            emit("me", j);
            return;
        }
        if (strS.equals("c_init")) {
            this.convs.clear();
            for (J j2 : j.objs("convs")) {
                this.convs.put(j2.s("conv"), j2);
            }
            this.groups.clear();
            for (J j3 : j.objs("groups")) {
                this.groups.put(j3.s("gid"), j3);
            }
            this.isOwner = j.b("owner");
            this.vip = j.b("vip");
            this.bubble = j.s("bubble");
            this.stk = j.a("stk");
            if (this.info != null) {
                this.info.put("vip", Boolean.valueOf(this.vip));
                this.info.put("bubble", this.bubble);
            }
            this.hall = j.has("hall") ? j.s("hall") : "10000";
            this.anns = j.objs("anns");
            this.bugN = j.i("bugs");
            this.reportsN = j.i("reports");
            emit("convs", j);
            emit("anns", j);
            emit("me", j);
            if (this.openConv != null) {
                sendQ(J.of("t", "c_hist", "conv", this.openConv));
                if (this.openConv.startsWith("g:")) {
                    sendQ(J.of("t", "c_ginfo", "gid", this.openConv.substring(2)));
                    return;
                }
                return;
            }
            return;
        }
        if (strS.equals("c_msg")) {
            onChat(j);
            return;
        }
        if (strS.equals("c_conv") || strS.equals("c_opened")) {
            J jO = j.o("s");
            if (jO != null) {
                J j4 = this.convs.get(jO.s("conv"));
                if (j4 != null) {
                    j4.putAll(jO);
                } else {
                    this.convs.put(jO.s("conv"), jO);
                }
                emit("convs", j);
                if (strS.equals("c_opened")) {
                    emit("open", J.of("conv", jO.s("conv")));
                    return;
                }
                return;
            }
            return;
        }
        if (strS.equals("c_hist")) {
            String strS2 = j.s("conv");
            List<J> list = this.msgs.get(strS2);
            List<J> listObjs = j.objs("l");
            if (j.l("before") <= 0 || list == null) {
                long jL = listObjs.isEmpty() ? 0L : listObjs.get(listObjs.size() - 1).l("id");
                HashSet hashSet = new HashSet();
                Iterator<J> it = listObjs.iterator();
                while (it.hasNext()) {
                    hashSet.add(Long.valueOf(it.next().l("id")));
                }
                long jMin = Long.MAX_VALUE;
                for (J j5 : listObjs) {
                    if (j5.l("id") > 0) {
                        jMin = Math.min(jMin, j5.l("id"));
                    }
                }
                ArrayList<J> arrayList = new ArrayList(listObjs);
                if (list != null) {
                    for (J j6 : list) {
                        if (j6.l("id") > jL || (!listObjs.isEmpty() && j6.l("id") > 0 && j6.l("id") < jMin)) {
                            if (hashSet.add(Long.valueOf(j6.l("id")))) {
                                arrayList.add(j6);
                            }
                        }
                    }
                }
                ArrayList arrayList2 = new ArrayList();
                for (J j7 : arrayList) {
                    if (j7.l("id") > 0) {
                        arrayList2.add(j7);
                    }
                }
                Collections.sort(arrayList2, new Comparator<J>() { // from class: com.changliao.im.Core.8
                    @Override // java.util.Comparator
                    public int compare(J j8, J j9) {
                        return Long.compare(j8.l("id"), j9.l("id"));
                    }
                });
                mergeFails(strS2, arrayList2);
                this.msgs.put(strS2, arrayList2);
            } else {
                long jL2 = j.l("before");
                ArrayList arrayList3 = new ArrayList(listObjs);
                for (J j8 : list) {
                    if (j8.l("id") >= jL2 || j8.l("id") < 0) {
                        arrayList3.add(j8);
                    }
                }
                this.msgs.put(strS2, arrayList3);
            }
            this.more.put(strS2, Boolean.valueOf(j.b("more")));
            emit("hist", j);
            if (strS2.equals(this.openConv)) {
                markRead(strS2, false);
                return;
            }
            return;
        }
        if (strS.equals("c_recall")) {
            String strS3 = j.s("conv");
            J jO2 = j.o("m");
            List<J> list2 = this.msgs.get(strS3);
            if (list2 != null && jO2 != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= list2.size()) {
                        break;
                    }
                    if (list2.get(i2).l("id") == jO2.l("id")) {
                        list2.set(i2, jO2);
                    }
                    i = i2 + 1;
                }
            }
            J jO3 = j.o("s");
            if (jO3 != null) {
                this.convs.put(jO3.s("conv"), jO3);
            }
            emit("convs", j);
            emit("hist", J.of("conv", strS3, "keep", true));
            return;
        }
        if (strS.equals("c_gcreated")) {
            J jO4 = j.o("s");
            if (jO4 != null) {
                this.convs.put(jO4.s("conv"), jO4);
            }
            Map<String, J> map = this.groups;
            String strS4 = j.s("gid");
            Object[] objArr = new Object[6];
            objArr[0] = "gid";
            objArr[1] = j.s("gid");
            objArr[2] = "name";
            objArr[3] = jO4 == null ? "" : jO4.s("title");
            objArr[4] = "n";
            objArr[5] = Long.valueOf(jO4 == null ? 0L : jO4.l("n"));
            map.put(strS4, J.of(objArr));
            emit("convs", j);
            emit("groups", j);
            if (j.b("quiet") || jO4 == null) {
                return;
            }
            emit("open", J.of("conv", jO4.s("conv")));
            return;
        }
        if (strS.equals("c_group")) {
            J jO5 = j.o("g");
            if (jO5 != null) {
                this.groups.put(j.s("gid"), jO5);
            }
            J jO6 = j.o("s");
            if (jO6 != null) {
                J j9 = this.convs.get(jO6.s("conv"));
                if (j9 != null) {
                    j9.putAll(jO6);
                } else {
                    this.convs.put(jO6.s("conv"), jO6);
                }
            }
            emit("convs", j);
            emit("groups", j);
            if (this.ginfo.containsKey(j.s("gid"))) {
                send(J.of("t", "c_ginfo", "gid", j.s("gid")));
                return;
            }
            return;
        }
        if (strS.equals("c_gone")) {
            this.groups.remove(j.s("gid"));
            this.convs.remove("g:" + j.s("gid"));
            this.ginfo.remove(j.s("gid"));
            emit("convs", j);
            emit("groups", j);
            emit("gone", j);
            emit("toast", J.of("msg", j.s("why"), "err", true));
            return;
        }
        if (strS.equals("c_ginfo")) {
            this.ginfo.put(j.s("gid"), j);
            J j10 = this.groups.get(j.s("gid"));
            if (j10 != null) {
                j10.put("name", j.s("name"));
                j10.put("n", Long.valueOf(j.a("members").size()));
                j10.put("role", j.s("myrole"));
            }
            emit("ginfo", j);
            return;
        }
        if (strS.equals("fr_list")) {
            this.fr = j;
            for (J j11 : j.objs("friends")) {
                for (J j12 : this.convs.values()) {
                    if (j12.s("conv").startsWith("p:") && j12.s("nk").equals(j11.s("nk"))) {
                        j12.put("online", Boolean.valueOf(j11.b("online")));
                    }
                }
            }
            emit("friends", j);
            emit("convs", j);
            return;
        }
        if (strS.equals("wc_hist")) {
            this.wc = j.objs("l");
            emit("wc", j);
            return;
        }
        if (strS.equals("wc")) {
            this.wc.add(j);
            if (this.wc.size() > 200) {
                this.wc.remove(0);
            }
            emit("wc", j);
            return;
        }
        if (strS.equals("c_ann")) {
            J jO7 = j.o("a");
            if (jO7 != null) {
                boolean z3 = false;
                Iterator<J> it2 = this.anns.iterator();
                while (true) {
                    z = z3;
                    if (!it2.hasNext()) {
                        break;
                    } else {
                        z3 = it2.next().l("id") == jO7.l("id") ? true : z;
                    }
                }
                if (!z) {
                    this.anns.add(jO7);
                }
            }
            emit("anns", j);
            emit("ann_new", j);
            return;
        }
        if (strS.equals("c_anns")) {
            this.anns = j.objs("l");
            emit("anns", j);
            return;
        }
        if (strS.equals("c_bug_ping")) {
            this.bugN++;
            emit("me", j);
            Object[] objArr2 = new Object[4];
            objArr2[0] = "title";
            objArr2[1] = "🐞 新的Bug反馈";
            objArr2[2] = "text";
            objArr2[3] = j.o("b") == null ? "" : j.o("b").s("nick") + "：" + j.o("b").s("text");
            emit("note", J.of(objArr2));
            return;
        }
        if (strS.equals("c_bug_upd")) {
            J jO8 = j.o("b");
            String str = (jO8 == null || jO8.s("reply").length() <= 0) ? "系统已读了你的Bug反馈" : "系统回复了你的Bug反馈：" + jO8.s("reply");
            emit("toast", J.of("msg", "🐞 " + str));
            emit("note", J.of("title", "🐞 Bug反馈", "text", str));
            return;
        }
        if (strS.equals("c_reports_ping")) {
            this.reportsN++;
            emit("me", j);
            emit(strS, j);
            return;
        }
        if (strS.equals("c_vipme")) {
            this.vip = j.b("vip");
            this.bubble = j.s("bubble");
            if (this.info != null) {
                this.info.put("vip", Boolean.valueOf(this.vip));
                this.info.put("bubble", this.bubble);
            }
            emit(strS, j);
            emit("me", j);
            return;
        }
        if (strS.equals("c_cleared")) {
            kv.put("fail:" + j.s("conv"), null);
            this.msgs.put(j.s("conv"), new ArrayList());
            this.more.put(j.s("conv"), false);
            J j13 = this.convs.get(j.s("conv"));
            if (j13 != null) {
                j13.put("pv", "");
            }
            emit("hist", J.of("conv", j.s("conv")));
            emit("convs", j);
            emit("toast", J.of("msg", "聊天记录已删除"));
            return;
        }
        if (strS.equals("c_feed_new")) {
            J jO9 = j.o("p");
            if (this.info != null && !j.s("by").equals(this.info.s("nk"))) {
                this.feedUnread++;
                Object[] objArr3 = new Object[4];
                objArr3[0] = "title";
                objArr3[1] = jO9 == null ? "动态" : jO9.s("nick");
                objArr3[2] = "text";
                objArr3[3] = "发表了新动态";
                emit("note", J.of(objArr3));
            }
            emit(strS, j);
            emit("me", j);
            return;
        }
        if (strS.equals("c_feed_ping")) {
            this.feedUnread++;
            emit("toast", J.of("msg", j.s("msg")));
            emit(strS, j);
            emit("me", j);
            return;
        }
        if (strS.equals("c_call") || strS.equals("c_gcall")) {
            emit(strS, j);
            return;
        }
        if (strS.equals("c_poked")) {
            emit("poked", j);
            return;
        }
        if (strS.equals("c_fail")) {
            failed(j);
            return;
        }
        if (strS.equals("c_banned")) {
            this.ban = j.b("on") ? j : null;
            emit("ban", j);
        } else if (strS.equals("c_stk")) {
            this.stk = j.a("l");
            emit("stk", j);
        } else if (strS.equals("c_typing")) {
            emit("typing", j);
        } else {
            emit(strS, j);
        }
    }

    public Set<String> pins() {
        HashSet hashSet = new HashSet();
        String str = kv.get("pins");
        if (str != null) {
            String[] strArrSplit = str.split("\n");
            for (String str2 : strArrSplit) {
                if (str2.length() > 0) {
                    hashSet.add(str2);
                }
            }
        }
        return hashSet;
    }

    public void poke() {
        if (this.started) {
            if (this.ws == null || !this.connected) {
                if (this.ws == null) {
                    connect();
                }
            } else if (System.currentTimeMillis() - this.lastRx > 15000) {
                final long jCurrentTimeMillis = System.currentTimeMillis();
                final Ws ws = this.ws;
                sendQ(J.of("t", "c_hb"));
                timer.later(new Runnable() { // from class: com.changliao.im.Core.5
                    @Override // java.lang.Runnable
                    public void run() {
                        if (Core.this.ws != ws || Core.this.lastRx >= jCurrentTimeMillis) {
                            return;
                        }
                        ws.close();
                    }
                }, 3500L);
            }
        }
    }

    public void remove(L l) {
        this.ls.remove(l);
    }

    public void resend(J j) {
        String strS = j.s("conv");
        dropFail(j);
        J jO = j.o("send");
        if (jO != null) {
            J jOf = J.of(new Object[0]);
            for (String str : jO.keySet()) {
                if (!str.equals("cid")) {
                    jOf.put(str, jO.get(str));
                }
            }
            send(jOf);
        }
        emit("hist", J.of("conv", strS, "keep", true));
    }

    void saveFails(String str, List<J> list) {
        while (list.size() > 60) {
            list.remove(0);
        }
        kv.put("fail:" + str, list.isEmpty() ? null : J.str(list));
    }

    public boolean send(J j) {
        Ws ws = this.ws;
        if (ws == null || !this.connected) {
            emit("toast", J.of("msg", "还没连上服务器，请稍等", "err", true));
            return false;
        }
        String strS = j.s("k");
        if ("c_send".equals(j.s("t")) && !j.has("cid") && (strS.equals("text") || strS.equals("img") || strS.equals("video") || strS.equals("file") || strS.equals("voice"))) {
            StringBuilder sbAppend = new StringBuilder().append(Long.toString(System.currentTimeMillis(), 36));
            int i = this.cidN + 1;
            this.cidN = i;
            final String string = sbAppend.append(Integer.toString(i, 36)).toString();
            j.put("cid", string);
            this.pend.put(string, j);
            if (this.pend.size() > 80) {
                this.pend.remove(this.pend.keySet().iterator().next());
            }
            final String strS2 = j.s("conv");
            timer.later(new Runnable() { // from class: com.changliao.im.Core.7
                @Override // java.lang.Runnable
                public void run() {
                    if (Core.this.pend.containsKey(string)) {
                        Core.this.failed(J.of("conv", strS2, "cid", string, "why", "timeout"));
                    }
                }
            }, 12000L);
        }
        return ws.send(j.toString());
    }

    public boolean sendBin(byte[] bArr) {
        Ws ws = this.ws;
        return ws != null && this.connected && ws.sendBin(bArr);
    }

    public boolean sendQ(J j) {
        Ws ws = this.ws;
        return ws != null && this.connected && ws.send(j.toString());
    }

    public boolean sendQ0(J j) {
        if (this.ws == null || !this.connected) {
            return false;
        }
        return send(j);
    }

    public void setMute(String str, boolean z) {
        if (z) {
            this.mutes.add(str);
        } else {
            this.mutes.remove(str);
        }
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = this.mutes.iterator();
        while (it.hasNext()) {
            sb.append(it.next()).append('\n');
        }
        kv.put("mutes", sb.toString());
        emit("convs", null);
    }

    public void setPin(String str, boolean z) {
        Set<String> setPins = pins();
        if (z) {
            setPins.add(str);
        } else {
            setPins.remove(str);
        }
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = setPins.iterator();
        while (it.hasNext()) {
            sb.append(it.next()).append('\n');
        }
        kv.put("pins", sb.toString());
        emit("convs", null);
    }

    public List<J> sortedConvs() {
        final Set<String> setPins = pins();
        ArrayList arrayList = new ArrayList();
        for (J j : this.convs.values()) {
            if (!hidden(j.s("conv"))) {
                arrayList.add(j);
            }
        }
        Collections.sort(arrayList, new Comparator<J>() { // from class: com.changliao.im.Core.9
            @Override // java.util.Comparator
            public int compare(J j2, J j3) {
                boolean zContains = setPins.contains(j2.s("conv"));
                if (zContains != setPins.contains(j3.s("conv"))) {
                    return zContains ? -1 : 1;
                }
                return Long.compare(j3.l("ts"), j2.l("ts"));
            }
        });
        return arrayList;
    }

    public void start() {
        if (this.started) {
            return;
        }
        this.started = true;
        String str = kv.get("mutes");
        if (str != null) {
            String[] strArrSplit = str.split("\n");
            for (String str2 : strArrSplit) {
                if (str2.length() > 0) {
                    this.mutes.add(str2);
                }
            }
        }
        connect();
        if (this.hbOn) {
            return;
        }
        this.hbOn = true;
        timer.later(this.hb, 20000L);
    }

    public String token() {
        // PATCH(需求2): 本地没有 tok 时给占位符，保证 token()!=null 的判定（启动/保活/轮询）全部通过
        String str = kv.get("tok");
        if (str == null || str.length() == 0) {
            return "[tok]";
        }
        return str;
    }

    public int unreadTotal() {
        int iL = 0;
        Iterator<J> it = this.convs.values().iterator();
        while (true) {
            int i = iL;
            if (!it.hasNext()) {
                return i;
            }
            J next = it.next();
            if (this.mutes.contains(next.s("conv"))) {
                iL = i;
            } else {
                iL = (int) (next.l("unread") + ((long) i));
            }
        }
    }
}
