package com.changliao.im;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public class Img {
    static Bitmap appic;
    static Bitmap defAv;
    static File dir;
    static Bitmap gBadge;
    static LruCache<String, Bitmap> mem;
    static ExecutorService pool = Executors.newFixedThreadPool(4);
    static Handler ui = new Handler(Looper.getMainLooper());

    public static class Av extends View {
        Integer bg1;
        Integer bg2;
        Bitmap bmp;
        int color;
        final RectF dr;
        boolean group;
        Ico icon;
        boolean letter;
        String name;
        boolean online;
        final Paint p;
        final RectF r;
        final Rect sr;
        final Paint tp;
        String url;

        public Av(Context context) {
            super(context);
            this.name = "?";
            this.sr = new Rect();
            this.dr = new RectF();
            this.p = new Paint(1);
            this.tp = new Paint(1);
            this.r = new RectF();
            this.tp.setColor(-1);
            this.tp.setTextAlign(Paint.Align.CENTER);
            this.tp.setTypeface(Typeface.DEFAULT_BOLD);
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            Bitmap bitmap;
            this.p.setColorFilter((!Night.active || Night.inDark(this)) ? null : Night.back);
            float width = getWidth();
            float height = getHeight();
            float fMin = Math.min(width, height);
            this.r.set((width - fMin) / 2.0f, (height - fMin) / 2.0f, (width + fMin) / 2.0f, (height + fMin) / 2.0f);
            this.p.setShader(null);
            if (this.bmp != null) {
                bitmap = this.bmp;
            } else {
                bitmap = (this.letter || this.bg1 != null) ? null : Img.defAv;
            }
            if (bitmap != null) {
                BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                float fMax = Math.max(fMin / bitmap.getWidth(), fMin / bitmap.getHeight());
                Matrix matrix = new Matrix();
                matrix.setScale(fMax, fMax);
                matrix.postTranslate(this.r.left + ((fMin - (bitmap.getWidth() * fMax)) / 2.0f), ((fMin - (bitmap.getHeight() * fMax)) / 2.0f) + this.r.top);
                bitmapShader.setLocalMatrix(matrix);
                this.p.setShader(bitmapShader);
                canvas.drawOval(this.r, this.p);
            } else if (this.bg1 != null) {
                this.p.setShader(new LinearGradient(this.r.left, this.r.top, this.r.right, this.r.bottom, this.bg1.intValue(), this.bg2.intValue(), Shader.TileMode.CLAMP));
                canvas.drawOval(this.r, this.p);
                if (this.icon != null) {
                    int i = (int) (0.24f * fMin);
                    this.icon.setBounds(((int) this.r.left) + i, ((int) this.r.top) + i, ((int) this.r.right) - i, ((int) this.r.bottom) - i);
                    this.icon.draw(canvas);
                }
            } else {
                this.p.setColor(this.color);
                canvas.drawOval(this.r, this.p);
                this.tp.setTextSize(0.42f * fMin);
                canvas.drawText(this.name.substring(0, Character.charCount(this.name.codePointAt(0))).toUpperCase(), width / 2.0f, (height / 2.0f) - ((this.tp.descent() + this.tp.ascent()) / 2.0f), this.tp);
            }
            if (this.online) {
                float fDp = Ui.dp(12.0f);
                float f = this.r.right - (fDp / 2.0f);
                float f2 = this.r.bottom - (fDp / 2.0f);
                this.p.setShader(null);
                this.p.setColor(-1);
                canvas.drawCircle(f, f2, (fDp / 2.0f) + Ui.dp(2.0f), this.p);
                this.p.setColor(Ui.GREEN);
                canvas.drawCircle(f, f2, fDp / 2.0f, this.p);
            }
            if (!this.group || Img.gBadge == null || fMin < Ui.dp(36.0f)) {
                return;
            }
            float fDp2 = Ui.dp(16.0f);
            float fDp3 = (this.r.right + Ui.dp(1.0f)) - (fDp2 / 2.0f);
            float fDp4 = (this.r.bottom + Ui.dp(1.0f)) - (fDp2 / 2.0f);
            this.p.setShader(null);
            this.p.setColor(-1);
            canvas.drawCircle(fDp3, fDp4, fDp2 / 2.0f, this.p);
            float f3 = 0.18f * fDp2;
            this.sr.set(0, 0, Img.gBadge.getWidth(), Img.gBadge.getHeight());
            this.dr.set((fDp3 - (fDp2 / 2.0f)) + f3, (fDp4 - (fDp2 / 2.0f)) + f3, (fDp3 + (fDp2 / 2.0f)) - f3, ((fDp2 / 2.0f) + fDp4) - f3);
            canvas.drawBitmap(Img.gBadge, this.sr, this.dr, this.p);
        }

        public void set(String str, String str2, boolean z) {
            if (str == null || str.length() == 0) {
                str = "?";
            }
            this.name = str;
            this.letter = z;
            this.group = z;
            this.bg1 = null;
            this.icon = null;
            this.color = Ui.hue(this.name);
            final String strAvUrl = Core.avUrl(str2);
            this.url = strAvUrl;
            this.bmp = strAvUrl != null ? Img.cached(strAvUrl, 200) : null;
            if (strAvUrl != null && this.bmp == null) {
                Img.get(strAvUrl, 200, new Cb() { // from class: com.changliao.im.Img.Av.1
                    @Override // com.changliao.im.Img.Cb
                    public void done(Bitmap bitmap) {
                        if (strAvUrl.equals(Av.this.url)) {
                            Av.this.bmp = bitmap;
                            Av.this.invalidate();
                        }
                    }
                });
            }
            invalidate();
        }

        public void set(String str, String str2, boolean z, String str3) {
            set(str, str2, z);
            this.color = Ui.hue(str3);
            invalidate();
        }

        public void setGroup(boolean z) {
            this.group = z;
            invalidate();
        }

        public void setIcon(String str, int i, int i2) {
            this.bmp = null;
            this.url = null;
            this.group = false;
            this.bg1 = Integer.valueOf(i);
            this.bg2 = Integer.valueOf(i2);
            this.icon = new Ico(str, -1);
            invalidate();
        }

        public void setOnline(boolean z) {
            this.online = z;
            invalidate();
        }
    }

    public interface Cb {
        void done(Bitmap bitmap);
    }

    static Bitmap asset(Context context, String str) {
        try {
            InputStream inputStreamOpen = context.getAssets().open(str);
            Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpen);
            inputStreamOpen.close();
            return bitmapDecodeStream;
        } catch (Exception e) {
            Crash.note(e);
            return null;
        }
    }

    public static Bitmap cached(String str, int i) {
        if (str == null) {
            return null;
        }
        return mem.get(key(str, i));
    }

    public static Bitmap decode(byte[] bArr, int i) {
        int i2 = 1;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        if (i > 0) {
            while (options.outWidth / (i2 * 2) >= i && options.outHeight / (i2 * 2) >= i) {
                i2 *= 2;
            }
        }
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inSampleSize = i2;
        return BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options2);
    }

    static Bitmap fetch(String str, int i) throws Exception {
        byte[] bArr;
        File file = new File(dir, Integer.toHexString(str.hashCode()) + "_" + str.length());
        if (!file.exists() || file.length() <= 0) {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(20000);
            if (httpURLConnection.getResponseCode() != 200) {
                httpURLConnection.disconnect();
                return null;
            }
            byte[] bArr2 = read(httpURLConnection.getInputStream());
            httpURLConnection.disconnect();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                fileOutputStream.write(bArr2);
                fileOutputStream.close();
                bArr = bArr2;
            } catch (Exception e) {
                bArr = bArr2;
            }
        } else {
            bArr = read(new FileInputStream(file));
        }
        return decode(bArr, i);
    }

    public static void get(final String str, final int i, final Cb cb) {
        if (str == null) {
            cb.done(null);
            return;
        }
        final String strKey = key(str, i);
        Bitmap bitmap = mem.get(strKey);
        if (bitmap != null) {
            cb.done(bitmap);
        } else {
            pool.execute(new Runnable() { // from class: com.changliao.im.Img.2
                @Override // java.lang.Runnable
                public void run() {
                    Bitmap tmpBitmap = null;
                    try {
                        tmpBitmap = Img.fetch(str, i);
                    } catch (Throwable th) {
                    }
                    final Bitmap bitmapFetch = tmpBitmap;
                    if (bitmapFetch != null) {
                        Img.mem.put(strKey, bitmapFetch);
                    }
                    Img.ui.post(new Runnable() { // from class: com.changliao.im.Img.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            cb.done(bitmapFetch);
                        }
                    });
                }
            });
        }
    }

    public static void init(Context context) {
        mem = new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8)) { // from class: com.changliao.im.Img.1
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.util.LruCache
            public int sizeOf(String str, Bitmap bitmap) {
                return bitmap.getByteCount();
            }
        };
        dir = new File(context.getCacheDir(), "img");
        dir.mkdirs();
        defAv = asset(context, "def_av.jpg");
        gBadge = asset(context, "gbadge.png");
        appic = asset(context, "appic.png");
    }

    public static void into(final ImageView imageView, final String str, int i) {
        Night.keep(imageView);
        imageView.setTag(str);
        Bitmap bitmapCached = cached(str, i);
        if (bitmapCached != null) {
            imageView.setImageBitmap(bitmapCached);
        } else {
            imageView.setImageDrawable(null);
            get(str, i, new Cb() { // from class: com.changliao.im.Img.3
                @Override // com.changliao.im.Img.Cb
                public void done(Bitmap bitmap) {
                    if (bitmap == null || str == null || !str.equals(imageView.getTag())) {
                        return;
                    }
                    imageView.setImageBitmap(bitmap);
                    imageView.setAlpha(0.0f);
                    imageView.animate().alpha(1.0f).setDuration(160L).start();
                }
            });
        }
    }

    static String key(String str, int i) {
        return i + "|" + str;
    }

    public static byte[] read(InputStream inputStream) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[16384];
        while (true) {
            int i = inputStream.read(bArr);
            if (i <= 0) {
                inputStream.close();
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, i);
        }
    }
}
