package com.changliao.im;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Layout;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.util.Linkify;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public class ChatScr extends Scr {
    static final String EMOJI = "😀 😁 😂 🤣 😊 😍 😘 😎 🤔 😏 😴 😭 😡 😱 🥳 🤗 🙄 😅 😇 🥺 😤 🤤 😋 🤩 👍 👎 👏 🙏 💪 👌 ✌️ 🤝 👋 ❤️ 💔 🔥 ⭐ 🎉 🎁 💯 ✅ ❌ ❓ 💤 🌹 🍉 🍺 ☕ 🐶 🐱 🐷 🐸 🦊 🌈 🍀 🎵 🍰 🐼 🐰 🌸 🌲 🌙 ☀️ 🌧️";
    static long lastSend;
    View banB;
    TextView bn;
    TextView callBar;
    public final String conv;
    ImageView emoB;
    TextView gbanT;
    boolean gcVideo;
    final String gid;
    final boolean group;
    boolean histOnce;
    TextView holdB;
    View inputV;
    FrameLayout jump;
    boolean jumpOn;
    ListView list;
    int maxBody;
    ImageView micB;
    int newN;
    TextView newPill;
    LinearLayout noticeBar;
    TextView noticeT;
    long olderAt;
    FrameLayout panel;
    MediaPlayer player;
    TextView playingV;
    ImageView plusB;
    MediaRecorder rec;
    boolean recCancel;
    File recF;
    long recT0;
    float recY0;
    J reply;
    LinearLayout replyBar;
    TextView replyT;
    long[] saved;
    final boolean self;
    TextView sendB;
    boolean stkTab;
    EditText ta;
    long typSent;
    long typingUntil;
    boolean voiceMode;
    static final WeakHashMap<View, Long> animEnd = new WeakHashMap<>();
    static final Pattern AT = Pattern.compile("(^|[\\s（(，,>])@([\\w\\u4e00-\\u9fff\\-·]{1,16}|全体成员)");
    static final HashMap<String, String> BUB_EMOJI = new HashMap<>();
    final Adapter ad = new Adapter();
    final Map<String, String> atMap = new LinkedHashMap();
    final List<J> ups = new ArrayList();
    final List<J> pend = new ArrayList();
    String panelMode = "";
    long playing = -1;

    /* JADX INFO: renamed from: com.changliao.im.ChatScr$38, reason: invalid class name */
    class AnonymousClass38 implements GalScr.Got {
        AnonymousClass38() {
        }

        @Override // com.changliao.im.GalScr.Got
        public void got(List<Uri> list, boolean z) {
            if (list.isEmpty()) {
                return;
            }
            final Uri uri = list.get(0);
            new Thread(new Runnable() { // from class: com.changliao.im.ChatScr.38.1
                @Override // java.lang.Runnable
                public void run() {
                    String str;
                    try {
                        Object[] objArrJpeg = Up.jpeg(ChatScr.this.a, uri, false);
                        byte[] bArr = (byte[]) objArrJpeg[0];
                        StringBuilder sbAppend = new StringBuilder().append("sticker.");
                        if (objArrJpeg[3].equals("image/gif")) {
                            str = "gif";
                        } else {
                            str = objArrJpeg[3].equals("image/png") ? "png" : "jpg";
                        }
                        final String strUpload = Up.upload(bArr, sbAppend.append(str).toString(), (String) objArrJpeg[3], null);
                        ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.38.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ChatScr.this.C.send(J.of("t", "c_stk", "act", "add", "fid", strUpload));
                            }
                        });
                    } catch (Throwable th) {
                        ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.38.1.2
                            @Override // java.lang.Runnable
                            public void run() {
                                ChatScr.this.toast("添加失败：" + th.getMessage());
                            }
                        });
                    }
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: com.changliao.im.ChatScr$40, reason: invalid class name */
    class AnonymousClass40 implements Runnable {
        final /* synthetic */ Context val$ctx;
        final /* synthetic */ boolean val$media;
        final /* synthetic */ List val$mine;
        final /* synthetic */ boolean val$orig;

        AnonymousClass40(List list, boolean z, Context context, boolean z2) {
            this.val$mine = list;
            this.val$media = z;
            this.val$ctx = context;
            this.val$orig = z2;
        }

        @Override // java.lang.Runnable
        public void run() {
            for (Object o : this.val$mine) {
                final J j = (J) o;
                final J jOf;
                try {
                    Uri uri = Uri.parse(j.s("uri"));
                    String strS = j.s("mime");
                    String strS2 = j.s("name");
                    Up.P p = new Up.P() { // from class: com.changliao.im.ChatScr.40.1
                        @Override // com.changliao.im.Up.P
                        public void p(final float f) {
                            ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.40.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    j.put("pct", Double.valueOf(f));
                                    ChatScr.this.ad.notifyDataSetChanged();
                                }
                            });
                        }
                    };
                    if (this.val$media && strS.startsWith("image/")) {
                        Object[] objArrJpeg = Up.jpeg(this.val$ctx, uri, this.val$orig);
                        if (objArrJpeg[3].equals("image/jpeg") && !strS2.toLowerCase().matches(".*\\.jpe?g$")) {
                            strS2 = strS2.replaceAll("\\.\\w+$", "") + ".jpg";
                        }
                        jOf = J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "img", "fid", Up.upload((byte[]) objArrJpeg[0], strS2, (String) objArrJpeg[3], p), "w", objArrJpeg[1], "h", objArrJpeg[2]);
                    } else if (this.val$media && strS.startsWith("video/")) {
                        Object[] objArrVideo = Up.video(this.val$ctx, uri);
                        String strUpload = objArrVideo[0] != null ? Up.upload((byte[]) objArrVideo[0], "poster.jpg", "image/jpeg", null) : null;
                        long jL = j.l("size");
                        if (jL < 0) {
                            jL = this.val$ctx.getContentResolver().openAssetFileDescriptor(uri, "r").getLength();
                        }
                        jOf = J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "video", "fid", Up.upload(this.val$ctx.getContentResolver().openInputStream(uri), jL, strS2, strS, p), "w", objArrVideo[1], "h", objArrVideo[2], "dur", objArrVideo[3]);
                        if (strUpload != null) {
                            jOf.put("poster", strUpload);
                        }
                    } else {
                        long jL2 = j.l("size");
                        if (jL2 < 0) {
                            jL2 = this.val$ctx.getContentResolver().openAssetFileDescriptor(uri, "r").getLength();
                        }
                        if (jL2 > 314572800) {
                            throw new Exception("文件太大了");
                        }
                        jOf = J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "file", "fid", Up.upload(this.val$ctx.getContentResolver().openInputStream(uri), jL2, strS2, strS, p));
                    }
                    ChatScr.gap();
                    ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.40.2
                        @Override // java.lang.Runnable
                        public void run() {
                            if (!ChatScr.this.C.sendQ0(jOf)) {
                                ChatScr.this.C.failLocal(jOf);
                            }
                            ChatScr.this.ups.remove(j);
                            ChatScr.this.ad.rebuild();
                        }
                    });
                } catch (Throwable th) {
                    ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.40.3
                        @Override // java.lang.Runnable
                        public void run() {
                            j.put("err", th.getMessage() == null ? "上传失败" : th.getMessage());
                            ChatScr.this.ad.notifyDataSetChanged();
                            ChatScr.this.toast("「" + j.s("name") + "」发送失败：" + j.s("err"));
                        }
                    });
                }
            }
        }
    }

    /* JADX INFO: renamed from: com.changliao.im.ChatScr$58, reason: invalid class name */
    class AnonymousClass58 implements Runnable {
        final /* synthetic */ J val$f;
        final /* synthetic */ J val$m;
        final /* synthetic */ String val$name;
        final /* synthetic */ TextView val$st;

        AnonymousClass58(J j, String str, TextView textView, J j2) {
            this.val$f = j;
            this.val$name = str;
            this.val$st = textView;
            this.val$m = j2;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                final File fileDownload = Up.download(ChatScr.this.a, this.val$f.s("id"), this.val$name, new Up.P() { // from class: com.changliao.im.ChatScr.58.1
                    @Override // com.changliao.im.Up.P
                    public void p(final float f) {
                        ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.58.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                AnonymousClass58.this.val$st.setText("正在下载 " + Math.round(f * 100.0f) + "%");
                            }
                        });
                    }
                });
                ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.58.2
                    @Override // java.lang.Runnable
                    public void run() {
                        AnonymousClass58.this.val$st.setText(Ui.size(AnonymousClass58.this.val$f.l("size")) + " · 已下载，点击打开");
                        if (!AnonymousClass58.this.val$m.b("mine")) {
                            ChatScr.this.C.sendQ(J.of("t", "c_fack", "conv", ChatScr.this.conv, "id", Long.valueOf(AnonymousClass58.this.val$m.l("id"))));
                        }
                        String lowerCase = AnonymousClass58.this.val$name.toLowerCase();
                        if (lowerCase.endsWith(".apk")) {
                            Upd.install(ChatScr.this.a, fileDownload);
                        } else if (!lowerCase.matches(".*\\.(txt|log|md|json|csv|ini|conf|xml|html?|js|css|py|java|c|cpp|h|sh|bat|srt|lrc|yml|yaml)$") || fileDownload.length() >= 2097152) {
                            Upd.open(ChatScr.this.a, fileDownload, URLConnection.guessContentTypeFromName(AnonymousClass58.this.val$name));
                        } else {
                            ChatScr.this.a.push(new TxtScr(fileDownload));
                        }
                    }
                });
            } catch (Throwable th) {
                ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.58.3
                    @Override // java.lang.Runnable
                    public void run() {
                        AnonymousClass58.this.val$st.setText("下载失败，点击重试");
                        ChatScr.this.toast("下载失败：" + th.getMessage());
                    }
                });
            }
        }
    }

    class Adapter extends BaseAdapter {
        boolean ready;
        List<J> items = new ArrayList();
        final LruCache<String, View> cache = new LruCache<>(120);

        Adapter() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return this.items.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return this.items.get(i);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return this.items.get(i).l("id");
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public int getItemViewType(int i) {
            return -1;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            long jL;
            View viewRow;
            J j = this.items.get(i);
            int i2 = i - 1;
            while (true) {
                if (i2 < 0) {
                    jL = 0;
                    break;
                }
                jL = this.items.get(i2).l("ts");
                if (jL > 0) {
                    break;
                }
                i2--;
            }
            String str = j.l("id") + "|" + j.s("k") + "|" + j.l("rcv") + "|" + j.s("err") + "|" + Math.round(j.d("pct") * 100.0d) + "|" + (jL == 0 || j.l("ts") - jL > 300) + "|" + j.s("text").hashCode() + "|" + (ChatScr.this.playing == j.l("id"));
            if (view != null && str.equals(view.getTag())) {
                return view;
            }
            View view2 = this.cache.get(str);
            if (view2 != null && (view2.getParent() == null || view2.getParent() == viewGroup)) {
                Long l = ChatScr.animEnd.get(view2);
                if (l != null && SystemClock.uptimeMillis() <= l.longValue()) {
                    return view2;
                }
                view2.setAlpha(1.0f);
                view2.setScaleX(1.0f);
                view2.setScaleY(1.0f);
                view2.setTranslationY(0.0f);
                return view2;
            }
            try {
                viewRow = ChatScr.this.row(j, jL);
            } catch (Throwable th) {
                Crash.note(th);
                TextView textViewText = Ui.text(ChatScr.this.a, ChatScr.preview(j) + "  （显示出错：" + th.getClass().getSimpleName() + "）", 13.0f, Ui.SUB);
                textViewText.setPadding(Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(12.0f));
                viewRow = textViewText;
            }
            viewRow.setTag(str);
            this.cache.put(str, viewRow);
            if (i != this.items.size() - 1 || !this.ready) {
                return viewRow;
            }
            if ((!j.b("pend") && j.b("mine") && !j.b("fail")) || j.s("k").equals("loading") || j.s("k").equals("empty")) {
                return viewRow;
            }
            ChatScr.popIn(viewRow, j.b("mine"), j.s("k").equals("sys"));
            return viewRow;
        }

        void rebuild() {
            List<J> list = ChatScr.this.C.msgs.get(ChatScr.this.conv);
            this.items = new ArrayList();
            if (list != null && Boolean.TRUE.equals(ChatScr.this.C.more.get(ChatScr.this.conv))) {
                this.items.add(J.of("k", "more", "id", -1L));
            }
            if (list != null) {
                this.items.addAll(list);
            }
            this.items.addAll(ChatScr.this.pend);
            this.items.addAll(ChatScr.this.ups);
            if (list == null) {
                this.items.add(J.of("k", "loading", "id", -2L));
            } else if (list.isEmpty() && ChatScr.this.ups.isEmpty()) {
                this.items.add(J.of("k", "empty", "id", -3L));
            }
            notifyDataSetChanged();
        }
    }

    static class HorizontalScroll extends HorizontalScrollView {
        HorizontalScroll(Context context) {
            super(context);
            setHorizontalScrollBarEnabled(false);
        }
    }

    static class PlayCircle extends View {
        final Paint p;
        final Path t;

        PlayCircle(Context context) {
            super(context);
            this.p = new Paint(1);
            this.t = new Path();
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float width = getWidth() / 2.0f;
            this.p.setStyle(Paint.Style.FILL);
            this.p.setColor(1929379840);
            canvas.drawCircle(width, width, width - Ui.dp(1.0f), this.p);
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(Ui.dp(2.0f));
            this.p.setColor(-1);
            canvas.drawCircle(width, width, width - Ui.dp(1.0f), this.p);
            this.p.setStyle(Paint.Style.FILL);
            this.t.reset();
            this.t.moveTo(Ui.dp(18.0f), Ui.dp(14.0f));
            this.t.lineTo(Ui.dp(33.0f), Ui.dp(23.0f));
            this.t.lineTo(Ui.dp(18.0f), Ui.dp(32.0f));
            this.t.close();
            canvas.drawPath(this.t, this.p);
        }
    }

    static class Tight extends TextView {
        Tight(Context context) {
            super(context);
        }

        @Override // android.widget.TextView, android.view.View
        protected void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            Layout layout = getLayout();
            if (layout == null || layout.getLineCount() < 2) {
                return;
            }
            float fMax = 0.0f;
            for (int i3 = 0; i3 < layout.getLineCount(); i3++) {
                fMax = Math.max(fMax, layout.getLineWidth(i3));
            }
            int lineCount = layout.getLineCount();
            int iCeil = ((int) Math.ceil(fMax)) + 1 + getCompoundPaddingLeft() + getCompoundPaddingRight();
            if (iCeil < getMeasuredWidth()) {
                super.onMeasure(View.MeasureSpec.makeMeasureSpec(iCeil, 1073741824), i2);
                Layout layout2 = getLayout();
                if (layout2 == null || layout2.getLineCount() != lineCount) {
                    super.onMeasure(i, i2);
                }
            }
        }
    }

    static class Wave extends View {
        final boolean on;
        final Paint p;
        final long t0;

        Wave(Context context, int i, boolean z) {
            super(context);
            this.p = new Paint(1);
            this.t0 = System.currentTimeMillis();
            this.p.setColor(i);
            this.on = z;
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float[] fArr = {6.0f, 12.0f, 17.0f};
            float height = getHeight();
            float fDp = Ui.dp(3.0f);
            for (int i = 0; i < 3; i++) {
                float fAbs = fArr[i];
                if (this.on) {
                    fAbs = 4.0f + (((float) Math.abs(Math.sin(((System.currentTimeMillis() - this.t0) / 250.0d) + (((double) i) * 0.6d)))) * 14.0f);
                }
                float fDp2 = Ui.dp(fAbs);
                float fDp3 = i * (Ui.dp(2.0f) + fDp);
                canvas.drawRoundRect(fDp3, (height - fDp2) / 2.0f, fDp3 + fDp, (fDp2 + height) / 2.0f, Ui.dp(2.0f), Ui.dp(2.0f), this.p);
            }
            if (this.on) {
                postInvalidateOnAnimation();
            }
        }
    }

    static {
        String[] strArr = {"gold", "👑", "sakura", "🌸", "ocean", "\u1fae7", "aurora", "✨", "neon", "⚡", "candy", "🍬", "night", "🌙", "glass", "❄️", "flame", "🔥", "mint", "🌿", "peach", "🍑", "lavender", "💜", "lemon", "🍋", "matcha", "🍵", "choco", "🍫", "ruby", "💎", "sunset", "🌅", "galaxy", "🪐", "cyber", "🤖", "cloud", "☁️", "jade", "🍀", "ink", "🖌️", "rainbow", "🌈", "diamond", "💠", "rose", "🌹"};
        for (int i = 0; i + 1 < strArr.length; i += 2) {
            BUB_EMOJI.put(strArr[i], strArr[i + 1]);
        }
    }

    public ChatScr(String str) {
        this.conv = str;
        this.group = str.startsWith("g:");
        this.gid = this.group ? str.substring(2) : null;
        this.self = Core.isSelf(str);
    }

    static void clip(View view, final float f) {
        view.setOutlineProvider(new ViewOutlineProvider() { // from class: com.changliao.im.ChatScr.53
            @Override // android.view.ViewOutlineProvider
            public void getOutline(View view2, Outline outline) {
                outline.setRoundRect(0, 0, view2.getWidth(), view2.getHeight(), Ui.dp(f));
            }
        });
        view.setClipToOutline(true);
    }

    static Tight findTight(View view) {
        if (view instanceof Tight) {
            return (Tight) view;
        }
        if (view instanceof ViewGroup) {
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= ((ViewGroup) view).getChildCount()) {
                    break;
                }
                Tight tightFindTight = findTight(((ViewGroup) view).getChildAt(i2));
                if (tightFindTight != null) {
                    return tightFindTight;
                }
                i = i2 + 1;
            }
        }
        return null;
    }

    static synchronized void gap() throws InterruptedException {
        long jCurrentTimeMillis = 520 - (System.currentTimeMillis() - lastSend);
        if (jCurrentTimeMillis > 0) {
            Thread.sleep(jCurrentTimeMillis);
        }
        lastSend = System.currentTimeMillis();
    }

    static String nameOf(J j) {
        return j.s("card").length() > 0 ? j.s("card") : j.s("nick");
    }

    static void openFileStatic(final MainActivity mainActivity, J j, final J j2, String str) {
        final String strS = j2.s("name");
        if (strS.toLowerCase().matches(".*\\.(jpe?g|png|gif|webp|bmp)$")) {
            mainActivity.push(new ImgScr(j2, str, j));
        } else {
            mainActivity.toast("正在下载「" + strS + "」…", false);
            new Thread(new Runnable() { // from class: com.changliao.im.ChatScr.59
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        final File fileDownload = Up.download(mainActivity, j2.s("id"), strS, null);
                        mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.59.1
                            @Override // java.lang.Runnable
                            public void run() {
                                String lowerCase = strS.toLowerCase();
                                if (lowerCase.endsWith(".apk")) {
                                    Upd.install(mainActivity, fileDownload);
                                } else if (!lowerCase.matches(".*\\.(txt|log|md|json|csv|ini|conf|xml|html?|js|css|py|java|c|cpp|h|sh|bat|srt|lrc|yml|yaml)$") || fileDownload.length() >= 2097152) {
                                    Upd.open(mainActivity, fileDownload, URLConnection.guessContentTypeFromName(strS));
                                } else {
                                    mainActivity.push(new TxtScr(fileDownload));
                                }
                            }
                        });
                    } catch (Throwable th) {
                        mainActivity.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.59.2
                            @Override // java.lang.Runnable
                            public void run() {
                                mainActivity.toast("下载失败", true);
                            }
                        });
                    }
                }
            }).start();
        }
    }

    static void popIn(View view, final boolean z, boolean z2) {
        animEnd.put(view, Long.valueOf(SystemClock.uptimeMillis() + 450));
        view.setAlpha(0.0f);
        view.setTranslationY(Ui.dp(z2 ? 8.0f : 26.0f));
        if (!z2) {
            view.setScaleX(0.72f);
            view.setScaleY(0.72f);
        }
        view.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.changliao.im.ChatScr.42
            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view2, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                view2.setPivotX(z ? (i3 - i) - Ui.dp(40.0f) : Ui.dp(40.0f));
                view2.setPivotY(i4 - i2);
                view2.removeOnLayoutChangeListener(this);
            }
        });
        view.animate().alpha(1.0f).translationY(0.0f).scaleX(1.0f).scaleY(1.0f).setDuration(z2 ? 220L : 380L).setInterpolator(z2 ? new DecelerateInterpolator() : new OvershootInterpolator(1.6f)).withLayer().start();
    }

    static String preview(J j) {
        String strS = j.s("k");
        J jO = j.o("f");
        if (strS.equals("img")) {
            return (jO == null || !jO.b("stk")) ? "[图片]" : "[表情]";
        }
        if (strS.equals("video")) {
            return "[视频]";
        }
        if (strS.equals("file")) {
            return "[文件] " + (jO == null ? "" : jO.s("name"));
        }
        return strS.equals("voice") ? "[语音]" : j.s("text");
    }

    static List<Uri> uris(Intent intent) {
        ArrayList arrayList = new ArrayList();
        if (intent == null) {
            return arrayList;
        }
        ClipData clipData = intent.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                Uri uri = clipData.getItemAt(i).getUri();
                if (uri != null) {
                    arrayList.add(uri);
                }
            }
        }
        if (arrayList.isEmpty() && intent.getData() != null) {
            arrayList.add(intent.getData());
        }
        return arrayList;
    }

    void addSticker() {
        this.a.push(new GalScr(new AnonymousClass38()).title("添加表情").single().onlyImg().noOrig().ok("添加"));
    }

    long[] anchor() {
        int firstVisiblePosition = this.list.getFirstVisiblePosition();
        int childCount = this.list.getChildCount();
        boolean z = this.ad.getCount() == 0 || (this.list.getLastVisiblePosition() >= this.ad.getCount() + (-2) && (this.list.getChildAt(childCount + (-1)) == null || this.list.getChildAt(childCount + (-1)).getBottom() <= (this.list.getHeight() - this.list.getPaddingBottom()) + Ui.dp(24.0f)));
        for (int i = 0; i < childCount; i++) {
            int i2 = firstVisiblePosition + i;
            if (i2 >= 0 && i2 < this.ad.items.size()) {
                long jL = this.ad.items.get(i2).l("id");
                if (jL != 0) {
                    long[] jArr = new long[3];
                    jArr[0] = jL;
                    jArr[1] = this.list.getChildAt(i).getTop();
                    jArr[2] = z ? 1L : 0L;
                    return jArr;
                }
            }
        }
        long[] jArr2 = new long[3];
        jArr2[0] = 0;
        jArr2[1] = 0;
        jArr2[2] = z ? 1L : 0L;
        return jArr2;
    }

    void badge() {
        this.newPill.setText(this.newN > 99 ? "99+" : String.valueOf(this.newN));
        if (this.newN <= 0 || this.newPill.getVisibility() == 0) {
            if (this.newN == 0) {
                this.newPill.setVisibility(8);
            }
        } else {
            this.newPill.setVisibility(0);
            this.newPill.setScaleX(0.0f);
            this.newPill.setScaleY(0.0f);
            this.newPill.animate().scaleX(1.0f).scaleY(1.0f).setDuration(260L).setInterpolator(new OvershootInterpolator(2.5f)).start();
        }
    }

    Drawable bubbleBg(J j, boolean z) {
        GradientDrawable gradientDrawable;
        int[] iArr = (!j.b("vip") || j.s("bub").length() <= 0) ? null : Bubbles.B.get(j.s("bub"));
        if (iArr != null) {
            int[] iArr2 = new int[Math.max(2, iArr.length - 1)];
            for (int i = 0; i < iArr2.length; i++) {
                iArr2[i] = iArr[Math.min(iArr.length - 1, i + 1)];
            }
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, iArr2);
            gradientDrawable.setStroke(Math.max(1, Ui.dp(1.0f)), -1929379841);
        } else if (z) {
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-11884801, Ui.BLUE, -14775046});
        } else {
            gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-1);
        }
        gradientDrawable.setCornerRadius(Ui.dp(12.0f));
        return gradientDrawable;
    }

    void bubbleShadow(View view, boolean z, boolean z2) {
        view.setElevation(Ui.dp((z || z2) ? 3.0f : 1.5f));
        if (Build.VERSION.SDK_INT >= 28) {
            int i = (!z || z2) ? -14796956 : -15309072;
            view.setOutlineSpotShadowColor(i);
            view.setOutlineAmbientShadowColor(i);
        }
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setBackgroundColor(Ui.BG);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setMinimumHeight(Ui.dp(56.0f));
        linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(8.0f), Ui.dp(6.0f));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setGravity(17);
        linearLayoutRow2.setPadding(Ui.dp(6.0f), 0, Ui.dp(8.0f), 0);
        linearLayoutRow2.setMinimumWidth(Ui.dp(42.0f));
        G.on(linearLayoutRow2, 0, 15.0f, 2.0f);
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico("back", Ui.TEXT));
        linearLayoutRow2.addView(imageView, Ui.lp(Ui.dp(28.0f), Ui.dp(28.0f)));
        this.bn = Ui.text(this.a, "", 13.0f, Ui.TEXT);
        this.bn.setGravity(17);
        this.bn.setMinWidth(Ui.dp(26.0f));
        this.bn.setPadding(Ui.dp(7.0f), 0, Ui.dp(7.0f), 0);
        this.bn.setBackground(Ui.round(-1841687, 13.0f));
        linearLayoutRow2.addView(this.bn, Ui.lpm(-2, Ui.dp(26.0f), 2, 0, 0, 0));
        linearLayoutRow2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.a.back();
            }
        });
        Ui.bounce(linearLayoutRow2);
        linearLayoutRow.addView(linearLayoutRow2, Ui.lpm(-2, Ui.dp(42.0f), 0, 0, 8, 0));
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        this.title = Ui.one(Ui.bold(Ui.text(this.a, "", 18.0f, Ui.TEXT)));
        this.sub = Ui.one(Ui.text(this.a, "", 12.0f, Ui.SUB));
        linearLayoutCol2.addView(this.title);
        linearLayoutCol2.addView(this.sub);
        linearLayoutRow.addView(linearLayoutCol2, Ui.lp(0, -2, 1.0f));
        if (!this.self) {
            ImageView imageView2 = new ImageView(this.a);
            imageView2.setImageDrawable(new Ico("menu", Ui.TEXT));
            int iDp = Ui.dp(8.0f);
            imageView2.setPadding(iDp, iDp, iDp, iDp);
            G.on(imageView2, 0, 15.0f, 2.0f);
            Ui.bounce(imageView2);
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    if (ChatScr.this.group) {
                        ChatScr.this.a.web("ginfo", "a", ChatScr.this.gid);
                    } else {
                        ChatScr.this.a.web("profile", "a", ChatScr.this.summary().s("nk"));
                    }
                }
            });
            linearLayoutRow.addView(imageView2, Ui.lp(Ui.dp(42.0f), Ui.dp(42.0f)));
        }
        linearLayoutCol.addView(linearLayoutRow);
        this.noticeBar = Ui.row(this.a);
        this.noticeBar.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(10.0f), Ui.dp(9.0f));
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1300, -2852});
        gradientDrawable.setCornerRadius(Ui.dp(16.0f));
        gradientDrawable.setStroke(1, -855638017);
        this.noticeBar.setBackground(gradientDrawable);
        this.noticeBar.setElevation(Ui.dp(2.0f));
        this.noticeBar.addView(new Emo(this.a, "📢", true), Ui.lpm(Ui.dp(30.0f), Ui.dp(30.0f), 0, 0, 6, 0));
        this.noticeT = Ui.one(Ui.text(this.a, "", 14.0f, -7710208));
        this.noticeBar.addView(this.noticeT, Ui.lp(0, -2, 1.0f));
        TextView textViewText = Ui.text(this.a, "×", 16.0f, -5207478);
        textViewText.setGravity(17);
        G.on(textViewText, 0, 13.0f, 1.0f);
        this.noticeBar.addView(textViewText, Ui.lpm(Ui.dp(26.0f), Ui.dp(26.0f), 8, 0, 0, 0));
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                J jNotice = ChatScr.this.notice();
                if (jNotice != null) {
                    App.kv.edit().putLong("ndis:" + ChatScr.this.gid, jNotice.l("id")).apply();
                }
                ChatScr.this.noticeBar.setVisibility(8);
            }
        });
        this.noticeBar.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.a.web("ginfo", "a", ChatScr.this.gid);
            }
        });
        this.noticeBar.setVisibility(8);
        linearLayoutCol.addView(this.noticeBar, Ui.lpm(-1, -2, 10, 8, 10, 0));
        this.callBar = Ui.bold(Ui.text(this.a, "", 14.0f, -1));
        this.callBar.setGravity(16);
        this.callBar.setPadding(Ui.dp(14.0f), Ui.dp(9.0f), Ui.dp(14.0f), Ui.dp(9.0f));
        G.on(this.callBar, 6, 16.0f, 3.0f);
        this.callBar.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                J jSummary = ChatScr.this.summary();
                Call.joinGroup(ChatScr.this.a, ChatScr.this.gid, jSummary.s("title"), jSummary.sn("av"), ChatScr.this.gcVideo);
            }
        });
        this.callBar.setVisibility(8);
        linearLayoutCol.addView(this.callBar, Ui.lpm(-1, -2, 10, 8, 10, 0));
        if (this.group) {
            this.C.sendQ(J.of("t", "c_gcall", "kind", "info", "gid", this.gid));
        }
        FrameLayout frameLayout = new FrameLayout(this.a);
        this.list = new ListView(this.a);
        this.list.setDivider(null);
        this.list.setSelector(new ColorDrawable(0));
        this.list.setCacheColorHint(0);
        this.list.setStackFromBottom(true);
        this.list.setTranscriptMode(1);
        this.list.setClipToPadding(false);
        this.list.setPadding(Ui.dp(12.0f), Ui.dp(10.0f), Ui.dp(12.0f), Ui.dp(6.0f));
        this.list.setAdapter((ListAdapter) this.ad);
        this.list.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.changliao.im.ChatScr.9
            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                if (i3 - i == i7 - i5 || i7 - i5 <= 0) {
                    return;
                }
                ChatScr.this.ad.cache.evictAll();
                ChatScr.this.ad.notifyDataSetChanged();
            }
        });
        this.list.setOnScrollListener(new AbsListView.OnScrollListener() { // from class: com.changliao.im.ChatScr.10
            @Override // android.widget.AbsListView.OnScrollListener
            public void onScroll(AbsListView absListView, int i, int i2, int i3) {
                boolean z = false;
                if (i3 > 0 && i + i2 >= i3 - 1 && ChatScr.this.newN > 0) {
                    ChatScr.this.newN = 0;
                    ChatScr.this.badge();
                }
                if (i == 0 && i3 > i2 && ChatScr.this.ad.ready) {
                    ChatScr.this.loadOlder();
                }
                ChatScr chatScr = ChatScr.this;
                if (i3 > 0 && i + i2 < i3 - 1) {
                    z = true;
                }
                chatScr.showJump(z);
            }

            @Override // android.widget.AbsListView.OnScrollListener
            public void onScrollStateChanged(AbsListView absListView, int i) {
                if (i == 1) {
                    ChatScr.this.a.hideKb();
                    if (ChatScr.this.panel.getVisibility() == 0) {
                        ChatScr.this.showPanel("");
                    }
                }
            }
        });
        frameLayout.addView(this.list, new FrameLayout.LayoutParams(-1, -1));
        this.jump = new FrameLayout(this.a);
        this.jump.setClipChildren(false);
        View view = new View(this.a);
        G.on(view, 0, 22.0f, 6.0f);
        this.jump.addView(view, new FrameLayout.LayoutParams(Ui.dp(44.0f), Ui.dp(44.0f), 17));
        ImageView imageView3 = new ImageView(this.a);
        imageView3.setImageDrawable(new Ico("back", -10787726));
        imageView3.setRotation(-90.0f);
        imageView3.setPadding(Ui.dp(11.0f), Ui.dp(11.0f), Ui.dp(11.0f), Ui.dp(11.0f));
        imageView3.setElevation(Ui.dp(7.0f));
        this.jump.addView(imageView3, new FrameLayout.LayoutParams(Ui.dp(44.0f), Ui.dp(44.0f), 17));
        this.newPill = Ui.bold(Ui.text(this.a, "", 11.0f, -1));
        this.newPill.setGravity(17);
        this.newPill.setMinWidth(Ui.dp(18.0f));
        this.newPill.setPadding(Ui.dp(5.0f), 0, Ui.dp(5.0f), 0);
        this.newPill.setBackground(Ui.round(-704705, 9.0f));
        this.newPill.setElevation(Ui.dp(8.0f));
        this.newPill.setVisibility(8);
        this.jump.addView(this.newPill, new FrameLayout.LayoutParams(-2, Ui.dp(18.0f), 8388661));
        this.jump.setPadding(Ui.dp(6.0f), Ui.dp(6.0f), Ui.dp(6.0f), Ui.dp(6.0f));
        this.jump.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                ChatScr.this.toBottom();
            }
        });
        this.jump.setVisibility(8);
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 8388693);
        layoutParamsFlp.rightMargin = Ui.dp(10.0f);
        layoutParamsFlp.bottomMargin = Ui.dp(12.0f);
        frameLayout.addView(this.jump, layoutParamsFlp);
        linearLayoutCol.addView(frameLayout, Ui.lp(-1, 0, 1.0f));
        G.keepClip(frameLayout);
        G.keepClip(linearLayoutCol);
        this.list.setClipChildren(true);
        this.banB = banBar();
        linearLayoutCol.addView(this.banB, Ui.lpm(-1, -2, 10, 6, 10, 6));
        this.inputV = buildInput();
        linearLayoutCol.addView(this.inputV);
        updBanUi();
        String string = App.kv.getString("draft:" + this.conv, null);
        if (string != null) {
            this.ta.setText(string);
            this.ta.setSelection(string.length());
        }
        head();
        this.ad.rebuild();
        this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.ChatScr.12
            @Override // java.lang.Runnable
            public void run() {
                ChatScr.this.ad.ready = true;
            }
        }, 900L);
        return linearLayoutCol;
    }

    View buildInput() {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setBackground(new LayerDrawable(new Drawable[]{new ColorDrawable(-526086), HomeScr.topLineColor(Ui.LINE)}));
        linearLayoutCol.setPadding(Ui.dp(10.0f), Ui.dp(8.0f), Ui.dp(10.0f), Ui.dp(4.0f));
        this.replyBar = Ui.row(this.a);
        this.replyBar.setPadding(Ui.dp(4.0f), 0, Ui.dp(4.0f), Ui.dp(7.0f));
        this.replyT = Ui.one(Ui.text(this.a, "", 13.0f, Ui.SUB));
        this.replyBar.addView(this.replyT, Ui.lp(0, -2, 1.0f));
        TextView textViewText = Ui.text(this.a, "×", 16.0f, Ui.SUB);
        textViewText.setGravity(17);
        G.on(textViewText, 0, 13.0f, 1.0f);
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.setReply(null);
            }
        });
        this.replyBar.addView(textViewText, Ui.lpm(Ui.dp(26.0f), Ui.dp(26.0f), 8, 0, 0, 0));
        this.replyBar.setVisibility(8);
        linearLayoutCol.addView(this.replyBar);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setGravity(80);
        FrameLayout frameLayout = new FrameLayout(this.a);
        this.ta = new EditText(this.a);
        this.ta.setTextSize(16.0f);
        this.ta.setTextColor(Ui.TEXT);
        this.ta.setHintTextColor(-6643285);
        this.ta.setMaxLines(5);
        this.ta.setMinHeight(Ui.dp(40.0f));
        this.ta.setLineSpacing(0.0f, 1.15f);
        this.ta.setInputType(147457);
        this.ta.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        this.ta.setBackground(new G(3, 16.0f));
        this.ta.setPadding(Ui.dp(12.0f), Ui.dp(9.0f), Ui.dp(12.0f), Ui.dp(9.0f));
        this.ta.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.changliao.im.ChatScr.16
            @Override // android.view.View.OnFocusChangeListener
            public void onFocusChange(View view, boolean z) {
                if (z) {
                    ChatScr.this.showPanel("");
                }
            }
        });
        this.ta.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.17
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.showPanel("");
            }
        });
        this.ta.addTextChangedListener(new TextWatcher() { // from class: com.changliao.im.ChatScr.18
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                boolean z = editable.toString().trim().length() > 0;
                ChatScr.this.setSendOn(z);
                if (!ChatScr.this.conv.startsWith("p:") || ChatScr.this.self || !z || System.currentTimeMillis() - ChatScr.this.typSent <= 2500) {
                    return;
                }
                ChatScr.this.typSent = System.currentTimeMillis();
                ChatScr.this.C.sendQ(J.of("t", "c_typing", "conv", ChatScr.this.conv));
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }
        });
        frameLayout.addView(this.ta, new FrameLayout.LayoutParams(-1, -2));
        this.holdB = Ui.text(this.a, "按住 说话", 16.0f, Ui.TEXT);
        this.holdB.setGravity(17);
        G.on(this.holdB, 0, 16.0f, 2.0f);
        this.holdB.setVisibility(8);
        this.holdB.setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.ChatScr.19
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return ChatScr.this.holdTouch(motionEvent);
            }
        });
        frameLayout.addView(this.holdB, new FrameLayout.LayoutParams(-1, Ui.dp(40.0f)));
        linearLayoutRow.addView(frameLayout, Ui.lp(0, -2, 1.0f));
        this.sendB = Ui.bold(Ui.text(this.a, "发送", 16.0f, -1));
        this.sendB.setGravity(17);
        this.sendB.setPadding(Ui.dp(18.0f), 0, Ui.dp(18.0f), 0);
        G.on(this.sendB, 1, 10.0f, 4.0f);
        this.sendB.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.20
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.sendText();
            }
        });
        Ui.bounce(this.sendB);
        linearLayoutRow.addView(this.sendB, Ui.lpm(-2, Ui.dp(40.0f), 8, 0, 0, 0));
        linearLayoutCol.addView(linearLayoutRow);
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setPadding(0, Ui.dp(6.0f), 0, Ui.dp(2.0f));
        this.micB = tool("mic", new View.OnClickListener() { // from class: com.changliao.im.ChatScr.21
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.setVoice(!ChatScr.this.voiceMode);
            }
        });
        ImageView olVar = tool("img", new View.OnClickListener() { // from class: com.changliao.im.ChatScr.22
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.pickMedia();
            }
        });
        ImageView olVar2 = tool("cam", new View.OnClickListener() { // from class: com.changliao.im.ChatScr.23
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.camera();
            }
        });
        this.emoB = tool("emo", new View.OnClickListener() { // from class: com.changliao.im.ChatScr.24
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.showPanel(ChatScr.this.panelMode.equals("emo") ? "" : "emo");
            }
        });
        this.plusB = tool("plus", new View.OnClickListener() { // from class: com.changliao.im.ChatScr.25
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.showPanel(ChatScr.this.panelMode.equals("plus") ? "" : "plus");
            }
        });
        View[] viewArr = {this.micB, olVar, olVar2, this.emoB, this.plusB};
        for (View view : viewArr) {
            FrameLayout frameLayout2 = new FrameLayout(this.a);
            frameLayout2.addView(view, Ui.flp(Ui.dp(42.0f), Ui.dp(42.0f), 17));
            linearLayoutRow2.addView(frameLayout2, Ui.lp(0, Ui.dp(46.0f), 1.0f));
        }
        linearLayoutCol.addView(linearLayoutRow2);
        this.panel = new FrameLayout(this.a);
        this.panel.setVisibility(8);
        linearLayoutCol.addView(this.panel, Ui.lp(-1, -2));
        setSendOn(false);
        return linearLayoutCol;
    }

    void call(boolean z) {
        J jSummary = summary();
        if (this.group) {
            Call.joinGroup(this.a, this.gid, jSummary.s("title"), jSummary.sn("av"), z);
        } else {
            Call.dial(this.a, jSummary.s("nk"), jSummary.s("title"), jSummary.sn("av"), z);
        }
    }

    void camera() {
        if (!this.a.has("android.permission.CAMERA")) {
            this.a.requestPermissions(new String[]{"android.permission.CAMERA"}, 6);
            toast("请允许使用相机后再试");
            return;
        }
        final String str = "IMG_" + System.currentTimeMillis() + ".jpg";
        Uri uri = Uri.parse("content://" + this.a.getPackageName() + ".prov/" + str);
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra("output", uri);
        intent.addFlags(3);
        intent.setClipData(ClipData.newRawUri("", uri));
        this.a.startFor(intent, new MainActivity.Res() { // from class: com.changliao.im.ChatScr.39
            @Override // com.changliao.im.MainActivity.Res
            public void got(int i, Intent intent2) {
                File file = new File(ChatScr.this.a.getExternalFilesDir("Camera"), str);
                if (i == -1 && file.exists() && file.length() > 0) {
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(Uri.fromFile(file));
                    ChatScr.this.sendUris(arrayList, true, false);
                }
            }
        });
    }

    View content(final J j, boolean z) {
        String size;
        String str;
        String string;
        int i;
        float f;
        int iMin;
        int iMax;
        int iMax2;
        String strS = j.s("k");
        final J j2 = j.o("f") == null ? new J() : j.o("f");
        boolean zWide = this.a.wide();
        if (strS.equals("img")) {
            boolean zB = j2.b("stk");
            int iL = (int) j2.l("w");
            int iL2 = (int) j2.l("h");
            if (zB) {
                iMin = Ui.dp(120.0f);
            } else {
                iMin = Math.min(this.maxBody, Ui.dp(zWide ? 300.0f : 240.0f));
            }
            int iDp = zB ? Ui.dp(120.0f) : Ui.dp(320.0f);
            if (iL <= 0 || iL2 <= 0) {
                int iDp2 = zB ? Ui.dp(120.0f) : Ui.dp(160.0f);
                iMax = iDp2;
                iMax2 = iDp2;
            } else {
                float fMin = Math.min((iMin * 1.0f) / iL, (iDp * 1.0f) / iL2);
                if (!zB) {
                    fMin = Math.min(fMin, Ui.D * 1.0f);
                }
                iMax2 = Math.max(Ui.dp(60.0f), (int) (iL * fMin));
                iMax = Math.max(Ui.dp(60.0f), (int) (fMin * iL2));
            }
            ImageView imageView = new ImageView(this.a);
            imageView.setScaleType(zB ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
            if (zB) {
                clip(imageView, 6.0f);
            } else {
                imageView.setBackground(Ui.round(-1841430, 10.0f));
                clip(imageView, 10.0f);
            }
            imageView.setLayoutParams(Ui.lp(iMax2, iMax));
            Img.into(imageView, Core.fileUrl(j2.s("id"), j2.s("name")), 600);
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.48
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ChatScr.this.a.push(new ImgScr(j2, ChatScr.this.conv, j));
                }
            });
            return imageView;
        }
        if (strS.equals("video")) {
            FrameLayout frameLayout = new FrameLayout(this.a);
            int iL3 = (int) j2.l("w");
            int iL4 = (int) j2.l("h");
            int iMin2 = Math.min(this.maxBody, Ui.dp(zWide ? 300.0f : 220.0f));
            int iDp3 = Ui.dp(300.0f);
            int iDp4 = Ui.dp(200.0f);
            int iDp5 = Ui.dp(140.0f);
            if (iL3 > 0 && iL4 > 0) {
                float fMin2 = Math.min((1.0f * iMin2) / iL3, (1.0f * iDp3) / iL4);
                iDp4 = (int) (iL3 * fMin2);
                iDp5 = (int) (fMin2 * iL4);
            }
            int iMax3 = Math.max(iDp4, Ui.dp(120.0f));
            int iMax4 = Math.max(iDp5, Ui.dp(90.0f));
            frameLayout.setBackground(Ui.round(Ui.TEXT, 10.0f));
            clip(frameLayout, 10.0f);
            if (j2.s("poster").length() > 0) {
                ImageView imageView2 = new ImageView(this.a);
                imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                Img.into(imageView2, Core.fileUrl(j2.s("poster"), "p.jpg"), 600);
                frameLayout.addView(imageView2, new FrameLayout.LayoutParams(-1, -1));
            }
            frameLayout.addView(new PlayCircle(this.a), Ui.flp(Ui.dp(46.0f), Ui.dp(46.0f), 17));
            long jL = j2.l("dur");
            TextView textViewText = Ui.text(this.a, jL > 0 ? (jL / 60) + ":" + Ui.pad((int) (jL % 60)) : Ui.size(j2.l("size")), 12.0f, -1);
            textViewText.setShadowLayer(Ui.dp(2.0f), 0.0f, Ui.dp(1.0f), -1728053248);
            FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 8388693);
            layoutParamsFlp.rightMargin = Ui.dp(7.0f);
            layoutParamsFlp.bottomMargin = Ui.dp(5.0f);
            frameLayout.addView(textViewText, layoutParamsFlp);
            frameLayout.setLayoutParams(Ui.lp(iMax3, iMax4));
            frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.49
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ChatScr.this.a.push(new VidScr(j2, ChatScr.this.conv, j));
                }
            });
            return frameLayout;
        }
        if (strS.equals("file") || strS.equals("up")) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setPadding(Ui.dp(12.0f), Ui.dp(11.0f), Ui.dp(12.0f), Ui.dp(11.0f));
            G g = new G(0, 12.0f);
            g.bg = -1;
            linearLayoutRow.setBackground(Ui.ripple(g, 12.0f));
            bubbleShadow(linearLayoutRow, false, false);
            boolean z2 = strS.equals("up") && j.b("img");
            String strS2 = strS.equals("up") ? j.s("name") : j2.s("name");
            linearLayoutRow.addView(Ui.text(this.a, z2 ? "🖼️" : Ui.fileIcon(strS2), 30.0f, Ui.TEXT), Ui.lpm(-2, -2, 0, 0, 10, 0));
            LinearLayout linearLayoutCol = Ui.col(this.a);
            TextView textViewText2 = Ui.text(this.a, strS2, 14.0f, Ui.TEXT);
            textViewText2.setMaxLines(2);
            textViewText2.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            linearLayoutCol.addView(textViewText2);
            if (strS.equals("up")) {
                size = j.has("err") ? j.s("err") : "上传中 " + Math.round(j.d("pct") * 100.0d) + "%";
            } else {
                size = Ui.size(j2.l("size"));
                if (j.b("mine") && j.l("rcv") > 0) {
                    size = size + " · " + (this.group ? j.l("rcv") + " 人已接收" : "对方已接收");
                } else if (App.kv.getString("dl:" + j2.s("id"), null) != null) {
                    size = size + " · 已下载，点击打开";
                }
                if (strS.equals("file") && j2.b("exp") && App.kv.getString("dl:" + j2.s("id"), null) == null) {
                    size = Ui.size(j2.l("size")) + " · 文件已过期";
                } else if (strS.equals("file") && j2.l("until") > 0 && App.kv.getString("dl:" + j2.s("id"), null) == null) {
                    long jL2 = j2.l("until") - (System.currentTimeMillis() / 1000);
                    StringBuilder sbAppend = new StringBuilder().append(size);
                    if (jL2 <= 0) {
                        string = " · 即将过期";
                    } else {
                        StringBuilder sbAppend2 = new StringBuilder().append(" · ");
                        if (jL2 >= 86400) {
                            str = (jL2 / 86400) + " 天";
                        } else {
                            str = jL2 >= 3600 ? (jL2 / 3600) + " 小时" : Math.max(1L, jL2 / 60) + " 分钟";
                        }
                        string = sbAppend2.append(str).append("后过期").toString();
                    }
                    size = sbAppend.append(string).toString();
                }
            }
            final TextView textViewText3 = Ui.text(this.a, size, 12.0f, j.has("err") ? Ui.RED : Ui.SUB);
            linearLayoutCol.addView(textViewText3, Ui.lpm(-2, -2, 0, 2, 0, 0));
            if (strS.equals("up") && !j.has("err")) {
                FrameLayout frameLayout2 = new FrameLayout(this.a);
                frameLayout2.setBackground(Ui.round(522096895, 2.0f));
                View view = new View(this.a);
                view.setBackground(Ui.round(Ui.BLUE, 2.0f));
                frameLayout2.addView(view, new FrameLayout.LayoutParams((int) (((double) Ui.dp(180.0f)) * j.d("pct")), -1));
                linearLayoutCol.addView(frameLayout2, Ui.lpm(Ui.dp(180.0f), Ui.dp(4.0f), 0, 6, 0, 0));
            }
            linearLayoutRow.addView(linearLayoutCol, Ui.lp(Math.min(this.maxBody, Ui.dp(250.0f)) - Ui.dp(64.0f), -2));
            if (strS.equals("file")) {
                linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.50
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        if (j2.b("exp") && App.kv.getString("dl:" + j2.s("id"), null) == null) {
                            ChatScr.this.toast("私聊文件只保存 3 天，这个文件已经过期了");
                        } else {
                            ChatScr.this.openFile(j, j2, textViewText3);
                        }
                    }
                });
            }
            return linearLayoutRow;
        }
        if (strS.equals("voice")) {
            long jMax = Math.max(1L, j2.l("dur"));
            LinearLayout linearLayoutRow2 = Ui.row(this.a);
            linearLayoutRow2.setPadding(Ui.dp(13.0f), Ui.dp(10.0f), Ui.dp(13.0f), Ui.dp(10.0f));
            linearLayoutRow2.setGravity(z ? 8388629 : 8388627);
            linearLayoutRow2.setBackground(Ui.ripple(bubbleBg(J.of(new Object[0]), z), 12.0f));
            bubbleShadow(linearLayoutRow2, z, false);
            int i2 = z ? -1 : Ui.TEXT;
            Wave wave = new Wave(this.a, i2, this.playing == j.l("id"));
            TextView textViewText4 = Ui.text(this.a, jMax + "\"", 15.0f, i2);
            if (z) {
                linearLayoutRow2.addView(textViewText4);
                linearLayoutRow2.addView(wave, Ui.lpm(Ui.dp(14.0f), Ui.dp(18.0f), 8, 0, 0, 0));
            } else {
                linearLayoutRow2.addView(wave, Ui.lpm(Ui.dp(14.0f), Ui.dp(18.0f), 0, 0, 8, 0));
                linearLayoutRow2.addView(textViewText4);
            }
            linearLayoutRow2.setLayoutParams(Ui.lp(Math.min(Ui.dp(220.0f), Ui.dp(76 + (4 * jMax))), -2));
            linearLayoutRow2.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.51
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    ChatScr.this.playVoice(j, j2);
                }
            });
            return linearLayoutRow2;
        }
        if (strS.equals("call")) {
            final boolean zStartsWith = j.s("text").startsWith("视频");
            LinearLayout linearLayoutRow3 = Ui.row(this.a);
            linearLayoutRow3.setPadding(Ui.dp(13.0f), Ui.dp(10.0f), Ui.dp(13.0f), Ui.dp(10.0f));
            linearLayoutRow3.setBackground(Ui.ripple(bubbleBg(J.of(new Object[0]), z), 12.0f));
            bubbleShadow(linearLayoutRow3, z, false);
            int i3 = z ? -1 : -14868183;
            ImageView imageView3 = new ImageView(this.a);
            imageView3.setImageDrawable(new Ico(zStartsWith ? "video" : "phone", i3));
            linearLayoutRow3.addView(imageView3, Ui.lpm(Ui.dp(20.0f), Ui.dp(20.0f), 0, 0, 8, 0));
            linearLayoutRow3.addView(Ui.text(this.a, j.s("text"), 16.0f, i3));
            linearLayoutRow3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.52
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (ChatScr.this.group || ChatScr.this.self) {
                        return;
                    }
                    ChatScr.this.call(zStartsWith);
                }
            });
            return linearLayoutRow3;
        }
        if (strS.equals("notice")) {
            LinearLayout linearLayoutRow4 = Ui.row(this.a);
            View view2 = new View(this.a);
            view2.setBackgroundColor(Ui.GOLD);
            linearLayoutRow4.addView(view2, Ui.lp(Ui.dp(4.0f), -1));
            LinearLayout linearLayoutCol2 = Ui.col(this.a);
            linearLayoutCol2.setPadding(Ui.dp(13.0f), Ui.dp(11.0f), Ui.dp(13.0f), Ui.dp(11.0f));
            LinearLayout linearLayoutRow5 = Ui.row(this.a);
            linearLayoutRow5.addView(new Emo(this.a, "📢", true), Ui.lpm(Ui.dp(26.0f), Ui.dp(26.0f), 0, 0, 4, 0));
            linearLayoutRow5.addView(Ui.bold(Ui.text(this.a, "群公告", 13.0f, -2524672)));
            linearLayoutCol2.addView(linearLayoutRow5, Ui.lpm(-2, -2, 0, 0, 0, 4));
            TextView textViewText5 = Ui.text(this.a, j.s("text"), 16.0f, Ui.TEXT);
            textViewText5.setMaxWidth(this.maxBody - Ui.dp(30.0f));
            linearLayoutCol2.addView(textViewText5, new LinearLayout.LayoutParams(-2, -2));
            linearLayoutRow4.addView(linearLayoutCol2);
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-218103809, -637535504});
            gradientDrawable.setCornerRadius(Ui.dp(12.0f));
            gradientDrawable.setStroke(1, -855638017);
            linearLayoutRow4.setBackground(gradientDrawable);
            clip(linearLayoutRow4, 12.0f);
            bubbleShadow(linearLayoutRow4, false, false);
            return linearLayoutRow4;
        }
        List<String> listOnly = j.s("re_text").length() > 0 ? null : Emo.only(j.s("text"));
        if (listOnly == null) {
            int[] iArr = (!j.b("vip") || j.s("bub").length() <= 0) ? null : Bubbles.B.get(j.s("bub"));
            if (iArr != null) {
                i = iArr[0];
            } else {
                i = z ? -1 : -14868183;
            }
            FrameLayout frameLayout3 = new FrameLayout(this.a);
            frameLayout3.setClipChildren(false);
            frameLayout3.setClipToPadding(false);
            LinearLayout linearLayoutCol3 = Ui.col(this.a);
            linearLayoutCol3.setBackground(bubbleBg(j, z));
            bubbleShadow(linearLayoutCol3, z, iArr != null);
            linearLayoutCol3.setPadding(Ui.dp(13.0f), Ui.dp(10.0f), Ui.dp(13.0f), Ui.dp(10.0f));
            if (j.s("re_text").length() > 0) {
                TextView textViewOne = Ui.one(Ui.text(this.a, j.s("re_from") + "：" + j.s("re_text"), 13.0f, (z && iArr == null) ? -1641729 : Ui.SUB));
                textViewOne.setMaxWidth(Ui.dp(240.0f));
                textViewOne.setBackground(Ui.round((z && iArr == null) ? 654311423 : 167772160, 6.0f));
                textViewOne.setPadding(Ui.dp(8.0f), Ui.dp(3.0f), Ui.dp(8.0f), Ui.dp(3.0f));
                linearLayoutCol3.addView(textViewOne, Ui.lpm(-2, -2, 0, 0, 0, 6));
            }
            Tight tight = new Tight(this.a);
            tight.setTextSize(16.0f);
            tight.setTextColor(i);
            tight.setMaxWidth(this.maxBody - Ui.dp(26.0f));
            tight.setLineSpacing(0.0f, 1.1f);
            SpannableString spannableString = new SpannableString(j.s("text"));
            Matcher matcher = AT.matcher(spannableString);
            while (matcher.find()) {
                spannableString.setSpan(new ForegroundColorSpan((z && iArr == null) ? -1 : Ui.BLUE), matcher.start(2) - 1, matcher.end(2), 33);
                if (z && iArr == null) {
                    spannableString.setSpan(new StyleSpan(1), matcher.start(2) - 1, matcher.end(2), 33);
                }
            }
            tight.setText(spannableString, TextView.BufferType.SPANNABLE);
            if (j.s("text").contains("http") || j.s("text").contains("www.")) {
                Linkify.addLinks(tight, 1);
                tight.setLinkTextColor((z && iArr == null) ? -1 : Ui.BLUE);
            }
            linearLayoutCol3.addView(tight, new LinearLayout.LayoutParams(-2, -2));
            if (iArr == null) {
                return linearLayoutCol3;
            }
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
            layoutParams.topMargin = Ui.dp(9.0f);
            layoutParams.leftMargin = z ? Ui.dp(6.0f) : 0;
            layoutParams.rightMargin = !z ? Ui.dp(6.0f) : 0;
            frameLayout3.addView(linearLayoutCol3, layoutParams);
            String str2 = BUB_EMOJI.get(j.s("bub"));
            if (str2 != null) {
                TextView textViewText6 = Ui.text(this.a, str2, 15.0f, Ui.TEXT);
                textViewText6.setShadowLayer(Ui.dp(1.0f), 0.0f, Ui.dp(1.0f), 855638016);
                textViewText6.setElevation(Ui.dp(4.0f));
                frameLayout3.addView(textViewText6, new FrameLayout.LayoutParams(-2, -2, (z ? 8388611 : 8388613) | 48));
            }
            return frameLayout3;
        }
        LinearLayout linearLayoutRow6 = Ui.row(this.a);
        if (listOnly.size() == 1) {
            f = 120.0f;
        } else {
            f = listOnly.size() == 2 ? 96.0f : 82.0f;
        }
        int iDp6 = Ui.dp(f);
        int i4 = 0;
        while (true) {
            int i5 = i4;
            if (i5 >= listOnly.size()) {
                return linearLayoutRow6;
            }
            linearLayoutRow6.addView(new Emo(this.a, listOnly.get(i5), false).key(this.conv + "|" + j.s("text") + "|" + i5), Ui.lp(iDp6, iDp6));
            i4 = i5 + 1;
        }
    }

    View emojiPanel() {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        ScrollView scrollView = new ScrollView(this.a);
        GridLayout gridLayout = new GridLayout(this.a);
        int iPanelW = panelW();
        int iMax = Math.max(6, iPanelW / Ui.dp(52.0f));
        gridLayout.setColumnCount(iMax);
        gridLayout.setPadding(Ui.dp(4.0f), Ui.dp(6.0f), Ui.dp(4.0f), Ui.dp(2.0f));
        int iDp = (iPanelW - Ui.dp(8.0f)) / iMax;
        if (this.stkTab) {
            TextView textViewText = Ui.text(this.a, "＋", 30.0f, -5196098);
            textViewText.setGravity(17);
            G.on(textViewText, 0, 10.0f, 1.0f);
            textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.27
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ChatScr.this.addSticker();
                }
            });
            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
            layoutParams.width = iDp - Ui.dp(6.0f);
            layoutParams.height = Ui.dp(80.0f);
            layoutParams.setMargins(Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f));
            gridLayout.addView(textViewText, layoutParams);
            Iterator<Object> it = this.C.stk.iterator();
            while (it.hasNext()) {
                final String strValueOf = String.valueOf(it.next());
                ImageView imageView = new ImageView(this.a);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setPadding(Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f));
                G.on(imageView, 0, 10.0f, 1.0f);
                Img.into(imageView, Core.fileUrl(strValueOf, "s.png"), 200);
                imageView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.28
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ChatScr.this.C.send(J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "img", "fid", strValueOf, "stk", 1));
                    }
                });
                imageView.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.changliao.im.ChatScr.29
                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View view) {
                        ChatScr.this.a.confirm("删除这个表情？", null, "删除", true, new Runnable() { // from class: com.changliao.im.ChatScr.29.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ChatScr.this.C.send(J.of("t", "c_stk", "act", "del", "fid", strValueOf));
                            }
                        });
                        return true;
                    }
                });
                GridLayout.LayoutParams layoutParams2 = new GridLayout.LayoutParams();
                layoutParams2.width = iDp - Ui.dp(6.0f);
                layoutParams2.height = Ui.dp(80.0f);
                layoutParams2.setMargins(Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f));
                gridLayout.addView(imageView, layoutParams2);
            }
            if (this.C.stk.isEmpty()) {
                TextView textViewText2 = Ui.text(this.a, "点 ＋ 添加图片表情，或长按聊天里的图片「添加到表情」", 13.0f, Ui.SUB);
                GridLayout.LayoutParams layoutParams3 = new GridLayout.LayoutParams(GridLayout.spec(1), GridLayout.spec(0, iMax));
                layoutParams3.setMargins(Ui.dp(8.0f), Ui.dp(8.0f), Ui.dp(8.0f), 0);
                gridLayout.addView(textViewText2, layoutParams3);
            }
        } else {
            for (final String str : EMOJI.split(" ")) {
                TextView textViewText3 = Ui.text(this.a, str, 27.0f, Ui.TEXT);
                textViewText3.setGravity(17);
                GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1627389953, 1207959551});
                gradientDrawable.setCornerRadius(Ui.dp(12.0f));
                gradientDrawable.setStroke(1, -1493172225);
                textViewText3.setBackground(Ui.ripple(gradientDrawable, 12.0f));
                textViewText3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.26
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ChatScr.this.ta.getText().insert(Math.max(0, ChatScr.this.ta.getSelectionStart()), str);
                    }
                });
                Ui.bounce(textViewText3);
                GridLayout.LayoutParams layoutParams4 = new GridLayout.LayoutParams();
                layoutParams4.width = iDp - Ui.dp(6.0f);
                layoutParams4.height = Ui.dp(46.0f);
                layoutParams4.setMargins(Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f), Ui.dp(3.0f));
                gridLayout.addView(textViewText3, layoutParams4);
            }
        }
        scrollView.addView(gridLayout);
        linearLayoutCol.addView(scrollView, Ui.lp(-1, Math.min((int) (this.a.getResources().getDisplayMetrics().heightPixels * 0.34f), Ui.dp(280.0f))));
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(4.0f), Ui.dp(6.0f), Ui.dp(4.0f), Ui.dp(2.0f));
        linearLayoutRow.addView(etab("😀", !this.stkTab, false));
        linearLayoutRow.addView(etab("♡", this.stkTab, true));
        linearLayoutCol.addView(linearLayoutRow);
        return linearLayoutCol;
    }

    View etab(String str, boolean z, final boolean z2) {
        TextView textViewText = Ui.text(this.a, str, 20.0f, z ? -1 : -7958372);
        textViewText.setGravity(17);
        G.on(textViewText, z ? 1 : 0, 8.0f, z ? 3.0f : 1.0f);
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.30
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChatScr.this.stkTab = z2;
                ChatScr.this.showPanel("emo");
            }
        });
        textViewText.setLayoutParams(Ui.lpm(Ui.dp(46.0f), Ui.dp(34.0f), 0, 0, 6, 0));
        return textViewText;
    }

    void head() {
        String str;
        J jSummary = summary();
        String strS = this.self ? "文件传输助手" : jSummary.s("title");
        String str2 = "";
        if (this.group) {
            J j = this.C.ginfo.get(this.gid);
            if (j != null) {
                List<J> listObjs = j.objs("members");
                Iterator<J> it = listObjs.iterator();
                int i = 0;
                while (it.hasNext()) {
                    i = it.next().b("online") ? i + 1 : i;
                }
                strS = j.s("name") + "(" + listObjs.size() + ")";
                str = listObjs.size() + " 人 · " + i + " 人在线" + (j.b("muteall") ? " · 全员禁言中" : "");
            } else {
                str = "";
            }
            J jNotice = notice();
            boolean z = (jNotice == null || App.kv.getLong(new StringBuilder().append("ndis:").append(this.gid).toString(), -1L) == jNotice.l("id")) ? false : true;
            if (z) {
                this.noticeT.setText(jNotice.s("text").replace('\n', ' '));
            }
            this.noticeBar.setVisibility(z ? 0 : 8);
        } else if (System.currentTimeMillis() < this.typingUntil) {
            str = "对方正在输入…";
        } else if (this.self) {
            str = "在不同设备之间传文件、存东西";
        } else {
            for (J j2 : this.C.fr.objs("friends")) {
                str2 = j2.s("nk").equals(jSummary.s("nk")) ? j2.b("online") ? "● 在线" : "离线 · " + HomeScr.ago(j2.l("last")) : str2;
            }
            str = str2;
        }
        if (!this.C.connected) {
            str = "连接中…";
        }
        this.title.setText(strS);
        this.sub.setText(str);
        this.sub.setTextColor(str.startsWith("●") ? Ui.GREEN : Ui.SUB);
        this.sub.setVisibility(str.length() == 0 ? 8 : 0);
        int iL = 0;
        for (J j3 : this.C.convs.values()) {
            if (!j3.s("conv").equals(this.conv) && !this.C.mutes.contains(j3.s("conv"))) {
                iL = (int) (j3.l("unread") + ((long) iL));
            }
            iL = iL;
        }
        this.bn.setText(iL > 99 ? "99+" : String.valueOf(iL));
        this.bn.setVisibility((iL <= 0 || this.a.wide()) ? 8 : 0);
    }

    boolean holdTouch(MotionEvent motionEvent) {
        boolean z = false;
        switch (motionEvent.getActionMasked()) {
            case G.LIGHT /* 0 */:
                this.recY0 = motionEvent.getRawY();
                this.recCancel = false;
                startRec();
                return true;
            case G.BLUE /* 1 */:
            case G.INSET /* 3 */:
                if (!this.recCancel && motionEvent.getActionMasked() == 1) {
                    z = true;
                }
                stopRec(z);
                return true;
            case G.DARK /* 2 */:
                z = this.recY0 - motionEvent.getRawY() > ((float) Ui.dp(70.0f));
                if (z == this.recCancel) {
                    return true;
                }
                this.recCancel = z;
                this.holdB.setText(z ? "松开手指，取消发送" : "松开 发送");
                this.holdB.setTextColor(z ? Ui.RED : Ui.TEXT);
                return true;
            default:
                return false;
        }
    }

    void insertAt(String str, String str2) {
        if (this.voiceMode) {
            setVoice(false);
        }
        this.atMap.put(str, str2);
        this.ta.getText().insert(Math.max(0, this.ta.getSelectionStart()), "@" + str + " ");
        this.a.showKb(this.ta);
    }

    int listW() {
        if (this.list.getWidth() > 0) {
            return this.list.getWidth();
        }
        int width = this.a.host.getWidth() > 0 ? this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels;
        return this.a.wide() ? width - ((int) (width * 0.36f)) : width;
    }

    void loadOlder() {
        Boolean bool;
        long j;
        if (System.currentTimeMillis() - this.olderAt >= 1200 && (bool = this.C.more.get(this.conv)) != null && bool.booleanValue()) {
            List<J> list = this.C.msgs.get(this.conv);
            if (list != null) {
                Iterator<J> it = list.iterator();
                j = 0;
                while (it.hasNext()) {
                    long jL = it.next().l("id");
                    if (jL <= 0 || (j != 0 && jL >= j)) {
                        jL = j;
                    }
                    j = jL;
                }
            } else {
                j = 0;
            }
            if (j > 0) {
                this.olderAt = System.currentTimeMillis();
                this.C.send(J.of("t", "c_hist", "conv", this.conv, "before", Long.valueOf(j)));
            }
        }
    }

    void memberSheet(String str, final MainActivity.Str str2) {
        J j = this.C.ginfo.get(this.gid);
        if (j == null) {
            toast("群成员还没加载好，稍等一下");
            return;
        }
        final ArrayList arrayList = new ArrayList();
        for (J j2 : j.objs("members")) {
            if (!j2.b("me")) {
                arrayList.add(j2);
            }
        }
        final String[] strArr = new String[Math.min(arrayList.size(), 40)];
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= strArr.length) {
                this.a.sheet(str, strArr, -1, new MainActivity.Str() { // from class: com.changliao.im.ChatScr.33
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str3) {
                        for (int i3 = 0; i3 < strArr.length; i3++) {
                            if (strArr[i3].equals(str3)) {
                                str2.ok(((J) arrayList.get(i3)).s("nk"));
                                return;
                            }
                        }
                    }
                });
                return;
            } else {
                strArr[i2] = nameOf((J) arrayList.get(i2));
                i = i2 + 1;
            }
        }
    }

    void menuAct(String str, J j) {
        String strS = j.s("k");
        if (str.equals("复制")) {
            ((ClipboardManager) this.a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("msg", j.s("text")));
            toast("已复制");
            return;
        }
        if (str.equals("回复")) {
            setReply(j);
            return;
        }
        if (str.equals("撤回")) {
            this.C.send(J.of("t", "c_recall", "conv", this.conv, "id", Long.valueOf(j.l("id"))));
            return;
        }
        if (str.equals("保存") || str.equals("下载")) {
            Save.save(this.a, j.o("f"), strS);
            return;
        }
        if (str.equals("@TA")) {
            insertAt(j.s("name").length() > 0 ? j.s("name") : j.s("from"), j.s("fnk"));
            return;
        }
        if (str.equals("添加到表情")) {
            J jO = j.o("f");
            if (jO != null) {
                this.C.send(J.of("t", "c_stk", "act", "add", "fid", jO.s("id")));
                return;
            }
            return;
        }
        if (str.equals("转发")) {
            this.a.push(new FwdScr(j));
        } else if (str.equals("收藏")) {
            MiscScr.addFav(this.a, j);
        }
    }

    void msgMenu(final J j, View view) {
        String strS = j.s("k");
        if (strS.equals("sys") || strS.equals("recall")) {
            return;
        }
        J j2 = this.group ? this.C.ginfo.get(this.gid) : null;
        String strS2 = j2 == null ? "" : j2.s("myrole");
        boolean z = (j.b("mine") && (System.currentTimeMillis() / 1000) - j.l("ts") <= 120) || !(j2 == null || j.b("mine") || (!strS2.equals("owner") && (!strS2.equals("admin") || !j.s("grole").equals("member"))));
        boolean z2 = strS.equals("img") || strS.equals("file") || strS.equals("video") || strS.equals("voice");
        ArrayList<String[]> arrayList = new ArrayList();
        if (strS.equals("text") || strS.equals("notice")) {
            arrayList.add(new String[]{"copy", "复制"});
        }
        if (strS.equals("text") || z2) {
            arrayList.add(new String[]{"fwd", "转发"});
        }
        if (!strS.equals("call")) {
            arrayList.add(new String[]{"reply", "回复"});
        }
        if (strS.equals("img") || strS.equals("file") || strS.equals("video")) {
            String[] strArr = new String[2];
            strArr[0] = "save";
            strArr[1] = strS.equals("img") ? "保存" : "下载";
            arrayList.add(strArr);
        }
        if (this.group && !j.b("mine")) {
            arrayList.add(new String[]{"at2", "@TA"});
        }
        if (!strS.equals("call")) {
            arrayList.add(new String[]{"star", "收藏"});
        }
        if (strS.equals("img")) {
            arrayList.add(new String[]{"add", "添加到表情"});
        }
        if (z) {
            arrayList.add(new String[]{"undo", "撤回"});
        }
        Tight tightFindTight = strS.equals("text") ? findTight(view) : null;
        if (tightFindTight != null) {
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add(new String[]{"copy", "复制"});
            arrayList2.add(new String[]{"fwd", "转发"});
            arrayList2.add(new String[]{"reply", "回复"});
            if (this.group && !j.b("mine")) {
                arrayList2.add(new String[]{"at2", "@TA"});
            }
            arrayList2.add(new String[]{"star", "收藏"});
            arrayList2.add(new String[]{"selall", "全选"});
            if (z) {
                arrayList2.add(new String[]{"undo", "撤回"});
            }
            Sel.start(this.a, tightFindTight, tightFindTight.getCurrentTextColor() == -1, arrayList2, new Sel.Act() { // from class: com.changliao.im.ChatScr.54
                @Override // com.changliao.im.Sel.Act
                public void act(String str, String str2, boolean z3) {
                    J jObj = z3 ? j : J.obj(j.toString());
                    if (!z3 && jObj != null) {
                        jObj.put("text", str2);
                        jObj.remove("re_text");
                        jObj.remove("re_from");
                    }
                    if (jObj == null) {
                        jObj = j;
                    }
                    if (str.equals("复制")) {
                        ((ClipboardManager) ChatScr.this.a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("msg", str2));
                        ChatScr.this.toast("已复制");
                    } else if (str.equals("转发")) {
                        ChatScr.this.a.push(new FwdScr(jObj));
                    } else if (str.equals("收藏")) {
                        MiscScr.addFav(ChatScr.this.a, jObj);
                    } else {
                        ChatScr.this.menuAct(str, j);
                    }
                }
            });
            return;
        }
        final FrameLayout frameLayout = new FrameLayout(this.a);
        final LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f));
        G g = new G(2, 14.0f);
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-231458750, -266329303});
        gradientDrawable.setCornerRadius(Ui.dp(14.0f));
        linearLayoutRow.setBackground(new LayerDrawable(new Drawable[]{gradientDrawable, g}));
        linearLayoutRow.setElevation(Ui.dp(14.0f));
        final Runnable runnable = new Runnable() { // from class: com.changliao.im.ChatScr.55
            @Override // java.lang.Runnable
            public void run() {
                frameLayout.setTag(null);
                linearLayoutRow.animate().alpha(0.0f).scaleX(0.9f).scaleY(0.9f).setDuration(120L).withEndAction(new Runnable() { // from class: com.changliao.im.ChatScr.55.1
                    @Override // java.lang.Runnable
                    public void run() {
                        ChatScr.this.a.overlay.removeView(frameLayout);
                    }
                }).start();
            }
        };
        frameLayout.setTag(runnable);
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.56
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                runnable.run();
            }
        });
        for (final String[] strArr2 : arrayList) {
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.setGravity(17);
            linearLayoutCol.setPadding(Ui.dp(8.0f), Ui.dp(7.0f), Ui.dp(8.0f), Ui.dp(7.0f));
            linearLayoutCol.setMinimumWidth(Ui.dp(50.0f));
            boolean zEquals = strArr2[0].equals("undo");
            ImageView imageView = new ImageView(this.a);
            imageView.setImageDrawable(new Ico(strArr2[0], zEquals ? -30070 : -1));
            linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(22.0f), Ui.dp(22.0f)));
            linearLayoutCol.addView(Ui.text(this.a, strArr2[1], 12.0f, zEquals ? -30070 : -1), Ui.lpm(-2, -2, 0, 3, 0, 0));
            linearLayoutCol.setBackground(Ui.ripple(new ColorDrawable(0), 8.0f));
            linearLayoutCol.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.57
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    runnable.run();
                    ChatScr.this.menuAct(strArr2[1], j);
                }
            });
            linearLayoutRow.addView(linearLayoutCol);
        }
        HorizontalScroll horizontalScroll = new HorizontalScroll(this.a);
        horizontalScroll.addView(linearLayoutRow);
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        int[] iArr2 = new int[2];
        this.a.overlay.getLocationInWindow(iArr2);
        linearLayoutRow.measure(0, 0);
        int width = this.a.overlay.getWidth();
        int iMin = Math.min(linearLayoutRow.getMeasuredWidth(), width - Ui.dp(16.0f));
        int measuredHeight = linearLayoutRow.getMeasuredHeight();
        int iMax = Math.max(Ui.dp(8.0f), Math.min((width - iMin) - Ui.dp(8.0f), ((iArr[0] - iArr2[0]) + (view.getWidth() / 2)) - (iMin / 2)));
        int iDp = ((iArr[1] - iArr2[1]) - measuredHeight) - Ui.dp(8.0f);
        if (iDp < Ui.dp(60.0f)) {
            iDp = (iArr[1] - iArr2[1]) + Math.min(view.getHeight(), Ui.dp(200.0f)) + Ui.dp(8.0f);
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(iMin, measuredHeight);
        layoutParams.leftMargin = iMax;
        layoutParams.topMargin = iDp;
        frameLayout.addView(horizontalScroll, layoutParams);
        this.a.overlay.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        linearLayoutRow.setPivotX(iMin / 2.0f);
        linearLayoutRow.setPivotY(measuredHeight);
        linearLayoutRow.setScaleX(0.7f);
        linearLayoutRow.setScaleY(0.7f);
        linearLayoutRow.setAlpha(0.0f);
        linearLayoutRow.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(380L).setInterpolator(new OvershootInterpolator(2.2f)).start();
    }

    J notice() {
        J j = this.group ? this.C.ginfo.get(this.gid) : null;
        if (j == null) {
            return null;
        }
        List<J> listObjs = j.objs("notices");
        return listObjs.isEmpty() ? null : listObjs.get(0);
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("hist") && this.conv.equals(j.s("conv"))) {
            boolean z = j.l("before") > 0 || j.b("keep");
            int firstVisiblePosition = this.list.getFirstVisiblePosition();
            int count = this.ad.getCount();
            long[] jArrAnchor = anchor();
            long j2 = jArrAnchor[0];
            int i = (int) jArrAnchor[1];
            boolean z2 = jArrAnchor[2] != 0;
            if (this.saved != null) {
                j2 = this.saved[0];
                i = (int) this.saved[1];
                z2 = this.saved[2] != 0;
                this.saved = null;
            }
            this.ad.rebuild();
            if (j.l("before") > 0) {
                this.list.setSelection((this.ad.getCount() + firstVisiblePosition) - count);
            } else if (!z && (!this.histOnce || z2)) {
                this.list.setSelection(this.ad.getCount() - 1);
            } else if (j2 != 0) {
                int i2 = 0;
                while (true) {
                    int i3 = i2;
                    if (i3 >= this.ad.items.size()) {
                        break;
                    }
                    if (this.ad.items.get(i3).l("id") == j2) {
                        this.list.setSelectionFromTop(i3, i);
                        break;
                    }
                    i2 = i3 + 1;
                }
            }
            this.histOnce = true;
            return;
        }
        if (str.equals("msg")) {
            J jO = j.o("m");
            if (jO == null || !this.conv.equals(jO.s("conv"))) {
                return;
            }
            if (jO.b("mine") && jO.s("k").equals("text")) {
                int i4 = 0;
                while (true) {
                    int i5 = i4;
                    if (i5 >= this.pend.size()) {
                        break;
                    }
                    if (this.pend.get(i5).s("text").equals(jO.s("text"))) {
                        this.pend.remove(i5);
                        break;
                    }
                    i4 = i5 + 1;
                }
            }
            boolean z3 = this.list.getLastVisiblePosition() >= this.ad.getCount() + (-2);
            this.ad.rebuild();
            if (jO.b("mine") || z3) {
                this.list.post(new Runnable() { // from class: com.changliao.im.ChatScr.13
                    @Override // java.lang.Runnable
                    public void run() {
                        ChatScr.this.list.setSelection(ChatScr.this.ad.getCount() - 1);
                    }
                });
                return;
            }
            this.newN++;
            badge();
            showJump(true);
            return;
        }
        if (str.equals("c_gcall") && this.group && this.gid.equals(j.s("gid")) && j.s("kind").equals("info")) {
            this.gcVideo = j.b("video");
            boolean z4 = j.b("active") && j.l("n") > 0;
            this.callBar.setText((this.gcVideo ? "📹 " : "📞 ") + j.l("n") + " 人正在" + (this.gcVideo ? "群视频通话" : "群语音通话") + "，点击加入");
            this.callBar.setVisibility(z4 ? 0 : 8);
            return;
        }
        if (str.equals("convs") || str.equals("conn") || str.equals("friends")) {
            head();
            return;
        }
        if (str.equals("typing") && this.conv.equals(j.s("conv"))) {
            this.typingUntil = System.currentTimeMillis() + 4000;
            head();
            this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.ChatScr.14
                @Override // java.lang.Runnable
                public void run() {
                    if (ChatScr.this.alive) {
                        ChatScr.this.head();
                    }
                }
            }, 4100L);
            return;
        }
        if (str.equals("ginfo") && this.group && this.gid.equals(j.s("gid"))) {
            head();
            updBanUi();
            return;
        }
        if (str.equals("ban")) {
            updBanUi();
            return;
        }
        if (str.equals("gone") && this.group && this.gid.equals(j.s("gid"))) {
            if (this.alive) {
                this.a.back();
                return;
            }
            return;
        }
        if (str.equals("stk") && this.stkTab && this.panelMode.equals("emo")) {
            showPanel("emo");
            return;
        }
        if (str.equals("c_frcv") && this.conv.equals(j.s("conv"))) {
            List<J> list = this.C.msgs.get(this.conv);
            if (list != null) {
                for (J j3 : list) {
                    if (j3.l("id") == j.l("id")) {
                        j3.put("rcv", Long.valueOf(j.l("n")));
                    }
                }
            }
            this.ad.notifyDataSetChanged();
            toast((j.s("by").length() > 0 ? j.s("by") : "对方") + " 已接收文件「" + j.s("name") + "」");
        }
    }

    @Override // com.changliao.im.Scr
    public boolean onBack() {
        if (this.panel.getVisibility() != 0) {
            return false;
        }
        showPanel("");
        return true;
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        if (this.conv.equals(this.C.openConv)) {
            this.C.openConv = null;
        }
        String string = this.ta.getText().toString();
        if (string.trim().length() > 0) {
            App.kv.edit().putString("draft:" + this.conv, string).apply();
        } else {
            App.kv.edit().remove("draft:" + this.conv).apply();
        }
        stopVoice();
        stopRec(false);
        this.C.emit("convs", null);
    }

    @Override // com.changliao.im.Scr
    public void onHide() {
        this.saved = anchor();
        if (this.conv.equals(this.C.openConv)) {
            this.C.openConv = null;
        }
        stopVoice();
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        this.C.openConv = this.conv;
        if (this.C.authed) {
            this.C.sendQ(J.of("t", "c_hist", "conv", this.conv));
            if (this.group) {
                this.C.sendQ(J.of("t", "c_ginfo", "gid", this.gid));
            }
        }
        this.C.markRead(this.conv, true);
        this.C.emit("convs", null);
    }

    void openFile(J j, J j2, TextView textView) {
        String strS = j2.s("name");
        String lowerCase = strS.toLowerCase();
        if (lowerCase.matches(".*\\.(jpe?g|png|gif|webp|bmp)$")) {
            this.a.push(new ImgScr(j2, this.conv, j));
        } else if (lowerCase.matches(".*\\.(mp4|webm|3gp|mov)$")) {
            this.a.push(new VidScr(j2, this.conv, j));
        } else {
            textView.setText("正在下载 0%");
            new Thread(new AnonymousClass58(j2, strS, textView, j)).start();
        }
    }

    int panelW() {
        View view = (View) this.panel.getParent();
        int width = view == null ? 0 : view.getWidth();
        return width > 0 ? width - Ui.dp(20.0f) : this.a.getResources().getDisplayMetrics().widthPixels - Ui.dp(20.0f);
    }

    void pickAt() {
        memberSheet("@ 谁？", new MainActivity.Str() { // from class: com.changliao.im.ChatScr.34
            @Override // com.changliao.im.MainActivity.Str
            public void ok(String str) {
                J j = ChatScr.this.C.ginfo.get(ChatScr.this.gid);
                if (j == null) {
                    return;
                }
                for (J j2 : j.objs("members")) {
                    if (j2.s("nk").equals(str)) {
                        ChatScr.this.insertAt(ChatScr.nameOf(j2), str);
                    }
                }
            }
        });
    }

    void pickFile() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
        intent.addCategory("android.intent.category.OPENABLE");
        this.a.startFor(Intent.createChooser(intent, "选择文件"), new MainActivity.Res() { // from class: com.changliao.im.ChatScr.37
            @Override // com.changliao.im.MainActivity.Res
            public void got(int i, Intent intent2) {
                if (i == -1) {
                    ChatScr.this.sendUris(ChatScr.uris(intent2), false, false);
                }
            }
        });
    }

    void pickMedia() {
        this.a.push(new GalScr(new GalScr.Got() { // from class: com.changliao.im.ChatScr.36
            @Override // com.changliao.im.GalScr.Got
            public void got(List<Uri> list, boolean z) {
                ChatScr.this.sendUris(list, true, z);
            }
        }));
    }

    void playVoice(J j, J j2) {
        if (this.playing == j.l("id")) {
            stopVoice();
            return;
        }
        stopVoice();
        try {
            this.playing = j.l("id");
            this.ad.notifyDataSetChanged();
            this.player = new MediaPlayer();
            this.player.setDataSource(Core.fileUrl(j2.s("id"), j2.s("name")));
            this.player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.changliao.im.ChatScr.60
                @Override // android.media.MediaPlayer.OnPreparedListener
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            this.player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.changliao.im.ChatScr.61
                @Override // android.media.MediaPlayer.OnCompletionListener
                public void onCompletion(MediaPlayer mediaPlayer) {
                    ChatScr.this.stopVoice();
                }
            });
            this.player.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.changliao.im.ChatScr.62
                @Override // android.media.MediaPlayer.OnErrorListener
                public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                    ChatScr.this.stopVoice();
                    ChatScr.this.toast("这条语音播放不了");
                    return true;
                }
            });
            this.player.prepareAsync();
        } catch (Throwable th) {
            stopVoice();
            toast("这条语音播放不了");
        }
    }

    void plus(String str) {
        showPanel("");
        if (str.equals("相册")) {
            pickMedia();
            return;
        }
        if (str.equals("文件")) {
            this.a.push(new FileScr(this));
            return;
        }
        if (str.endsWith("语音") || str.equals("语音通话")) {
            call(false);
            return;
        }
        if (str.endsWith("视频") || str.equals("视频通话")) {
            call(true);
            return;
        }
        if (str.equals("@成员")) {
            pickAt();
            return;
        }
        if (str.equals("收藏")) {
            this.a.push(new MiscScr.FavScr(this.conv));
        } else if (str.equals("戳一戳")) {
            if (this.group) {
                memberSheet("戳一戳谁？", new MainActivity.Str() { // from class: com.changliao.im.ChatScr.32
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        ChatScr.this.C.send(J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "poke", "target", str2));
                    }
                });
            } else {
                this.C.send(J.of("t", "c_send", "conv", this.conv, "k", "poke"));
            }
        }
    }

    View plusPanel() {
        GridLayout gridLayout = new GridLayout(this.a);
        gridLayout.setColumnCount(4);
        gridLayout.setPadding(Ui.dp(4.0f), Ui.dp(14.0f), Ui.dp(4.0f), Ui.dp(6.0f));
        int iPanelW = (panelW() - Ui.dp(8.0f)) / 4;
        ArrayList arrayList = new ArrayList();
        arrayList.add(new String[]{"img", "相册"});
        arrayList.add(new String[]{"file", "文件"});
        if (!this.self) {
            String[] strArr = new String[2];
            strArr[0] = "phone";
            strArr[1] = this.group ? "群语音" : "语音通话";
            arrayList.add(strArr);
            String[] strArr2 = new String[2];
            strArr2[0] = "video";
            strArr2[1] = this.group ? "群视频" : "视频通话";
            arrayList.add(strArr2);
            arrayList.add(new String[]{"poke", "戳一戳"});
        }
        if (this.group) {
            arrayList.add(new String[]{"at", "@成员"});
        }
        arrayList.add(new String[]{"star", "收藏"});
        int i = 0;
        Iterator it = arrayList.iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return gridLayout;
            }
            final String[] strArr3 = (String[]) it.next();
            LinearLayout linearLayoutCol = Ui.col(this.a);
            linearLayoutCol.setGravity(1);
            ImageView imageView = new ImageView(this.a);
            imageView.setImageDrawable(new Ico(strArr3[0], -11642519));
            int iDp = Ui.dp(15.0f);
            imageView.setPadding(iDp, iDp, iDp, iDp);
            G.on(imageView, 0, 20.0f, 4.0f);
            linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(58.0f), Ui.dp(58.0f)));
            linearLayoutCol.addView(Ui.text(this.a, strArr3[1], 12.0f, -11642519), Ui.lpm(-2, -2, 0, 7, 0, 0));
            Ui.bounce(imageView);
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.31
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ChatScr.this.plus(strArr3[1]);
                }
            });
            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
            layoutParams.width = iPanelW;
            layoutParams.bottomMargin = Ui.dp(12.0f);
            gridLayout.addView(linearLayoutCol, layoutParams);
            linearLayoutCol.setScaleX(0.6f);
            linearLayoutCol.setScaleY(0.6f);
            linearLayoutCol.setAlpha(0.0f);
            i = i2 + 1;
            linearLayoutCol.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setStartDelay(30 * ((long) i2)).setDuration(500L).setInterpolator(new OvershootInterpolator(2.0f)).start();
        }
    }

    View row(final J j, long j2) {
        String strS;
        View viewContentTmp;
        TextView textViewRoleTag;
        LinearLayout linearLayoutCol = Ui.col(this.a);
        String strS2 = j.s("k");
        this.maxBody = (int) ((this.a.wide() ? 0.64f : 0.72f) * (listW() - Ui.dp(24.0f)));
        if (strS2.equals("more")) {
            TextView textViewText = Ui.text(this.a, "查看更早的消息", 13.0f, Ui.BLUE);
            textViewText.setGravity(17);
            textViewText.setPadding(Ui.dp(12.0f), Ui.dp(5.0f), Ui.dp(12.0f), Ui.dp(5.0f));
            G.on(textViewText, 0, 16.0f, 1.0f);
            textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.43
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ChatScr.this.loadOlder();
                }
            });
            LinearLayout.LayoutParams layoutParamsLpm = Ui.lpm(-2, -2, 0, 4, 0, 12);
            layoutParamsLpm.gravity = 1;
            linearLayoutCol.addView(textViewText, layoutParamsLpm);
            return linearLayoutCol;
        }
        if (strS2.equals("loading") || strS2.equals("empty")) {
            linearLayoutCol.addView(empty(strS2.equals("loading") ? "加载中…" : "还没有消息，打个招呼吧 👋"));
            return linearLayoutCol;
        }
        if (j2 == 0 || j.l("ts") - j2 > 300) {
            TextView textViewText2 = Ui.text(this.a, Ui.fullWhen(j.l("ts")), 13.0f, -6051406);
            textViewText2.setGravity(17);
            linearLayoutCol.addView(textViewText2, Ui.lpm(-1, -2, 16, 6, 16, 14));
        }
        if (strS2.equals("sys") || strS2.equals("recall")) {
            if (strS2.equals("sys")) {
                strS = j.s("text");
            } else {
                strS = ((j.b("mine") && j.s("by").equals(this.C.myNick())) ? "你" : j.s("by")) + " 撤回了一条消息";
            }
            TextView textViewText3 = Ui.text(this.a, strS, 13.0f, -6051406);
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-526086, -986636});
            gradientDrawable.setCornerRadius(Ui.dp(10.0f));
            gradientDrawable.setStroke(1, -1275068417);
            textViewText3.setBackground(gradientDrawable);
            textViewText3.setPadding(Ui.dp(10.0f), Ui.dp(3.0f), Ui.dp(10.0f), Ui.dp(3.0f));
            textViewText3.setGravity(17);
            LinearLayout.LayoutParams layoutParamsLpm2 = Ui.lpm(-2, -2, 16, 0, 16, 14);
            layoutParamsLpm2.gravity = 1;
            linearLayoutCol.addView(textViewText3, layoutParamsLpm2);
            return linearLayoutCol;
        }
        boolean zB = j.b("mine");
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setGravity((zB ? 8388613 : 8388611) | 48);
        final Img.Av av = new Img.Av(this.a);
        if (!strS2.equals("up") || this.C.info == null) {
            av.set(j.s("from"), j.sn("av"), false);
        } else {
            av.set(this.C.myNick(), this.C.info.sn("av"), false);
        }
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        linearLayoutCol2.setGravity(zB ? 8388613 : 8388611);
        if (!strS2.equals("up") && ((!zB || this.group) && !this.self)) {
            try {
                LinearLayout linearLayoutRow2 = Ui.row(this.a);
                ArrayList arrayList = new ArrayList();
                TextView textViewOne = Ui.one(Ui.text(this.a, j.s("name").length() > 0 ? j.s("name") : j.s("from"), 12.0f, j.b("vip") ? -3569152 : Ui.SUB));
                if (j.b("vip")) {
                    textViewOne.setTypeface(bold);
                }
                textViewOne.setMaxWidth(Ui.dp(150.0f));
                arrayList.add(textViewOne);
                if (j.b("vip")) {
                    arrayList.add(Ui.vipTag(this.a));
                }
                if (this.group && j.l("glv") > 0) {
                    arrayList.add(Ui.lvTag(this.a, j.l("glv"), j.s("glvn")));
                }
                if (this.group && (textViewRoleTag = Ui.roleTag(this.a, j.s("grole"))) != null) {
                    arrayList.add(textViewRoleTag);
                }
                if (this.group && j.s("gtitle").length() > 0) {
                    TextView textViewTag = Ui.tag(this.a, j.s("gtitle"), -3626);
                    textViewTag.setTextColor(-3900928);
                    arrayList.add(textViewTag);
                }
                if (zB) {
                    Collections.reverse(arrayList);
                }
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= arrayList.size()) {
                        break;
                    }
                    View view = (View) arrayList.get(i2);
                    LinearLayout.LayoutParams layoutParamsLp = view.getLayoutParams() instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) view.getLayoutParams() : Ui.lp(-2, -2);
                    layoutParamsLp.leftMargin = i2 == 0 ? 0 : Ui.dp(5.0f);
                    linearLayoutRow2.addView(view, layoutParamsLp);
                    i = i2 + 1;
                }
                linearLayoutCol2.addView(linearLayoutRow2, Ui.lpm(-2, -2, 0, 0, 0, 4));
            } catch (Throwable th) {
                Crash.note(th);
            }
        }
        try {
            viewContentTmp = content(j, zB);
        } catch (Throwable th2) {
            Crash.note(th2);
            TextView textViewText4 = Ui.text(this.a, preview(j).length() > 0 ? preview(j) : "[" + strS2 + "]", 16.0f, zB ? -1 : Ui.TEXT);
            textViewText4.setPadding(Ui.dp(13.0f), Ui.dp(10.0f), Ui.dp(13.0f), Ui.dp(10.0f));
            textViewText4.setBackground(bubbleBg(J.of(new Object[0]), zB));
            viewContentTmp = textViewText4;
        }
        final View viewContent = viewContentTmp;
        ViewGroup.LayoutParams layoutParams = viewContent.getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(layoutParams != null ? layoutParams.width : -2, layoutParams != null ? layoutParams.height : -2);
        layoutParams2.gravity = zB ? 8388613 : 8388611;
        linearLayoutCol2.addView(viewContent, layoutParams2);
        int iDp = Ui.dp(36.0f);
        if (zB && j.b("fail")) {
            TextView textViewBold = Ui.bold(Ui.text(this.a, "!", 14.0f, -1));
            textViewBold.setGravity(17);
            textViewBold.setBackground(Ui.oval(-704705));
            textViewBold.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.44
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    String str;
                    String strS3 = j.s("why");
                    MainActivity mainActivity = ChatScr.this.a;
                    if (strS3.equals("notfriend")) {
                        str = "对方已不是你的好友，重发前请先加对方为好友。";
                    } else {
                        str = strS3.equals("err") ? "上次没发出去，确定再发一次吗？" : "这条消息上次没有发出去（网络不好）。";
                    }
                    mainActivity.confirm("重发该消息？", str, "重发", false, new Runnable() { // from class: com.changliao.im.ChatScr.44.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ChatScr.this.C.resend(j);
                        }
                    });
                }
            });
            LinearLayout.LayoutParams layoutParamsLpm3 = Ui.lpm(Ui.dp(20.0f), Ui.dp(20.0f), 0, 0, 8, 0);
            layoutParamsLpm3.gravity = 16;
            linearLayoutRow.addView(textViewBold, layoutParamsLpm3);
        }
        if (zB) {
            linearLayoutRow.addView(linearLayoutCol2, Ui.lp(-2, -2));
            linearLayoutRow.addView(av, Ui.lpm(iDp, iDp, 10, 0, 0, 0));
        } else {
            linearLayoutRow.addView(av, Ui.lpm(iDp, iDp, 0, 0, 10, 0));
            linearLayoutRow.addView(linearLayoutCol2, Ui.lp(-2, -2));
        }
        linearLayoutCol.addView(linearLayoutRow, Ui.lpm(-1, -2, 0, 0, 0, 16));
        if (!zB && !this.self && !strS2.equals("up")) {
            final long[] jArr = {0};
            av.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.ChatScr.45
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    if (jCurrentTimeMillis - jArr[0] >= 320) {
                        jArr[0] = jCurrentTimeMillis;
                        ChatScr.this.a.h.postAtTime(new Runnable() { // from class: com.changliao.im.ChatScr.45.2
                            @Override // java.lang.Runnable
                            public void run() {
                                if (jArr[0] == 0 || j.s("fnk").length() <= 0) {
                                    return;
                                }
                                MainActivity mainActivity = ChatScr.this.a;
                                String[] strArr = new String[4];
                                strArr[0] = "a";
                                strArr[1] = j.s("fnk");
                                strArr[2] = "g";
                                strArr[3] = ChatScr.this.gid == null ? "" : ChatScr.this.gid;
                                mainActivity.web("profile", strArr);
                            }
                        }, av, SystemClock.uptimeMillis() + 330);
                    } else {
                        jArr[0] = 0;
                        ChatScr.this.a.h.removeCallbacksAndMessages(av);
                        av.animate().rotation(-14.0f).scaleX(1.08f).scaleY(1.08f).setDuration(90L).withEndAction(new Runnable() { // from class: com.changliao.im.ChatScr.45.1
                            @Override // java.lang.Runnable
                            public void run() {
                                av.animate().rotation(0.0f).scaleX(1.0f).scaleY(1.0f).setDuration(300L).setInterpolator(new OvershootInterpolator(3.0f)).start();
                            }
                        }).start();
                        ChatScr.this.C.send(ChatScr.this.group ? J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "poke", "target", j.s("fnk")) : J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "poke"));
                    }
                }
            });
            if (this.group) {
                av.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.changliao.im.ChatScr.46
                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View view2) {
                        ChatScr.this.a.vib(15);
                        ChatScr.this.insertAt(j.s("name").length() > 0 ? j.s("name") : j.s("from"), j.s("fnk"));
                        return true;
                    }
                });
            }
        }
        if (!strS2.equals("up") && !j.b("fail") && !j.b("pend")) {
            View.OnLongClickListener onLongClickListener = new View.OnLongClickListener() { // from class: com.changliao.im.ChatScr.47
                @Override // android.view.View.OnLongClickListener
                public boolean onLongClick(View view2) {
                    ChatScr.this.a.vib(15);
                    ChatScr.this.msgMenu(j, viewContent);
                    return true;
                }
            };
            viewContent.setOnLongClickListener(onLongClickListener);
            if (viewContent instanceof ViewGroup) {
                int i3 = 0;
                while (true) {
                    int i4 = i3;
                    if (i4 >= ((ViewGroup) viewContent).getChildCount()) {
                        break;
                    }
                    View childAt = ((ViewGroup) viewContent).getChildAt(i4);
                    if ((childAt instanceof TextView) && ((TextView) childAt).getMovementMethod() != null) {
                        childAt.setOnLongClickListener(onLongClickListener);
                    }
                    i3 = i4 + 1;
                }
            }
        }
        return linearLayoutCol;
    }

    void sendText() {
        String strTrim = this.ta.getText().toString().trim();
        if (strTrim.length() == 0) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        for (Map.Entry<String, String> entry : this.atMap.entrySet()) {
            if (strTrim.contains("@" + entry.getKey())) {
                arrayList.add(entry.getValue());
            }
        }
        if (strTrim.contains("@全体成员")) {
            arrayList.add("*");
        }
        J jOf = J.of("t", "c_send", "conv", this.conv, "k", "text", "text", strTrim, "at", arrayList);
        if (this.reply != null) {
            jOf.put("re", Long.valueOf(this.reply.l("id")));
        }
        boolean z = this.reply == null;
        if (this.C.send(jOf)) {
            this.ta.setText("");
            this.atMap.clear();
            setReply(null);
            App.kv.edit().remove("draft:" + this.conv).apply();
            if (z) {
                Object[] objArr = new Object[24];
                objArr[0] = "k";
                objArr[1] = "text";
                objArr[2] = "text";
                objArr[3] = strTrim;
                objArr[4] = "mine";
                objArr[5] = true;
                objArr[6] = "pend";
                objArr[7] = true;
                objArr[8] = "id";
                objArr[9] = Long.valueOf(-System.nanoTime());
                objArr[10] = "ts";
                objArr[11] = Long.valueOf(System.currentTimeMillis() / 1000);
                objArr[12] = "conv";
                objArr[13] = this.conv;
                objArr[14] = "from";
                objArr[15] = this.C.myNick();
                objArr[16] = "name";
                objArr[17] = this.C.myNick();
                objArr[18] = "av";
                objArr[19] = this.C.info == null ? null : this.C.info.sn("av");
                objArr[20] = "vip";
                objArr[21] = Boolean.valueOf(this.C.vip);
                objArr[22] = "bubble";
                objArr[23] = this.C.bubble;
                final J jOf2 = J.of(objArr);
                this.pend.add(jOf2);
                this.ad.rebuild();
                this.list.setSelection(this.ad.getCount() - 1);
                this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.ChatScr.35
                    @Override // java.lang.Runnable
                    public void run() {
                        if (ChatScr.this.pend.remove(jOf2) && ChatScr.this.alive) {
                            ChatScr.this.ad.rebuild();
                        }
                    }
                }, 20000L);
            }
        }
    }

    void sendUris(List<Uri> list, boolean z, boolean z2) {
        if (list.isEmpty()) {
            return;
        }
        Context applicationContext = this.a.getApplicationContext();
        ArrayList arrayList = new ArrayList();
        for (Uri uri : list) {
            String[] strArrInfo = Up.info(applicationContext, uri);
            String type = applicationContext.getContentResolver().getType(uri);
            if (type == null) {
                type = URLConnection.guessContentTypeFromName(strArrInfo[0]);
            }
            Object[] objArr = new Object[18];
            objArr[0] = "k";
            objArr[1] = "up";
            objArr[2] = "name";
            objArr[3] = strArrInfo[0];
            objArr[4] = "pct";
            objArr[5] = Double.valueOf(0.0d);
            objArr[6] = "uri";
            objArr[7] = uri.toString();
            objArr[8] = "mime";
            objArr[9] = type == null ? "" : type;
            objArr[10] = "size";
            objArr[11] = Long.valueOf(Long.parseLong(strArrInfo[1]));
            objArr[12] = "id";
            objArr[13] = Long.valueOf(-System.nanoTime());
            objArr[14] = "mine";
            objArr[15] = true;
            objArr[16] = "ts";
            objArr[17] = Long.valueOf(System.currentTimeMillis() / 1000);
            J jOf = J.of(objArr);
            jOf.put("img", Boolean.valueOf(z && type != null && type.startsWith("image/")));
            this.ups.add(jOf);
            arrayList.add(jOf);
        }
        this.ad.rebuild();
        this.list.setSelection(this.ad.getCount() - 1);
        new Thread(new AnonymousClass40(arrayList, z, applicationContext, z2)).start();
    }

    void setReply(J j) {
        this.reply = j;
        this.replyBar.setVisibility(j == null ? 8 : 0);
        if (j != null) {
            if (this.voiceMode) {
                setVoice(false);
            }
            this.replyT.setText("回复 " + (j.s("name").length() > 0 ? j.s("name") : j.s("from")) + "：" + preview(j));
            this.a.showKb(this.ta);
        }
    }

    void setSendOn(boolean z) {
        this.sendB.setAlpha(z ? 1.0f : 0.5f);
        this.sendB.setElevation(z ? Ui.dp(4.0f) : 0.0f);
    }

    void setVoice(boolean z) {
        if (z && !this.a.has("android.permission.RECORD_AUDIO")) {
            this.a.requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 5);
            toast("请允许使用麦克风后再试");
            return;
        }
        this.voiceMode = z;
        this.holdB.setVisibility(z ? 0 : 4);
        this.ta.setVisibility(z ? 4 : 0);
        if (!z) {
            this.holdB.setVisibility(8);
        }
        ((Ico) this.micB.getDrawable()).tint(z ? Ui.BLUE : -11642519);
        this.micB.setImageDrawable(new Ico(z ? "kb" : "mic", -11642519));
        if (!z) {
            this.a.showKb(this.ta);
        } else {
            this.a.hideKb();
            showPanel("");
        }
    }

    void showJump(boolean z) {
        if (this.jump == null || z == this.jumpOn) {
            return;
        }
        this.jumpOn = z;
        this.jump.animate().cancel();
        if (!z) {
            this.jump.animate().alpha(0.0f).scaleX(0.6f).scaleY(0.6f).translationY(Ui.dp(10.0f)).setDuration(180L).setInterpolator(new AccelerateInterpolator()).withEndAction(new Runnable() { // from class: com.changliao.im.ChatScr.1
                @Override // java.lang.Runnable
                public void run() {
                    if (ChatScr.this.jumpOn) {
                        return;
                    }
                    ChatScr.this.jump.setVisibility(8);
                }
            }).start();
            return;
        }
        this.jump.setVisibility(0);
        this.jump.setAlpha(0.0f);
        this.jump.setScaleX(0.5f);
        this.jump.setScaleY(0.5f);
        this.jump.setTranslationY(Ui.dp(14.0f));
        this.jump.animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).translationY(0.0f).setDuration(280L).setInterpolator(new OvershootInterpolator(1.8f)).withEndAction(null).start();
    }

    void showPanel(String str) {
        this.panelMode = str;
        this.panel.removeAllViews();
        boolean zEquals = str.equals("plus");
        G.on(this.plusB, zEquals ? 1 : 0, 21.0f, 3.0f);
        this.plusB.setImageDrawable(new Ico("plus", zEquals ? -1 : -11642519));
        this.plusB.animate().rotation(zEquals ? 45.0f : 0.0f).setDuration(450L).setInterpolator(new OvershootInterpolator(2.0f)).start();
        ((Ico) this.emoB.getDrawable()).tint(str.equals("emo") ? Ui.BLUE : -11642519);
        if (str.length() == 0) {
            this.panel.setVisibility(8);
            return;
        }
        this.a.hideKb();
        this.ta.clearFocus();
        View viewEmojiPanel = str.equals("emo") ? emojiPanel() : plusPanel();
        this.panel.addView(viewEmojiPanel);
        this.panel.setVisibility(0);
        viewEmojiPanel.setAlpha(0.0f);
        viewEmojiPanel.setTranslationY(Ui.dp(16.0f));
        viewEmojiPanel.animate().alpha(1.0f).translationY(0.0f).setDuration(380L).setInterpolator(new DecelerateInterpolator(2.0f)).start();
    }

    void startRec() {
        stopVoice();
        try {
            this.recF = new File(this.a.getCacheDir(), "voice_" + System.currentTimeMillis() + ".m4a");
            this.rec = new MediaRecorder();
            this.rec.setAudioSource(1);
            this.rec.setOutputFormat(2);
            this.rec.setAudioEncoder(3);
            this.rec.setAudioSamplingRate(44100);
            this.rec.setAudioEncodingBitRate(64000);
            this.rec.setOutputFile(this.recF.getPath());
            this.rec.prepare();
            this.rec.start();
            this.recT0 = System.currentTimeMillis();
            this.holdB.setText("松开 发送");
            this.a.vib(20);
            G.on(this.holdB, 1, 16.0f, 3.0f);
            this.holdB.setTextColor(-1);
        } catch (Throwable th) {
            this.rec = null;
            toast("录音失败：请检查麦克风权限");
        }
    }

    void stopRec(boolean z) {
        if (this.rec == null) {
            return;
        }
        MediaRecorder mediaRecorder = this.rec;
        this.rec = null;
        try {
            mediaRecorder.stop();
        } catch (Throwable th) {
            z = false;
        }
        try {
            mediaRecorder.release();
        } catch (Throwable th2) {
        }
        this.holdB.setText("按住 说话");
        this.holdB.setTextColor(Ui.TEXT);
        G.on(this.holdB, 0, 16.0f, 2.0f);
        final int iRound = (int) Math.round((System.currentTimeMillis() - this.recT0) / 1000.0d);
        if (z) {
            if (iRound < 1) {
                toast("说话时间太短");
            } else {
                final File file = this.recF;
                new Thread(new Runnable() { // from class: com.changliao.im.ChatScr.41
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            String strUpload = Up.upload(Img.read(new FileInputStream(file)), "voice.m4a", "audio/mp4", null);
                            file.delete();
                            ChatScr.gap();
                            final J jOf = J.of("t", "c_send", "conv", ChatScr.this.conv, "k", "voice", "fid", strUpload, "dur", Integer.valueOf(Math.min(60, iRound)));
                            ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.41.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    if (ChatScr.this.C.sendQ0(jOf)) {
                                        return;
                                    }
                                    ChatScr.this.C.failLocal(jOf);
                                }
                            });
                        } catch (Throwable th3) {
                            ChatScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.ChatScr.41.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    ChatScr.this.toast("语音发送失败：" + th3.getMessage());
                                }
                            });
                        }
                    }
                }).start();
            }
        }
    }

    void stopVoice() {
        boolean z = this.playing != -1;
        this.playing = -1L;
        if (this.player != null) {
            try {
                this.player.release();
            } catch (Throwable th) {
            }
            this.player = null;
        }
        if (z) {
            this.ad.notifyDataSetChanged();
        }
    }

    J summary() {
        J j = this.C.convs.get(this.conv);
        return j == null ? J.of("conv", this.conv, "title", "") : j;
    }

    void toBottom() {
        this.jump.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80L).withEndAction(new Runnable() { // from class: com.changliao.im.ChatScr.2
            @Override // java.lang.Runnable
            public void run() {
                ChatScr.this.jump.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160L).start();
            }
        }).start();
        final int count = this.ad.getCount() - 1;
        if (count < 0) {
            return;
        }
        if (count - this.list.getFirstVisiblePosition() > 12) {
            this.list.setSelection(count - 12);
        }
        this.list.post(new Runnable() { // from class: com.changliao.im.ChatScr.3
            @Override // java.lang.Runnable
            public void run() {
                ChatScr.this.list.smoothScrollToPosition(count);
            }
        });
        this.newN = 0;
        badge();
    }

    ImageView tool(String str, View.OnClickListener onClickListener) {
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, -11642519));
        int iDp = Ui.dp(9.0f);
        imageView.setPadding(iDp, iDp, iDp, iDp);
        G.on(imageView, 0, 21.0f, 3.0f);
        imageView.setOnClickListener(onClickListener);
        Ui.bounce(imageView);
        return imageView;
    }

    void updBanUi() {
        updBan(this.banB);
        J j = this.group ? this.C.ginfo.get(this.gid) : null;
        boolean z = j != null && j.b("banned");
        boolean z2 = this.C.banned() || z;
        if (this.inputV != null) {
            this.inputV.setVisibility(z2 ? 8 : 0);
        }
        if (z && !this.C.banned()) {
            if (this.gbanT == null) {
                this.gbanT = Ui.text(this.a, "", 13.0f, -2544339);
                this.gbanT.setGravity(17);
                this.gbanT.setLineSpacing(0.0f, 1.25f);
                this.gbanT.setPadding(Ui.dp(14.0f), Ui.dp(12.0f), Ui.dp(14.0f), Ui.dp(14.0f));
                this.gbanT.setBackgroundColor(-3342);
                ((LinearLayout) this.inputV.getParent()).addView(this.gbanT, ((LinearLayout) this.inputV.getParent()).indexOfChild(this.inputV));
            }
            this.gbanT.setVisibility(0);
            this.gbanT.setText("该群因「" + (j.s("ban_reason").length() > 0 ? j.s("ban_reason") : "违规") + "」已被封禁，期间只能查看消息\n" + MiscScr.ReportsScr.left(j.l("ban_until")) + (j.s("myrole").equals("owner") ? " · 群主可以在群设置里申诉" : ""));
        } else if (this.gbanT != null) {
            this.gbanT.setVisibility(8);
        }
        if (z2) {
            this.a.hideKb();
            if (this.panel == null || this.panel.getVisibility() != 0) {
                return;
            }
            showPanel("");
        }
    }
}
