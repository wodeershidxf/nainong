package com.changliao.im;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public class LoginScr extends Scr {
    LinearLayout card;
    EditText code;
    LinearLayout codeBox;
    TextView codeBtn;
    boolean codeMode;
    EditText email;
    int left;
    TextView msg;
    EditText pw;
    LinearLayout pwBox;
    TextView tabCode;
    TextView tabPw;

    static Drawable segBg() {
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1644050, -1183757});
        gradientDrawable.setCornerRadius(Ui.dp(12.0f));
        gradientDrawable.setStroke(1, -855638017);
        return gradientDrawable;
    }

    static void style(TextView textView, boolean z) {
        textView.setTextColor(z ? Ui.TEXT : Ui.SUB);
        textView.setTypeface(z ? bold : null);
        if (z) {
            G.on(textView, 0, 10.0f, 2.0f);
            return;
        }
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{1811939327, 704643071});
        gradientDrawable.setCornerRadius(Ui.dp(10.0f));
        gradientDrawable.setStroke(Math.max(1, Ui.dp(1.0f)), -1929379841);
        textView.setBackground(gradientDrawable);
        textView.setElevation(Ui.dp(0.5f));
    }

    @Override // com.changliao.im.Scr
    public View build() {
        ScrollView scrollView = new ScrollView(this.a);
        scrollView.setFillViewport(true);
        scrollView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1510401, -591621, -591621}));
        FrameLayout frameLayout = new FrameLayout(this.a);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setPadding(Ui.dp(24.0f), Ui.dp(40.0f), Ui.dp(24.0f), Ui.dp(30.0f));
        ImageView imageView = new ImageView(this.a);
        imageView.setImageBitmap(Img.appic);
        LinearLayout.LayoutParams layoutParamsLpm = Ui.lpm(Ui.dp(76.0f), Ui.dp(76.0f), 0, 20, 0, 12);
        layoutParamsLpm.gravity = 1;
        linearLayoutCol.addView(imageView, layoutParamsLpm);
        TextView textViewBold = Ui.bold(Ui.text(this.a, "NAINONG Chat", 26.0f, Ui.TEXT));
        textViewBold.setGravity(17);
        textViewBold.setLetterSpacing(0.115384616f);
        linearLayoutCol.addView(textViewBold);
        TextView textViewText = Ui.text(this.a, "聊天 · 语音视频 · 传文件", 14.0f, Ui.SUB);
        textViewText.setGravity(17);
        linearLayoutCol.addView(textViewText, Ui.lpm(-1, -2, 0, 6, 0, 30));
        this.card = Ui.col(this.a);
        G g = new G(0, 20.0f);
        g.bg = -1;
        this.card.setBackground(g);
        this.card.setElevation(Ui.dp(6.0f));
        if (Build.VERSION.SDK_INT >= 28) {
            this.card.setOutlineSpotShadowColor(-14795666);
            this.card.setOutlineAmbientShadowColor(-14795666);
        }
        this.card.setPadding(Ui.dp(18.0f), Ui.dp(18.0f), Ui.dp(18.0f), Ui.dp(18.0f));
        linearLayoutCol.addView(this.card, Ui.lp(-1, -2));
        main();
        frameLayout.addView(linearLayoutCol, new FrameLayout.LayoutParams(Math.min(this.a.getResources().getDisplayMetrics().widthPixels, Ui.dp(468.0f)), -2, 1));
        scrollView.addView(frameLayout);
        return scrollView;
    }

    @Override // com.changliao.im.Scr
    public boolean full() {
        return true;
    }

    void login() {
        // PATCH(需求2)：验证闸门恒通过。
        // 原逻辑：邮箱格式校验 → auth_code 发码 → auth_login(email,code) → 服务端 auth_ok 才放行。
        // 现在：不校验邮箱、不校验验证码、不等服务端回包，直接 Core.enter()（authed=true + c_hello）。
        App.kv.edit().putString("lastEmail", mail()).apply();
        this.a.hideKb();
        msg("已跳过验证，正在进入…", true);
        this.C.enter();
    }

    String mail() {
        return this.email.getText().toString().trim().toLowerCase();
    }

    void main() {
        this.card.removeAllViews();
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setBackground(segBg());
        linearLayoutRow.setPadding(Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f), Ui.dp(4.0f));
        this.tabPw = tab("密码登录", false);
        this.tabCode = tab("验证码登录 / 注册", true);
        linearLayoutRow.addView(this.tabPw, Ui.lp(0, -2, 1.0f));
        linearLayoutRow.addView(this.tabCode, Ui.lp(0, -2, 1.0f));
        this.card.addView(linearLayoutRow, Ui.lpm(-1, -2, 0, 0, 0, 14));
        this.email = Ui.input(this.a, "邮箱，例如 123456@qq.com", false);
        this.email.setInputType(33);
        String string = App.kv.getString("lastEmail", null);
        if (string != null) {
            this.email.setText(string);
        }
        this.card.addView(this.email, Ui.lpm(-1, -2, 0, 0, 0, 12));
        this.pwBox = Ui.col(this.a);
        this.pw = Ui.input(this.a, "密码", true);
        this.pw.setImeOptions(2);
        this.pw.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.changliao.im.LoginScr.1
            @Override // android.widget.TextView.OnEditorActionListener
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                LoginScr.this.login();
                return true;
            }
        });
        this.pwBox.addView(this.pw);
        this.card.addView(this.pwBox, Ui.lpm(-1, -2, 0, 0, 0, 12));
        this.codeBox = Ui.col(this.a);
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        this.code = Ui.input(this.a, "6 位验证码", false);
        this.code.setInputType(2);
        linearLayoutRow2.addView(this.code, Ui.lp(0, -2, 1.0f));
        this.codeBtn = Ui.btnGray(this.a, "获取验证码", new View.OnClickListener() { // from class: com.changliao.im.LoginScr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LoginScr.this.sendCode();
            }
        });
        this.codeBtn.setTextSize(14.0f);
        this.codeBtn.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(14.0f), Ui.dp(6.0f));
        LinearLayout.LayoutParams layoutParamsLp = Ui.lp(-2, -2);
        layoutParamsLp.leftMargin = Ui.dp(8.0f);
        linearLayoutRow2.addView(this.codeBtn, layoutParamsLp);
        this.codeBox.addView(linearLayoutRow2);
        TextView textViewText = Ui.text(this.a, "新邮箱用验证码登录会自动注册账号", 13.0f, Ui.SUB);
        textViewText.setPadding(0, Ui.dp(8.0f), 0, 0);
        this.codeBox.addView(textViewText);
        this.card.addView(this.codeBox, Ui.lpm(-1, -2, 0, 0, 0, 12));
        this.card.addView(Ui.btn(this.a, "登录", new View.OnClickListener() { // from class: com.changliao.im.LoginScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LoginScr.this.login();
            }
        }));
        this.msg = Ui.text(this.a, "", 14.0f, Ui.SUB);
        this.msg.setPadding(Ui.dp(2.0f), Ui.dp(10.0f), Ui.dp(2.0f), 0);
        this.msg.setMinHeight(Ui.dp(32.0f));
        this.card.addView(this.msg);
        setMode(false);
    }

    void msg(String str, boolean z) {
        if (this.msg == null) {
            return;
        }
        TextView textView = this.msg;
        if (str == null) {
            str = "";
        }
        textView.setText(str);
        this.msg.setTextColor(z ? Ui.GREEN : Ui.RED);
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("auth_msg")) {
            msg(j.s("msg"), j.b("ok"));
        } else {
            if (!str.equals("toast") || this.C.authed) {
                return;
            }
            msg(j.s("msg"), !j.b("err"));
        }
    }

    void sendCode() {
        // PATCH(需求2)：获取验证码按钮也走跳过逻辑，不再要求邮箱格式与真实发码
        msg("验证码已跳过，直接点「登录」即可进入", true);
    }

    void setMode(boolean z) {
        this.codeMode = z;
        style(this.tabPw, !z);
        style(this.tabCode, z);
        this.pwBox.setVisibility(z ? 8 : 0);
        this.codeBox.setVisibility(z ? 0 : 8);
        msg(null, true);
    }

    public void step(String str) {
        this.card.removeAllViews();
        if (str.equals("need_nick")) {
            this.card.addView(Ui.text(this.a, "给自己起一个昵称（唯一，好友靠它找到你）", 15.0f, Ui.TEXT));
            final EditText editTextInput = Ui.input(this.a, "昵称", false);
            editTextInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
            this.card.addView(editTextInput, Ui.lpm(-1, -2, 0, 12, 0, 12));
            this.card.addView(Ui.btn(this.a, "确定", new View.OnClickListener() { // from class: com.changliao.im.LoginScr.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String strTrim = editTextInput.getText().toString().trim();
                    if (strTrim.length() > 0) {
                        LoginScr.this.C.send(J.of("t", "set_nick", "nick", strTrim));
                    }
                }
            }));
        } else {
            this.card.addView(Ui.text(this.a, "设置一个密码，以后用「邮箱 + 密码」直接登录（也可以以后再设）", 15.0f, Ui.TEXT));
            final EditText editTextInput2 = Ui.input(this.a, "新密码（至少 6 位）", true);
            this.card.addView(editTextInput2, Ui.lpm(-1, -2, 0, 12, 0, 12));
            this.card.addView(Ui.btn(this.a, "设置密码", new View.OnClickListener() { // from class: com.changliao.im.LoginScr.7
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    String string = editTextInput2.getText().toString();
                    if (string.length() < 6) {
                        LoginScr.this.msg("密码至少 6 位", false);
                    } else {
                        LoginScr.this.C.send(J.of("t", "set_pw", "pw", string));
                    }
                }
            }));
            this.card.addView(Ui.btnGray(this.a, "以后再说", new View.OnClickListener() { // from class: com.changliao.im.LoginScr.8
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    LoginScr.this.C.enter();
                }
            }), Ui.lpm(-1, -2, 0, 10, 0, 0));
        }
        this.msg = Ui.text(this.a, "", 13.0f, Ui.SUB);
        this.msg.setGravity(17);
        this.msg.setPadding(0, Ui.dp(10.0f), 0, 0);
        this.card.addView(this.msg);
    }

    TextView tab(String str, final boolean z) {
        TextView textViewText = Ui.text(this.a, str, 15.0f, Ui.SUB);
        textViewText.setGravity(17);
        textViewText.setPadding(0, Ui.dp(9.0f), 0, Ui.dp(9.0f));
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.LoginScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LoginScr.this.setMode(z);
            }
        });
        return textViewText;
    }
}
