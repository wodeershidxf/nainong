package com.changliao.im;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.os.Build;
import android.view.TextureView;
import android.view.View;
import android.view.ViewParent;
import android.widget.ImageView;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
final class Night {
    static final float A = 26.0f;
    static final float B = 0.8980392f;
    static final WeakHashMap<View, Boolean> DARK;
    static boolean active;
    static ColorMatrixColorFilter back;
    static ColorMatrixColorFilter dark;
    static Boolean lite;
    static final float[] H = {-0.574f, 1.43f, 0.144f, 0.426f, 0.43f, 0.144f, 0.426f, 1.43f, -0.856f};
    static final Paint darkP = new Paint();
    static final Paint backP = new Paint();

    static {
        float[] fArr = new float[20];
        for (int i = 0; i < 3; i++) {
            for (int i2 = 0; i2 < 3; i2++) {
                fArr[(i * 5) + i2] = (-0.8980392f) * H[(i * 3) + i2];
            }
            fArr[(i * 5) + 4] = 255.0f;
        }
        fArr[18] = 1.0f;
        dark = new ColorMatrixColorFilter(new ColorMatrix(fArr));
        float[] fArr2 = new float[20];
        for (int i3 = 0; i3 < 3; i3++) {
            for (int i4 = 0; i4 < 3; i4++) {
                fArr2[(i3 * 5) + i4] = (-H[(i3 * 3) + i4]) / B;
            }
            fArr2[(i3 * 5) + 4] = 283.95197f;
        }
        fArr2[18] = 1.0f;
        back = new ColorMatrixColorFilter(new ColorMatrix(fArr2));
        darkP.setColorFilter(dark);
        backP.setColorFilter(back);
        DARK = new WeakHashMap<>();
    }

    Night() {
    }

    static void apply(View view, Context context) {
        active = on(context);
        if (active) {
            view.setLayerType(2, darkP);
        } else {
            view.setLayerType(0, null);
        }
    }

    static void darkPage(View view) {
        if (!active || view == null) {
            return;
        }
        DARK.put(view, true);
        view.setLayerType(2, backP);
    }

    static boolean inDark(View view) {
        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
            if (DARK.containsKey(parent)) {
                return true;
            }
        }
        return false;
    }

    static int inv(int i) {
        return (iv((i >> 16) & 255) << 16) | (-16777216) | (iv((i >> 8) & 255) << 8) | iv(i & 255);
    }

    static int iv(int i) {
        return Math.max(0, Math.min(255, (((255 - i) * 229) / 255) + 26));
    }

    static void keep(View view) {
        if (!active || view == null) {
            return;
        }
        if (view.isAttachedToWindow()) {
            keepNow(view);
        } else {
            view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() { // from class: com.changliao.im.Night.1
                @Override // android.view.View.OnAttachStateChangeListener
                public void onViewAttachedToWindow(View view2) {
                    view2.removeOnAttachStateChangeListener(this);
                    Night.keepNow(view2);
                }

                @Override // android.view.View.OnAttachStateChangeListener
                public void onViewDetachedFromWindow(View view2) {
                }
            });
        }
    }

    static void keepNow(View view) {
        if (inDark(view)) {
            return;
        }
        if (view instanceof TextureView) {
            ((TextureView) view).setLayerPaint(backP);
        } else if (view instanceof ImageView) {
            ((ImageView) view).setColorFilter(back);
        } else {
            view.setLayerType(2, backP);
        }
    }

    static boolean lite(Context context) {
        // PATCH(需求1): 流畅模式恒关 —— 深色模式依赖阴影/玻璃高光渲染，lite 打开会让深色层不完整。
        lite = Boolean.FALSE;
        return false;
    }

    static int mode() {
        // PATCH(需求1): 夜间模式恒为「强制开」，不再读 prefs("nk").getInt("night")
        return 1;
    }

    static boolean on(Context context) {
        // PATCH(需求1): 深色判定恒真，不做 uiMode 跟随、不依赖 prefs
        return true;
    }
}
