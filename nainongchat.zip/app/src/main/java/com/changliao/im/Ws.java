package com.changliao.im;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public class Ws {
    static final String B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    public static volatile Bin binL;
    private volatile boolean dead;
    private final String host;
    private final L l;
    private OutputStream out;
    private final int port;
    private Thread sender;
    private Socket sock;
    private final SecureRandom rnd = new SecureRandom();
    private int msgOp = 1;
    private final LinkedBlockingQueue<Object[]> q = new LinkedBlockingQueue<>();

    public interface Bin {
        void bin(byte[] bArr);
    }

    public interface L {
        void closed(Ws ws, String str);

        void open(Ws ws);

        void text(Ws ws, String str);
    }

    public Ws(String str, int i, L l) {
        this.host = str;
        this.port = i;
        this.l = l;
    }

    static String b64(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bArr.length; i += 3) {
            int i2 = ((bArr[i] & 255) << 16) | (i + 1 < bArr.length ? (bArr[i + 1] & 255) << 8 : 0) | (i + 2 < bArr.length ? bArr[i + 2] & 255 : 0);
            sb.append(B64.charAt((i2 >> 18) & 63)).append(B64.charAt((i2 >> 12) & 63));
            sb.append(i + 1 < bArr.length ? B64.charAt((i2 >> 6) & 63) : '=');
            sb.append(i + 2 < bArr.length ? B64.charAt(i2 & 63) : '=');
        }
        return sb.toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void frame(int i, byte[] bArr) throws IOException {
        synchronized (this) {
            OutputStream outputStream = this.out;
            if (outputStream == null || this.dead) {
                throw new IOException("未连接");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length + 14);
            byteArrayOutputStream.write(i | 128);
            if (bArr.length < 126) {
                byteArrayOutputStream.write(bArr.length | 128);
            } else if (bArr.length < 65536) {
                byteArrayOutputStream.write(254);
                byteArrayOutputStream.write(bArr.length >> 8);
                byteArrayOutputStream.write(bArr.length & 255);
            } else {
                byteArrayOutputStream.write(255);
                for (int i2 = 7; i2 >= 0; i2--) {
                    byteArrayOutputStream.write((int) ((((long) bArr.length) >> (i2 * 8)) & 255));
                }
            }
            byte[] bArr2 = new byte[4];
            this.rnd.nextBytes(bArr2);
            byteArrayOutputStream.write(bArr2, 0, 4);
            byte[] bArr3 = new byte[bArr.length];
            for (int i3 = 0; i3 < bArr.length; i3++) {
                bArr3[i3] = (byte) (bArr[i3] ^ bArr2[i3 & 3]);
            }
            byteArrayOutputStream.write(bArr3, 0, bArr3.length);
            outputStream.write(byteArrayOutputStream.toByteArray());
            outputStream.flush();
        }
    }

    private static void full(InputStream inputStream, byte[] bArr) throws IOException {
        int i = 0;
        while (i < bArr.length) {
            int i2 = inputStream.read(bArr, i, bArr.length - i);
            if (i2 < 0) {
                throw new IOException("连接断开");
            }
            i += i2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loop() {
        long jRd;
        byte[] bArr;
        String strValueOf = "关闭";
        try {
            this.sock = new Socket();
            this.sock.connect(new InetSocketAddress(this.host, this.port), 8000);
            this.sock.setTcpNoDelay(true);
            this.sock.setSoTimeout(0);
            InputStream inputStream = this.sock.getInputStream();
            OutputStream outputStream = this.sock.getOutputStream();
            byte[] bArr2 = new byte[16];
            this.rnd.nextBytes(bArr2);
            outputStream.write(("GET / HTTP/1.1\r\nHost: " + this.host + ":" + this.port + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + b64(bArr2) + "\r\nSec-WebSocket-Version: 13\r\nUser-Agent: NAINONG-Chat\r\n\r\n").getBytes("UTF-8"));
            outputStream.flush();
            StringBuilder sb = new StringBuilder();
            int i = 0;
            do {
                int i2 = inputStream.read();
                if (i2 < 0) {
                    throw new IOException("握手失败");
                }
                sb.append((char) i2);
                i = (i << 8) | (i2 & 255);
                if (i == 218762506) {
                    if (!sb.toString().startsWith("HTTP/1.1 101")) {
                        throw new IOException("握手失败");
                    }
                    this.out = outputStream;
                    if (this.dead) {
                        return;
                    }
                    this.l.open(this);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    while (!this.dead) {
                        int iRd = rd(inputStream);
                        int iRd2 = rd(inputStream);
                        int i3 = iRd & 15;
                        boolean z = (iRd & 128) != 0;
                        long jRd2 = iRd2 & 127;
                        if (jRd2 == 126) {
                            jRd = (rd(inputStream) << 8) | rd(inputStream);
                        } else {
                            if (jRd2 == 127) {
                                jRd2 = 0;
                                for (int i4 = 0; i4 < 8; i4++) {
                                    jRd2 = (jRd2 << 8) | ((long) rd(inputStream));
                                }
                            }
                            jRd = jRd2;
                        }
                        if ((iRd2 & 128) != 0) {
                            byte[] bArr3 = new byte[4];
                            full(inputStream, bArr3);
                            bArr = bArr3;
                        } else {
                            bArr = null;
                        }
                        if (jRd > 33554432) {
                            throw new IOException("消息太大");
                        }
                        byte[] bArr4 = new byte[(int) jRd];
                        full(inputStream, bArr4);
                        if (bArr != null) {
                            for (int i5 = 0; i5 < bArr4.length; i5++) {
                                bArr4[i5] = (byte) (bArr4[i5] ^ bArr[i5 & 3]);
                            }
                        }
                        if (i3 == 8) {
                            strValueOf = "服务器关闭了连接";
                            break;
                        }
                        if (i3 == 9) {
                            frame(10, bArr4);
                        } else if (i3 != 10 && (i3 == 1 || i3 == 2 || i3 == 0)) {
                            if (i3 != 0) {
                                this.msgOp = i3;
                            }
                            byteArrayOutputStream.write(bArr4, 0, bArr4.length);
                            if (z) {
                                if (this.msgOp == 2) {
                                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                                    byteArrayOutputStream.reset();
                                    Bin bin = binL;
                                    if (bin != null) {
                                        try {
                                            bin.bin(byteArray);
                                        } catch (Throwable th) {
                                            Crash.note(th);
                                        }
                                    }
                                } else {
                                    String str = new String(byteArrayOutputStream.toByteArray(), "UTF-8");
                                    byteArrayOutputStream.reset();
                                    try {
                                        this.l.text(this, str);
                                    } catch (Throwable th2) {
                                        Crash.note(th2);
                                    }
                                }
                            }
                        }
                    }
                    close();
                    this.l.closed(this, strValueOf);
                    return;
                }
            } while (sb.length() <= 8192);
            throw new IOException("握手失败");
        } catch (Throwable th3) {
            strValueOf = String.valueOf(th3.getMessage());
        }
    }

    private boolean put(int i, byte[] bArr) {
        if (this.dead || this.out == null) {
            return false;
        }
        this.q.offer(new Object[]{Integer.valueOf(i), bArr});
        synchronized (this) {
            if (this.sender == null) {
                this.sender = new Thread(new Runnable() { // from class: com.changliao.im.Ws.2
                    @Override // java.lang.Runnable
                    public void run() {
                        while (!Ws.this.dead) {
                            try {
                                Object[] objArr = (Object[]) Ws.this.q.poll(30L, TimeUnit.SECONDS);
                                if (objArr != null) {
                                    Ws.this.frame(((Integer) objArr[0]).intValue(), (byte[]) objArr[1]);
                                }
                            } catch (InterruptedException e) {
                                return;
                            } catch (Exception e2) {
                                Ws.this.close();
                                return;
                            }
                        }
                    }
                }, "ws-send");
                this.sender.setDaemon(true);
                this.sender.start();
            }
        }
        return true;
    }

    private static int rd(InputStream inputStream) throws IOException {
        int i = inputStream.read();
        if (i < 0) {
            throw new IOException("连接断开");
        }
        return i;
    }

    public boolean alive() {
        return (this.dead || this.out == null) ? false : true;
    }

    public void close() {
        this.dead = true;
        if (this.sender != null) {
            this.sender.interrupt();
        }
        try {
            if (this.sock != null) {
                this.sock.close();
            }
        } catch (Exception e) {
        }
    }

    public boolean send(String str) {
        try {
            return put(1, str.getBytes("UTF-8"));
        } catch (Exception e) {
            return false;
        }
    }

    public boolean sendBin(byte[] bArr) {
        if (this.q.size() > 60) {
            return false;
        }
        return put(2, bArr);
    }

    public void start() {
        Thread thread = new Thread(new Runnable() { // from class: com.changliao.im.Ws.1
            @Override // java.lang.Runnable
            public void run() {
                Ws.this.loop();
            }
        }, "ws");
        thread.setDaemon(true);
        thread.start();
    }
}
