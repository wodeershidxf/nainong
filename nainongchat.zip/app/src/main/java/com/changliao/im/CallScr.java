package com.changliao.im;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.PowerManager;
import android.view.TextureView;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class CallScr extends Scr {
    Img.Av av;
    TextureView big;
    FrameLayout bigBox;
    LinearLayout btns;
    Call c;
    FrameLayout fr;
    FrameLayout grid;
    TextureView local;
    FrameLayout localBox;
    Tile meTile;
    TextView name;
    PowerManager.WakeLock prox;
    TextView st;
    LinearLayout who;
    final Map<Integer, Tile> tiles = new HashMap();
    int built = -1;
    final Runnable tick = new Runnable() { // from class: com.changliao.im.CallScr.5
        @Override // java.lang.Runnable
        public void run() {
            if (!CallScr.this.alive || CallScr.this.c == null) {
                return;
            }
            CallScr.this.st.setText(CallScr.this.c.status());
            if (CallScr.this.c.state == 3 && CallScr.this.c.rtc != null) {
                if (CallScr.this.c.group) {
                    for (Map.Entry<Integer, Tile> entry : CallScr.this.tiles.entrySet()) {
                        entry.getValue().upd(CallScr.this.c.rtc.hasVideo(entry.getKey().intValue()), CallScr.this.c.rtc.talking(entry.getKey().intValue()));
                    }
                    if (CallScr.this.meTile != null) {
                        CallScr.this.meTile.upd(CallScr.this.c.video && CallScr.this.c.camOn, CallScr.this.c.rtc.meTalking());
                    }
                } else if (CallScr.this.big != null) {
                    boolean z = CallScr.this.c.remoteSid >= 0 && CallScr.this.c.rtc.hasVideo(CallScr.this.c.remoteSid);
                    CallScr.this.big.setAlpha(z ? 1.0f : 0.0f);
                    CallScr.this.av.setVisibility(z ? 8 : 0);
                    CallScr.this.name.setVisibility(z ? 8 : 0);
                }
            }
            CallScr.this.a.h.postDelayed(this, 500L);
        }
    };

    final class Tile extends FrameLayout {
        final Img.Av av;
        final TextView nm;
        boolean talk;
        final TextureView tv;

        Tile(Context context, J j, boolean z) {
            super(context);
            setBackground(Ui.round(587202559, 14.0f));
            CallScr.round(this, 14.0f);
            this.tv = new TextureView(context);
            this.tv.setAlpha(0.0f);
            addView(this.tv, new FrameLayout.LayoutParams(-1, -1));
            this.av = new Img.Av(context);
            this.av.set(j.s("nick"), j.sn("av"), false);
            addView(this.av, Ui.flp(Ui.dp(56.0f), Ui.dp(56.0f), 17));
            this.nm = Ui.one(Ui.text(context, z ? "我" : j.s("nick"), 12.0f, -1));
            this.nm.setShadowLayer(4.0f, 0.0f, 1.0f, -1728053248);
            FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 8388691);
            layoutParamsFlp.leftMargin = Ui.dp(8.0f);
            layoutParamsFlp.bottomMargin = Ui.dp(6.0f);
            layoutParamsFlp.rightMargin = Ui.dp(8.0f);
            addView(this.nm, layoutParamsFlp);
        }

        void upd(boolean z, boolean z2) {
            this.tv.setAlpha(z ? 1.0f : 0.0f);
            this.av.setVisibility(z ? 8 : 0);
            if (z2 != this.talk) {
                this.talk = z2;
                setForeground(z2 ? Ui.round(0, 14.0f, 2, -13318311) : null);
            }
        }
    }

    static void round(View view, final float f) {
        view.setOutlineProvider(new ViewOutlineProvider() { // from class: com.changliao.im.CallScr.8
            @Override // android.view.ViewOutlineProvider
            public void getOutline(View view2, Outline outline) {
                outline.setRoundRect(0, 0, view2.getWidth(), view2.getHeight(), Ui.dp(f));
            }
        });
        view.setClipToOutline(true);
    }

    View btn(String str, String str2, int i, int i2, View.OnClickListener onClickListener) {
        int i3;
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setGravity(1);
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico(str, i2));
        imageView.setPadding(Ui.dp(17.0f), Ui.dp(17.0f), Ui.dp(17.0f), Ui.dp(17.0f));
        if (i == -50384) {
            i3 = 4;
        } else if (i == -13318311 || i == -13577896) {
            i3 = 6;
        } else {
            i3 = i == -1 ? 0 : 2;
        }
        G.on(imageView, i3, 32.0f, i3 == 2 ? 0.0f : 4.0f);
        if (i3 == 0) {
            G g = (G) ((RippleDrawable) imageView.getBackground()).getDrawable(0);
            g.btn = false;
            g.bg = -1;
        }
        imageView.setOnClickListener(onClickListener);
        Ui.bounce(imageView);
        linearLayoutCol.addView(imageView, Ui.lp(Ui.dp(64.0f), Ui.dp(64.0f)));
        TextView textViewText = Ui.text(this.a, str2, 12.0f, -570425345);
        textViewText.setGravity(17);
        linearLayoutCol.addView(textViewText, Ui.lpm(-2, -2, 0, 8, 0, 0));
        return linearLayoutCol;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        this.c = Call.cur;
        this.fr = new FrameLayout(this.a);
        this.fr.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-14011578, -15394268}));
        this.fr.setKeepScreenOn(true);
        this.fr.setClickable(true);
        if (this.c == null) {
            this.a.h.post(new Runnable() { // from class: com.changliao.im.CallScr.1
                @Override // java.lang.Runnable
                public void run() {
                    if (CallScr.this.alive) {
                        CallScr.this.a.back();
                    }
                }
            });
            return this.fr;
        }
        if (this.c.group) {
            this.grid = new FrameLayout(this.a) { // from class: com.changliao.im.CallScr.2
                @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
                protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
                    CallScr.this.layoutGrid(i3 - i, i4 - i2);
                }
            };
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
            layoutParams.topMargin = Ui.dp(110.0f);
            layoutParams.bottomMargin = Ui.dp(200.0f);
            this.fr.addView(this.grid, layoutParams);
        } else {
            this.bigBox = new FrameLayout(this.a);
            this.fr.addView(this.bigBox, new FrameLayout.LayoutParams(-1, -1));
        }
        ImageView imageViewIconBtn = Ui.iconBtn(this.a, "back", -1, 42.0f, new View.OnClickListener() { // from class: com.changliao.im.CallScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CallScr.this.a.back();
            }
        });
        imageViewIconBtn.setBackground(Ui.glassDark(21.0f));
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(Ui.dp(42.0f), Ui.dp(42.0f), 8388659);
        layoutParamsFlp.leftMargin = Ui.dp(14.0f);
        layoutParamsFlp.topMargin = Ui.dp(14.0f);
        this.fr.addView(imageViewIconBtn, layoutParamsFlp);
        this.who = Ui.col(this.a);
        this.who.setGravity(1);
        this.av = new Img.Av(this.a);
        if (this.c.group) {
            this.av.set(this.c.name, this.c.av, true, this.c.gid);
            this.av.setGroup(true);
        } else {
            this.av.set(this.c.name, this.c.av, false);
        }
        this.who.addView(this.av, Ui.lp(Ui.dp(this.c.group ? 64.0f : 96.0f), Ui.dp(this.c.group ? 64.0f : 96.0f)));
        this.name = Ui.one(Ui.bold(Ui.text(this.a, this.c.name, this.c.group ? 18.0f : 24.0f, -1)));
        this.name.setGravity(17);
        this.who.addView(this.name, Ui.lpm(-2, -2, 0, 14, 0, 0));
        this.st = Ui.text(this.a, "", 14.0f, -855638017);
        this.st.setGravity(17);
        this.who.addView(this.st, Ui.lpm(-2, -2, 0, 8, 0, 0));
        FrameLayout.LayoutParams layoutParamsFlp2 = Ui.flp(-1, -2, 48);
        layoutParamsFlp2.topMargin = Ui.dp(this.c.group ? 20.0f : 110.0f);
        layoutParamsFlp2.leftMargin = Ui.dp(60.0f);
        layoutParamsFlp2.rightMargin = Ui.dp(60.0f);
        this.fr.addView(this.who, layoutParamsFlp2);
        if (this.c.group) {
            this.who.setOrientation(1);
        }
        this.btns = Ui.col(this.a);
        this.btns.setGravity(1);
        FrameLayout.LayoutParams layoutParamsFlp3 = Ui.flp(-1, -2, 80);
        layoutParamsFlp3.bottomMargin = Ui.dp(36.0f);
        this.fr.addView(this.btns, layoutParamsFlp3);
        this.c.onChange = new Runnable() { // from class: com.changliao.im.CallScr.4
            @Override // java.lang.Runnable
            public void run() {
                if (CallScr.this.alive) {
                    CallScr.this.refresh();
                }
            }
        };
        refresh();
        this.a.h.post(this.tick);
        return this.fr;
    }

    void buildBtns() {
        String str;
        this.btns.removeAllViews();
        if (this.c.state == 1) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setGravity(17);
            linearLayoutRow.addView(btn("hang", this.c.group ? "忽略" : "拒绝", -50384, -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.9
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CallScr.this.c.hangup();
                }
            }), Ui.lp(0, -2, 1.0f));
            linearLayoutRow.addView(btn(this.c.video ? "video" : "pickup", this.c.group ? "加入" : "接听", -13318311, -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.10
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CallScr.this.c.accept();
                }
            }), Ui.lp(0, -2, 1.0f));
            this.btns.addView(linearLayoutRow, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setGravity(17);
        linearLayoutRow2.addView(btn(this.c.muted ? "micoff" : "mic", this.c.muted ? "已静音" : "麦克风", this.c.muted ? -1 : 872415231, this.c.muted ? -14999766 : -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CallScr.this.c.setMute(!CallScr.this.c.muted);
            }
        }), Ui.lp(0, -2, 1.0f));
        linearLayoutRow2.addView(btn("share", this.c.sharing ? "停止共享" : "共享屏幕", this.c.sharing ? -1 : 872415231, this.c.sharing ? -14999766 : -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CallScr.this.c.share(CallScr.this.a);
            }
        }), Ui.lp(0, -2, 1.0f));
        linearLayoutRow2.addView(btn("spk", this.c.speaker ? "扬声器已开" : "扬声器", this.c.speaker ? -1 : 872415231, this.c.speaker ? -14999766 : -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CallScr.this.c.setSpeaker(!CallScr.this.c.speaker);
            }
        }), Ui.lp(0, -2, 1.0f));
        if (this.c.video) {
            linearLayoutRow2.addView(btn("video", this.c.camOn ? "摄像头" : "摄像头已关", this.c.camOn ? 872415231 : -1, this.c.camOn ? -1 : -14999766, new View.OnClickListener() { // from class: com.changliao.im.CallScr.14
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CallScr.this.c.setCam(!CallScr.this.c.camOn);
                }
            }), Ui.lp(0, -2, 1.0f));
            linearLayoutRow2.addView(btn("flip", "翻转", 872415231, -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.15
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CallScr.this.c.flip();
                }
            }), Ui.lp(0, -2, 1.0f));
        }
        this.btns.addView(linearLayoutRow2, new LinearLayout.LayoutParams(-1, -2));
        if (this.c.state == 0) {
            str = "取消";
        } else {
            str = this.c.group ? "退出" : "挂断";
        }
        this.btns.addView(btn("hang", str, -50384, -1, new View.OnClickListener() { // from class: com.changliao.im.CallScr.16
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CallScr.this.c.hangup();
            }
        }), Ui.lpm(-2, -2, 0, 22, 0, 0));
    }

    @Override // com.changliao.im.Scr
    public boolean dark() {
        return true;
    }

    @Override // com.changliao.im.Scr
    public boolean full() {
        return true;
    }

    void layoutGrid(int i, int i2) {
        int childCount = this.grid.getChildCount();
        if (childCount == 0) {
            return;
        }
        int i3 = childCount > 1 ? childCount <= 4 ? 2 : 3 : 1;
        int i4 = ((childCount + i3) - 1) / i3;
        int iDp = Ui.dp(8.0f);
        int iDp2 = ((i - (Ui.dp(12.0f) * 2)) - ((i3 - 1) * iDp)) / i3;
        int iMin = Math.min((i2 - ((i4 - 1) * iDp)) / i4, (iDp2 * 4) / 3);
        int i5 = (i2 - (((i4 - 1) * iDp) + (iMin * i4))) / 2;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = this.grid.getChildAt(i6);
            int i7 = i6 / i3;
            int iMin2 = Math.min(i3, childCount - (i7 * i3));
            int i8 = ((i6 % i3) * (iDp2 + iDp)) + ((i - (((iMin2 - 1) * iDp) + (iDp2 * iMin2))) / 2);
            int i9 = (i7 * (iMin + iDp)) + i5;
            childAt.measure(View.MeasureSpec.makeMeasureSpec(iDp2, 1073741824), View.MeasureSpec.makeMeasureSpec(iMin, 1073741824));
            childAt.layout(i8, i9, i8 + iDp2, i9 + iMin);
        }
    }

    @Override // com.changliao.im.Scr
    public boolean onBack() {
        return false;
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        proximity(false);
        this.a.darkBars(false);
        if (this.c != null) {
            this.c.onChange = null;
            if (this.c.rtc != null) {
                this.c.rtc.setLocal(null);
            }
        }
        this.a.callPill();
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        this.a.darkBars(true);
    }

    /* JADX WARN: Code duplicated, block: B:8:0x0024  */
    void proximity(boolean z) {
        if (z) {
            try {
                if (this.prox == null) {
                    this.prox = ((PowerManager) this.a.getSystemService("power")).newWakeLock(32, "nk:call");
                    this.prox.acquire(10800000L);
                } else if (!z && this.prox != null) {
                    this.prox.release();
                    this.prox = null;
                }
            } catch (Throwable th) {
                this.prox = null;
            }
        } else if (!z) {
            this.prox.release();
            this.prox = null;
        }
    }

    void refresh() {
        boolean z = true;
        if (this.c == null) {
            return;
        }
        if (this.c.state == 4) {
            this.st.setText("通话已结束");
            this.a.h.postDelayed(new Runnable() { // from class: com.changliao.im.CallScr.6
                @Override // java.lang.Runnable
                public void run() {
                    if (CallScr.this.alive) {
                        CallScr.this.a.back();
                    }
                }
            }, 600L);
            this.btns.removeAllViews();
            return;
        }
        this.st.setText(this.c.status());
        int i = (this.c.sharing ? 8 : 0) + (this.c.state * 100) + (this.c.muted ? 1 : 0) + (this.c.speaker ? 2 : 0) + (this.c.camOn ? 4 : 0);
        if (i != this.built) {
            this.built = i;
            buildBtns();
        }
        if (this.c.state == 3 && this.c.rtc != null) {
            if (this.c.group) {
                syncTiles();
            } else {
                if (this.c.video && this.local == null) {
                    this.localBox = new FrameLayout(this.a);
                    this.local = new TextureView(this.a);
                    this.localBox.addView(this.local, new FrameLayout.LayoutParams(-1, -1));
                    round(this.localBox, 12.0f);
                    FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(Ui.dp(108.0f), Ui.dp(152.0f), 8388661);
                    layoutParamsFlp.topMargin = Ui.dp(14.0f);
                    layoutParamsFlp.rightMargin = Ui.dp(14.0f);
                    this.fr.addView(this.localBox, layoutParamsFlp);
                    this.localBox.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.CallScr.7
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            CallScr.this.c.flip();
                        }
                    });
                    this.c.rtc.setLocal(this.local);
                }
                if (this.localBox != null) {
                    this.localBox.setVisibility((!this.c.camOn || this.c.sharing) ? 8 : 0);
                }
                if (this.c.remoteSid >= 0 && this.big == null) {
                    this.big = new TextureView(this.a);
                    this.big.setAlpha(0.0f);
                    this.bigBox.addView(this.big, new FrameLayout.LayoutParams(-1, -1));
                    this.c.rtc.attach(this.c.remoteSid, this.big);
                }
            }
        }
        if (this.c.group || this.c.video || this.c.speaker || (this.c.state != 3 && this.c.state != 0)) {
            z = false;
        }
        proximity(z);
    }

    void syncTiles() {
        if (this.meTile == null) {
            Object[] objArr = new Object[4];
            objArr[0] = "nick";
            objArr[1] = this.C.myNick();
            objArr[2] = "av";
            objArr[3] = this.C.info == null ? null : this.C.info.sn("av");
            this.meTile = new Tile(this.a, J.of(objArr), true);
            this.grid.addView(this.meTile);
            if (this.c.video) {
                this.c.rtc.setLocal(this.meTile.tv);
                this.meTile.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.CallScr.17
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CallScr.this.c.flip();
                    }
                });
            }
        }
        for (Integer num : new ArrayList<Integer>(this.tiles.keySet())) {
            if (!this.c.peers.containsKey(num)) {
                this.grid.removeView(this.tiles.remove(num));
            }
        }
        for (Map.Entry<Integer, J> entry : this.c.peers.entrySet()) {
            Tile tile = this.tiles.get(entry.getKey());
            if (tile == null) {
                Tile tile2 = new Tile(this.a, entry.getValue(), false);
                this.tiles.put(entry.getKey(), tile2);
                this.grid.addView(tile2);
                tile = tile2;
            }
            this.c.rtc.attach(entry.getKey().intValue(), tile.tv);
        }
        this.grid.requestLayout();
    }
}
