package com.changliao.im;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

/* JADX INFO: loaded from: classes.dex */
public class VidScr extends Scr {
    final String conv;
    TextView cur;
    boolean drag;
    TextView dur;
    final J f;
    final J m;
    ImageView pp;
    SeekBar sb;
    View ui;
    VideoView vv;
    ProgressBar wait;
    final Runnable hide = new Runnable() { // from class: com.changliao.im.VidScr.9
        @Override // java.lang.Runnable
        public void run() {
            if (!VidScr.this.vv.isPlaying() || VidScr.this.drag) {
                return;
            }
            VidScr.this.showUi(false);
        }
    };
    final Runnable tick = new Runnable() { // from class: com.changliao.im.VidScr.10
        @Override // java.lang.Runnable
        public void run() {
            if (VidScr.this.alive) {
                int duration = VidScr.this.vv.getDuration();
                int currentPosition = VidScr.this.vv.getCurrentPosition();
                if (duration > 0 && !VidScr.this.drag) {
                    VidScr.this.sb.setProgress((int) ((((long) currentPosition) * 1000) / ((long) duration)));
                    VidScr.this.cur.setText(VidScr.t(currentPosition));
                }
                VidScr.this.a.h.postDelayed(this, 250L);
            }
        }
    };

    static class PlayIco extends Drawable {
        final Paint p = new Paint(1);
        final boolean playing;

        PlayIco(boolean z) {
            this.playing = z;
            this.p.setColor(-1);
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            float fWidth = bounds.width();
            float fHeight = bounds.height();
            float f = bounds.left;
            float f2 = bounds.top;
            if (this.playing) {
                float f3 = fWidth * 0.2f;
                canvas.drawRoundRect(f + (0.22f * fWidth), f2 + (0.18f * fHeight), (0.22f * fWidth) + f + f3, f2 + (0.82f * fHeight), f3 / 3.0f, f3 / 3.0f, this.p);
                canvas.drawRoundRect(f + (0.58f * fWidth), f2 + (0.18f * fHeight), (0.58f * fWidth) + f + f3, f2 + (0.82f * fHeight), f3 / 3.0f, f3 / 3.0f, this.p);
            } else {
                Path path = new Path();
                path.moveTo((0.3f * fWidth) + f, (0.16f * fHeight) + f2);
                path.lineTo((0.86f * fWidth) + f, (0.5f * fHeight) + f2);
                path.lineTo((0.3f * fWidth) + f, (0.84f * fHeight) + f2);
                path.close();
                canvas.drawPath(path, this.p);
            }
        }

        @Override // android.graphics.drawable.Drawable
        public int getOpacity() {
            return -3;
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int i) {
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter colorFilter) {
        }
    }

    public VidScr(J j, String str, J j2) {
        this.f = j;
        this.conv = str;
        this.m = j2;
    }

    static String t(int i) {
        int iMax = Math.max(0, i / 1000);
        return Ui.pad(iMax / 60) + ":" + Ui.pad(iMax % 60);
    }

    @Override // com.changliao.im.Scr
    public View build() {
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setBackgroundColor(-16777216);
        this.vv = new VideoView(this.a);
        frameLayout.addView(this.vv, Ui.flp(-1, -1, 17));
        this.wait = new ProgressBar(this.a);
        frameLayout.addView(this.wait, Ui.flp(Ui.dp(40.0f), Ui.dp(40.0f), 17));
        FrameLayout frameLayout2 = new FrameLayout(this.a);
        this.ui = frameLayout2;
        frameLayout.addView(frameLayout2, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.VidScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                VidScr.this.showUi(VidScr.this.ui.getAlpha() < 0.5f);
            }
        });
        ImageView imageViewIconBtn = Ui.iconBtn(this.a, "back", -1, 42.0f, new View.OnClickListener() { // from class: com.changliao.im.VidScr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                VidScr.this.a.back();
            }
        });
        imageViewIconBtn.setBackground(Ui.glassDark(21.0f));
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(Ui.dp(42.0f), Ui.dp(42.0f), 8388659);
        layoutParamsFlp.leftMargin = Ui.dp(12.0f);
        layoutParamsFlp.topMargin = Ui.dp(12.0f);
        frameLayout2.addView(imageViewIconBtn, layoutParamsFlp);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        this.pp = new ImageView(this.a);
        this.pp.setPadding(Ui.dp(10.0f), Ui.dp(10.0f), Ui.dp(10.0f), Ui.dp(10.0f));
        this.pp.setBackground(Ui.glassDark(22.0f));
        this.pp.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.VidScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (VidScr.this.vv.isPlaying()) {
                    VidScr.this.vv.pause();
                } else {
                    VidScr.this.vv.start();
                }
                VidScr.this.icon();
                VidScr.this.poke();
            }
        });
        Ui.bounce(this.pp);
        linearLayoutRow.addView(this.pp, Ui.lp(Ui.dp(44.0f), Ui.dp(44.0f)));
        LinearLayout linearLayoutCol = Ui.col(this.a);
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        this.cur = Ui.text(this.a, "00:00", 12.0f, -1);
        this.dur = Ui.text(this.a, "00:00", 12.0f, -1);
        linearLayoutRow2.addView(this.cur, Ui.lp(0, -2, 1.0f));
        linearLayoutRow2.addView(this.dur);
        linearLayoutRow2.setPadding(Ui.dp(14.0f), 0, Ui.dp(14.0f), 0);
        linearLayoutCol.addView(linearLayoutRow2);
        this.sb = new SeekBar(this.a);
        this.sb.setMax(1000);
        this.sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.changliao.im.VidScr.4
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (!z || VidScr.this.vv.getDuration() <= 0) {
                    return;
                }
                VidScr.this.cur.setText(VidScr.t((int) ((((long) VidScr.this.vv.getDuration()) * ((long) i)) / 1000)));
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
                VidScr.this.drag = true;
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
                VidScr.this.drag = false;
                if (VidScr.this.vv.getDuration() > 0) {
                    VidScr.this.vv.seekTo((int) ((((long) VidScr.this.vv.getDuration()) * ((long) seekBar.getProgress())) / 1000));
                }
                VidScr.this.poke();
            }
        });
        linearLayoutCol.addView(this.sb);
        linearLayoutRow.addView(linearLayoutCol, Ui.lpm(0, -2, 6, 0, 0, 0));
        ((LinearLayout.LayoutParams) linearLayoutCol.getLayoutParams()).weight = 1.0f;
        FrameLayout.LayoutParams layoutParamsFlp2 = Ui.flp(-1, -2, 80);
        layoutParamsFlp2.leftMargin = Ui.dp(14.0f);
        layoutParamsFlp2.rightMargin = Ui.dp(8.0f);
        layoutParamsFlp2.bottomMargin = Ui.dp(92.0f);
        frameLayout2.addView(linearLayoutRow, layoutParamsFlp2);
        LinearLayout linearLayoutRow3 = Ui.row(this.a);
        linearLayoutRow3.addView(op("dl", new View.OnClickListener() { // from class: com.changliao.im.VidScr.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Save.save(VidScr.this.a, VidScr.this.f, "video");
            }
        }));
        FrameLayout.LayoutParams layoutParamsFlp3 = Ui.flp(-2, -2, 8388693);
        layoutParamsFlp3.rightMargin = Ui.dp(16.0f);
        layoutParamsFlp3.bottomMargin = Ui.dp(26.0f);
        frameLayout2.addView(linearLayoutRow3, layoutParamsFlp3);
        icon();
        this.vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.changliao.im.VidScr.6
            @Override // android.media.MediaPlayer.OnPreparedListener
            public void onPrepared(MediaPlayer mediaPlayer) {
                VidScr.this.wait.setVisibility(8);
                VidScr.this.dur.setText(VidScr.t(VidScr.this.vv.getDuration()));
                VidScr.this.vv.start();
                VidScr.this.icon();
                VidScr.this.poke();
            }
        });
        this.vv.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.changliao.im.VidScr.7
            @Override // android.media.MediaPlayer.OnCompletionListener
            public void onCompletion(MediaPlayer mediaPlayer) {
                VidScr.this.icon();
                VidScr.this.showUi(true);
            }
        });
        this.vv.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.changliao.im.VidScr.8
            @Override // android.media.MediaPlayer.OnErrorListener
            public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                VidScr.this.wait.setVisibility(8);
                VidScr.this.toast("这个视频播放不了，可以保存到手机后用别的播放器看");
                return true;
            }
        });
        this.vv.setVideoURI(Uri.parse(Core.fileUrl(this.f.s("id"), this.f.s("name"))));
        this.a.h.post(this.tick);
        return frameLayout;
    }

    @Override // com.changliao.im.Scr
    public boolean dark() {
        return true;
    }

    @Override // com.changliao.im.Scr
    public boolean full() {
        return true;
    }

    void icon() {
        this.pp.setImageDrawable(new PlayIco(this.vv.isPlaying()));
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        this.a.darkBars(false);
        try {
            this.vv.stopPlayback();
        } catch (Throwable th) {
        }
    }

    @Override // com.changliao.im.Scr
    public void onHide() {
        this.a.darkBars(false);
        try {
            this.vv.pause();
            icon();
        } catch (Throwable th) {
        }
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        this.a.darkBars(true);
    }

    ImageView op(String str, View.OnClickListener onClickListener) {
        ImageView imageViewIconBtn = Ui.iconBtn(this.a, str, -1, 46.0f, onClickListener);
        imageViewIconBtn.setBackground(Ui.glassDark(23.0f));
        ((LinearLayout.LayoutParams) imageViewIconBtn.getLayoutParams()).leftMargin = Ui.dp(12.0f);
        return imageViewIconBtn;
    }

    void poke() {
        this.a.h.removeCallbacks(this.hide);
        this.a.h.postDelayed(this.hide, 3000L);
    }

    void showUi(boolean z) {
        this.ui.animate().alpha(z ? 1.0f : 0.0f).setDuration(200L).start();
        this.ui.setVisibility(0);
        if (z) {
            poke();
        }
        for (int i = 0; i < ((FrameLayout) this.ui).getChildCount(); i++) {
            ((FrameLayout) this.ui).getChildAt(i).setEnabled(z);
        }
    }
}
