package com.changliao.im;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* JADX INFO: loaded from: classes.dex */
public class Boot extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        try {
            App.init(context);
            if (Core.I.token() != null) {
                App.startBg(context);
            }
        } catch (Throwable th) {
            Crash.note(th);
        }
    }
}
