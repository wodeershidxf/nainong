package com.changliao.im;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public class Notif {
    static final String BG = "nk_bg2";
    static final String CALL = "nk_call2";
    static final String MSG = "nk_msg";
    static int n = 10;

    static Notification bg(Context context) {
        return new Notification.Builder(context, BG).setSmallIcon(icon(context)).setContentTitle("NAINONG Chat").setContentText("正在后台运行，保证能及时收到消息和来电").setContentIntent(open(context, null, 3)).setOngoing(true).build();
    }

    public static void call(Context context, String str, boolean z) {
        try {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            PendingIntent pendingIntentOpen = open(context, null, 7);
            notificationManager.notify(7, new Notification.Builder(context, CALL).setSmallIcon(icon(context)).setContentTitle(str).setContentText(z ? "邀请你视频通话" : "邀请你语音通话").setAutoCancel(true).setContentIntent(pendingIntentOpen).setFullScreenIntent(pendingIntentOpen, true).setCategory("call").setTimeoutAfter(60000L).build());
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    public static void cancel(Context context, int i) {
        try {
            ((NotificationManager) context.getSystemService("notification")).cancel(i);
        } catch (Throwable th) {
        }
    }

    static void channels(Context context) {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        NotificationChannel notificationChannel = new NotificationChannel(MSG, "聊天消息", 4);
        notificationChannel.enableVibration(true);
        notificationManager.createNotificationChannel(notificationChannel);
        NotificationChannel notificationChannel2 = new NotificationChannel(CALL, "语音和视频来电", 4);
        notificationChannel2.setSound(RingtoneManager.getDefaultUri(1), new AudioAttributes.Builder().setUsage(6).build());
        notificationChannel2.setBypassDnd(true);
        notificationChannel2.setLockscreenVisibility(1);
        notificationChannel2.enableVibration(true);
        notificationChannel2.setVibrationPattern(new long[]{0, 800, 600, 800, 600, 800});
        notificationManager.createNotificationChannel(notificationChannel2);
        try {
            notificationManager.deleteNotificationChannel("nk_bg");
            notificationManager.deleteNotificationChannel("nk_call");
        } catch (Throwable th) {
        }
        NotificationChannel notificationChannel3 = new NotificationChannel(BG, "后台运行", 2);
        notificationChannel3.setShowBadge(false);
        notificationManager.createNotificationChannel(notificationChannel3);
    }

    public static void clear(Context context) {
        try {
            ((NotificationManager) context.getSystemService("notification")).cancelAll();
        } catch (Throwable th) {
        }
        if (Keeper.on) {
            App.startBg(context);
        }
    }

    static int icon(Context context) {
        return context.getApplicationInfo().icon;
    }

    public static void msg(Context context, String str, String str2, String str3) {
        int iHashCode;
        try {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            if (str3 == null) {
                iHashCode = n + 1;
                n = iHashCode;
            } else {
                iHashCode = (str3.hashCode() & 16777215) + 1000;
            }
            notificationManager.notify(iHashCode, new Notification.Builder(context, MSG).setSmallIcon(icon(context)).setContentTitle(str).setContentText(str2).setStyle(new Notification.BigTextStyle().bigText(str2)).setAutoCancel(true).setContentIntent(open(context, str3, iHashCode)).setCategory("msg").setWhen(System.currentTimeMillis()).setShowWhen(true).build());
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    static PendingIntent open(Context context, String str, int i) {
        Intent intent = new Intent(context, (Class<?>) MainActivity.class);
        intent.addFlags(805306368);
        if (str != null) {
            intent.putExtra("conv", str);
        }
        return PendingIntent.getActivity(context, i, intent, 201326592);
    }
}
