package com.changliao.im;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public class GalScr extends Scr {
    static final ExecutorService pool = Executors.newFixedThreadPool(3);
    static final LruCache<Long, Bitmap> thumbs = new LruCache<Long, Bitmap>(25165824) { // from class: com.changliao.im.GalScr.1
        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.util.LruCache
        public int sizeOf(Long l, Bitmap bitmap) {
            return bitmap.getByteCount();
        }
    };
    TextView albI;
    View albPanel;
    TextView albT;
    final Got cb;
    FrameLayout emptyBox;
    TextView goB;
    GridView grid;
    boolean noOrig;
    boolean onlyImg;
    boolean orig;
    TextView origB;
    View origDot;
    FrameLayout pv;
    int pvAt;
    TextView pvB;
    TextView pvGo;
    ImageView pvImg;
    List<It> pvL;
    TextView pvN;
    View pvOrig;
    TextView pvSel;
    VideoView pvVid;
    FrameLayout root;
    boolean single;
    String title = "最近照片";
    String okText = "发送";
    int max = 20;
    final List<It> all = new ArrayList();
    List<It> shown = new ArrayList();
    final List<It> sel = new ArrayList();
    String album = "";
    final GA ad = new GA();

    class Cell extends FrameLayout {
        It it;
        final ImageView iv;
        final TextView sc;
        final TextView vd;

        Cell() {
            super(GalScr.this.a);
            setBackgroundColor(-15000803);
            this.iv = new ImageView(GalScr.this.a);
            this.iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            addView(this.iv, new FrameLayout.LayoutParams(-1, -1));
            this.vd = Ui.text(GalScr.this.a, "", 11.0f, -1);
            this.vd.setShadowLayer(3.0f, 0.0f, 1.0f, -16777216);
            FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(-2, -2, 8388691);
            layoutParamsFlp.leftMargin = Ui.dp(5.0f);
            layoutParamsFlp.bottomMargin = Ui.dp(3.0f);
            addView(this.vd, layoutParamsFlp);
            this.sc = Ui.bold(Ui.text(GalScr.this.a, "", 13.0f, -1));
            this.sc.setGravity(17);
            FrameLayout.LayoutParams layoutParamsFlp2 = Ui.flp(Ui.dp(26.0f), Ui.dp(26.0f), 8388661);
            layoutParamsFlp2.topMargin = Ui.dp(6.0f);
            layoutParamsFlp2.rightMargin = Ui.dp(6.0f);
            addView(this.sc, layoutParamsFlp2);
            View view = new View(GalScr.this.a);
            view.setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.GalScr.Cell.1
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View view2, MotionEvent motionEvent) {
                    if (motionEvent.getActionMasked() == 0) {
                        view2.getParent().requestDisallowInterceptTouchEvent(false);
                    }
                    if (motionEvent.getActionMasked() == 1) {
                        GalScr.this.toggle(Cell.this.it);
                        Cell.this.sc.animate().scaleX(1.15f).scaleY(1.15f).setDuration(90L).withEndAction(new Runnable() { // from class: com.changliao.im.GalScr.Cell.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Cell.this.sc.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160L).start();
                            }
                        }).start();
                    }
                    return true;
                }
            });
            addView(view, Ui.flp(Ui.dp(52.0f), Ui.dp(52.0f), 8388661));
            setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.Cell.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    GalScr.this.preview(GalScr.this.shown, GalScr.this.shown.indexOf(Cell.this.it));
                }
            });
        }

        void bind(It it) {
            this.it = it;
            this.iv.setTag(Long.valueOf(it.id));
            Bitmap bitmap = GalScr.thumbs.get(Long.valueOf(it.id));
            this.iv.setImageBitmap(bitmap);
            if (bitmap == null) {
                GalScr.this.thumb(it, this.iv);
            }
            this.vd.setText(it.vid ? "▶ " + (it.dur / 60) + ":" + Ui.pad(it.dur % 60) : "");
            mark();
        }

        void mark() {
            String strValueOf;
            int iIndexOf = GalScr.this.sel.indexOf(this.it);
            TextView textView = this.sc;
            if (iIndexOf >= 0) {
                strValueOf = GalScr.this.single ? "✓" : String.valueOf(iIndexOf + 1);
            } else {
                strValueOf = "";
            }
            textView.setText(strValueOf);
            this.sc.setBackground(Ui.round(iIndexOf >= 0 ? -14774017 : 1073741824, 13.0f, 2, iIndexOf >= 0 ? -14774017 : -218103809));
            this.iv.setAlpha(iIndexOf >= 0 ? 0.72f : 1.0f);
        }
    }

    class GA extends BaseAdapter {
        GA() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return GalScr.this.shown.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return GalScr.this.shown.get(i);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return GalScr.this.shown.get(i).id;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            Cell cell = view instanceof Cell ? (Cell) view : GalScr.this.new Cell();
            cell.setLayoutParams(new AbsListView.LayoutParams(-1, ((GalScr.this.grid.getWidth() > 0 ? GalScr.this.grid.getWidth() : GalScr.this.a.getResources().getDisplayMetrics().widthPixels) - Ui.dp(9.0f)) / 4));
            cell.bind(GalScr.this.shown.get(i));
            return cell;
        }
    }

    public interface Got {
        void got(List<Uri> list, boolean z);
    }

    static final class It {
        String bk;
        int dur;
        long id;
        String mime;
        Uri uri;
        boolean vid;

        It() {
        }
    }

    public GalScr(Got got) {
        this.cb = got;
    }

    static GradientDrawable ring() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(0);
        gradientDrawable.setStroke(Ui.dp(1.5f), -1);
        return gradientDrawable;
    }

    View albRow(final String str, final String str2, List<It> list) {
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(18.0f), Ui.dp(10.0f), Ui.dp(18.0f), Ui.dp(10.0f));
        linearLayoutRow.setBackground(Ui.press(this.album.equals(str) ? 352321535 : 0, 0.0f));
        ImageView imageView = new ImageView(this.a);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackground(Ui.round(-14540254, 8.0f));
        ChatScr.clip(imageView, 8.0f);
        if (!list.isEmpty()) {
            It it = list.get(0);
            imageView.setTag(Long.valueOf(it.id));
            Bitmap bitmap = thumbs.get(Long.valueOf(it.id));
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
            } else {
                thumb(it, imageView);
            }
        }
        linearLayoutRow.addView(imageView, Ui.lpm(Ui.dp(60.0f), Ui.dp(60.0f), 0, 0, 14, 0));
        linearLayoutRow.addView(Ui.one(Ui.text(this.a, str2, 16.0f, -1)), Ui.lp(0, -2, 1.0f));
        linearLayoutRow.addView(Ui.text(this.a, String.valueOf(list.size()), 14.0f, -7696487));
        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.album = str;
                GalScr.this.albT.setText(str2);
                GalScr.this.toggleAlbums();
                GalScr.this.filter();
            }
        });
        return linearLayoutRow;
    }

    void askPerm() {
        if (Build.VERSION.SDK_INT >= 33) {
            this.a.requestPermissions(new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"}, 11);
        } else {
            this.a.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 11);
        }
    }

    @Override // com.changliao.im.Scr
    public View build() {
        this.root = new FrameLayout(this.a);
        this.root.setBackgroundColor(-16777216);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        this.root.addView(linearLayoutCol, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout = new FrameLayout(this.a);
        frameLayout.setMinimumHeight(Ui.dp(56.0f));
        TextView textViewText = Ui.text(this.a, "✕", 24.0f, -1);
        textViewText.setGravity(17);
        textViewText.setTextSize(20.0f);
        G.on(textViewText, 2, 20.0f, 0.0f);
        Ui.bounce(textViewText);
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.a.back();
            }
        });
        FrameLayout.LayoutParams layoutParamsFlp = Ui.flp(Ui.dp(40.0f), Ui.dp(40.0f), 8388627);
        layoutParamsFlp.leftMargin = Ui.dp(10.0f);
        frameLayout.addView(textViewText, layoutParamsFlp);
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setGravity(17);
        linearLayoutRow.setPadding(Ui.dp(12.0f), Ui.dp(6.0f), Ui.dp(12.0f), Ui.dp(6.0f));
        G.on(linearLayoutRow, 2, 18.0f, 0.0f);
        Ui.bounce(linearLayoutRow);
        this.albT = Ui.one(Ui.bold(Ui.text(this.a, this.title, 18.0f, -1)));
        this.albT.setMaxWidth(Ui.dp(200.0f));
        this.albI = Ui.text(this.a, "▾", 13.0f, -855638017);
        linearLayoutRow.addView(this.albT);
        linearLayoutRow.addView(this.albI, Ui.lpm(-2, -2, 6, 0, 0, 0));
        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.toggleAlbums();
            }
        });
        frameLayout.addView(linearLayoutRow, Ui.flp(-2, -2, 17));
        linearLayoutCol.addView(frameLayout, new LinearLayout.LayoutParams(-1, Ui.dp(56.0f)));
        FrameLayout frameLayout2 = new FrameLayout(this.a);
        linearLayoutCol.addView(frameLayout2, Ui.lp(-1, 0, 1.0f));
        this.grid = new GridView(this.a);
        this.grid.setNumColumns(4);
        this.grid.setHorizontalSpacing(Ui.dp(3.0f));
        this.grid.setVerticalSpacing(Ui.dp(3.0f));
        this.grid.setStretchMode(2);
        this.grid.setSelector(new ColorDrawable(0));
        this.grid.setAdapter((ListAdapter) this.ad);
        this.grid.setClipToPadding(false);
        this.grid.setPadding(0, 0, 0, Ui.dp(8.0f));
        frameLayout2.addView(this.grid, new FrameLayout.LayoutParams(-1, -1));
        this.emptyBox = new FrameLayout(this.a);
        frameLayout2.addView(this.emptyBox, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setBackgroundColor(-183891444);
        linearLayoutRow2.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(14.0f), Ui.dp(12.0f));
        this.pvB = Ui.text(this.a, "预览", 16.0f, -1);
        this.pvB.setPadding(Ui.dp(14.0f), Ui.dp(6.0f), Ui.dp(14.0f), Ui.dp(6.0f));
        G.on(this.pvB, 2, 16.0f, 0.0f);
        Ui.bounce(this.pvB);
        this.pvB.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GalScr.this.sel.isEmpty()) {
                    return;
                }
                GalScr.this.preview(new ArrayList(GalScr.this.sel), 0);
            }
        });
        linearLayoutRow2.addView(this.pvB);
        if (!this.noOrig) {
            LinearLayout linearLayoutRow3 = Ui.row(this.a);
            linearLayoutRow3.setPadding(Ui.dp(12.0f), Ui.dp(6.0f), Ui.dp(14.0f), Ui.dp(6.0f));
            G.on(linearLayoutRow3, 2, 16.0f, 0.0f);
            Ui.bounce(linearLayoutRow3);
            this.origDot = new View(this.a);
            linearLayoutRow3.addView(this.origDot, Ui.lpm(Ui.dp(18.0f), Ui.dp(18.0f), 0, 0, 6, 0));
            this.origB = Ui.text(this.a, "原图", 16.0f, -1);
            linearLayoutRow3.addView(this.origB);
            linearLayoutRow3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GalScr.this.orig = !GalScr.this.orig;
                    GalScr.this.upd();
                }
            });
            linearLayoutRow2.addView(linearLayoutRow3, Ui.lpm(-2, -2, 12, 0, 0, 0));
        }
        linearLayoutRow2.addView(new View(this.a), Ui.lp(0, 1, 1.0f));
        this.goB = Ui.btn(this.a, this.okText, new View.OnClickListener() { // from class: com.changliao.im.GalScr.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.go();
            }
        });
        this.goB.setMinWidth(Ui.dp(120.0f));
        linearLayoutRow2.addView(this.goB, Ui.lp(-2, Ui.dp(42.0f)));
        linearLayoutCol.addView(linearLayoutRow2, new LinearLayout.LayoutParams(-1, -2));
        load();
        upd();
        return this.root;
    }

    void closePv() {
        if (this.pv == null) {
            return;
        }
        try {
            this.pvVid.stopPlayback();
        } catch (Throwable th) {
        }
        FrameLayout frameLayout = this.pv;
        this.pv = null;
        this.root.removeView(frameLayout);
    }

    @Override // com.changliao.im.Scr
    public boolean dark() {
        return true;
    }

    void filter() {
        this.shown = new ArrayList();
        for (It it : this.all) {
            if (this.album.length() != 0) {
                if (this.album.equals("__vid")) {
                    if (it.vid) {
                    }
                } else if (this.album.equals(it.bk)) {
                }
            }
            this.shown.add(it);
        }
        this.ad.notifyDataSetChanged();
        this.grid.setSelection(0);
        this.emptyBox.removeAllViews();
        if (!this.shown.isEmpty()) {
            this.emptyBox.setVisibility(8);
            return;
        }
        this.emptyBox.setVisibility(0);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setGravity(1);
        TextView textViewText = Ui.text(this.a, perm() ? "相册里没有照片" : "相册里没有照片\n如果有照片却看不到，请允许 App 访问「照片和视频」", 14.0f, -6643542);
        textViewText.setGravity(17);
        textViewText.setLineSpacing(0.0f, 1.3f);
        linearLayoutCol.addView(textViewText);
        if (!perm()) {
            linearLayoutCol.addView(Ui.btn(this.a, "允许访问照片", new View.OnClickListener() { // from class: com.changliao.im.GalScr.7
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GalScr.this.askPerm();
                }
            }), Ui.lpm(-2, Ui.dp(40.0f), 0, 18, 0, 0));
        }
        linearLayoutCol.addView(Ui.btnGray(this.a, "从系统相册选择（可多选）", new View.OnClickListener() { // from class: com.changliao.im.GalScr.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.sys();
            }
        }), Ui.lpm(-2, Ui.dp(40.0f), 0, 12, 0, 0));
        this.emptyBox.addView(linearLayoutCol, Ui.flp(-2, -2, 17));
    }

    @Override // com.changliao.im.Scr
    public boolean full() {
        return true;
    }

    void go() {
        if (this.sel.isEmpty()) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        Iterator<It> it = this.sel.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().uri);
        }
        this.a.back();
        this.cb.got(arrayList, this.orig);
    }

    void load() {
        this.all.clear();
        if (perm()) {
            try {
                Cursor cursorQuery = this.a.getContentResolver().query(MediaStore.Files.getContentUri("external"), new String[]{"_id", "mime_type", "media_type", "bucket_display_name", "duration"}, this.onlyImg ? "media_type=1" : "media_type IN (1,3)", null, "date_added DESC");
                if (cursorQuery != null) {
                    while (cursorQuery.moveToNext() && this.all.size() < 3000) {
                        It it = new It();
                        it.id = cursorQuery.getLong(0);
                        it.mime = cursorQuery.getString(1) == null ? "" : cursorQuery.getString(1);
                        it.vid = cursorQuery.getInt(2) == 3;
                        it.bk = cursorQuery.isNull(3) ? "其他" : cursorQuery.getString(3);
                        it.dur = cursorQuery.isNull(4) ? 0 : (int) Math.round(cursorQuery.getLong(4) / 1000.0d);
                        it.uri = ContentUris.withAppendedId(it.vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, it.id);
                        this.all.add(it);
                    }
                    cursorQuery.close();
                }
            } catch (Throwable th) {
                Crash.note(th);
            }
        }
        filter();
    }

    public GalScr max(int i) {
        this.max = i;
        return this;
    }

    public GalScr noOrig() {
        this.noOrig = true;
        return this;
    }

    public GalScr ok(String str) {
        this.okText = str;
        return this;
    }

    @Override // com.changliao.im.Scr
    public boolean onBack() {
        if (this.pv != null) {
            closePv();
            return true;
        }
        if (this.albPanel == null) {
            return false;
        }
        toggleAlbums();
        return true;
    }

    @Override // com.changliao.im.Scr
    public void onClose() {
        this.a.darkBars(false);
    }

    @Override // com.changliao.im.Scr
    public void onShow() {
        this.a.darkBars(true);
        if (this.all.isEmpty() && perm()) {
            load();
        }
    }

    public GalScr onlyImg() {
        this.onlyImg = true;
        return this;
    }

    boolean perm() {
        if (Build.VERSION.SDK_INT >= 33) {
            return this.a.has("android.permission.READ_MEDIA_IMAGES") || this.a.has("android.permission.READ_MEDIA_VIDEO");
        }
        return this.a.has("android.permission.READ_EXTERNAL_STORAGE");
    }

    void preview(List<It> list, int i) {
        if (list.isEmpty()) {
            return;
        }
        this.pvL = new ArrayList(list);
        this.pvAt = Math.max(0, Math.min(list.size() - 1, i));
        this.pv = new FrameLayout(this.a);
        this.pv.setBackgroundColor(-16777216);
        this.pv.setClickable(true);
        this.pvImg = new ImageView(this.a);
        this.pvImg.setScaleType(ImageView.ScaleType.FIT_CENTER);
        this.pv.addView(this.pvImg, new FrameLayout.LayoutParams(-1, -1));
        this.pvVid = new VideoView(this.a);
        this.pv.addView(this.pvVid, Ui.flp(-1, -1, 17));
        LinearLayout linearLayoutRow = Ui.row(this.a);
        linearLayoutRow.setPadding(Ui.dp(10.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
        linearLayoutRow.setBackgroundColor(-1728053248);
        TextView textViewText = Ui.text(this.a, "‹", 28.0f, -1);
        textViewText.setGravity(17);
        textViewText.setPadding(0, 0, 0, Ui.dp(3.0f));
        G.on(textViewText, 2, 20.0f, 0.0f);
        Ui.bounce(textViewText);
        textViewText.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.closePv();
            }
        });
        linearLayoutRow.addView(textViewText, Ui.lp(Ui.dp(40.0f), Ui.dp(40.0f)));
        this.pvN = Ui.text(this.a, "", 16.0f, -1);
        this.pvN.setGravity(17);
        linearLayoutRow.addView(this.pvN, Ui.lp(0, -2, 1.0f));
        this.pvSel = Ui.bold(Ui.text(this.a, "", 13.0f, -1));
        this.pvSel.setGravity(17);
        this.pvSel.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GalScr.this.toggle(GalScr.this.pvL.get(GalScr.this.pvAt));
            }
        });
        linearLayoutRow.addView(this.pvSel, Ui.lp(Ui.dp(28.0f), Ui.dp(28.0f)));
        this.pv.addView(linearLayoutRow, Ui.flp(-1, -2, 48));
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setBackgroundColor(-1728053248);
        linearLayoutRow2.setPadding(Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(14.0f), Ui.dp(12.0f));
        if (!this.noOrig) {
            LinearLayout linearLayoutRow3 = Ui.row(this.a);
            this.pvOrig = new View(this.a);
            linearLayoutRow3.addView(this.pvOrig, Ui.lpm(Ui.dp(18.0f), Ui.dp(18.0f), 0, 0, 6, 0));
            linearLayoutRow3.addView(Ui.text(this.a, "原图", 16.0f, -1));
            linearLayoutRow3.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GalScr.15
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GalScr.this.orig = !GalScr.this.orig;
                    GalScr.this.upd();
                }
            });
            linearLayoutRow2.addView(linearLayoutRow3);
        }
        linearLayoutRow2.addView(new View(this.a), Ui.lp(0, 1, 1.0f));
        this.pvGo = Ui.btn(this.a, this.okText, new View.OnClickListener() { // from class: com.changliao.im.GalScr.16
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GalScr.this.sel.isEmpty()) {
                    GalScr.this.toggle(GalScr.this.pvL.get(GalScr.this.pvAt));
                }
                GalScr.this.closePv();
                GalScr.this.go();
            }
        });
        this.pvGo.setMinWidth(Ui.dp(120.0f));
        linearLayoutRow2.addView(this.pvGo, Ui.lp(-2, Ui.dp(42.0f)));
        this.pv.addView(linearLayoutRow2, Ui.flp(-1, -2, 80));
        final float[] fArr = {0.0f};
        this.pv.setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.GalScr.17
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 0) {
                    fArr[0] = motionEvent.getX();
                } else if (motionEvent.getAction() == 1) {
                    float x = motionEvent.getX() - fArr[0];
                    if (Math.abs(x) > Ui.dp(50.0f)) {
                        int iMax = Math.max(0, Math.min(GalScr.this.pvL.size() - 1, (x < 0.0f ? 1 : -1) + GalScr.this.pvAt));
                        if (iMax != GalScr.this.pvAt) {
                            GalScr.this.pvAt = iMax;
                            GalScr.this.pvShow();
                        }
                    }
                }
                return true;
            }
        });
        this.pv.setElevation(Ui.dp(30.0f));
        this.root.addView(this.pv, new FrameLayout.LayoutParams(-1, -1));
        this.pv.setAlpha(0.0f);
        this.pv.animate().alpha(1.0f).setDuration(180L).start();
        pvShow();
    }

    void pvShow() {
        final It it = this.pvL.get(this.pvAt);
        try {
            this.pvVid.stopPlayback();
        } catch (Throwable th) {
        }
        if (it.vid) {
            this.pvImg.setVisibility(8);
            this.pvVid.setVisibility(0);
            this.pvVid.setVideoURI(it.uri);
            this.pvVid.start();
        } else {
            this.pvVid.setVisibility(8);
            this.pvImg.setVisibility(0);
            this.pvImg.setImageBitmap(thumbs.get(Long.valueOf(it.id)));
            this.pvImg.setTag(Long.valueOf(it.id));
            final ImageView imageView = this.pvImg;
            pool.execute(new Runnable() { // from class: com.changliao.im.GalScr.18
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        final Bitmap bitmapDecode = Img.decode(Img.read(GalScr.this.a.getContentResolver().openInputStream(it.uri)), 1800);
                        GalScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.GalScr.18.1
                            @Override // java.lang.Runnable
                            public void run() {
                                if (!Long.valueOf(it.id).equals(imageView.getTag()) || bitmapDecode == null) {
                                    return;
                                }
                                imageView.setImageBitmap(bitmapDecode);
                            }
                        });
                    } catch (Throwable th2) {
                    }
                }
            });
        }
        pvUpd();
    }

    void pvUpd() {
        String strValueOf;
        if (this.pv == null) {
            return;
        }
        this.pvN.setText((this.pvAt + 1) + "/" + this.pvL.size());
        int iIndexOf = this.sel.indexOf(this.pvL.get(this.pvAt));
        TextView textView = this.pvSel;
        if (iIndexOf >= 0) {
            strValueOf = this.single ? "✓" : String.valueOf(iIndexOf + 1);
        } else {
            strValueOf = "";
        }
        textView.setText(strValueOf);
        this.pvSel.setBackground(Ui.round(iIndexOf >= 0 ? -14774017 : 1073741824, 14.0f, 2, iIndexOf >= 0 ? -14774017 : -218103809));
        this.pvGo.setText(this.okText + ((this.sel.size() <= 0 || this.single) ? "" : "(" + this.sel.size() + ")"));
        if (this.pvOrig != null) {
            this.pvOrig.setBackground(this.orig ? new LayerDrawable(new Drawable[]{Ui.oval(Ui.BLUE), ring()}) : ring());
        }
    }

    public GalScr single() {
        this.single = true;
        this.max = 1;
        return this;
    }

    void sys() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType(this.onlyImg ? "image/*" : "*/*");
        if (!this.onlyImg) {
            intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*"});
        }
        intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", !this.single);
        intent.addCategory("android.intent.category.OPENABLE");
        this.a.startFor(Intent.createChooser(intent, "选择照片"), new MainActivity.Res() { // from class: com.changliao.im.GalScr.9
            @Override // com.changliao.im.MainActivity.Res
            public void got(int i, Intent intent2) {
                if (i != -1) {
                    return;
                }
                List<Uri> listUris = ChatScr.uris(intent2);
                if (listUris.isEmpty()) {
                    return;
                }
                while (listUris.size() > GalScr.this.max) {
                    listUris.remove(listUris.size() - 1);
                }
                if (GalScr.this.alive) {
                    GalScr.this.a.back();
                }
                GalScr.this.cb.got(listUris, false);
            }
        });
    }

    void thumb(final It it, final ImageView imageView) {
        pool.execute(new Runnable() { // from class: com.changliao.im.GalScr.10
            @Override // java.lang.Runnable
            public void run() {
                Bitmap tmpThumb = null;
                if (GalScr.this.alive && Long.valueOf(it.id).equals(imageView.getTag())) {
                    try {
                        if (Build.VERSION.SDK_INT >= 29) {
                            tmpThumb = GalScr.this.a.getContentResolver().loadThumbnail(it.uri, new Size(256, 256), null);
                        } else {
                            tmpThumb = it.vid ? MediaStore.Video.Thumbnails.getThumbnail(GalScr.this.a.getContentResolver(), it.id, 1, null) : MediaStore.Images.Thumbnails.getThumbnail(GalScr.this.a.getContentResolver(), it.id, 1, null);
                        }
                    } catch (Throwable th) {
                    }
                    final Bitmap thumbnail = tmpThumb;
                    if (thumbnail != null) {
                        GalScr.thumbs.put(Long.valueOf(it.id), thumbnail);
                        GalScr.this.a.runOnUiThread(new Runnable() { // from class: com.changliao.im.GalScr.10.1
                            @Override // java.lang.Runnable
                            public void run() {
                                if (Long.valueOf(it.id).equals(imageView.getTag())) {
                                    imageView.setImageBitmap(thumbnail);
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    public GalScr title(String str) {
        this.title = str;
        return this;
    }

    void toggle(It it) {
        if (it == null) {
            return;
        }
        int iIndexOf = this.sel.indexOf(it);
        if (iIndexOf >= 0) {
            this.sel.remove(iIndexOf);
        } else {
            if (this.sel.size() >= this.max) {
                if (!this.single) {
                    toast("最多只能选 " + this.max + " 个");
                    return;
                }
                this.sel.clear();
            }
            this.sel.add(it);
        }
        upd();
        this.ad.notifyDataSetChanged();
        this.grid.invalidateViews();
    }

    void toggleAlbums() {
        if (this.albPanel != null) {
            this.root.removeView(this.albPanel);
            this.albPanel = null;
            this.albI.animate().rotation(0.0f).setDuration(250L).start();
            return;
        }
        this.albI.animate().rotation(180.0f).setDuration(250L).start();
        ScrollView scrollView = new ScrollView(this.a);
        scrollView.setBackgroundColor(-150205426);
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setPadding(0, Ui.dp(6.0f), 0, Ui.dp(20.0f));
        scrollView.addView(linearLayoutCol);
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        ArrayList arrayList = new ArrayList();
        for (It it : this.all) {
            if (it.vid) {
                arrayList.add(it);
            }
            List arrayList2 = (List) linkedHashMap.get(it.bk);
            if (arrayList2 == null) {
                arrayList2 = new ArrayList();
                linkedHashMap.put(it.bk, arrayList2);
            }
            arrayList2.add(it);
        }
        ArrayList<Map.Entry> arrayList3 = new ArrayList(linkedHashMap.entrySet());
        Collections.sort(arrayList3, new Comparator<Map.Entry>() { // from class: com.changliao.im.GalScr.11
            @Override // java.util.Comparator
            public int compare(Map.Entry entry, Map.Entry entry2) {
                return ((List) entry2.getValue()).size() - ((List) entry.getValue()).size();
            }
        });
        linearLayoutCol.addView(albRow("", "最近照片", this.all));
        if (!arrayList.isEmpty() && !this.onlyImg) {
            linearLayoutCol.addView(albRow("__vid", "所有视频", arrayList));
        }
        for (Map.Entry entry : arrayList3) {
            linearLayoutCol.addView(albRow((String) entry.getKey(), (String) entry.getKey(), (List) entry.getValue()));
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.topMargin = Ui.dp(56.0f);
        this.root.addView(scrollView, layoutParams);
        this.albPanel = scrollView;
        scrollView.setAlpha(0.0f);
        scrollView.setTranslationY(-Ui.dp(20.0f));
        scrollView.animate().alpha(1.0f).translationY(0.0f).setDuration(250L).start();
    }

    void upd() {
        for (int i = 0; i < this.grid.getChildCount(); i++) {
            View childAt = this.grid.getChildAt(i);
            if (childAt instanceof Cell) {
                ((Cell) childAt).mark();
            }
        }
        this.goB.setText(this.okText + ((this.sel.size() <= 0 || this.single) ? "" : "(" + this.sel.size() + ")"));
        this.goB.setAlpha(this.sel.isEmpty() ? 0.45f : 1.0f);
        this.pvB.setTextColor(this.sel.isEmpty() ? -9736328 : -1);
        if (this.origDot != null) {
            this.origDot.setBackground(this.orig ? new LayerDrawable(new Drawable[]{Ui.oval(Ui.BLUE), ring()}) : ring());
        }
        if (this.pv != null) {
            pvUpd();
        }
    }
}
