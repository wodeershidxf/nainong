package com.changliao.im;

import android.content.Context;
import android.os.PowerManager;

/* JADX INFO: loaded from: classes.dex */
public class PowerWake {
    static void on(Context context) {
        try {
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            if (powerManager == null || powerManager.isInteractive()) {
                return;
            }
            powerManager.newWakeLock(805306378, "nk:call").acquire(8000L);
        } catch (Throwable th) {
        }
    }
}
