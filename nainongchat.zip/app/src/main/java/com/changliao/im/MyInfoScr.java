package com.changliao.im;

import android.graphics.Bitmap;
import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;
import java.io.ByteArrayOutputStream;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class MyInfoScr extends Scr {
    LinearLayout body;

    /* JADX INFO: renamed from: com.changliao.im.MyInfoScr$6, reason: invalid class name */
    static class AnonymousClass6 implements GalScr.Got {
        final /* synthetic */ MainActivity val$a;
        final /* synthetic */ String val$gid;

        AnonymousClass6(MainActivity mainActivity, String str) {
            this.val$a = mainActivity;
            this.val$gid = str;
        }

        @Override // com.changliao.im.GalScr.Got
        public void got(List<Uri> list, boolean z) {
            if (list.isEmpty()) {
                return;
            }
            final Uri uri = list.get(0);
            this.val$a.toast("正在上传头像…", false);
            new Thread(new Runnable() { // from class: com.changliao.im.MyInfoScr.6.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Bitmap bitmapDecode = Img.decode(Img.read(AnonymousClass6.this.val$a.getContentResolver().openInputStream(uri)), 640);
                        if (bitmapDecode == null) {
                            throw new Exception();
                        }
                        int iMin = Math.min(bitmapDecode.getWidth(), bitmapDecode.getHeight());
                        Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(Bitmap.createBitmap(bitmapDecode, (bitmapDecode.getWidth() - iMin) / 2, (bitmapDecode.getHeight() - iMin) / 2, iMin, iMin), 320, 320, true);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmapCreateScaledBitmap.compress(Bitmap.CompressFormat.JPEG, 88, byteArrayOutputStream);
                        final String strUpload = Up.upload(byteArrayOutputStream.toByteArray(), "avatar.jpg", "image/jpeg", null);
                        AnonymousClass6.this.val$a.runOnUiThread(new Runnable() { // from class: com.changliao.im.MyInfoScr.6.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Core.I.send(AnonymousClass6.this.val$gid != null ? J.of("t", "c_avatar", "fid", strUpload, "gid", AnonymousClass6.this.val$gid) : J.of("t", "c_avatar", "fid", strUpload));
                            }
                        });
                    } catch (Throwable th) {
                        AnonymousClass6.this.val$a.runOnUiThread(new Runnable() { // from class: com.changliao.im.MyInfoScr.6.1.2
                            @Override // java.lang.Runnable
                            public void run() {
                                AnonymousClass6.this.val$a.toast("这张图片用不了，换一张试试", true);
                            }
                        });
                    }
                }
            }).start();
        }
    }

    public static void pickAvatar(MainActivity mainActivity, String str) {
        mainActivity.push(new GalScr(new AnonymousClass6(mainActivity, str)).title("选择头像").single().onlyImg().noOrig().ok("确定"));
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("编辑资料", true);
        this.body = scrollPage(linearLayoutPage);
        render();
        return linearLayoutPage;
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("me")) {
            render();
        }
    }

    void render() {
        this.body.removeAllViews();
        final J j = this.C.info;
        if (j == null) {
            return;
        }
        LinearLayout linearLayoutCsec = csec(this.body);
        LinearLayout linearLayoutOpt = opt(linearLayoutCsec, "头像", "", true, new View.OnClickListener() { // from class: com.changliao.im.MyInfoScr.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MyInfoScr.pickAvatar(MyInfoScr.this.a, null);
            }
        });
        Img.Av av = new Img.Av(this.a);
        av.set(j.s("nick"), j.sn("av"), false);
        linearLayoutOpt.addView(av, linearLayoutOpt.getChildCount() - 1, Ui.lpm(Ui.dp(40.0f), Ui.dp(40.0f), 8, 0, 0, 0));
        opt(linearLayoutCsec, "昵称", j.s("nick"), true, new View.OnClickListener() { // from class: com.changliao.im.MyInfoScr.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MyInfoScr.this.a.ask("修改昵称", "昵称", j.s("nick"), false, 16, new MainActivity.Str() { // from class: com.changliao.im.MyInfoScr.2.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str) {
                        if (str.length() > 0) {
                            MyInfoScr.this.C.send(J.of("t", "set_nick", "nick", str));
                        }
                    }
                });
            }
        });
        opt(linearLayoutCsec, "个性签名", j.s("bio").length() > 0 ? j.s("bio") : "未填写", true, new View.OnClickListener() { // from class: com.changliao.im.MyInfoScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MyInfoScr.this.a.ask("个性签名", "介绍一下自己吧", j.s("bio"), true, 80, new MainActivity.Str() { // from class: com.changliao.im.MyInfoScr.3.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str) {
                        j.put("bio", str);
                        MyInfoScr.this.C.send(J.of("t", "c_bio", "bio", str));
                        MyInfoScr.this.render();
                    }
                });
            }
        });
        opt(linearLayoutCsec, "NK号", j.s("nk") + "（点击复制）", false, new View.OnClickListener() { // from class: com.changliao.im.MyInfoScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MyInfoScr.this.copy(j.s("nk"));
            }
        });
        opt(linearLayoutCsec, "邮箱", j.s("email"), false, null);
        opt(csec(this.body), "登录密码", j.b("has_pw") ? "已设置，点击修改" : "未设置", true, new View.OnClickListener() { // from class: com.changliao.im.MyInfoScr.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MyInfoScr.this.a.ask("设置登录密码", "新密码（至少 6 位）", "", false, 64, new MainActivity.Str() { // from class: com.changliao.im.MyInfoScr.5.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str) {
                        if (str.length() == 0) {
                            return;
                        }
                        if (str.length() < 6) {
                            MyInfoScr.this.err("密码至少 6 位");
                        } else {
                            MyInfoScr.this.C.send(J.of("t", "set_pw", "pw", str));
                        }
                    }
                });
            }
        });
    }
}
