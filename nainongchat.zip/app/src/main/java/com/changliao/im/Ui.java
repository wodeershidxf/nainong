package com.changliao.im;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Calendar;

/* JADX INFO: loaded from: classes.dex */
public final class Ui {
    public static final int BG = -855051;
    public static final int BLUE = -14774017;
    public static final int BLUE2 = -16090394;
    public static final int GOLD = -24806;
    public static final int GREEN = -15090069;
    public static final int LINE = -1644309;
    public static final int M = -1;
    public static final int PANEL = -1;
    public static final int PANEL2 = -657672;
    public static final int RED = -702390;
    public static final int SUB = -7695972;
    public static final int TEXT = -14868183;
    public static final int W = -2;
    static final String WK = "日一二三四五六";
    public static float D = 3.0f;
    static final int[] COLORS = {-12611750, -12619858, -6071766, -7712856, -5226406, -13660273, -6653408, -10851702};
    static final int[] LVC = {-5984838, -13319044, -12874753, -7643914, -30147, -45715};

    public static int alpha(int i, float f) {
        return Color.argb(Math.round(255.0f * f), Color.red(i), Color.green(i), Color.blue(i));
    }

    public static ValueAnimator anim(long j, ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.setDuration(j);
        valueAnimatorOfFloat.addUpdateListener(animatorUpdateListener);
        valueAnimatorOfFloat.start();
        return valueAnimatorOfFloat;
    }

    public static TextView badge(Context context, String str) {
        TextView textViewBold = bold(text(context, str, 11.0f, -1));
        textViewBold.setGravity(17);
        textViewBold.setMinWidth(dp(19.0f));
        textViewBold.setPadding(dp(6.0f), 0, dp(6.0f), 0);
        textViewBold.setTextSize(2, 12.0f);
        textViewBold.setTypeface(Typeface.DEFAULT);
        textViewBold.setBackground(round(RED, 10.0f));
        textViewBold.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(19.0f)));
        return textViewBold;
    }

    public static TextView bold(TextView textView) {
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        return textView;
    }

    public static void bounce(View view) {
        view.setOnTouchListener(new View.OnTouchListener() { // from class: com.changliao.im.Ui.1
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View view2, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 0) {
                    view2.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90L).setInterpolator(null).start();
                    return false;
                }
                if (motionEvent.getAction() != 1 && motionEvent.getAction() != 3) {
                    return false;
                }
                view2.animate().scaleX(1.0f).scaleY(1.0f).setDuration(260L).setInterpolator(new OvershootInterpolator(2.2f)).start();
                return false;
            }
        });
    }

    public static TextView btn(Context context, String str, View.OnClickListener onClickListener) {
        TextView textViewBold = bold(text(context, str, 16.0f, -1));
        textViewBold.setGravity(17);
        textViewBold.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        textViewBold.setShadowLayer(dp(1.0f), 0.0f, dp(1.0f), 1073752184);
        G.on(textViewBold, 1, 14.0f, 5.0f);
        textViewBold.setOnClickListener(onClickListener);
        bounce(textViewBold);
        return textViewBold;
    }

    public static TextView btnGray(Context context, String str, View.OnClickListener onClickListener) {
        TextView textViewText = text(context, str, 16.0f, TEXT);
        textViewText.setGravity(17);
        textViewText.setPadding(dp(14.0f), dp(12.0f), dp(14.0f), dp(12.0f));
        G.on(textViewText, 0, 14.0f, 3.0f);
        textViewText.setOnClickListener(onClickListener);
        bounce(textViewText);
        return textViewText;
    }

    public static TextView chip(Context context, String str, boolean z, View.OnClickListener onClickListener) {
        TextView textViewText = text(context, str, 14.0f, z ? -1 : TEXT);
        textViewText.setGravity(17);
        textViewText.setPadding(dp(14.0f), dp(6.0f), dp(14.0f), dp(6.0f));
        G.on(textViewText, z ? 1 : 0, 16.0f, 2.0f);
        textViewText.setOnClickListener(onClickListener);
        bounce(textViewText);
        return textViewText;
    }

    public static LinearLayout col(Context context) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        return linearLayout;
    }

    static int dayDiff(Calendar calendar) {
        Calendar calendar2 = (Calendar) calendar.clone();
        calendar2.set(11, 12);
        calendar2.set(12, 0);
        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(11, 12);
        calendar3.set(12, 0);
        return (int) Math.round((calendar3.getTimeInMillis() - calendar2.getTimeInMillis()) / 8.64E7d);
    }

    public static int dp(float f) {
        return Math.round(D * f);
    }

    public static void fadeIn(View view) {
        view.setAlpha(0.0f);
        view.setTranslationY(dp(8.0f));
        view.animate().alpha(1.0f).translationY(0.0f).setDuration(220L).start();
    }

    public static String fileIcon(String str) {
        String lowerCase = str == null ? "" : str.substring(str.lastIndexOf(46) + 1).toLowerCase();
        if (lowerCase.matches("png|jpe?g|gif|webp|bmp|heic")) {
            return "🖼️";
        }
        if (lowerCase.matches("mp3|wav|ogg|m4a|flac|aac")) {
            return "🎵";
        }
        if (lowerCase.matches("mp4|mov|avi|mkv|webm|3gp")) {
            return "🎬";
        }
        if (lowerCase.matches("zip|rar|7z|tar|gz")) {
            return "🗜️";
        }
        if (lowerCase.equals("apk")) {
            return "📦";
        }
        if (lowerCase.equals("pdf")) {
            return "📕";
        }
        if (lowerCase.matches("docx?|txt|md")) {
            return "📄";
        }
        if (lowerCase.matches("xlsx?|csv")) {
            return "📊";
        }
        return lowerCase.matches("pptx?") ? "📽️" : "📎";
    }

    public static FrameLayout.LayoutParams flp(int i, int i2, int i3) {
        return new FrameLayout.LayoutParams(i, i2, i3);
    }

    public static String fullWhen(long j) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(1000 * j);
        int iDayDiff = dayDiff(calendar);
        String strQqTime = qqTime(calendar);
        if (iDayDiff <= 0) {
            return strQqTime;
        }
        if (iDayDiff == 1) {
            return "昨天 " + strQqTime;
        }
        if (iDayDiff < 7) {
            return "星期" + WK.charAt(calendar.get(7) - 1) + " " + strQqTime;
        }
        return (calendar.get(1) == Calendar.getInstance().get(1) ? "" : calendar.get(1) + "年") + (calendar.get(2) + 1) + "月" + calendar.get(5) + "日 " + strQqTime;
    }

    public static Drawable glass(float f) {
        return new RippleDrawable(ColorStateList.valueOf(337016816), new G(0, f), null);
    }

    public static Drawable glassDark(float f) {
        return new RippleDrawable(ColorStateList.valueOf(872415231), new G(2, f), null);
    }

    public static GradientDrawable grad(float f, int... iArr) {
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, iArr);
        gradientDrawable.setCornerRadius(dp(f));
        return gradientDrawable;
    }

    public static int hue(String str) {
        long jCharAt = 0;
        if (str == null) {
            str = "?";
        }
        for (int i = 0; i < str.length(); i++) {
            jCharAt = ((jCharAt * 31) + ((long) str.charAt(i))) & 4294967295L;
        }
        return COLORS[(int) (jCharAt % ((long) COLORS.length))];
    }

    public static ImageView iconBtn(Context context, String str, int i, float f, View.OnClickListener onClickListener) {
        ImageView imageView = new ImageView(context);
        imageView.setImageDrawable(new Ico(str, i));
        int iDp = dp(0.22f * f);
        imageView.setPadding(iDp, iDp, iDp, iDp);
        boolean z = (((i >> 16) & 255) + ((i >> 8) & 255)) + (i & 255) > 600;
        G.on(imageView, z ? 2 : 0, f / 2.0f, z ? 0.0f : 2.0f);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(dp(f), dp(f)));
        imageView.setOnClickListener(onClickListener);
        bounce(imageView);
        return imageView;
    }

    public static EditText input(Context context, String str, boolean z) {
        EditText editText = new EditText(context);
        editText.setHint(str);
        editText.setTextSize(2, 16.0f);
        editText.setTextColor(TEXT);
        editText.setHintTextColor(-6643285);
        editText.setSingleLine(true);
        editText.setBackground(new G(3, 14.0f));
        editText.setPadding(dp(13.0f), dp(11.0f), dp(13.0f), dp(11.0f));
        if (z) {
            editText.setInputType(129);
        }
        return editText;
    }

    public static View line(Context context) {
        View view = new View(context);
        view.setBackgroundColor(LINE);
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.5f))));
        return view;
    }

    public static LinearLayout.LayoutParams lp(int i, int i2) {
        return new LinearLayout.LayoutParams(i, i2);
    }

    public static LinearLayout.LayoutParams lp(int i, int i2, float f) {
        return new LinearLayout.LayoutParams(i, i2, f);
    }

    public static LinearLayout.LayoutParams lpm(int i, int i2, int i3, int i4, int i5, int i6) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, i2);
        layoutParams.setMargins(dp(i3), dp(i4), dp(i5), dp(i6));
        return layoutParams;
    }

    public static TextView lvTag(Context context, long j, String str) {
        int iMin = ((int) Math.min(6L, Math.max(1L, j))) - 1;
        TextView textViewBold = bold(text(context, "LV" + j + ((str == null || str.length() == 0) ? "" : " " + str), 10.0f, -1));
        textViewBold.setGravity(17);
        textViewBold.setIncludeFontPadding(false);
        textViewBold.setPadding(dp(6.0f), 0, dp(6.0f), 0);
        textViewBold.setBackground(iMin == 5 ? grad(8.0f, -45715, -19641) : round(LVC[iMin], 8.0f));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, dp(16.0f));
        layoutParams.leftMargin = dp(5.0f);
        textViewBold.setLayoutParams(layoutParams);
        return textViewBold;
    }

    public static TextView one(TextView textView) {
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        return textView;
    }

    public static GradientDrawable oval(int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    static String pad(int i) {
        return i < 10 ? "0" + i : String.valueOf(i);
    }

    public static Drawable press(int i, float f) {
        return ripple(round(i, f), f);
    }

    static String qqTime(Calendar calendar) {
        String str;
        int i;
        int i2 = calendar.get(11);
        if (i2 < 6) {
            str = "凌晨";
        } else if (i2 < 12) {
            str = "上午";
        } else {
            str = i2 < 18 ? "下午" : "晚上";
        }
        StringBuilder sbAppend = new StringBuilder().append(str);
        if (i2 < 6) {
            i = i2;
        } else {
            i = i2 % 12 == 0 ? 12 : i2 % 12;
        }
        return sbAppend.append(i).append(":").append(pad(calendar.get(12))).toString();
    }

    public static Drawable ripple(Drawable drawable, float f) {
        return new RippleDrawable(ColorStateList.valueOf(570425344), drawable, round(-1, f));
    }

    public static TextView roleTag(Context context, String str) {
        if ("owner".equals(str)) {
            return tag(context, "群主", GOLD);
        }
        if ("admin".equals(str)) {
            return tag(context, "管理员", -13912461);
        }
        return null;
    }

    public static GradientDrawable round(int i, float f) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(f));
        return gradientDrawable;
    }

    public static GradientDrawable round(int i, float f, int i2, int i3) {
        GradientDrawable gradientDrawableRound = round(i, f);
        gradientDrawableRound.setStroke(dp((float) i2) == 0 ? 1 : dp(i2), i3);
        return gradientDrawableRound;
    }

    public static LinearLayout row(Context context) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        return linearLayout;
    }

    public static String size(long j) {
        if (j < 1024) {
            return j + " B";
        }
        return j < 1048576 ? String.format("%.1f KB", Double.valueOf(j / 1024.0d)) : String.format("%.1f MB", Double.valueOf(j / 1048576.0d));
    }

    public static View space(Context context, int i) {
        View view = new View(context);
        view.setLayoutParams(new LinearLayout.LayoutParams(1, dp(i)));
        return view;
    }

    public static TextView tag(Context context, String str, int i) {
        TextView textViewBold = bold(text(context, str, 10.0f, -1));
        textViewBold.setGravity(17);
        textViewBold.setIncludeFontPadding(false);
        textViewBold.setPadding(dp(5.0f), 0, dp(5.0f), 0);
        textViewBold.setBackground(round(i, 4.0f));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, dp(16.0f));
        layoutParams.leftMargin = dp(5.0f);
        textViewBold.setLayoutParams(layoutParams);
        return textViewBold;
    }

    public static TextView text(Context context, String str, float f, int i) {
        TextView textView = new TextView(context);
        textView.setText(str);
        textView.setTextSize(2, f);
        textView.setTextColor(i);
        textView.setIncludeFontPadding(true);
        return textView;
    }

    public static TextView vipTag(Context context) {
        TextView textViewText = text(context, "VIP", 10.5f, -9747712);
        textViewText.setTypeface(Typeface.create(Typeface.DEFAULT, 3));
        textViewText.setLetterSpacing(0.05f);
        textViewText.setGravity(17);
        textViewText.setIncludeFontPadding(false);
        textViewText.setPadding(dp(6.0f), 0, dp(6.0f), 0);
        textViewText.setBackground(new G(5, 8.0f));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, dp(16.0f));
        layoutParams.leftMargin = dp(5.0f);
        textViewText.setLayoutParams(layoutParams);
        return textViewText;
    }

    public static String when(long j) {
        if (j <= 0) {
            return "";
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(1000 * j);
        int iDayDiff = dayDiff(calendar);
        if (iDayDiff <= 0) {
            return qqTime(calendar);
        }
        if (iDayDiff == 1) {
            return "昨天";
        }
        if (iDayDiff < 7) {
            return "星期" + WK.charAt(calendar.get(7) - 1);
        }
        return calendar.get(1) == Calendar.getInstance().get(1) ? (calendar.get(2) + 1) + "月" + calendar.get(5) + "日" : calendar.get(1) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(5);
    }
}
