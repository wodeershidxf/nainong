package com.changliao.im;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.ToneGenerator;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
final class Call implements Rtc.Ui {
    static final Core C = Core.I;
    static final int CALLING = 0;
    static final int CONNECTING = 2;
    static final int ENDED = 4;
    static final int RINGING = 1;
    static final int TALKING = 3;
    static Context ctx;
    static Call cur;
    String av;
    boolean camOn;
    String cid;
    String from;
    String gid;
    final boolean group;
    final boolean incoming;
    boolean muted;
    String name;
    String nk;
    Runnable onChange;
    boolean ringing;
    Ringtone rt;
    Rtc rtc;
    boolean sharing;
    boolean speaker;
    int state;
    long t0;
    ToneGenerator tg;
    final boolean video;
    boolean wantAccept;
    long began = System.currentTimeMillis();
    String note = "";
    int mySid = -1;
    int remoteSid = -1;
    final LinkedHashMap<Integer, J> peers = new LinkedHashMap<>();
    boolean front = true;

    Call(boolean z, boolean z2, boolean z3) {
        this.group = z;
        this.video = z2;
        this.incoming = z3;
        this.camOn = z2;
        this.speaker = z2;
    }

    static void bgOpen() {
        try {
            PowerWake.on(ctx);
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)) {
                Intent intent = new Intent(ctx, (Class<?>) MainActivity.class);
                intent.addFlags(805437440);
                intent.putExtra("openCall", true);
                ctx.startActivity(intent);
            }
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    static boolean busy() {
        return (cur == null || cur.state == 4) ? false : true;
    }

    static void dial(MainActivity mainActivity, String str, String str2, String str3, boolean z) {
        if (busy()) {
            if (cur.state != 4) {
                cur.show();
            }
            mainActivity.toast("正在通话中", false);
            return;
        }
        if (!C.connected) {
            mainActivity.toast("还没连上服务器，请稍等", true);
            return;
        }
        if (!perms(mainActivity, z)) {
            mainActivity.toast("请允许使用麦克风" + (z ? "和摄像头" : "") + "后再拨打", false);
            return;
        }
        Call call = new Call(false, z, false);
        call.cid = Long.toString(System.currentTimeMillis(), 36) + Integer.toString((int) (Math.random() * 1000000.0d), 36);
        call.nk = str;
        call.name = str2;
        call.av = str3;
        call.state = 0;
        cur = call;
        C.send(J.of("t", "c_call", "kind", "invite", "callid", call.cid, "nick", str, "video", Boolean.valueOf(z), "native", true));
        call.timeout(45000L);
        call.show();
    }

    static void init(Context context) {
        ctx = context.getApplicationContext();
        C.add(new Core.L() { // from class: com.changliao.im.Call.1
            @Override // com.changliao.im.Core.L
            public void on(String str, J j) {
                if (str.equals("c_call")) {
                    Call.onCall(j);
                } else if (str.equals("c_gcall")) {
                    Call.onG(j);
                }
            }
        });
    }

    static void joinGroup(MainActivity mainActivity, String str, String str2, String str3, boolean z) {
        if (busy()) {
            if (!cur.group || !str.equals(cur.gid)) {
                cur.show();
                mainActivity.toast("正在通话中", false);
                return;
            } else {
                if (cur.state == 1) {
                    cur.accept();
                }
                cur.show();
                return;
            }
        }
        if (!C.connected) {
            mainActivity.toast("还没连上服务器，请稍等", true);
            return;
        }
        if (!perms(mainActivity, z)) {
            mainActivity.toast("请允许使用麦克风" + (z ? "和摄像头" : "") + "后再试", false);
            return;
        }
        Call call = new Call(true, z, false);
        call.gid = str;
        call.name = str2;
        call.av = str3;
        call.state = 2;
        cur = call;
        call.joinNow();
        call.show();
    }

    static void onCall(J j) {
        J jO;
        String strS = j.s("kind");
        if (!strS.equals("invite")) {
            Call call = cur;
            if (call == null || call.group || !j.s("callid").equals(call.cid)) {
                return;
            }
            if (strS.equals("accept") && call.state == 0) {
                call.talk();
                return;
            }
            if (strS.equals("notified") && call.state == 0) {
                call.note = "对方不在线，已发送来电提醒，等待接听…";
                call.timeout(60000L);
                call.changed();
                return;
            } else {
                if (strS.equals("taken")) {
                    call.end("已在其他设备上接听");
                    return;
                }
                if (strS.equals("end")) {
                    String strS2 = j.s("why");
                    call.end((strS2.equals("hangup") || strS2.equals("cancel")) ? null : j.s("text"));
                    return;
                } else {
                    if (!strS.equals("state") || (jO = j.o("data")) == null || !jO.b("kf") || call.rtc == null) {
                        return;
                    }
                    call.rtc.key();
                    return;
                }
            }
        }
        String strS3 = j.s("callid");
        if (cur == null || !strS3.equals(cur.cid)) {
            if (busy()) {
                C.sendQ(J.of("t", "c_call", "kind", "busy", "callid", strS3));
                return;
            }
            if (!j.b("native")) {
                C.sendQ(J.of("t", "c_call", "kind", "busy", "callid", strS3));
                Core core = C;
                Object[] objArr = new Object[4];
                objArr[0] = "msg";
                objArr[1] = (j.s("from").length() > 0 ? j.s("from") : "好友") + " 用的是旧版本，接不通。请让对方更新到最新版 App";
                objArr[2] = "err";
                objArr[3] = true;
                core.emit("toast", J.of(objArr));
                return;
            }
            Call call2 = new Call(false, j.b("video"), true);
            call2.cid = strS3;
            call2.nk = j.s("nk");
            call2.name = j.s("from");
            call2.av = j.sn("av");
            call2.state = 1;
            cur = call2;
            call2.timeout(60000L);
            if (C.foreground) {
                call2.show();
                return;
            }
            Notif.call(ctx, call2.name.length() > 0 ? call2.name : "好友", call2.video);
            call2.ring();
            bgOpen();
        }
    }

    static void onG(J j) {
        J jO;
        String strS = j.s("kind");
        Call call = cur;
        if (strS.equals("ring")) {
            if (busy()) {
                return;
            }
            Call call2 = new Call(true, j.b("video"), true);
            call2.gid = j.s("gid");
            call2.name = j.s("name");
            call2.av = j.sn("av");
            call2.from = j.s("from");
            call2.state = 1;
            cur = call2;
            call2.timeout(45000L);
            if (C.foreground) {
                call2.show();
                return;
            } else {
                Notif.call(ctx, call2.name + "（" + call2.from + "）", call2.video);
                return;
            }
        }
        if (call != null && call.group && j.s("gid").equals(call.gid)) {
            if (strS.equals("joined")) {
                call.mySid = j.i("sid");
                for (J j2 : j.objs("peers")) {
                    call.peers.put(Integer.valueOf(j2.i("sid")), j2);
                }
                call.talk();
                return;
            }
            if (strS.equals("peer_join")) {
                call.peers.put(Integer.valueOf(j.i("sid")), j);
                call.changed();
                return;
            }
            if (strS.equals("peer_leave")) {
                int i = j.i("sid");
                call.peers.remove(Integer.valueOf(i));
                if (call.rtc != null) {
                    call.rtc.forget(i);
                }
                call.changed();
                return;
            }
            if (strS.equals("muted_by")) {
                call.setMute(true);
                C.emit("toast", J.of("msg", j.s("by") + " 把你静音了"));
            } else {
                if (!strS.equals("signal") || (jO = j.o("data")) == null || !jO.b("kf") || call.rtc == null) {
                    return;
                }
                call.rtc.key();
            }
        }
    }

    static void permDone(MainActivity mainActivity) {
        Call call = cur;
        if (call != null && call.wantAccept && call.state == 1) {
            call.wantAccept = false;
            if (mainActivity.has("android.permission.RECORD_AUDIO")) {
                call.accept();
            }
        }
    }

    static boolean perms(MainActivity mainActivity, boolean z) {
        ArrayList arrayList = new ArrayList();
        if (!mainActivity.has("android.permission.RECORD_AUDIO")) {
            arrayList.add("android.permission.RECORD_AUDIO");
        }
        if (z && !mainActivity.has("android.permission.CAMERA")) {
            arrayList.add("android.permission.CAMERA");
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        mainActivity.requestPermissions((String[]) arrayList.toArray(new String[0]), 9);
        return false;
    }

    void accept() {
        if (this.state != 1) {
            return;
        }
        MainActivity mainActivity = MainActivity.cur;
        if (mainActivity != null && !perms(mainActivity, this.video)) {
            this.wantAccept = true;
            mainActivity.toast("请允许使用麦克风" + (this.video ? "和摄像头" : "") + "后接听", false);
            return;
        }
        unring();
        if (this.group) {
            joinNow();
        } else {
            C.send(J.of("t", "c_call", "kind", "accept", "callid", this.cid));
            talk();
        }
    }

    void changed() {
        Runnable runnable = this.onChange;
        if (runnable != null) {
            runnable.run();
        }
        MainActivity mainActivity = MainActivity.cur;
        if (mainActivity != null) {
            mainActivity.callPill();
        }
    }

    void end(String str) {
        try {
            if (App.kv.getBoolean("keep", true)) {
                App.startBg(ctx, 0);
            } else {
                ctx.stopService(new Intent(ctx, (Class<?>) Keeper.class));
            }
        } catch (Throwable th) {
        }
        if (this.state == 4) {
            return;
        }
        this.state = 4;
        unring();
        this.sharing = false;
        if (this.rtc != null) {
            this.rtc.stop();
            this.rtc = null;
        }
        if (cur == this) {
            cur = null;
        }
        Notif.cancel(ctx, 7);
        if (str != null && str.length() > 0) {
            C.emit("toast", J.of("msg", str));
        }
        changed();
    }

    void flip() {
        this.front = !this.front;
        if (this.rtc != null) {
            this.rtc.flip();
        }
    }

    void hangup() {
        String str;
        if (this.state == 4) {
            return;
        }
        if (this.group) {
            if (this.state != 1) {
                C.sendQ(J.of("t", "c_gcall", "kind", "leave", "gid", this.gid));
            }
            end(null);
        } else {
            if (this.state == 0) {
                str = "cancel";
            } else {
                str = this.state == 1 ? "reject" : "hangup";
            }
            C.sendQ(J.of("t", "c_call", "kind", str, "callid", this.cid));
            end(null);
        }
    }

    void joinNow() {
        this.state = 2;
        C.send(J.of("t", "c_gcall", "kind", "join", "gid", this.gid, "video", Boolean.valueOf(this.video)));
        Core.timer.later(new Runnable() { // from class: com.changliao.im.Call.2
            @Override // java.lang.Runnable
            public void run() {
                if (Call.cur == Call.this && Call.this.state == 2) {
                    Call.this.end("加入通话失败");
                }
            }
        }, 10000L);
        changed();
    }

    @Override // com.changliao.im.Rtc.Ui
    public void needKey(int i) {
        if (this.group) {
            C.sendQ(J.of("t", "c_gcall", "kind", "signal", "gid", this.gid, "to", Integer.valueOf(i), "data", J.of("kf", 1)));
        } else {
            C.sendQ(J.of("t", "c_call", "kind", "state", "callid", this.cid, "data", J.of("kf", 1)));
        }
    }

    @Override // com.changliao.im.Rtc.Ui
    public void newVideo(int i) {
        if (!this.group) {
            this.remoteSid = i;
        }
        Runnable runnable = this.onChange;
        if (runnable != null) {
            runnable.run();
        }
    }

    void ring() {
        if (this.ringing) {
            return;
        }
        this.ringing = true;
        try {
            if (this.state != 1) {
                this.tg = new ToneGenerator(0, 70);
                this.tg.startTone(23);
                return;
            }
            this.rt = RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(1));
            if (this.rt != null) {
                this.rt.setAudioAttributes(new AudioAttributes.Builder().setUsage(6).build());
                if (Build.VERSION.SDK_INT >= 28) {
                    this.rt.setLooping(true);
                }
                this.rt.play();
            }
            Vibrator vibrator = (Vibrator) ctx.getSystemService("vibrator");
            if (vibrator != null) {
                vibrator.vibrate(new long[]{0, 800, 1200}, 0);
            }
        } catch (Throwable th) {
            Crash.note(th);
        }
    }

    void setCam(boolean z) {
        this.camOn = z;
        if (this.rtc != null) {
            this.rtc.setCam(z);
        }
        changed();
    }

    void setMute(boolean z) {
        this.muted = z;
        if (this.rtc != null) {
            this.rtc.muted = z;
        }
        changed();
    }

    void setSpeaker(boolean z) {
        this.speaker = z;
        if (this.rtc != null) {
            this.rtc.setSpeaker(z);
        }
        changed();
    }

    void share(final MainActivity mainActivity) {
        if (this.rtc == null || this.state != 3) {
            mainActivity.toast("接通后才能共享屏幕", false);
            return;
        }
        if (this.sharing) {
            this.sharing = false;
            this.rtc.stopScreen();
            changed();
            mainActivity.toast("已停止共享屏幕", false);
            return;
        }
        final MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) mainActivity.getSystemService("media_projection");
        try {
            mainActivity.startFor(mediaProjectionManager.createScreenCaptureIntent(), new MainActivity.Res() { // from class: com.changliao.im.Call.3
                @Override // com.changliao.im.MainActivity.Res
                public void got(final int i, final Intent intent) {
                    if (i != -1 || intent == null) {
                        return;
                    }
                    App.startBg(mainActivity, (Call.this.video ? 64 : 0) | 160);
                    final int[] iArr = {0};
                    mainActivity.h.postDelayed(new Runnable() { // from class: com.changliao.im.Call.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (Call.this.rtc == null || Call.this.state != 3) {
                                return;
                            }
                            try {
                                MediaProjection mediaProjection = mediaProjectionManager.getMediaProjection(i, intent);
                                if (mediaProjection == null) {
                                    mainActivity.toast("共享屏幕失败了", true);
                                } else {
                                    DisplayMetrics displayMetrics = new DisplayMetrics();
                                    mainActivity.getWindowManager().getDefaultDisplay().getRealMetrics(displayMetrics);
                                    Call.this.rtc.startScreen(mediaProjection, displayMetrics.widthPixels, displayMetrics.heightPixels, displayMetrics.densityDpi);
                                    Call.this.sharing = Call.this.rtc.sharing;
                                    Call.this.changed();
                                    if (Call.this.sharing) {
                                        mainActivity.toast("正在共享屏幕，对方能看到你的屏幕。可以缩小通话去打开别的 App", false);
                                    }
                                }
                            } catch (SecurityException e) {
                                int[] iArr2 = iArr;
                                int i2 = iArr2[0] + 1;
                                iArr2[0] = i2;
                                if (i2 < 4) {
                                    mainActivity.h.postDelayed(this, 700L);
                                } else {
                                    Crash.note(e);
                                    mainActivity.toast("共享屏幕失败：请在设置里打开「后台保持在线」后再试", true);
                                }
                            } catch (Throwable th) {
                                Crash.note(th);
                                mainActivity.toast("共享屏幕失败了", true);
                            }
                        }
                    }, 500L);
                }
            });
        } catch (Throwable th) {
            mainActivity.toast("这台手机不支持共享屏幕", true);
        }
    }

    void show() {
        MainActivity mainActivity = MainActivity.cur;
        if (mainActivity == null) {
            return;
        }
        if (!(mainActivity.topScr() instanceof CallScr)) {
            mainActivity.push(new CallScr());
        }
        if (this.state == 1 || this.state == 0) {
            ring();
        }
    }

    String status() {
        if (this.state == 3) {
            return this.group ? (this.peers.size() + 1) + " 人通话中 · " + time() : time();
        }
        if (this.state == 1) {
            if (this.group) {
                return this.from + " 邀请你加入" + (this.video ? "群视频通话" : "群语音通话");
            }
            return this.video ? "邀请你视频通话…" : "邀请你语音通话…";
        }
        if (this.state == 0) {
            return this.note.length() > 0 ? this.note : "正在等待对方接受邀请…";
        }
        return this.state == 2 ? "正在加入…" : "通话已结束";
    }

    void talk() {
        unring();
        this.state = 3;
        this.t0 = System.currentTimeMillis();
        this.note = "";
        this.rtc = new Rtc(ctx, this.video, this.group);
        this.rtc.ui = this;
        this.rtc.muted = this.muted;
        this.rtc.front = this.front;
        this.rtc.start();
        if (!this.video) {
            this.rtc.setSpeaker(this.speaker);
        }
        App.startBg(ctx, (this.video ? 64 : 0) | 128);
        if (MainActivity.cur != null) {
            MainActivity.cur.vib(40);
        }
        changed();
    }

    String time() {
        if (this.state != 3) {
            return "";
        }
        int iCurrentTimeMillis = (int) ((System.currentTimeMillis() - this.t0) / 1000);
        return Ui.pad(iCurrentTimeMillis / 60) + ":" + Ui.pad(iCurrentTimeMillis % 60);
    }

    void timeout(long j) {
        final int i = this.state;
        final long jCurrentTimeMillis = System.currentTimeMillis();
        this.began = jCurrentTimeMillis;
        Core.timer.later(new Runnable() { // from class: com.changliao.im.Call.4
            @Override // java.lang.Runnable
            public void run() {
                if (Call.cur == Call.this && Call.this.state == i && Call.this.began == jCurrentTimeMillis) {
                    if (i == 0) {
                        Call.C.sendQ(J.of("t", "c_call", "kind", "timeout", "callid", Call.this.cid));
                        Call.this.end("对方无应答");
                    } else if (i == 1) {
                        if (Call.this.group) {
                            Call.this.end(null);
                        } else {
                            Call.C.sendQ(J.of("t", "c_call", "kind", "reject", "callid", Call.this.cid));
                            Call.this.end(null);
                        }
                    }
                }
            }
        }, j);
    }

    void unring() {
        if (this.ringing) {
            this.ringing = false;
            try {
                if (this.rt != null) {
                    this.rt.stop();
                }
            } catch (Throwable th) {
            }
            try {
                if (this.tg != null) {
                    this.tg.stopTone();
                    this.tg.release();
                }
            } catch (Throwable th2) {
            }
            try {
                Vibrator vibrator = (Vibrator) ctx.getSystemService("vibrator");
                if (vibrator != null) {
                    vibrator.cancel();
                }
            } catch (Throwable th3) {
            }
            this.rt = null;
            this.tg = null;
        }
    }

    @Override // com.changliao.im.Rtc.Ui
    public void videoInfo(int i) {
    }
}
