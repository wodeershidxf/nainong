package com.changliao.im;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/* JADX INFO: loaded from: classes.dex */
public class Crash {
    static File dir;
    public static String ver = "";

    public static void install(File file) {
        dir = file;
        final Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: com.changliao.im.Crash.1
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public void uncaughtException(Thread thread, Throwable th) {
                Crash.save("crash.txt", "闪退 v" + Crash.ver + " [" + thread.getName() + "]\n" + Crash.trace(th), false);
                if (defaultUncaughtExceptionHandler != null) {
                    defaultUncaughtExceptionHandler.uncaughtException(thread, th);
                }
            }
        });
    }

    public static void note(Throwable th) {
        try {
            th.printStackTrace();
        } catch (Throwable th2) {
        }
        save("errors.txt", "出错 v" + ver + "\n" + trace(th) + "\n", true);
    }

    static synchronized void save(String str, String str2, boolean z) {
        if (dir != null) {
            try {
                File file = new File(dir, str);
                if (z && file.length() > 12000) {
                    z = false;
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file, z);
                fileOutputStream.write(str2.getBytes("UTF-8"));
                fileOutputStream.close();
            } catch (Throwable th) {
            }
        }
    }

    public static String take(String str) {
        int i;
        int i2;
        int i3 = 0;
        if (dir == null) {
            return null;
        }
        File file = new File(dir, str);
        if (!file.exists()) {
            return null;
        }
        try {
            byte[] bArr = new byte[(int) Math.min(file.length(), 16000L)];
            FileInputStream fileInputStream = new FileInputStream(file);
            while (true) {
                i = i3;
                if (i >= bArr.length || (i2 = fileInputStream.read(bArr, i, bArr.length - i)) < 0) {
                    break;
                }
                i3 = i2 + i;
            }
            fileInputStream.close();
            file.delete();
            return new String(bArr, 0, i, "UTF-8");
        } catch (Throwable th) {
            return null;
        }
    }

    public static String trace(Throwable th) {
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        String string = stringWriter.toString();
        return string.length() > 3500 ? string.substring(0, 3500) : string;
    }
}
