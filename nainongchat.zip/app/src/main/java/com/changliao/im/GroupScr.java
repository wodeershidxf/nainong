package com.changliao.im;

import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.util.Linkify;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class GroupScr extends Scr {
    LinearLayout body;
    final String gid;

    public static class KickScr extends Scr {
        final String gid;
        LinearLayout list;
        TextView ok;
        final List<String> sel = new ArrayList();

        KickScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("移除群成员", true);
            this.ok = tb("移除", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.KickScr.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    if (KickScr.this.sel.isEmpty()) {
                        KickScr.this.err("请选择要移除的成员");
                    } else {
                        KickScr.this.a.confirm("移除群成员", "确定移除选中的 " + KickScr.this.sel.size() + " 人吗？", "移除", true, new Runnable() { // from class: com.changliao.im.GroupScr.KickScr.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Iterator<String> it = KickScr.this.sel.iterator();
                                while (it.hasNext()) {
                                    KickScr.this.C.send(J.of("t", "c_gkick", "gid", KickScr.this.gid, "nick", it.next()));
                                }
                                KickScr.this.a.back();
                            }
                        });
                    }
                }
            });
            this.list = scrollPage(linearLayoutPage);
            J j = this.C.ginfo.get(this.gid);
            if (j != null) {
                for (final J j2 : j.objs("members")) {
                    if (!j2.b("me") && !j2.s("role").equals("owner") && (j.s("myrole").equals("owner") || j2.s("role").equals("member"))) {
                        final Scr.Chk chk = new Scr.Chk(this.a);
                        LinearLayout linearLayoutRow = row(this.list, av(j2.s("nick"), j2.sn("av"), j2.b("online")), 40, GroupScr.nm(j2), null, null, null);
                        linearLayoutRow.addView(chk, 0, Ui.lpm(Ui.dp(22.0f), Ui.dp(22.0f), 0, 0, 12, 0));
                        linearLayoutRow.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GroupScr.KickScr.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (KickScr.this.sel.contains(j2.s("nk"))) {
                                    KickScr.this.sel.remove(j2.s("nk"));
                                } else {
                                    KickScr.this.sel.add(j2.s("nk"));
                                }
                                chk.set(KickScr.this.sel.contains(j2.s("nk")));
                                KickScr.this.ok.setText(KickScr.this.sel.isEmpty() ? "移除" : "移除(" + KickScr.this.sel.size() + ")");
                            }
                        });
                    }
                }
            }
            if (this.list.getChildCount() == 0) {
                this.list.addView(empty("没有可以移除的成员"));
            }
            return linearLayoutPage;
        }
    }

    public static class LevelsScr extends Scr {
        static final String[] DN = {"潜水", "冒泡", "吐槽", "活跃", "话唠", "传说"};
        static final int[] DT = {0, 30, 100, 300, 800, 2000};
        LinearLayout body;
        final String gid;
        final EditText[] names = new EditText[6];
        final EditText[] thrs = new EditText[6];
        boolean show = true;

        LevelsScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("群等级", true);
            this.body = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
                render();
            }
        }

        void render() {
            this.body.removeAllViews();
            this.right.removeAllViews();
            J j = this.C.ginfo.get(this.gid);
            if (j == null) {
                return;
            }
            J jO = j.o("lvcfg");
            List<Object> listA = jO != null ? jO.a("names") : null;
            List<Object> listA2 = jO != null ? jO.a("thr") : null;
            this.show = jO == null || !jO.has("show") || jO.b("show");
            boolean z = j.s("myrole").equals("owner") || j.s("myrole").equals("admin");
            J jMe = GroupScr.me(j);
            int iMax = (int) Math.max(1L, jMe.l("lv"));
            long jL = jMe.l("pts");
            long[] jArr = new long[6];
            String[] strArr = new String[6];
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= 6) {
                    break;
                }
                jArr[i2] = (listA2 == null || listA2.size() <= i2) ? DT[i2] : ((Number) listA2.get(i2)).longValue();
                strArr[i2] = (listA == null || listA.size() <= i2) ? DN[i2] : String.valueOf(listA.get(i2));
                i = i2 + 1;
            }
            if (z) {
                tb("保存", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.LevelsScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        LevelsScr.this.save();
                    }
                });
            }
            LinearLayout linearLayoutCsec = csec(this.body);
            linearLayoutCsec.setPadding(Ui.dp(18.0f), Ui.dp(16.0f), Ui.dp(18.0f), Ui.dp(16.0f));
            linearLayoutCsec.addView(Ui.text(this.a, "我在本群", 13.0f, Ui.SUB));
            LinearLayout linearLayoutRow = Ui.row(this.a);
            TextView textViewLvTag = Ui.lvTag(this.a, iMax, jMe.s("lvn"));
            textViewLvTag.setTextSize(13.0f);
            ((LinearLayout.LayoutParams) textViewLvTag.getLayoutParams()).height = Ui.dp(22.0f);
            ((LinearLayout.LayoutParams) textViewLvTag.getLayoutParams()).leftMargin = 0;
            linearLayoutRow.addView(textViewLvTag);
            linearLayoutRow.addView(Ui.text(this.a, "积分 " + jL, 15.0f, Ui.TEXT), Ui.lpm(-2, -2, 10, 0, 0, 0));
            linearLayoutCsec.addView(linearLayoutRow, Ui.lpm(-2, -2, 0, 10, 0, 10));
            final float fMax = iMax >= 6 ? 1.0f : Math.max(0.04f, Math.min(1.0f, (jL - jArr[iMax - 1]) / Math.max(1L, jArr[iMax] - jArr[iMax - 1])));
            FrameLayout frameLayout = new FrameLayout(this.a);
            frameLayout.setBackground(Ui.round(779652266, 4.0f));
            final View view = new View(this.a);
            view.setBackground(Ui.grad(4.0f, -11685121, -15304720));
            frameLayout.addView(view, new FrameLayout.LayoutParams(0, -1));
            frameLayout.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.changliao.im.GroupScr.LevelsScr.2
                @Override // android.view.View.OnLayoutChangeListener
                public void onLayoutChange(View view2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
                    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
                    int i11 = (int) ((i5 - i3) * fMax);
                    if (layoutParams.width != i11) {
                        layoutParams.width = i11;
                        view.setLayoutParams(layoutParams);
                    }
                }
            });
            linearLayoutCsec.addView(frameLayout, Ui.lp(-1, Ui.dp(8.0f)));
            linearLayoutCsec.addView(Ui.text(this.a, iMax >= 6 ? "已经是最高等级啦" : "再获得 " + Math.max(0L, jArr[iMax] - jL) + " 积分升到 LV" + (iMax + 1), 12.0f, Ui.SUB), Ui.lpm(-2, -2, 0, 8, 0, 0));
            sec(this.body, "每天第一次在群里发言 +2 积分，每发一条消息 +1 积分（每天最多算 20 条）");
            if (z) {
                optSw(csec(this.body), "在消息里显示群等级", null, this.show, new Scr.Sw.L() { // from class: com.changliao.im.GroupScr.LevelsScr.3
                    @Override // com.changliao.im.Scr.Sw.L
                    public void on(boolean z2) {
                        LevelsScr.this.show = z2;
                    }
                });
            }
            LinearLayout linearLayoutCsec2 = csec(this.body);
            int i3 = 0;
            while (true) {
                int i4 = i3;
                if (i4 >= 6) {
                    break;
                }
                LinearLayout linearLayoutRow2 = Ui.row(this.a);
                linearLayoutRow2.setPadding(Ui.dp(16.0f), Ui.dp(10.0f), Ui.dp(16.0f), Ui.dp(10.0f));
                TextView textViewLvTag2 = Ui.lvTag(this.a, i4 + 1, null);
                textViewLvTag2.setTextSize(11.0f);
                ((LinearLayout.LayoutParams) textViewLvTag2.getLayoutParams()).height = Ui.dp(20.0f);
                ((LinearLayout.LayoutParams) textViewLvTag2.getLayoutParams()).leftMargin = 0;
                textViewLvTag2.setMinWidth(Ui.dp(36.0f));
                linearLayoutRow2.addView(textViewLvTag2);
                if (z) {
                    this.names[i4] = Ui.input(this.a, "等级名称", false);
                    this.names[i4].setText(strArr[i4]);
                    this.names[i4].setPadding(Ui.dp(10.0f), Ui.dp(6.0f), Ui.dp(10.0f), Ui.dp(6.0f));
                    this.names[i4].setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
                    linearLayoutRow2.addView(this.names[i4], Ui.lpm(0, -2, 10, 0, 8, 0));
                    ((LinearLayout.LayoutParams) this.names[i4].getLayoutParams()).weight = 1.0f;
                    linearLayoutRow2.addView(Ui.text(this.a, "需要", 13.0f, Ui.SUB));
                    this.thrs[i4] = Ui.input(this.a, "", false);
                    this.thrs[i4].setText(String.valueOf(jArr[i4]));
                    this.thrs[i4].setInputType(2);
                    this.thrs[i4].setPadding(Ui.dp(8.0f), Ui.dp(6.0f), Ui.dp(8.0f), Ui.dp(6.0f));
                    if (i4 == 0) {
                        this.thrs[i4].setEnabled(false);
                    }
                    linearLayoutRow2.addView(this.thrs[i4], Ui.lpm(Ui.dp(76.0f), -2, 6, 0, 6, 0));
                    linearLayoutRow2.addView(Ui.text(this.a, "积分", 13.0f, Ui.SUB));
                } else {
                    linearLayoutRow2.addView(Ui.text(this.a, strArr[i4], 16.0f, Ui.TEXT), Ui.lpm(0, -2, 10, 0, 0, 0));
                    ((LinearLayout.LayoutParams) linearLayoutRow2.getChildAt(1).getLayoutParams()).weight = 1.0f;
                    linearLayoutRow2.addView(Ui.text(this.a, jArr[i4] + " 积分", 14.0f, Ui.SUB));
                }
                linearLayoutCsec2.addView(linearLayoutRow2);
                i3 = i4 + 1;
            }
            if (z) {
                LinearLayout linearLayoutCol = Ui.col(this.a);
                linearLayoutCol.setPadding(Ui.dp(16.0f), Ui.dp(4.0f), Ui.dp(16.0f), Ui.dp(24.0f));
                linearLayoutCol.addView(Ui.btnGray(this.a, "恢复 QQ 默认等级", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.LevelsScr.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        for (int i5 = 0; i5 < 6; i5++) {
                            LevelsScr.this.names[i5].setText(LevelsScr.DN[i5]);
                            LevelsScr.this.thrs[i5].setText(String.valueOf(LevelsScr.DT[i5]));
                        }
                        LevelsScr.this.toast("已恢复默认，点右上角保存");
                    }
                }));
                this.body.addView(linearLayoutCol);
            }
        }

        void save() {
            long j;
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int i = 0;
            long j2 = -1;
            while (i < 6) {
                arrayList.add(this.names[i].getText().toString().trim());
                try {
                    j = Long.parseLong(this.thrs[i].getText().toString().trim());
                } catch (Exception e) {
                    j = 0;
                }
                if (i > 0 && j <= j2) {
                    err("LV" + (i + 1) + " 需要的积分要比 LV" + i + " 多");
                    return;
                } else {
                    arrayList2.add(Long.valueOf(j));
                    i++;
                    j2 = j;
                }
            }
            this.C.send(J.of("t", "c_glevel", "gid", this.gid, "names", arrayList, "thr", arrayList2, "show", Boolean.valueOf(this.show)));
        }
    }

    public static class MembersScr extends Scr {
        final String gid;
        LinearLayout list;
        String q = "";

        MembersScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("群成员", true);
            searchBox(linearLayoutPage, "搜索群成员").addTextChangedListener(new TextWatcher() { // from class: com.changliao.im.GroupScr.MembersScr.1
                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                    MembersScr.this.q = editable.toString().trim().toLowerCase();
                    MembersScr.this.render();
                }

                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }
            });
            this.list = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
                render();
            }
        }

        void render() {
            this.list.removeAllViews();
            J j = this.C.ginfo.get(this.gid);
            if (j == null) {
                return;
            }
            this.title.setText("群成员（" + j.a("members").size() + "）");
            J jO = j.o("lvcfg");
            boolean z = jO == null || !jO.has("show") || jO.b("show");
            int i = 0;
            for (final J j2 : j.objs("members")) {
                if (this.q.length() <= 0 || j2.s("nick").toLowerCase().contains(this.q) || j2.s("card").toLowerCase().contains(this.q) || j2.s("nk").contains(this.q)) {
                    int i2 = i + 1;
                    LinearLayout linearLayout = (LinearLayout) row(this.list, av(j2.s("nick"), j2.sn("av"), j2.b("online")), 50, GroupScr.nm(j2), (j2.b("online") ? "在线" : "离线") + " · NK " + j2.s("nk"), null, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.MembersScr.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            MembersScr.this.a.push(new ProfileScr(j2.s("nk"), MembersScr.this.gid));
                        }
                    }).getChildAt(1);
                    TextView textView = (TextView) linearLayout.getChildAt(0);
                    linearLayout.removeViewAt(0);
                    LinearLayout linearLayoutRow = Ui.row(this.a);
                    linearLayoutRow.addView(textView);
                    if (j2.b("vip")) {
                        textView.setTextColor(-3569152);
                        textView.setTypeface(bold);
                        linearLayoutRow.addView(Ui.vipTag(this.a));
                    }
                    if (z && j2.l("lv") > 0) {
                        linearLayoutRow.addView(Ui.lvTag(this.a, j2.l("lv"), j2.s("lvn")));
                    }
                    TextView textViewRoleTag = Ui.roleTag(this.a, j2.s("role"));
                    if (textViewRoleTag != null) {
                        linearLayoutRow.addView(textViewRoleTag);
                    }
                    if (j2.l("mute") > 0) {
                        linearLayoutRow.addView(Ui.tag(this.a, "禁言中", -6248784));
                    }
                    if (j2.b("me")) {
                        linearLayoutRow.addView(Ui.tag(this.a, "我", -4670011));
                    }
                    linearLayout.addView(linearLayoutRow, 0);
                    i = i2;
                }
            }
            if (i == 0) {
                this.list.addView(empty("没有找到"));
            }
        }
    }

    public static class NoticesScr extends Scr {
        LinearLayout body;
        final String gid;

        NoticesScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("群公告", true);
            J j = this.C.ginfo.get(this.gid);
            if (j != null && !j.s("myrole").equals("member")) {
                tb("发布", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.NoticesScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        NoticesScr.this.a.ask("发布群公告", "公告内容，会通知所有群成员", "", true, 1000, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.NoticesScr.1.1
                            @Override // com.changliao.im.MainActivity.Str
                            public void ok(String str) {
                                if (str.length() > 0) {
                                    NoticesScr.this.C.send(J.of("t", "c_gnotice", "gid", NoticesScr.this.gid, "text", str));
                                }
                            }
                        });
                    }
                });
            }
            this.body = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
                render();
            }
        }

        void render() {
            this.body.removeAllViews();
            J j = this.C.ginfo.get(this.gid);
            if (j == null) {
                return;
            }
            boolean z = !j.s("myrole").equals("member");
            List<J> listObjs = j.objs("notices");
            if (listObjs.isEmpty()) {
                this.body.addView(empty("还没有群公告" + (z ? "\n点右上角「发布」" : "")));
                return;
            }
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= listObjs.size()) {
                    return;
                }
                final J j2 = listObjs.get(i2);
                LinearLayout linearLayoutCsec = csec(this.body);
                linearLayoutCsec.setPadding(Ui.dp(16.0f), Ui.dp(14.0f), Ui.dp(16.0f), Ui.dp(12.0f));
                if (i2 == 0) {
                    TextView textViewTag = Ui.tag(this.a, "最新", Ui.GOLD);
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) textViewTag.getLayoutParams();
                    layoutParams.leftMargin = 0;
                    layoutParams.bottomMargin = Ui.dp(8.0f);
                    linearLayoutCsec.addView(textViewTag);
                }
                TextView textViewText = Ui.text(this.a, j2.s("text"), 15.0f, Ui.TEXT);
                textViewText.setLineSpacing(0.0f, 1.3f);
                textViewText.setTextIsSelectable(true);
                Linkify.addLinks(textViewText, 1);
                linearLayoutCsec.addView(textViewText);
                LinearLayout linearLayoutRow = Ui.row(this.a);
                linearLayoutRow.addView(Ui.text(this.a, j2.s("by") + " · " + Ui.fullWhen(j2.l("ts")), 12.0f, Ui.SUB), Ui.lp(0, -2, 1.0f));
                if (z) {
                    linearLayoutRow.addView(sm("删除", 0, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.NoticesScr.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            NoticesScr.this.a.confirm("删除这条公告？", null, "删除", true, new Runnable() { // from class: com.changliao.im.GroupScr.NoticesScr.2.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    NoticesScr.this.C.send(J.of("t", "c_gnotice_del", "gid", NoticesScr.this.gid, "id", Long.valueOf(j2.l("id"))));
                                }
                            });
                        }
                    }));
                }
                linearLayoutCsec.addView(linearLayoutRow, Ui.lpm(-1, -2, 0, 10, 0, 0));
                i = i2 + 1;
            }
        }
    }

    public static class ReqsScr extends Scr {
        final String gid;
        LinearLayout list;

        ReqsScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("加群申请", true);
            this.list = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
                render();
            }
        }

        void render() {
            this.list.removeAllViews();
            J j = this.C.ginfo.get(this.gid);
            if (j == null) {
                return;
            }
            if (j.a("reqs").isEmpty()) {
                this.list.addView(empty("没有待处理的申请"));
                return;
            }
            for (final J j2 : j.objs("reqs")) {
                LinearLayout linearLayoutRow = Ui.row(this.a);
                linearLayoutRow.addView(sm("同意", 1, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.ReqsScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ReqsScr.this.C.send(J.of("t", "c_greq", "gid", ReqsScr.this.gid, "nick", j2.s("nk"), "ok", true));
                    }
                }));
                linearLayoutRow.addView(sm("拒绝", 0, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.ReqsScr.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ReqsScr.this.C.send(J.of("t", "c_greq", "gid", ReqsScr.this.gid, "nick", j2.s("nk"), "ok", false));
                    }
                }), Ui.lpm(-2, -2, 6, 0, 0, 0));
                row(this.list, av(j2.s("nick"), j2.sn("av"), false), 50, j2.s("nick"), (j2.s("text").length() > 0 ? "留言：" + j2.s("text") : "申请加入") + " · " + HomeScr.ago(j2.l("ts")), linearLayoutRow, null);
            }
        }
    }

    public static class TitlesScr extends Scr {
        final String gid;
        LinearLayout list;

        TitlesScr(String str) {
            this.gid = str;
        }

        @Override // com.changliao.im.Scr
        public View build() {
            LinearLayout linearLayoutPage = page("群头衔", true);
            this.list = scrollPage(linearLayoutPage);
            render();
            return linearLayoutPage;
        }

        @Override // com.changliao.im.Scr, com.changliao.im.Core.L
        public void on(String str, J j) {
            if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
                render();
            }
        }

        void render() {
            TextView textViewTag;
            this.list.removeAllViews();
            J j = this.C.ginfo.get(this.gid);
            if (j == null) {
                return;
            }
            boolean zEquals = j.s("myrole").equals("owner");
            sec(this.list, zEquals ? "点成员设置专属头衔（最多 6 个字）" : "只有群主能设置群头衔");
            for (final J j2 : j.objs("members")) {
                if (j2.s("title").length() > 0) {
                    textViewTag = Ui.tag(this.a, j2.s("title"), -3626);
                    textViewTag.setTextColor(-3900928);
                } else {
                    textViewTag = null;
                }
                row(this.list, av(j2.s("nick"), j2.sn("av"), j2.b("online")), 40, GroupScr.nm(j2), null, textViewTag, zEquals ? new View.OnClickListener() { // from class: com.changliao.im.GroupScr.TitlesScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        TitlesScr.this.a.ask("设置「" + GroupScr.nm(j2) + "」的头衔", "留空则取消头衔", j2.s("title"), false, 6, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.TitlesScr.1.1
                            @Override // com.changliao.im.MainActivity.Str
                            public void ok(String str) {
                                TitlesScr.this.C.send(J.of("t", "c_gtitle", "gid", TitlesScr.this.gid, "nick", j2.s("nk"), "title", str));
                            }
                        });
                    }
                } : null);
            }
        }
    }

    public GroupScr(String str) {
        this.gid = str;
    }

    static String joinTxt(String str) {
        if (str.equals("free")) {
            return "允许任何人加入";
        }
        if (str.equals("approve")) {
            return "需要验证";
        }
        if (str.equals("invite")) {
            return "仅可通过邀请";
        }
        return str.equals("admin_invite") ? "仅管理员可邀请" : "";
    }

    static J me(J j) {
        for (J j2 : j.objs("members")) {
            if (j2.b("me")) {
                return j2;
            }
        }
        return new J();
    }

    public static void memberMenu(final MainActivity mainActivity, final String str, final String str2) {
        final J j = Core.I.ginfo.get(str);
        if (j == null) {
            return;
        }
        J j2 = null;
        for (J j3 : j.objs("members")) {
            if (!j3.s("nk").equals(str2)) {
                j3 = j2;
            }
            j2 = j3;
        }
        if (j2 == null) {
            mainActivity.toast("TA 已经不在群里了", true);
            return;
        }
        String strS = j.s("myrole");
        boolean z = (j2.b("me") || j2.s("role").equals("owner") || (!strS.equals("owner") && (!strS.equals("admin") || !j2.s("role").equals("member")))) ? false : true;
        final String strNm = nm(j2);
        final boolean zEquals = j2.s("role").equals("admin");
        boolean z2 = j2.l("mute") > 0;
        ArrayList arrayList = new ArrayList();
        if (strS.equals("owner") && !j2.b("me")) {
            arrayList.add(zEquals ? "取消管理员" : "设为管理员");
        }
        if (z) {
            arrayList.add(z2 ? "解除禁言" : "禁言…");
        }
        if (z) {
            arrayList.add("移出本群");
        }
        if (strS.equals("owner") || strS.equals("admin")) {
            arrayList.add("调整群等级（当前 LV" + j2.l("lv") + (j2.b("lvfix") ? " · 手动" : "") + "）");
        }
        if (strS.equals("owner") && !j2.b("me")) {
            arrayList.add("转让群主给TA");
        }
        mainActivity.sheet(strNm + (z2 ? " · 禁言中" : ""), (String[]) arrayList.toArray(new String[0]), -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.34
            @Override // com.changliao.im.MainActivity.Str
            public void ok(String str3) {
                final Core core = Core.I;
                if (str3.endsWith("管理员")) {
                    Object[] objArr = new Object[8];
                    objArr[0] = "t";
                    objArr[1] = "c_gadmin";
                    objArr[2] = "gid";
                    objArr[3] = str;
                    objArr[4] = "nick";
                    objArr[5] = str2;
                    objArr[6] = "on";
                    objArr[7] = Boolean.valueOf(zEquals ? false : true);
                    core.send(J.of(objArr));
                    return;
                }
                if (str3.equals("解除禁言")) {
                    core.send(J.of("t", "c_gmute", "gid", str, "nick", str2, "min", 0));
                    return;
                }
                if (str3.equals("禁言…")) {
                    final int[] iArr = {10, 60, 720, 1440, 10080, 43200};
                    final String[] strArr = {"10 分钟", "1 小时", "12 小时", "1 天", "7 天", "30 天"};
                    mainActivity.sheet("禁言 " + strNm, strArr, -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.34.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str4) {
                            for (int i = 0; i < strArr.length; i++) {
                                if (strArr[i].equals(str4)) {
                                    core.send(J.of("t", "c_gmute", "gid", str, "nick", str2, "min", Integer.valueOf(iArr[i])));
                                }
                            }
                        }
                    });
                    return;
                }
                if (str3.equals("移出本群")) {
                    mainActivity.confirm("移出本群", "确定把「" + strNm + "」移出群聊吗？", "移出", true, new Runnable() { // from class: com.changliao.im.GroupScr.34.2
                        @Override // java.lang.Runnable
                        public void run() {
                            core.send(J.of("t", "c_gkick", "gid", str, "nick", str2));
                            mainActivity.back();
                        }
                    });
                    return;
                }
                if (!str3.startsWith("调整群等级")) {
                    if (str3.startsWith("转让")) {
                        mainActivity.confirm("转让群主", "确定把群主转让给「" + strNm + "」吗？", "转让", true, new Runnable() { // from class: com.changliao.im.GroupScr.34.4
                            @Override // java.lang.Runnable
                            public void run() {
                                core.send(J.of("t", "c_gtransfer", "gid", str, "nick", str2));
                            }
                        });
                        return;
                    }
                    return;
                }
                List<Object> listA = j.o("lvcfg") != null ? j.o("lvcfg").a("names") : new ArrayList<>();
                final String[] strArr2 = new String[7];
                int i = 0;
                while (i < 6) {
                    strArr2[i] = "LV" + (i + 1) + (i < listA.size() ? " " + listA.get(i) : "");
                    i++;
                }
                strArr2[6] = "按积分自动计算";
                mainActivity.sheet("设置 " + strNm + " 的群等级", strArr2, -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.34.3
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str4) {
                        int i2 = 0;
                        while (i2 < 7) {
                            if (strArr2[i2].equals(str4)) {
                                Core core2 = core;
                                Object[] objArr2 = new Object[8];
                                objArr2[0] = "t";
                                objArr2[1] = "c_glv_set";
                                objArr2[2] = "gid";
                                objArr2[3] = str;
                                objArr2[4] = "nick";
                                objArr2[5] = str2;
                                objArr2[6] = "lv";
                                objArr2[7] = Integer.valueOf(i2 < 6 ? i2 + 1 : 0);
                                core2.send(J.of(objArr2));
                            }
                            i2++;
                        }
                    }
                });
            }
        });
    }

    static String nm(J j) {
        return j.s("card").length() > 0 ? j.s("card") : j.s("nick");
    }

    public static void report(final MainActivity mainActivity, final String str, final boolean z) {
        MainActivity.Str str2 = new MainActivity.Str() { // from class: com.changliao.im.GroupScr.35
            @Override // com.changliao.im.MainActivity.Str
            public void ok(final String str3) {
                mainActivity.ask(z ? "申诉说明" : "举报说明", z ? "说明一下情况，系统会重新审核" : "补充说明（可不填）", "", true, 500, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.35.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str4) {
                        if (z && str4.length() == 0) {
                            mainActivity.toast("请写一下申诉理由", true);
                            return;
                        }
                        Core core = Core.I;
                        Object[] objArr = new Object[8];
                        objArr[0] = "t";
                        objArr[1] = z ? "c_appeal" : "c_report";
                        objArr[2] = "gid";
                        objArr[3] = str;
                        objArr[4] = "reason";
                        objArr[5] = str3;
                        objArr[6] = "text";
                        objArr[7] = str4;
                        core.send(J.of(objArr));
                    }
                });
            }
        };
        if (z) {
            str2.ok("申诉");
        } else {
            mainActivity.sheet("选择举报原因", new String[]{"色情低俗", "违法犯罪", "诈骗", "赌博", "政治敏感", "侮辱谩骂", "广告骚扰", "其他"}, -1, str2);
        }
    }

    static void transferSheet(final MainActivity mainActivity, final String str) {
        J j = Core.I.ginfo.get(str);
        if (j == null) {
            return;
        }
        final ArrayList arrayList = new ArrayList();
        for (J j2 : j.objs("members")) {
            if (!j2.b("me")) {
                arrayList.add(j2);
            }
        }
        final String[] strArr = new String[Math.min(40, arrayList.size())];
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= strArr.length) {
                mainActivity.sheet("把群主转让给", strArr, -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.33
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        for (int i3 = 0; i3 < strArr.length; i3++) {
                            if (strArr[i3].equals(str2)) {
                                final String strS = ((J) arrayList.get(i3)).s("nk");
                                mainActivity.confirm("转让群主", "确定把群主转让给「" + str2 + "」吗？转让后你会变成普通成员。", "转让", true, new Runnable() { // from class: com.changliao.im.GroupScr.33.1
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        Core.I.send(J.of("t", "c_gtransfer", "gid", str, "nick", strS));
                                    }
                                });
                                return;
                            }
                        }
                    }
                });
                return;
            } else {
                strArr[i2] = nm((J) arrayList.get(i2));
                i = i2 + 1;
            }
        }
    }

    TextView addm(String str) {
        TextView textViewText = Ui.text(this.a, str, 22.0f, Ui.SUB);
        textViewText.setGravity(17);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(-525828);
        gradientDrawable.setStroke(Ui.dp(1.0f), 1937280170, Ui.dp(3.0f), Ui.dp(3.0f));
        textViewText.setBackground(gradientDrawable);
        return textViewText;
    }

    @Override // com.changliao.im.Scr
    public View build() {
        LinearLayout linearLayoutPage = page("聊天信息", true);
        this.body = scrollPage(linearLayoutPage);
        this.C.send(J.of("t", "c_ginfo", "gid", this.gid));
        render();
        return linearLayoutPage;
    }

    View cell(int i, View view, String str, View.OnClickListener onClickListener) {
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.setGravity(1);
        linearLayoutCol.addView(view, Ui.lp(Ui.dp(40.0f), Ui.dp(40.0f)));
        TextView textViewOne = Ui.one(Ui.text(this.a, str, 12.0f, Ui.SUB));
        textViewOne.setGravity(17);
        linearLayoutCol.addView(textViewOne, Ui.lpm(-1, -2, 2, 4, 2, 0));
        linearLayoutCol.setOnClickListener(onClickListener);
        Ui.bounce(linearLayoutCol);
        GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = i;
        layoutParams.bottomMargin = Ui.dp(12.0f);
        linearLayoutCol.setLayoutParams(layoutParams);
        return linearLayoutCol;
    }

    J gi() {
        return this.C.ginfo.get(this.gid);
    }

    @Override // com.changliao.im.Scr, com.changliao.im.Core.L
    public void on(String str, J j) {
        if (str.equals("ginfo") && this.gid.equals(j.s("gid"))) {
            render();
            return;
        }
        if (str.equals("convs")) {
        }
        if (str.equals("gone") && this.gid.equals(j.s("gid"))) {
            this.a.popTo(HomeScr.class);
        }
    }

    void render() {
        this.body.removeAllViews();
        final J jGi = gi();
        if (jGi == null) {
            this.body.addView(empty("加载中…"));
            return;
        }
        final boolean z = jGi.s("myrole").equals("owner") || jGi.s("myrole").equals("admin");
        final String str = "g:" + this.gid;
        final String string = App.kv.getString("gremark:" + this.gid, "");
        if (jGi.b("banned")) {
            LinearLayout linearLayoutRow = Ui.row(this.a);
            linearLayoutRow.setPadding(Ui.dp(14.0f), Ui.dp(10.0f), Ui.dp(14.0f), Ui.dp(10.0f));
            linearLayoutRow.setBackground(Ui.round(-4627, 16.0f));
            linearLayoutRow.addView(Ui.text(this.a, "⚠️ 该群因「" + (jGi.s("ban_reason").length() > 0 ? jGi.s("ban_reason") : "违规") + "」已被封禁，期间只能查看消息\n" + MiscScr.ReportsScr.left(jGi.l("ban_until")), 14.0f, Ui.RED), Ui.lp(0, -2, 1.0f));
            if (this.C.isOwner) {
                linearLayoutRow.addView(sm("解封", 1, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        GroupScr.this.C.send(J.of("t", "c_rdeal", "gid", GroupScr.this.gid, "act", "unban"));
                    }
                }), Ui.lpm(-2, -2, 0, 0, 6, 0));
            }
            if (jGi.s("myrole").equals("owner")) {
                linearLayoutRow.addView(sm("申诉", 1, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        GroupScr.report(GroupScr.this.a, GroupScr.this.gid, true);
                    }
                }));
            }
            this.body.addView(linearLayoutRow, Ui.lpm(-1, -2, 10, 8, 10, 0));
        }
        LinearLayout linearLayoutCsec = csec(this.body);
        LinearLayout linearLayoutRow2 = Ui.row(this.a);
        linearLayoutRow2.setPadding(Ui.dp(16.0f), Ui.dp(16.0f), Ui.dp(12.0f), Ui.dp(16.0f));
        Img.Av av = new Img.Av(this.a);
        av.set(jGi.s("name"), jGi.sn("av"), true, str);
        if (this.C.isHall(str) && !jGi.has("av")) {
            av.setIcon("globe", -20163, -34257);
        }
        av.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GroupScr.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (jGi.has("av")) {
                    GroupScr.this.a.push(new ImgScr(J.of("id", jGi.s("av"), "name", "avatar.jpg"), null, null));
                } else if (z) {
                    MyInfoScr.pickAvatar(GroupScr.this.a, GroupScr.this.gid);
                }
            }
        });
        linearLayoutRow2.addView(av, Ui.lpm(Ui.dp(66.0f), Ui.dp(66.0f), 0, 0, 14, 0));
        LinearLayout linearLayoutCol = Ui.col(this.a);
        linearLayoutCol.addView(Ui.bold(Ui.text(this.a, string.length() > 0 ? string : jGi.s("name"), 19.0f, Ui.TEXT)));
        LinearLayout linearLayoutRow3 = Ui.row(this.a);
        linearLayoutRow3.addView(Ui.text(this.a, "群号：" + this.gid, 13.0f, Ui.SUB));
        TextView textViewText = Ui.text(this.a, joinTxt(jGi.s("join")), 11.0f, -9735552);
        textViewText.setPadding(Ui.dp(6.0f), Ui.dp(1.0f), Ui.dp(6.0f), Ui.dp(1.0f));
        textViewText.setBackground(Ui.round(-1117965, 4.0f));
        if (joinTxt(jGi.s("join")).length() > 0) {
            linearLayoutRow3.addView(textViewText, Ui.lpm(-2, -2, 6, 0, 0, 0));
        }
        linearLayoutCol.addView(linearLayoutRow3, Ui.lpm(-2, -2, 0, 4, 0, 0));
        linearLayoutRow2.addView(linearLayoutCol, Ui.lp(0, -2, 1.0f));
        ImageView imageView = new ImageView(this.a);
        imageView.setImageDrawable(new Ico("copy", Ui.TEXT));
        int iDp = Ui.dp(9.0f);
        imageView.setPadding(iDp, iDp, iDp, iDp);
        G.on(imageView, 0, 15.0f, 2.0f);
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.changliao.im.GroupScr.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.copy(GroupScr.this.gid);
            }
        });
        linearLayoutRow2.addView(imageView, Ui.lp(Ui.dp(42.0f), Ui.dp(42.0f)));
        linearLayoutCsec.addView(linearLayoutRow2);
        LinearLayout linearLayoutCsec2 = csec(this.body);
        opt(linearLayoutCsec2, "群成员", jGi.a("members").size() + "人", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new MembersScr(GroupScr.this.gid));
            }
        });
        GridLayout gridLayout = new GridLayout(this.a);
        gridLayout.setColumnCount(5);
        gridLayout.setPadding(Ui.dp(10.0f), Ui.dp(4.0f), Ui.dp(10.0f), Ui.dp(12.0f));
        int width = (((this.a.host.getWidth() > 0 ? this.a.wide() ? (int) (this.a.host.getWidth() * 0.64f) : this.a.host.getWidth() : this.a.getResources().getDisplayMetrics().widthPixels) - Ui.dp(24.0f)) - Ui.dp(20.0f)) / 5;
        List<J> listObjs = jGi.objs("members");
        int iMin = Math.min(listObjs.size(), z ? 13 : 14);
        for (int i = 0; i < iMin; i++) {
            final J j = listObjs.get(i);
            gridLayout.addView(cell(width, av(j.s("nick"), j.sn("av"), j.b("online")), nm(j), new View.OnClickListener() { // from class: com.changliao.im.GroupScr.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.push(new ProfileScr(j.s("nk"), GroupScr.this.gid));
                }
            }));
        }
        gridLayout.addView(cell(width, addm("＋"), "邀请", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ArrayList arrayList = new ArrayList();
                Iterator<J> it = GroupScr.this.gi().objs("members").iterator();
                while (it.hasNext()) {
                    arrayList.add(it.next().s("nk"));
                }
                GroupScr.this.a.push(new PickScr("邀请好友进群", arrayList, "确定", false, null, new PickScr.Done() { // from class: com.changliao.im.GroupScr.7.1
                    @Override // com.changliao.im.PickScr.Done
                    public void done(List<String> list, String str2) {
                        GroupScr.this.C.send(J.of("t", "c_ginvite", "gid", GroupScr.this.gid, "nicks", new ArrayList(list)));
                    }
                }));
            }
        }));
        if (z) {
            gridLayout.addView(cell(width, addm("－"), "移除", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.8
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.push(new KickScr(GroupScr.this.gid));
                }
            }));
        }
        linearLayoutCsec2.addView(gridLayout);
        J j2 = jGi.objs("notices").isEmpty() ? null : jGi.objs("notices").get(0);
        LinearLayout linearLayoutCsec3 = csec(this.body);
        opt(linearLayoutCsec3, "群名称", jGi.s("name"), true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (z) {
                    GroupScr.this.a.ask("修改群名称", "", jGi.s("name"), false, 24, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.9.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str2) {
                            if (str2.length() > 0) {
                                GroupScr.this.C.send(J.of("t", "c_gset", "gid", GroupScr.this.gid, "name", str2));
                            }
                        }
                    });
                } else {
                    GroupScr.this.toast("只有群主和管理员能改群名称");
                }
            }
        });
        opt(linearLayoutCsec3, "群备注", string.length() > 0 ? string : "未设置", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.ask("群备注（只有你自己能看到）", "", string, false, 24, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.10.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        if (str2.length() > 0) {
                            App.kv.edit().putString("gremark:" + GroupScr.this.gid, str2).apply();
                        } else {
                            App.kv.edit().remove("gremark:" + GroupScr.this.gid).apply();
                        }
                        GroupScr.this.render();
                        GroupScr.this.C.emit("convs", null);
                    }
                });
            }
        });
        opt(linearLayoutCsec3, "群公告", j2 != null ? j2.s("text").replace('\n', ' ') : z ? "点击发布群公告" : "暂无公告", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new NoticesScr(GroupScr.this.gid));
            }
        });
        opt(linearLayoutCsec3, "群文件 / 相册", "", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new MediaScr(str, GroupScr.this.gid, "img"));
            }
        });
        opt(linearLayoutCsec3, "查找聊天记录", "图片、视频、文件", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new MediaScr(str, null, "img"));
            }
        });
        opt(linearLayoutCsec3, "群通话", "语音 / 视频", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.sheet(null, new String[]{"群语音通话", "群视频通话"}, -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.14.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        Call.joinGroup(GroupScr.this.a, GroupScr.this.gid, jGi.s("name"), jGi.sn("avatar"), str2.contains("视频"));
                    }
                });
            }
        });
        if (z) {
            LinearLayout linearLayoutCsec4 = csec(this.body);
            sec2(linearLayoutCsec4, "管理群");
            opt(linearLayoutCsec4, "加群设置", joinTxt(jGi.s("join")), true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.15
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    final String[] strArr = {"free", "approve", "invite", "admin_invite"};
                    String[] strArr2 = new String[4];
                    for (int i2 = 0; i2 < 4; i2++) {
                        strArr2[i2] = (jGi.s("join").equals(strArr[i2]) ? "✓ " : "") + GroupScr.joinTxt(strArr[i2]);
                    }
                    GroupScr.this.a.sheet("加群设置", strArr2, -1, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.15.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str2) {
                            for (String str3 : strArr) {
                                if (str2.endsWith(GroupScr.joinTxt(str3))) {
                                    GroupScr.this.C.send(J.of("t", "c_gset", "gid", GroupScr.this.gid, "join", str3));
                                }
                            }
                        }
                    });
                }
            });
            int size = jGi.a("reqs").size();
            opt(linearLayoutCsec4, "加群申请", size > 0 ? size + " 条" : "无", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.16
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.push(new ReqsScr(GroupScr.this.gid));
                }
            });
            optSw(linearLayoutCsec4, "全员禁言", null, jGi.b("muteall"), new Scr.Sw.L() { // from class: com.changliao.im.GroupScr.17
                @Override // com.changliao.im.Scr.Sw.L
                public void on(boolean z2) {
                    jGi.put("muteall", Boolean.valueOf(z2));
                    GroupScr.this.C.send(J.of("t", "c_gmuteall", "gid", GroupScr.this.gid, "on", Boolean.valueOf(z2)));
                }
            });
            opt(linearLayoutCsec4, "群介绍", jGi.s("intro").length() > 0 ? jGi.s("intro") : "未设置", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.18
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.ask("群介绍", "介绍一下这个群", jGi.s("intro"), true, 200, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.18.1
                        @Override // com.changliao.im.MainActivity.Str
                        public void ok(String str2) {
                            GroupScr.this.C.send(J.of("t", "c_gset", "gid", GroupScr.this.gid, "intro", str2));
                        }
                    });
                }
            });
            opt(linearLayoutCsec4, "群头像", "点击更换", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.19
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MyInfoScr.pickAvatar(GroupScr.this.a, GroupScr.this.gid);
                }
            });
            J jO = jGi.o("lvcfg");
            opt(linearLayoutCsec4, "群等级设置", (jO == null || !jO.has("show") || jO.b("show")) ? "自定义等级名称和积分" : "已关闭", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.20
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.push(new LevelsScr(GroupScr.this.gid));
                }
            });
        }
        LinearLayout linearLayoutCsec5 = csec(this.body);
        optSw(linearLayoutCsec5, "设为置顶", null, this.C.pins().contains(str), new Scr.Sw.L() { // from class: com.changliao.im.GroupScr.21
            @Override // com.changliao.im.Scr.Sw.L
            public void on(boolean z2) {
                GroupScr.this.C.setPin(str, z2);
            }
        });
        opt(linearLayoutCsec5, "隐藏会话", "从消息列表隐藏，有新消息时再出现", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.22
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.C.hide(str);
                GroupScr.this.toast("已隐藏，有新消息时会重新出现");
                GroupScr.this.a.popTo(HomeScr.class);
            }
        });
        optSw(linearLayoutCsec5, "消息免打扰", null, this.C.mutes.contains(str), new Scr.Sw.L() { // from class: com.changliao.im.GroupScr.23
            @Override // com.changliao.im.Scr.Sw.L
            public void on(boolean z2) {
                GroupScr.this.C.setMute(str, z2);
            }
        });
        LinearLayout linearLayoutCsec6 = csec(this.body);
        J jMe = me(jGi);
        opt(linearLayoutCsec6, "我在本群的昵称", jGi.s("mycard").length() > 0 ? jGi.s("mycard") : this.C.myNick(), true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.24
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.ask("我的本群昵称（留空则显示你的昵称）", "", jGi.s("mycard"), false, 16, new MainActivity.Str() { // from class: com.changliao.im.GroupScr.24.1
                    @Override // com.changliao.im.MainActivity.Str
                    public void ok(String str2) {
                        GroupScr.this.C.send(J.of("t", "c_gcard", "gid", GroupScr.this.gid, "card", str2));
                    }
                });
            }
        });
        opt(linearLayoutCsec6, "我的群等级", "LV" + Math.max(1L, jMe.l("lv")) + " " + jMe.s("lvn") + " · 积分 " + jMe.l("pts"), true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.25
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new LevelsScr(GroupScr.this.gid));
            }
        });
        opt(linearLayoutCsec6, "个性设置", "群头衔" + (jMe.s("title").length() > 0 ? "：" + jMe.s("title") : ""), true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.26
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.push(new TitlesScr(GroupScr.this.gid));
            }
        });
        LinearLayout linearLayoutCsec7 = csec(this.body);
        ((TextView) opt(linearLayoutCsec7, "删除聊天记录", "", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.27
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.this.a.confirm("删除聊天记录", "只删除你这里的记录，其他群成员不受影响。", "删除", true, new Runnable() { // from class: com.changliao.im.GroupScr.27.1
                    @Override // java.lang.Runnable
                    public void run() {
                        GroupScr.this.C.send(J.of("t", "c_clear", "conv", str));
                    }
                });
            }
        }).getChildAt(0)).setTextColor(Ui.RED);
        opt(linearLayoutCsec7, "举报群聊", "", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.28
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GroupScr.report(GroupScr.this.a, GroupScr.this.gid, false);
            }
        });
        if (this.C.isOwner && !jGi.b("banned") && !this.gid.equals(this.C.hall)) {
            opt(linearLayoutCsec7, "封禁该群", "", true, new View.OnClickListener() { // from class: com.changliao.im.GroupScr.29
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MiscScr.ReportsScr.pickBan(GroupScr.this.a, "封禁群「" + jGi.s("name") + "」多久？", "", new MiscScr.ReportsScr.BanCb() { // from class: com.changliao.im.GroupScr.29.1
                        @Override // com.changliao.im.MiscScr.ReportsScr.BanCb
                        public void ban(int i2, String str2) {
                            GroupScr.this.C.send(J.of("t", "c_rdeal", "gid", GroupScr.this.gid, "act", "ban", "mins", Integer.valueOf(i2), "why", str2));
                        }
                    });
                }
            });
        }
        LinearLayout linearLayoutCol2 = Ui.col(this.a);
        linearLayoutCol2.setPadding(Ui.dp(16.0f), Ui.dp(8.0f), Ui.dp(16.0f), Ui.dp(24.0f));
        if (jGi.b("hall") || this.C.isHall(str)) {
            linearLayoutCol2.addView(empty("奶龙聊天室是所有人的群，每个用户都会自动加入"));
        } else if (jGi.s("myrole").equals("owner")) {
            linearLayoutCol2.addView(Ui.btnGray(this.a, "转让群主", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.30
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.transferSheet(GroupScr.this.a, GroupScr.this.gid);
                }
            }));
            TextView textViewBtnGray = Ui.btnGray(this.a, "解散群聊", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.31
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.confirm("解散群聊", "解散后所有成员都会被移出，聊天记录也会删除，不能恢复。", "解散", true, new Runnable() { // from class: com.changliao.im.GroupScr.31.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GroupScr.this.C.send(J.of("t", "c_gdismiss", "gid", GroupScr.this.gid));
                        }
                    });
                }
            });
            textViewBtnGray.setTextColor(Ui.RED);
            linearLayoutCol2.addView(textViewBtnGray, Ui.lpm(-1, -2, 0, 12, 0, 0));
        } else {
            TextView textViewBtnGray2 = Ui.btnGray(this.a, "退出群聊", new View.OnClickListener() { // from class: com.changliao.im.GroupScr.32
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    GroupScr.this.a.confirm("退出群聊", "确定退出「" + jGi.s("name") + "」吗？", "退出", true, new Runnable() { // from class: com.changliao.im.GroupScr.32.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GroupScr.this.C.send(J.of("t", "c_gleave", "gid", GroupScr.this.gid));
                            GroupScr.this.C.convs.remove(str);
                            GroupScr.this.C.groups.remove(GroupScr.this.gid);
                            GroupScr.this.C.emit("convs", null);
                            GroupScr.this.a.popTo(HomeScr.class);
                        }
                    });
                }
            });
            textViewBtnGray2.setTextColor(Ui.RED);
            linearLayoutCol2.addView(textViewBtnGray2);
        }
        this.body.addView(linearLayoutCol2);
    }
}
